#!/usr/bin/env bash
# ================================================================
#  KREM Headcount Planner - One-click launcher (Mac/Linux)
# ================================================================
set -e
cd "$(dirname "$0")"

echo
echo "============================================"
echo "  Starting KREM Headcount Planner..."
echo "============================================"
echo

if [ ! -d backend/.venv ]; then
    echo "[ERROR] Python virtual environment not found."
    echo "        Run ./install.sh first."
    exit 1
fi
if [ ! -d frontend/node_modules ]; then
    echo "[ERROR] Frontend dependencies not installed."
    echo "        Run ./install.sh first."
    exit 1
fi

# Check MongoDB port 27017
if ! (echo > /dev/tcp/127.0.0.1/27017) >/dev/null 2>&1; then
    echo "[WARN] MongoDB is not reachable on port 27017."
    echo "       Start it with:"
    echo "         macOS (brew): brew services start mongodb-community"
    echo "         Linux (systemd): sudo systemctl start mongod"
    read -p "Press ENTER to continue anyway..."
else
    echo "[OK] MongoDB is running"
fi

# Cleanup function to stop background processes on exit
cleanup() {
    echo
    echo "Stopping backend and frontend..."
    kill "$BACKEND_PID" 2>/dev/null || true
    kill "$FRONTEND_PID" 2>/dev/null || true
    wait 2>/dev/null || true
    exit 0
}
trap cleanup INT TERM

# Start backend
echo "Launching backend (port 8001)..."
(
    cd backend
    source .venv/bin/activate
    uvicorn server:app --host 0.0.0.0 --port 8001 --reload
) &
BACKEND_PID=$!

# Wait for backend to bind
sleep 4

# Start frontend
echo "Launching frontend (port 3000)..."
(
    cd frontend
    yarn start
) &
FRONTEND_PID=$!

# Open browser after a delay (best effort)
sleep 6
if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:3000" >/dev/null 2>&1 &
elif command -v open >/dev/null 2>&1; then
    open "http://localhost:3000" >/dev/null 2>&1 &
fi

echo
echo "============================================"
echo "  Running!"
echo "============================================"
echo "  Backend:  http://localhost:8001/api/"
echo "  Frontend: http://localhost:3000"
echo
echo "Press Ctrl+C to stop both processes."
echo "============================================"

# Wait for both
wait
