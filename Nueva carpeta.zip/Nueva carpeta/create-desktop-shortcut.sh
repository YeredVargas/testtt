#!/usr/bin/env bash
# ================================================================
#  KREM Headcount Planner - Create Desktop Shortcut (Linux only)
#  Creates ~/Desktop/krem-planner.desktop pointing at start.sh
#  with the custom PNG icon assigned.
#  (macOS users: use Automator or just drag start.sh to the Dock.)
# ================================================================
set -e
cd "$(dirname "$0")"
APP_DIR="$(pwd)"

if [ ! -f "$APP_DIR/start.sh" ]; then
    echo "[ERROR] start.sh not found next to this script."
    exit 1
fi
if [ ! -f "$APP_DIR/assets/krem-planner.png" ]; then
    echo "[ERROR] assets/krem-planner.png not found."
    exit 1
fi

DESKTOP_DIR="$HOME/Desktop"
mkdir -p "$DESKTOP_DIR"
SHORTCUT="$DESKTOP_DIR/krem-planner.desktop"

cat > "$SHORTCUT" <<EOF
[Desktop Entry]
Type=Application
Name=KREM Planner
Comment=KREM Plant Headcount Planner
Exec="$APP_DIR/start.sh"
Icon=$APP_DIR/assets/krem-planner.png
Terminal=true
Categories=Utility;Office;
EOF

chmod +x "$SHORTCUT"

if command -v gio >/dev/null 2>&1; then
    gio set "$SHORTCUT" metadata::trusted true 2>/dev/null || true
fi

echo
echo "============================================"
echo "  Shortcut created: $SHORTCUT"
echo "============================================"
echo
echo "If your desktop asks to 'trust' the launcher on first click,"
echo "right-click it -> Properties -> Permissions -> Allow executing."
echo
