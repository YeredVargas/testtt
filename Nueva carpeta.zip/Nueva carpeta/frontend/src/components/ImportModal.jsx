import React, { useState, useCallback } from "react";
import axios from "axios";

export default function ImportModal({ open, onClose, endpoint, title, onSuccess }) {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const onDrop = useCallback((e) => {
    e.preventDefault();
    const f = e.dataTransfer.files?.[0];
    if (f) setFile(f);
  }, []);

  const onFileChange = (e) => {
    const f = e.target.files?.[0];
    if (f) setFile(f);
  };

  const upload = async () => {
    if (!file) return;
    setLoading(true);
    setResult(null);
    const fd = new FormData();
    fd.append("file", file);
    try {
      // Let the browser set the Content-Type (including boundary) for FormData
      const res = await axios.post(endpoint, fd);
      setResult(res.data);
      if (!res.data?.error) {
        // notify parent of success
        onSuccess && onSuccess(res.data);
        // close modal after success
        onClose && onClose();
      }
    } catch (err) {
      setResult({ error: err?.response?.data || err.message });
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-md shadow-lg w-full max-w-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="text-slate-500">Close</button>
        </div>
        <div
          onDrop={onDrop}
          onDragOver={(e) => e.preventDefault()}
          className="border-2 border-dashed border-slate-200 rounded-md p-6 text-center"
        >
          {file ? (
            <div>{file.name}</div>
          ) : (
            <div>Drag & drop an .xlsx file here, or click to select</div>
          )}
          <input type="file" accept=".xlsx,.xlsm" onChange={onFileChange} className="mt-3" />
        </div>
        <div className="flex items-center gap-2 mt-4">
          <button onClick={upload} disabled={!file || loading} className="bg-blue-700 text-white px-3 py-1 rounded">
            {loading ? "Uploading..." : "Upload"}
          </button>
          <button onClick={onClose} className="px-3 py-1">Cancel</button>
        </div>
        {result && (
          <div className={`mt-4 p-3 rounded text-sm font-medium ${result.error ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>
            {result.error ? (
              <>Error: {typeof result.error === "string" ? result.error : result.error.detail || JSON.stringify(result.error)}</>
            ) : (
              <>
                <div>{result.message || `Se insertaron ${result.inserted || 0} registros correctamente.`}</div>
                {(result.created !== undefined || result.updated !== undefined || result.skipped !== undefined) && (
                  <div className="mt-2 text-xs font-normal space-y-1">
                    {result.created !== undefined && <div>Creados: <span className="font-semibold">{result.created}</span></div>}
                    {result.updated !== undefined && <div>Actualizados: <span className="font-semibold">{result.updated}</span></div>}
                    {result.skipped !== undefined && <div>Omitidos: <span className="font-semibold">{result.skipped}</span></div>}
                    {result.processed !== undefined && <div>Leidos: <span className="font-semibold">{result.processed}</span></div>}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
