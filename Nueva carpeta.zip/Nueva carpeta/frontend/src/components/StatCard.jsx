export default function StatCard({ label, value, delta, accent = "blue", icon: Icon, testId }) {
  const accents = {
    blue:   "border-l-blue-600",
    indigo: "border-l-indigo-600",
    orange: "border-l-orange-600",
    slate:  "border-l-slate-500",
    green:  "border-l-emerald-600",
  };
  return (
    <div
      className={`bg-white border border-slate-200 border-l-4 ${accents[accent]} rounded-md p-4 transition-transform duration-150 hover:-translate-y-[1px]`}
      data-testid={testId}
    >
      <div className="flex items-center justify-between">
        <div className="text-overline">{label}</div>
        {Icon && <Icon className="w-4 h-4 text-slate-400" />}
      </div>
      <div className="font-heading text-3xl font-bold text-slate-900 mt-2 tabular-nums">{value}</div>
      {delta && <div className="text-xs text-slate-500 mt-1">{delta}</div>}
    </div>
  );
}
