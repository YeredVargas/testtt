import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";

import Layout from "@/components/Layout";
import DashboardPage from "@/pages/Dashboard";
import MatrixPage from "@/pages/Matrix";
import PeoplePage from "@/pages/People";
import PositionsPage from "@/pages/Positions";
import MilestonesPage from "@/pages/Milestones";
import ReportsPage from "@/pages/Reports";
import LevelsPage from "@/pages/Levels";
import OrgChartPage from "@/pages/OrgChart";

export default function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/matrix" element={<MatrixPage />} />
            <Route path="/people" element={<PeoplePage />} />
            <Route path="/positions" element={<PositionsPage />} />
            <Route path="/levels" element={<LevelsPage />} />
            <Route path="/orgchart" element={<OrgChartPage />} />
            <Route path="/milestones" element={<MilestonesPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
      <Toaster position="top-right" richColors closeButton />
    </div>
  );
}
