import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { api, endpoints } from "@/lib/api";
import ImportModal from "@/components/ImportModal";

export default function LevelsPage() {
  const [levels, setLevels] = useState([]);
  const [importOpen, setImportOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [edit, setEdit] = useState(null);
  const [form, setForm] = useState({ name: "", position_name: "" });

  async function load() {
    const res = await api.get(endpoints.levels);
    setLevels(res.data || []);
  }
  useEffect(() => { load(); }, []);

  function openCreate() {
    setEdit(null);
    setForm({ name: "", position_name: "" });
    setDialogOpen(true);
  }
  function openEdit(lv) {
    setEdit(lv);
    setForm({ name: lv.name, position_name: lv.position_name || "" });
    setDialogOpen(true);
  }

  async function submit(e) {
    e.preventDefault();
    try {
      if (edit) {
        await api.patch(`${endpoints.levels}/${edit.id}`, form);
      } else {
        await api.post(endpoints.levels, form);
      }
      toast.success("Saved");
      setDialogOpen(false);
      await load();
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Save failed");
    }
  }

  async function remove(lv) {
    if (!confirm(`Delete level ${lv.name}?`)) return;
    try {
      await api.delete(`${endpoints.levels}/${lv.id}`);
      toast.success("Deleted");
      await load();
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Delete failed");
    }
  }

  return (
    <>
      <PageHeader
        title="Levels"
        subtitle="Manage position levels."
        actions={
          <div className="flex items-center">
            <Button onClick={() => setImportOpen(true)} className="mr-2">Importar Niveles</Button>
            <Button onClick={openCreate}><Plus className="w-4 h-4 mr-1"/> New Level</Button>
          </div>
        }
      />

      <div className="px-6 lg:px-8 py-6">
        <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr className="text-left">
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Position</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Name</th>
                <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Created</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {levels.map((lv) => (
                <tr key={lv.id} className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer" onClick={() => openEdit(lv)}>
                  <td className="px-4 py-3 text-slate-700">{lv.position_name || "-"}</td>
                  <td className="px-4 py-3 font-medium text-slate-900">{lv.name}</td>
                  <td className="px-4 py-3 text-slate-500 text-sm">{lv.created_at ? new Date(lv.created_at).toLocaleString() : "-"}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={(e) => { e.stopPropagation(); remove(lv); }} className="text-slate-400 hover:text-red-600"><Trash2 className="w-4 h-4"/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ImportModal
        open={importOpen}
        onClose={() => setImportOpen(false)}
        endpoint={`${process.env.REACT_APP_BACKEND_URL}/api/levels/import`}
        title="Importar Niveles - Digitalización"
        onSuccess={(res) => {
          // show toast including the required word Digitalización
          toast.success(`Digitalización completada: Niveles importados con éxito (${res.inserted} insertados)`);
          load();
        }}
      />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{edit ? "Edit Level" : "New Level"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            {edit && (
              <div className="grid grid-cols-1 gap-3">
                <div>
                  <Label>Created</Label>
                  <div className="text-sm text-slate-500">{edit.created_at ? new Date(edit.created_at).toLocaleString() : "-"}</div>
                </div>
              </div>
            )}
            <div>
              <Label>Position</Label>
              <Input value={form.position_name || ""} onChange={(e) => setForm({ ...form, position_name: e.target.value })} />
            </div>
            <div>
              <Label>Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-700 hover:bg-blue-800">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
