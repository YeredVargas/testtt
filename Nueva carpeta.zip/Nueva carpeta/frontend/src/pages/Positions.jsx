import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, Briefcase, Layers } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import { api, endpoints } from "@/lib/api";
import ImportModal from "@/components/ImportModal";

const CLASSES = ["DL", "IL", "DLNUN"];
const SHIFTS = ["1st", "2nd", "3rd", "N/A"];
const STATUS_OPTIONS = ["hired", "vacant", "tbd", "planned", "temp", "transfer"];

export default function PositionsPage() {
  const [importOpen, setImportOpen] = useState(false);
  const [areas, setAreas] = useState([]);
  const [positions, setPositions] = useState([]);
  const [tab, setTab] = useState("positions");

  const [posDialog, setPosDialog] = useState(false);
  const [posEdit, setPosEdit] = useState(null);
  const [posForm, setPosForm] = useState({ name: "", area_id: "", classification: "DL", shift: "1st", status: "planned", level: "__none", centro_costos: "" });
  const [levels, setLevels] = useState([]);

  const [areaDialog, setAreaDialog] = useState(false);
  const [areaEdit, setAreaEdit] = useState(null);
  const [areaForm, setAreaForm] = useState({ name: "", code: "", description: "" });

  async function load() {
    const [a, p, l] = await Promise.all([api.get(endpoints.areas), api.get(endpoints.positions), api.get(endpoints.levels)]);
    setAreas(a.data);
    setPositions(p.data);
    setLevels(l.data || []);
  }
  useEffect(() => { load(); }, []);

  const areaById = useMemo(() => Object.fromEntries(areas.map((a) => [a.id, a])), [areas]);
  const byArea = useMemo(() => {
    const m = new Map();
    positions.forEach((p) => {
      if (!m.has(p.area_id)) m.set(p.area_id, []);
      m.get(p.area_id).push(p);
    });
    return m;
  }, [positions]);

  function openPosCreate() {
    setPosEdit(null);
    setPosForm({ name: "", area_id: areas[0]?.id || "", classification: "DL", shift: "1st", status: "planned", level: levels[0]?.id || "__none", centro_costos: "" });
    setPosDialog(true);
  }
  function openPosEdit(p) {
    setPosEdit(p);
    setPosForm({ name: p.name, area_id: p.area_id, classification: p.classification, shift: p.shift || "1st", status: p.status || "planned", level: p.level || "__none", centro_costos: p.centro_costos || "" });
    setPosDialog(true);
  }
  async function submitPos(e) {
    e.preventDefault();
    try {
      const payload = { ...posForm };
      if (payload.level === "__none") {
        // remove empty sentinel so backend receives no level
        delete payload.level;
      }
      if (!payload.centro_costos?.trim()) payload.centro_costos = null;
      if (posEdit) {
        await api.patch(`${endpoints.positions}/${posEdit.id}`, payload);
      } else {
        await api.post(endpoints.positions, payload);
      }
      toast.success("Saved");
      setPosDialog(false);
      await load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Save failed");
    }
  }
  async function removePos(p) {
    if (!confirm(`Delete position ${p.name}? Its planning cells will also be removed.`)) return;
    try {
      await api.delete(`${endpoints.positions}/${p.id}`);
      toast.success("Deleted");
      await load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Delete failed");
    }
  }

  function openAreaCreate() {
    setAreaEdit(null);
    setAreaForm({ name: "", code: "", description: "" });
    setAreaDialog(true);
  }
  function openAreaEdit(a) {
    setAreaEdit(a);
    setAreaForm({ name: a.name, code: a.code || "", description: a.description || "" });
    setAreaDialog(true);
  }
  async function submitArea(e) {
    e.preventDefault();
    try {
      if (areaEdit) {
        await api.patch(`${endpoints.areas}/${areaEdit.id}`, areaForm);
      } else {
        await api.post(endpoints.areas, areaForm);
      }
      toast.success("Saved");
      setAreaDialog(false);
      await load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Save failed");
    }
  }
  async function removeArea(a) {
    if (!confirm(`Delete area ${a.name}?`)) return;
    try {
      await api.delete(`${endpoints.areas}/${a.id}`);
      toast.success("Deleted");
      await load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Delete failed");
    }
  }

  return (
    <>
      <PageHeader
        title="Positions & Areas"
        subtitle="Configure the plant structure. Directs = Operators (DL), Indirects (IL), and Non-Union Direct (DLNUN)."
        testId="positions-header"
        actions={
          <Button onClick={() => setImportOpen(true)} className="mr-2">Import</Button>
        }
      />

      <div className="px-6 lg:px-8 py-6">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList data-testid="positions-tabs" className="bg-white border border-slate-200">
            <TabsTrigger value="positions" data-testid="tab-positions">
              <Briefcase className="w-4 h-4 mr-1.5" />
              Positions
            </TabsTrigger>
            <TabsTrigger value="areas" data-testid="tab-areas">
              <Layers className="w-4 h-4 mr-1.5" />
              Areas
            </TabsTrigger>
          </TabsList>

          <TabsContent value="positions" className="mt-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-slate-500">
                {positions.length} positions across {areas.length} areas
              </div>
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  data-testid="clear-positions-btn"
                  className="border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800"
                  onClick={async () => {
                    if (!positions.length) return;
                    if (!confirm("Delete all existing positions? This will also remove all planning cells and unassign people from their positions.")) return;
                    try {
                      await api.delete(endpoints.positionsBulkDelete);
                      toast.success("All positions deleted");
                      await load();
                    } catch (e) {
                      toast.error(e?.response?.data?.detail || "Bulk delete failed");
                    }
                  }}
                  disabled={!positions.length}
                >
                  Clear Positions
                </Button>
                <Button data-testid="add-position-btn" onClick={openPosCreate} className="bg-blue-700 hover:bg-blue-800">
                  <Plus className="w-4 h-4 mr-1" /> Add Position
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              {areas.map((a) => {
                const list = byArea.get(a.id) || [];
                return (
                  <div key={a.id} className="bg-white border border-slate-200 rounded-md">
                    <div className="px-4 py-2.5 bg-blue-50 border-b border-blue-100 flex items-center justify-between">
                      <div className="font-heading font-semibold text-sm text-blue-900">
                        {a.name} <span className="text-blue-600/70 font-normal">· {a.code}</span>
                      </div>
                      <div className="text-xs text-blue-700">{list.length} positions</div>
                    </div>
                    {list.length === 0 ? (
                      <div className="px-4 py-6 text-sm text-slate-400 text-center">No positions</div>
                    ) : (
                      <table className="w-full text-sm">
                        <tbody>
                          {list.map((p) => (
                            <tr
                              key={p.id}
                              onClick={() => openPosEdit(p)}
                              className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors duration-150"
                              data-testid={`pos-row-${p.id}`}
                            >
                              <td className="px-4 py-2 font-medium text-slate-900 w-[42%]">{p.name}</td>
                              <td className="px-4 py-2">
                                <span className={`classification-badge class-${p.classification}`}>{p.classification}</span>
                              </td>
                              <td className="px-4 py-2 text-slate-500">Shift {p.shift}</td>
                              <td className="px-4 py-2 text-slate-500 text-xs">CC: {p.centro_costos || "—"}</td>
                              <td className="px-4 py-2 text-right">
                                <button
                                  data-testid={`delete-position-${p.id}`}
                                  onClick={(e) => { e.stopPropagation(); removePos(p); }}
                                  className="text-slate-400 hover:text-red-600 transition-colors duration-150"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="areas" className="mt-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-slate-500">{areas.length} areas</div>
              <Button data-testid="add-area-btn" onClick={openAreaCreate} className="bg-blue-700 hover:bg-blue-800">
                <Plus className="w-4 h-4 mr-1" /> Add Area
              </Button>
            </div>
            <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr className="text-left">
                    <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Name</th>
                    <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Code</th>
                    <th className="px-4 py-3 font-heading font-semibold text-xs uppercase tracking-wider text-slate-500">Description</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {areas.map((a) => (
                    <tr
                      key={a.id}
                      onClick={() => openAreaEdit(a)}
                      className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors duration-150"
                      data-testid={`area-row-${a.id}`}
                    >
                      <td className="px-4 py-2.5 font-medium text-slate-900">{a.name}</td>
                      <td className="px-4 py-2.5 text-slate-600 font-mono text-xs">{a.code}</td>
                      <td className="px-4 py-2.5 text-slate-500">{a.description}</td>
                      <td className="px-4 py-2.5 text-right">
                        <button
                          data-testid={`delete-area-${a.id}`}
                          onClick={(e) => { e.stopPropagation(); removeArea(a); }}
                          className="text-slate-400 hover:text-red-600 transition-colors duration-150"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Position dialog */}
      <Dialog open={posDialog} onOpenChange={setPosDialog}>
        <DialogContent data-testid="position-dialog">
          <DialogHeader>
            <DialogTitle>{posEdit ? "Edit position" : "Add position"}</DialogTitle>
            <DialogDescription>Name matches the label in the matrix (e.g. Operator (SMT 1)).</DialogDescription>
          </DialogHeader>
          <form onSubmit={submitPos} className="space-y-3">
            <div>
              <Label>Name</Label>
              <Input
                data-testid="form-pos-name"
                value={posForm.name}
                onChange={(e) => setPosForm({ ...posForm, name: e.target.value })}
                required
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label>Area</Label>
                <Select value={posForm.area_id} onValueChange={(v) => setPosForm({ ...posForm, area_id: v })}>
                  <SelectTrigger data-testid="form-pos-area"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {areas.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Classification</Label>
                <Select value={posForm.classification} onValueChange={(v) => setPosForm({ ...posForm, classification: v })}>
                  <SelectTrigger data-testid="form-pos-class"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CLASSES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Shift</Label>
                <Select value={posForm.shift} onValueChange={(v) => setPosForm({ ...posForm, shift: v })}>
                  <SelectTrigger data-testid="form-pos-shift"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SHIFTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Status</Label>
                <Select value={posForm.status} onValueChange={(v) => setPosForm({ ...posForm, status: v })}>
                  <SelectTrigger data-testid="form-pos-status"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {STATUS_OPTIONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Level</Label>
                <Select value={posForm.level} onValueChange={(v) => setPosForm({ ...posForm, level: v })}>
                  <SelectTrigger data-testid="form-pos-level"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none">(none)</SelectItem>
                    {levels.map((lv) => <SelectItem key={lv.id} value={lv.id}>{lv.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Centro de costos</Label>
              <Input
                data-testid="form-pos-centro-costos"
                value={posForm.centro_costos}
                onChange={(e) => setPosForm({ ...posForm, centro_costos: e.target.value })}
                placeholder="Ej. 4100-SMT"
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setPosDialog(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-700 hover:bg-blue-800" data-testid="save-position-btn">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Area dialog */}
      <Dialog open={areaDialog} onOpenChange={setAreaDialog}>
        <DialogContent data-testid="area-dialog">
          <DialogHeader>
            <DialogTitle>{areaEdit ? "Edit area" : "Add area"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={submitArea} className="space-y-3">
            <div>
              <Label>Name</Label>
              <Input
                data-testid="form-area-name"
                value={areaForm.name}
                onChange={(e) => setAreaForm({ ...areaForm, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label>Code</Label>
              <Input
                data-testid="form-area-code"
                value={areaForm.code}
                onChange={(e) => setAreaForm({ ...areaForm, code: e.target.value })}
              />
            </div>
            <div>
              <Label>Description</Label>
              <Input
                data-testid="form-area-desc"
                value={areaForm.description}
                onChange={(e) => setAreaForm({ ...areaForm, description: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setAreaDialog(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-700 hover:bg-blue-800" data-testid="save-area-btn">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Import modal */}
      <ImportModal
        open={importOpen}
        onClose={() => setImportOpen(false)}
        endpoint={`${process.env.REACT_APP_BACKEND_URL}/api/positions/import`}
        title="Importar Positions - Digitalización"
      />
    </>
  );
}
