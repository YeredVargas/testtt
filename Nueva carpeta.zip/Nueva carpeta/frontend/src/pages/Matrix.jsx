import { Fragment, memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { RotateCcw, ChevronDown, ChevronRight, Users } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverAnchor, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, endpoints } from "@/lib/api";
import { generateFiscalYear, isoWeekOfDate } from "@/lib/cw";
import { cn } from "@/lib/utils";

const STATUSES = ["hired", "vacant", "tbd", "planned", "temp", "transfer"];

function MatrixCell({
  position,
  week,
  weekIndex,
  initial,
  onSave,
  onToggleAssignment,
  people,
  selectedPersonIds,
  assignmentsEnabled,
  isActive,
  isPanelOpen,
  onSelect,
  onPanelOpenChange,
  onUpdatePersonStatus,
}) {
  const [manualVal, setManualVal] = useState(String(initial ?? 0));
  const inputRef = useRef(null);
  useEffect(() => { setManualVal(String(initial ?? 0)); }, [initial]);
  useEffect(() => {
    if (!isActive || !inputRef.current) return;
    inputRef.current.focus();
    inputRef.current.select();
  }, [isActive]);

  const assignedPeople = people || [];
  const selectedIds = selectedPersonIds || [];
  const plannedCount = Number(initial ?? 0);
  const selectedCount = selectedIds.length;
  const pendingCount = Math.max(plannedCount - selectedCount, 0);
  const isPeopleCovered = plannedCount > 0 && selectedCount > 0 && plannedCount === selectedCount;
  const isMixedPending = plannedCount > 0 && selectedCount > 0 && pendingCount > 0;
  const isPendingOnly = plannedCount > 0 && selectedCount === 0;

  const stateLabel = isPeopleCovered
    ? "Cubierta con personas"
    : isMixedPending
      ? "Mixta con pendientes"
      : isPendingOnly
        ? "Planeada sin personas"
        : "Sin captura";

  const shellClassName = cn(
    "matrix-cell-shell group border text-slate-900",
    isActive
      ? "border-blue-500 ring-2 ring-blue-200"
      : "border-transparent focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-200",
    isPeopleCovered && "bg-blue-100",
    isMixedPending && "bg-amber-100",
    isPendingOnly && "bg-violet-100",
    plannedCount === 0 && "bg-transparent hover:bg-slate-100",
  );

  function togglePerson(personId) {
    onToggleAssignment(weekIndex, personId, !selectedIds.includes(personId));
  }

  function commitManualValue() {
    const sanitized = manualVal.replace(/[^0-9]/g, "");
    const next = sanitized === "" ? 0 : parseInt(sanitized, 10);
    if (Number.isNaN(next)) return;
    if (next < selectedCount) {
      setManualVal(String(plannedCount));
      toast.error("Digitalizacion: el total planeado no puede quedar debajo de las personas ligadas en esta celda.");
      return;
    }
    setManualVal(String(next));
    if (next !== plannedCount) onSave(next);
  }

  return (
    <Popover open={isPanelOpen} onOpenChange={onPanelOpenChange}>
      <PopoverAnchor asChild>
        <div
          className={shellClassName}
          data-testid={`cell-shell-${position.id}-${week.key}`}
          onClick={() => onSelect()}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (/^[0-9]$/.test(e.key)) {
              e.preventDefault();
              setManualVal(e.key);
              onSelect();
              return;
            }
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onSelect();
            }
          }}
        >
          {isActive ? (
            <>
              <Input
                ref={inputRef}
                value={manualVal}
                inputMode="numeric"
                onClick={(e) => e.stopPropagation()}
                onChange={(e) => setManualVal(e.target.value.replace(/[^0-9]/g, ""))}
                onBlur={commitManualValue}
                onKeyDown={(e) => {
                  e.stopPropagation();
                  if (e.key === "Enter") {
                    e.preventDefault();
                    commitManualValue();
                    e.currentTarget.blur();
                  }
                  if (e.key === "Escape") {
                    e.preventDefault();
                    setManualVal(String(plannedCount));
                    e.currentTarget.blur();
                  }
                }}
                className="h-6 w-10 border-0 bg-transparent px-0 text-center font-mono text-xs shadow-none focus-visible:ring-0"
                aria-label={`Planned count for ${position.name} ${week.key}`}
              />
              <PopoverTrigger asChild>
                <button
                  type="button"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex h-5 w-5 items-center justify-center rounded-sm text-slate-500 transition-colors hover:bg-white/70 hover:text-slate-700"
                  aria-label={`Open people panel for ${position.name} ${week.key}`}
                >
                  <Users className="h-3.5 w-3.5" />
                </button>
              </PopoverTrigger>
            </>
          ) : (
            <span className="matrix-cell-value" data-testid={`cell-${position.id}-${week.key}`}>
              {plannedCount || ""}
            </span>
          )}
        </div>
      </PopoverAnchor>
      <PopoverContent
        align="start"
        side="right"
        sideOffset={10}
        className="w-[28rem] border-slate-200 bg-white p-0"
      >
        <div className="border-b border-slate-200 px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="rounded-md bg-blue-100 p-2 text-blue-700">
              <Users className="h-4 w-4" />
            </div>
            <div className="min-w-0 truncate font-heading text-sm font-semibold text-slate-900">{position.name}</div>
          </div>
        </div>

        <div className="max-h-80 overflow-y-auto px-4 py-3">
          <div className="mb-3 inline-flex rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-[11px] font-medium text-slate-700">
            {stateLabel}
          </div>

          {(assignedPeople.length > 0 || pendingCount > 0) && (
            <div className="space-y-2">
              {!assignmentsEnabled && (
                <div className="rounded-md bg-amber-50 px-3 py-2 text-xs text-amber-700">
                  Reinicia el servicio para habilitar la seleccion semanal de personas.
                </div>
              )}
              {assignmentsEnabled && assignedPeople.length > 0 ? (
                assignedPeople.map((person) => {
                  const checked = selectedIds.includes(person.id);
                  return (
                    <label key={person.id} className={`block cursor-pointer rounded-md border px-3 py-2.5 ${checked ? "border-blue-300 bg-blue-50" : "border-slate-200"}`}>
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          className="mt-1 h-4 w-4 accent-blue-600"
                          checked={checked}
                          onChange={() => togglePerson(person.id)}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="break-words text-xs font-medium leading-4 text-slate-900">{person.name || "TBD"}</div>
                        </div>
                        <div className="w-[124px] shrink-0" onClick={(event) => event.stopPropagation()}>
                          <Select value={person.status || "planned"} onValueChange={(value) => onUpdatePersonStatus(person.id, value)}>
                            <SelectTrigger className="h-8 text-xs" aria-label={`Status for ${person.name || "TBD"}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {STATUSES.map((status) => (
                                <SelectItem key={status} value={status}>{status}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </label>
                  );
                })
              ) : assignedPeople.length > 0 ? (
                assignedPeople.map((person) => (
                  <div key={person.id} className="rounded-md border border-slate-200 px-3 py-2.5 text-sm font-medium text-slate-900">
                    {person.name || "TBD"}
                  </div>
                ))
              ) : null}

              {assignedPeople.length === 0 && pendingCount > 0 && (
                <div className="rounded-md border border-dashed border-slate-200 px-3 py-4 text-center text-xs text-slate-400">
                  Sin personas disponibles en esta posicion.
                </div>
              )}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

const MemoMatrixCell = memo(MatrixCell, (prev, next) => {
  if (prev.initial !== next.initial) return false;
  if (prev.week.key !== next.week.key) return false;
  if (prev.weekIndex !== next.weekIndex) return false;
  if (prev.position.id !== next.position.id) return false;
  if (prev.assignmentsEnabled !== next.assignmentsEnabled) return false;
  if (prev.isActive !== next.isActive) return false;
  if (prev.isPanelOpen !== next.isPanelOpen) return false;

  const prevSelected = prev.selectedPersonIds || [];
  const nextSelected = next.selectedPersonIds || [];
  if (prevSelected.length !== nextSelected.length) return false;
  for (let index = 0; index < prevSelected.length; index += 1) {
    if (prevSelected[index] !== nextSelected[index]) return false;
  }

  const prevPeople = prev.people || [];
  const nextPeople = next.people || [];
  if (prevPeople.length !== nextPeople.length) return false;
  for (let index = 0; index < prevPeople.length; index += 1) {
    const prevPerson = prevPeople[index];
    const nextPerson = nextPeople[index];
    if (
      prevPerson?.id !== nextPerson?.id ||
      prevPerson?.name !== nextPerson?.name ||
      prevPerson?.status !== nextPerson?.status
    ) {
      return false;
    }
  }

  return true;
});

export default function MatrixPage() {
  const [areas, setAreas] = useState([]);
  const [positions, setPositions] = useState([]);
  const [people, setPeople] = useState([]);
  const [plan, setPlan] = useState({});
  const [assignments, setAssignments] = useState({});
  const [milestones, setMilestones] = useState([]);
  const [startYear, setStartYear] = useState(2026);
  const [startCw, setStartCw] = useState(27);
  const [collapsed, setCollapsed] = useState({});
  const [classFilter, setClassFilter] = useState("all");
  const [saving, setSaving] = useState(false);
  const [assignmentsEnabled, setAssignmentsEnabled] = useState(true);
  const [activeCell, setActiveCell] = useState(null);
  const [panelCell, setPanelCell] = useState(null);
  const scrollRef = useRef(null);

  const weeks = useMemo(() => generateFiscalYear(startYear, startCw, 52), [startYear, startCw]);
  const planRef = useRef(plan);
  const assignmentsRef = useRef(assignments);
  const weeksRef = useRef(weeks);
  const peopleRef = useRef(people);
  const currentWeekKey = useMemo(() => {
    const today = new Date();
    const localDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    const { year, cw } = isoWeekOfDate(localDate);
    return `${year}-CW${String(cw).padStart(2, "0")}`;
  }, []);

  async function load() {
    let assignmentsSupported = true;
    const assignmentsRequest = api.get(endpoints.headcountAssignments).catch((error) => {
      if (error?.response?.status === 404) {
        assignmentsSupported = false;
        return { data: {} };
      }
      throw error;
    });

    const [a, p, ppl, hc, asg, ms] = await Promise.all([
      api.get(endpoints.areas),
      api.get(endpoints.positions),
      api.get(endpoints.people),
      api.get(endpoints.headcount),
      assignmentsRequest,
      api.get(endpoints.milestones),
    ]);
    setAssignmentsEnabled(assignmentsSupported);
    setAreas(a.data);
    setPositions(p.data);
    setPeople(ppl.data);
    setPlan(hc.data);
    setAssignments(asg.data);
    setMilestones(ms.data);
  }
  useEffect(() => { load(); }, []);
  useEffect(() => { planRef.current = plan; }, [plan]);
  useEffect(() => { assignmentsRef.current = assignments; }, [assignments]);
  useEffect(() => { weeksRef.current = weeks; }, [weeks]);
  useEffect(() => { peopleRef.current = people; }, [people]);

  const areaById = useMemo(() => Object.fromEntries(areas.map((a) => [a.id, a])), [areas]);
  const msByKey = useMemo(() => milestones.reduce((acc, milestone) => {
    const key = `${milestone.year}-CW${String(milestone.cw).padStart(2, "0")}`;
    if (!acc[key]) acc[key] = [];
    acc[key].push(milestone);
    return acc;
  }, {}), [milestones]);
  const phaseLegend = useMemo(() => {
    const grouped = new Map();
    milestones.forEach((milestone) => {
      const key = milestone.phase_id || `legacy-${milestone.id}`;
      if (!grouped.has(key)) {
        grouped.set(key, {
          id: key,
          name: milestone.phase_name || milestone.name,
          color: milestone.color || "#64748B",
          milestones: [],
          isLegacy: !milestone.phase_id,
        });
      }
      grouped.get(key).milestones.push(milestone);
    });
    return Array.from(grouped.values())
      .map((phase) => ({
        ...phase,
        milestoneCount: phase.milestones.length,
        milestones: phase.milestones.sort((a, b) => {
          if (a.year !== b.year) return a.year - b.year;
          if (a.cw !== b.cw) return a.cw - b.cw;
          return a.name.localeCompare(b.name);
        }),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [milestones]);

  const filteredPositions = useMemo(() => {
    let base = positions;
    if (classFilter !== "all") base = base.filter((p) => p.classification === classFilter);
    return base;
  }, [positions, classFilter]);

  const grouped = useMemo(() => {
    const map = new Map();
    filteredPositions.forEach((p) => {
      if (!map.has(p.area_id)) map.set(p.area_id, []);
      map.get(p.area_id).push(p);
    });
    return Array.from(map.entries()).map(([aid, list]) => ({
      area: areaById[aid] || { name: "Unknown", id: aid },
      positions: list,
    }));
  }, [filteredPositions, areaById]);

  const peopleByPosition = useMemo(() => {
    const map = {};
    people.forEach((person) => {
      if (!person.position_id) return;
      if (!map[person.position_id]) map[person.position_id] = [];
      map[person.position_id].push(person);
    });
    return map;
  }, [people]);

  useEffect(() => {
    if (!activeCell) return;
    const visiblePositionIds = new Set(filteredPositions.map((position) => position.id));
    if (!visiblePositionIds.has(activeCell.positionId) || collapsed[activeCell.areaId]) {
      setActiveCell(null);
    }
  }, [activeCell, collapsed, filteredPositions]);

  useEffect(() => {
    if (!panelCell) return;
    const visiblePositionIds = new Set(filteredPositions.map((position) => position.id));
    if (!visiblePositionIds.has(panelCell.positionId) || collapsed[panelCell.areaId]) {
      setPanelCell(null);
    }
  }, [panelCell, collapsed, filteredPositions]);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    const currentWeekHeader = scrollContainer.querySelector(`[data-week-key="${currentWeekKey}"]`);
    if (!currentWeekHeader) return;

    const stickyColumnsWidth = 486;
    const targetLeft = Math.max(currentWeekHeader.offsetLeft - stickyColumnsWidth - 24, 0);
    const frame = window.requestAnimationFrame(() => {
      scrollContainer.scrollTo({ left: targetLeft, behavior: "smooth" });
    });

    return () => window.cancelAnimationFrame(frame);
  }, [currentWeekKey, weeks]);

  const selectCell = useCallback((positionId, weekKey, areaId) => {
    setActiveCell({ positionId, weekKey, areaId });
    setPanelCell((prev) => (
      prev?.positionId === positionId && prev?.weekKey === weekKey ? prev : null
    ));
  }, []);

  const manualPropagationWeeks = useCallback((posId, startWeekIndex) => {
    const currentWeeks = weeksRef.current;
    const currentPlan = planRef.current;
    const startWeek = currentWeeks[startWeekIndex];
    if (!startWeek) return [];

    const startCount = currentPlan[posId]?.[startWeek.key] ?? 0;
    const targetWeeks = [startWeek];

    for (let index = startWeekIndex + 1; index < currentWeeks.length; index += 1) {
      const futureWeek = currentWeeks[index];
      const futureCount = currentPlan[posId]?.[futureWeek.key] ?? 0;
      if (futureCount !== startCount) break;
      targetWeeks.push(futureWeek);
    }

    return targetWeeks;
  }, []);

  const saveCell = useCallback(async (pos, weekIndex, count) => {
    const currentPlan = planRef.current;
    const currentAssignments = assignmentsRef.current;
    const targetWeeks = manualPropagationWeeks(pos.id, weekIndex);
    const previousPlanByKey = Object.fromEntries(
      targetWeeks.map((futureWeek) => [futureWeek.key, currentPlan[pos.id]?.[futureWeek.key] ?? 0])
    );
    const previousAssignmentsByKey = Object.fromEntries(
      targetWeeks.map((futureWeek) => [futureWeek.key, currentAssignments[pos.id]?.[futureWeek.key] || []])
    );
    const nextPlanByKey = {};
    const requestCells = [];

    for (const futureWeek of targetWeeks) {
      const assignedCount = previousAssignmentsByKey[futureWeek.key].length;
      if (count < assignedCount) {
        toast.error("Digitalizacion: el total planeado no puede quedar debajo de las personas ligadas en una de las semanas siguientes.");
        return;
      }
      nextPlanByKey[futureWeek.key] = count;
      requestCells.push({
        position_id: pos.id,
        year: futureWeek.year,
        cw: futureWeek.cw,
        count,
      });
    }

    setPlan((prev) => ({
      ...prev,
      [pos.id]: {
        ...(prev[pos.id] || {}),
        ...nextPlanByKey,
      },
    }));

    setSaving(true);
    try {
      await api.post(endpoints.headcountBulk, { cells: requestCells });
    } catch (error) {
      setPlan((prev) => ({
        ...prev,
        [pos.id]: {
          ...(prev[pos.id] || {}),
          ...previousPlanByKey,
        },
      }));
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudo guardar la celda.");
    } finally {
      setSaving(false);
    }
  }, [manualPropagationWeeks]);

  const toggleAssignmentAcrossWeeks = useCallback(async (pos, startWeekIndex, personId, checked) => {
    if (!assignmentsEnabled) {
      toast.error("Digitalizacion: reinicia el servicio para habilitar la seleccion semanal de personas.");
      return;
    }

    const currentWeeks = weeksRef.current;
    const currentAssignments = assignmentsRef.current;
    const currentPlan = planRef.current;
    const upcomingWeeks = currentWeeks.slice(startWeekIndex);
    const nextAssignmentsByKey = {};
    const requestCells = [];
    upcomingWeeks.forEach((futureWeek) => {
      const currentIds = currentAssignments[pos.id]?.[futureWeek.key] || [];
      nextAssignmentsByKey[futureWeek.key] = checked
        ? (currentIds.includes(personId) ? currentIds : [...currentIds, personId])
        : currentIds.filter((id) => id !== personId);
      requestCells.push({
        position_id: pos.id,
        year: futureWeek.year,
        cw: futureWeek.cw,
        person_ids: nextAssignmentsByKey[futureWeek.key],
      });
    });

    const nextPlanByKey = Object.fromEntries(
      upcomingWeeks.map((futureWeek) => {
        const currentIds = currentAssignments[pos.id]?.[futureWeek.key] || [];
        const currentCount = currentPlan[pos.id]?.[futureWeek.key] ?? 0;
        const nextAssignedCount = nextAssignmentsByKey[futureWeek.key].length;
        const nextCount = currentCount > currentIds.length
          ? Math.max(currentCount, nextAssignedCount)
          : nextAssignedCount;
        return [futureWeek.key, nextCount];
      })
    );
    const previousAssignmentsByKey = Object.fromEntries(
      upcomingWeeks.map((futureWeek) => [futureWeek.key, currentAssignments[pos.id]?.[futureWeek.key] || []])
    );
    const previousPlanByKey = Object.fromEntries(
      upcomingWeeks.map((futureWeek) => [futureWeek.key, currentPlan[pos.id]?.[futureWeek.key] ?? 0])
    );

    setAssignments((prev) => ({
      ...prev,
      [pos.id]: {
        ...(prev[pos.id] || {}),
        ...nextAssignmentsByKey,
      },
    }));
    setPlan((prev) => ({
      ...prev,
      [pos.id]: {
        ...(prev[pos.id] || {}),
        ...nextPlanByKey,
      },
    }));

    setSaving(true);
    try {
      await api.post(endpoints.headcountAssignmentsBulk, { cells: requestCells });
    } catch (error) {
      setAssignments((prev) => ({
        ...prev,
        [pos.id]: {
          ...(prev[pos.id] || {}),
          ...previousAssignmentsByKey,
        },
      }));
      setPlan((prev) => ({
        ...prev,
        [pos.id]: {
          ...(prev[pos.id] || {}),
          ...previousPlanByKey,
        },
      }));
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudo actualizar la seleccion de personas.");
    } finally {
      setSaving(false);
    }
  }, [assignmentsEnabled]);

  const updatePersonStatus = useCallback(async (personId, status) => {
    const previousPeople = peopleRef.current;
    setPeople((prev) => prev.map((person) => (
      person.id === personId ? { ...person, status } : person
    )));

    try {
      await api.patch(`${endpoints.people}/${personId}`, { status });
    } catch (error) {
      setPeople(previousPeople);
      toast.error(error?.response?.data?.detail || "Digitalizacion: no se pudo actualizar el status de la persona.");
    }
  }, []);

  function totalForPosition(posId) {
    return Object.values(plan[posId] || {}).reduce((s, v) => s + (v || 0), 0);
  }

  function grandTotalForWeek(key) {
    return filteredPositions.reduce((acc, p) => acc + (plan[p.id]?.[key] || 0), 0);
  }

  return (
    <>
      <PageHeader
        title="Headcount Matrix"
        subtitle="Excel-like planning grid - selecciona una celda para capturar headcount; abre el panel de personas cuando haga falta"
        testId="matrix-header"
        actions={
          <div className="flex items-center gap-2">
            <Select value={String(startYear)} onValueChange={(v) => setStartYear(parseInt(v, 10))}>
              <SelectTrigger className="w-[110px] h-9" data-testid="matrix-year-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[2026, 2027].map((y) => (
                  <SelectItem key={y} value={String(y)}>FY {y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={String(startCw)} onValueChange={(v) => setStartCw(parseInt(v, 10))}>
              <SelectTrigger className="w-[110px] h-9" data-testid="matrix-startcw-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {Array.from({ length: 52 }, (_, i) => i + 1).map((w) => (
                  <SelectItem key={w} value={String(w)}>Start CW{String(w).padStart(2, "0")}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-[130px] h-9" data-testid="matrix-class-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="DL">DL only</SelectItem>
                <SelectItem value="IL">IL only</SelectItem>
                <SelectItem value="DLNUN">DLNUN only</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="sm"
              data-testid="matrix-reset-btn"
              onClick={() => scrollRef.current?.scrollTo({ left: 0, behavior: "smooth" })}
              className="text-slate-600"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset scroll
            </Button>
          </div>
        }
      />

      <div className="px-6 lg:px-8 py-6 space-y-4">
        <div className="flex items-center gap-3 flex-wrap text-xs">
          <span className="text-overline">Legend</span>
          <span className="classification-badge class-DL">DL · Direct</span>
          <span className="classification-badge class-IL">IL · Indirect</span>
          <span className="classification-badge class-DLNUN">DLNUN · Non-Union</span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-100 px-2 py-1 text-slate-700">
            <span className="h-2 w-2 rounded-full bg-blue-500" />
            Planeada con personas
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-2 py-1 text-slate-700">
            <span className="h-2 w-2 rounded-full bg-amber-500" />
            Planeada con pendientes
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-violet-100 px-2 py-1 text-slate-700">
            <span className="h-2 w-2 rounded-full bg-violet-500" />
            Planeada sin personas
          </span>
          <div className="flex w-full flex-wrap items-center gap-2 rounded-md border border-slate-200 bg-white px-3 py-2 shadow-sm">
            <span className="text-overline text-slate-500">Phases</span>
            {phaseLegend.length === 0 ? (
              <span className="text-xs text-slate-400">Sin phases visibles en este rango.</span>
            ) : (
              phaseLegend.map((phase) => (
                <Popover key={phase.id}>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-slate-700 transition-colors hover:bg-slate-100"
                    >
                      <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: phase.color }} />
                      <span className="max-w-[220px] truncate font-semibold">{phase.name}</span>
                      <span className="rounded-full bg-white px-1.5 py-0.5 text-[10px] text-slate-500">
                        {phase.milestoneCount}
                      </span>
                    </button>
                  </PopoverTrigger>
                  <PopoverContent align="start" className="w-80 border-slate-200 p-0">
                    <div className="border-b border-slate-200 px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="h-3 w-3 rounded-full" style={{ backgroundColor: phase.color }} />
                        <div className="min-w-0 truncate font-heading text-sm font-semibold text-slate-900">{phase.name}</div>
                      </div>
                    </div>
                    <div className="max-h-72 overflow-y-auto px-4 py-3 space-y-2">
                      {phase.milestones.map((milestone) => (
                        <div key={milestone.id} className="rounded-md border border-slate-200 bg-slate-50 px-3 py-2">
                          <div className="flex items-center justify-between gap-3">
                            <div className="min-w-0">
                              <div className="truncate text-sm font-medium text-slate-900">{milestone.name}</div>
                              <div className="text-[11px] uppercase tracking-wide text-slate-500">{milestone.type.replace("_", " ")}</div>
                            </div>
                            <div className="text-right text-xs text-slate-500">
                              <div>{milestone.date}</div>
                              <div>CW{String(milestone.cw).padStart(2, "0")}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </PopoverContent>
                </Popover>
              ))
            )}
          </div>
          <span className="ml-auto text-xs text-slate-500 flex items-center gap-2">
            {saving && <span className="animate-pulse text-blue-600">Saving…</span>}
            <span data-testid="matrix-positions-count">{filteredPositions.length} positions · {weeks.length} weeks</span>
          </span>
        </div>

        <div className="matrix-scroll" ref={scrollRef} data-testid="matrix-scroll">
          <table>
            <thead>
              <tr>
                <th className="sticky-col col-1">Area</th>
                <th className="sticky-col col-2">Position</th>
                <th className="sticky-col col-3">Class</th>
                <th className="sticky-col col-4">Shift</th>
                {weeks.map((w) => {
                  const milestoneGroup = msByKey[w.key] || [];
                  const primaryMilestone = milestoneGroup[0];
                  return (
                    <th
                      key={w.key}
                      data-week-key={w.key}
                      style={primaryMilestone ? { background: primaryMilestone.color, color: "#fff" } : undefined}
                      className={primaryMilestone ? "milestone-col" : undefined}
                    >
                      <div className="text-[10px] opacity-80">{w.monthLabel || "\u00A0"}</div>
                      <div>{w.label}</div>
                    </th>
                  );
                })}
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {grouped.map(({ area, positions: aps }) => {
                const isCollapsed = collapsed[area.id];
                return (
                  <Fragment key={area.id}>
                    <tr className="area-row">
                      <td
                        colSpan={4 + weeks.length + 1}
                        className="sticky-col col-1"
                        style={{ position: "sticky", left: 0, background: "#eff6ff", color: "#1e3a8a", fontWeight: 700, textAlign: "left", padding: "6px 12px", borderBottom: "2px solid #93c5fd" }}
                      >
                        <button
                          data-testid={`area-toggle-${area.id}`}
                          onClick={() => setCollapsed((prev) => ({ ...prev, [area.id]: !isCollapsed }))}
                          className="inline-flex items-center gap-1.5 text-xs font-heading tracking-wide"
                        >
                          {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          {area.name} <span className="text-slate-500 font-normal">· {aps.length}</span>
                        </button>
                      </td>
                    </tr>
                    {!isCollapsed && aps.map((p) => (
                      <tr key={p.id}>
                        <td className="sticky-col col-1 text-xs text-slate-500">{area.code || area.name}</td>
                        <td className="sticky-col col-2" data-testid={`pos-name-${p.id}`}>{p.name}</td>
                        <td className="sticky-col col-3">
                          <span className={`classification-badge class-${p.classification}`}>{p.classification}</span>
                        </td>
                        <td className="sticky-col col-4 text-xs text-slate-500">{p.shift}</td>
                        {weeks.map((w, weekIndex) => {
                          const isMs = (msByKey[w.key] || []).length > 0;
                          return (
                            <td key={w.key} className={isMs ? "milestone-col" : undefined}>
                              <MemoMatrixCell
                                position={p}
                                week={w}
                                weekIndex={weekIndex}
                                initial={plan[p.id]?.[w.key] ?? 0}
                                onSave={(v) => saveCell(p, weekIndex, v)}
                                onToggleAssignment={(startWeekIndex, personId, checked) => toggleAssignmentAcrossWeeks(p, startWeekIndex, personId, checked)}
                                people={peopleByPosition[p.id]}
                                selectedPersonIds={assignments[p.id]?.[w.key] || []}
                                assignmentsEnabled={assignmentsEnabled}
                                isActive={activeCell?.positionId === p.id && activeCell?.weekKey === w.key}
                                isPanelOpen={panelCell?.positionId === p.id && panelCell?.weekKey === w.key}
                                onSelect={() => selectCell(p.id, w.key, area.id)}
                                onPanelOpenChange={(open) => {
                                  if (open) {
                                    setActiveCell({ positionId: p.id, weekKey: w.key, areaId: area.id });
                                    setPanelCell({ positionId: p.id, weekKey: w.key, areaId: area.id });
                                    return;
                                  }
                                  setPanelCell((prev) => (
                                    prev?.positionId === p.id && prev?.weekKey === w.key ? null : prev
                                  ));
                                }}
                                onUpdatePersonStatus={updatePersonStatus}
                              />
                            </td>
                          );
                        })}
                        <td className="font-semibold text-slate-700 tabular-nums">{totalForPosition(p.id)}</td>
                      </tr>
                    ))}
                  </Fragment>
                );
              })}
              <tr className="grand-total-row">
                <td className="sticky-col col-1">TOTAL</td>
                <td className="sticky-col col-2">Grand Total (all classes shown)</td>
                <td className="sticky-col col-3">—</td>
                <td className="sticky-col col-4">—</td>
                {weeks.map((w) => (
                  <td key={w.key}>{grandTotalForWeek(w.key)}</td>
                ))}
                <td>{filteredPositions.reduce((acc, p) => acc + totalForPosition(p.id), 0)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
