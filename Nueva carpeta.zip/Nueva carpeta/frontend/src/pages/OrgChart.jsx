import { useEffect, useMemo, useState, useRef } from "react";
import { toast } from "sonner";
import { UserX, ZoomIn, ZoomOut, Maximize, Expand, Shrink } from "lucide-react";
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";

import PageHeader from "@/components/PageHeader";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, endpoints } from "@/lib/api";

// Colores de estado
const STATUS_DOT = {
  hired:    "bg-emerald-500",
  vacant:   "bg-rose-500",
  tbd:      "bg-orange-500",
  planned:  "bg-blue-500",
  temp:     "bg-purple-500",
  transfer: "bg-slate-400",
};

// Colores de jerarquía
const GEN_COLORS = [
  { bg: "bg-teal-500", text: "text-white", sub: "text-teal-50" },
  { bg: "bg-emerald-800", text: "text-white", sub: "text-emerald-100" },
  { bg: "bg-slate-200", text: "text-slate-900", sub: "text-slate-500" },
];
const DEFAULT_COLOR = { bg: "bg-slate-200", text: "text-slate-900", sub: "text-slate-500" };

function PersonPill({ person, color }) {
  const isTbd = (person.name || "").trim().toUpperCase() === "TBD";
  const statusColor = STATUS_DOT[person.status] || STATUS_DOT.planned;
  
  return (
    <div
      className={`relative min-w-[160px] max-w-[220px] rounded-md pl-4 pr-12 py-3 shadow-sm ${color.bg} overflow-hidden`}
      data-testid={`org-person-${person.id}`}
    >
      <div 
        className={`absolute top-0 right-0 w-8 h-full ${statusColor}`} 
        title={person.status} 
      />
      
      {/* Texto Principal: Nombre de la Posición */}
      <div className={`font-heading font-semibold text-sm text-center leading-tight ${color.text}`}>
        {person.position_name || "—"}
      </div>

      {/* Subtítulo: Nombre de la Persona */}
      <div className={`text-[11px] text-center truncate mt-0.5 ${color.sub}`}>
        {isTbd ? (
          <span className="inline-flex items-center gap-1 justify-center">
            <UserX className="w-3 h-3" /> TBD
          </span>
        ) : (
          person.name || "—"
        )}
      </div>
    </div>
  );
}

function AreaNodeTree({ area, showAreaTitle }) {
  const generations = [
    ...area.layers.map((l) => ({ label: `Layer ${l.layer}`, people: l.people })),
    ...(area.unassigned.length > 0 ? [{ label: "Unassigned layer", people: area.unassigned }] : []),
  ];

  if (generations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-sm text-slate-400">
        {showAreaTitle && <div className="font-bold text-slate-700 mb-2">{area.area_name}</div>}
        No people assigned.
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      {showAreaTitle && (
        <div className="flex flex-col items-center">
          <div className="bg-slate-700 text-white text-xs px-6 py-2 rounded-full font-bold shadow-sm z-10 tracking-widest uppercase">
            {area.area_name}
          </div>
          <div className="w-px h-6 bg-slate-300" />
        </div>
      )}

      {generations.map((gen, idx) => {
        const color = GEN_COLORS[idx] || DEFAULT_COLOR;
        const hasFork = gen.people.length > 1;

        return (
          <div key={idx} className="flex flex-col items-center">
            {idx > 0 && <div className="org-gen-connector" />}
            
            {gen.label && (
              <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1">
                {gen.label}
              </div>
            )}
            
            <ul className="org-sib-list flex gap-4">
              {gen.people.map((p) => (
                <li key={p.id} className="org-sib-item flex flex-col items-center relative">
                  {hasFork && <span className="org-dot" />}
                  <PersonPill person={p} color={color} />
                </li>
              ))}
            </ul>
          </div>
        );
      })}
    </div>
  );
}

export default function OrgChartPage() {
  const [areas, setAreas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState("all");
  
  const chartContainerRef = useRef(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const r = await api.get(endpoints.orgChart);
      const data = r.data.areas || [];
      setAreas(data);
      const firstWithPeople = data.find((a) => a.layers.length > 0 || a.unassigned.length > 0);
      setSelected((firstWithPeople || data[0])?.area_id || "all");
    } catch {
      toast.error("Failed to load org chart");
    } finally {
      setLoading(false);
    }
  }
  
  useEffect(() => { load(); }, []);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      chartContainerRef.current?.requestFullscreen().catch(err => {
        toast.error("No se pudo iniciar pantalla completa");
      });
    } else {
      document.exitFullscreen();
    }
  };

  const selectedArea = useMemo(
    () => areas.find((a) => a.area_id === selected),
    [areas, selected]
  );

  return (
    <div className="flex flex-col h-[calc(100vh-20px)] overflow-hidden">
      <div className="shrink-0">
        <PageHeader
          title="Layer"
          subtitle="Grouped by Area, then by Layer (1 top → 10 bottom). Drag to move, scroll to zoom."
          testId="orgchart-header"
          actions={
            <Select value={selected} onValueChange={setSelected}>
              <SelectTrigger className="w-[220px] bg-white" data-testid="org-area-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All areas (combined)</SelectItem>
                {areas.map((a) => (
                  <SelectItem key={a.area_id} value={a.area_id}>{a.area_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          }
        />
      </div>

      <div 
        ref={chartContainerRef} 
        className="flex-1 w-full bg-slate-50 relative overflow-hidden group border-t border-slate-200"
      >
        {loading ? (
          <div className="text-sm text-slate-400 w-full h-full flex items-center justify-center">Loading…</div>
        ) : (
          <TransformWrapper
            initialScale={selected === "all" ? 0.6 : 1}
            minScale={0.1} 
            maxScale={3}
            centerOnInit={true}
            limitToBounds={false} 
            wheel={{ step: 0.1 }}
            panning={{ velocityDisabled: false }}
          >
            {({ zoomIn, zoomOut, resetTransform }) => (
              <>
                <div className="absolute top-6 right-6 z-20 flex flex-col gap-2 bg-white p-1.5 rounded-xl shadow-lg border border-slate-200 opacity-80 hover:opacity-100 transition-opacity">
                  <button onClick={() => zoomIn()} className="p-2 bg-slate-50 hover:bg-slate-200 rounded-lg text-slate-700 transition-colors" title="Zoom In">
                    <ZoomIn className="w-5 h-5" />
                  </button>
                  <button onClick={() => zoomOut()} className="p-2 bg-slate-50 hover:bg-slate-200 rounded-lg text-slate-700 transition-colors" title="Zoom Out">
                    <ZoomOut className="w-5 h-5" />
                  </button>
                  <button onClick={() => resetTransform()} className="p-2 bg-slate-50 hover:bg-slate-200 rounded-lg text-slate-700 transition-colors" title="Centrar">
                    <Maximize className="w-5 h-5" />
                  </button>
                  
                  <div className="w-full h-px bg-slate-200 my-0.5"></div>
                  
                  <button onClick={toggleFullscreen} className="p-2 bg-slate-50 hover:bg-slate-200 rounded-lg text-slate-700 transition-colors" title="Pantalla Completa">
                    {isFullscreen ? <Shrink className="w-5 h-5" /> : <Expand className="w-5 h-5" />}
                  </button>
                </div>

                <div className="w-full h-full cursor-grab active:cursor-grabbing">
                  <TransformComponent wrapperClass="!w-full !h-full" contentClass="!w-full !h-full flex justify-center items-center min-w-max min-h-max p-32">
                    
                    {selected === "all" ? (
                      <div className="flex flex-col items-center">
                        <div className="bg-slate-900 text-white font-black text-xl px-10 py-4 rounded-xl shadow-xl z-20 mb-2">
                          KREM Plant
                        </div>
                        <div className="w-px h-8 bg-slate-400"></div>
                        
                        <div className="flex items-start gap-12 border-t-2 border-slate-400 pt-6 relative px-10">
                          {areas.map((area) => (
                            <div key={area.area_id} className="relative flex flex-col items-center min-w-min">
                              <div className="absolute -top-6 w-px h-6 bg-slate-400"></div>
                              <AreaNodeTree area={area} showAreaTitle={true} />
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : selectedArea ? (
                      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
                        <AreaNodeTree area={selectedArea} showAreaTitle={false} />
                      </div>
                    ) : (
                      <div className="text-sm text-slate-400 text-center py-10">No area selected.</div>
                    )}
                    
                  </TransformComponent>
                </div>
              </>
            )}
          </TransformWrapper>
        )}
      </div>
    </div>
  );
}