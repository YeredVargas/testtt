from openpyxl import load_workbook
from pathlib import Path
import json

F = Path("NIVELES KOSTAL (003).xlsx")
out = {"exists": F.exists()}
if F.exists():
    wb = load_workbook(F, data_only=True)
    ws = wb.active
    # find header row: first row with at least 2 non-empty string cells
    header_row = None
    for r in range(1, min(ws.max_row, 50) + 1):
        vals = [ws.cell(r, c).value for c in range(1, ws.max_column+1)]
        str_count = sum(1 for v in vals if isinstance(v, str) and v.strip())
        if str_count >= 1:
            header_row = r
            headers = [ (v.strip() if isinstance(v, str) else v) for v in vals ]
            break
    preview = None
    if header_row:
        # find first non-empty data row
        for r in range(header_row+1, min(ws.max_row, header_row+20)+1):
            row_vals = [ws.cell(r, c).value for c in range(1, ws.max_column+1)]
            if any(v is not None and (not isinstance(v, str) or v.strip()) for v in row_vals):
                preview = row_vals
                break
        out.update({"header_row": header_row, "headers": headers, "preview": preview})

print(json.dumps(out, ensure_ascii=False, indent=2))
