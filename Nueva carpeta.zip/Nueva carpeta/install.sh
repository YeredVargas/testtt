#!/usr/bin/env bash
# ================================================================
#  KREM Headcount Planner - First-time installer (Mac/Linux)
# ================================================================
set -e
cd "$(dirname "$0")"

echo
echo "============================================"
echo "  KREM Headcount Planner - Local Installer"
echo "============================================"
echo

# ----- Check Python
if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] python3 is not installed."
    echo "        Install Python 3.11+ (https://www.python.org/downloads/)"
    exit 1
fi
echo "[OK] Python $(python3 --version | awk '{print $2}') found"

# ----- Check Node
if ! command -v node >/dev/null 2>&1; then
    echo "[ERROR] Node.js is not installed."
    echo "        Install Node 20+ (https://nodejs.org/)"
    exit 1
fi
echo "[OK] Node $(node --version) found"

# ----- Check Yarn
if ! command -v yarn >/dev/null 2>&1; then
    echo "[INFO] Installing yarn via npm..."
    npm install -g yarn
fi
echo "[OK] Yarn $(yarn --version) ready"

# ----- Check MongoDB
if ! command -v mongod >/dev/null 2>&1; then
    echo "[WARN] MongoDB (mongod) not detected in PATH."
    echo "       Install via https://www.mongodb.com/try/download/community"
    echo "       or 'brew tap mongodb/brew && brew install mongodb-community' on macOS."
    echo "       The app will not work without MongoDB running."
    read -p "Press ENTER to continue anyway..."
else
    echo "[OK] MongoDB CLI detected"
fi

echo
echo "--------------------------------------------"
echo "  Backend setup"
echo "--------------------------------------------"
cd backend
if [ ! -d .venv ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate
echo "Installing Python dependencies (this can take a couple of minutes)..."
pip install --upgrade pip
pip install -r requirements.txt

if [ ! -f .env ]; then
    echo "Creating backend/.env with defaults..."
    cat > .env <<EOF
MONGO_URL=mongodb://localhost:27017
DB_NAME=krem_headcount
CORS_ORIGINS=*
EOF
    echo "[OK] backend/.env created"
else
    echo "[OK] backend/.env already exists - keeping it"
fi
deactivate
cd ..

echo
echo "--------------------------------------------"
echo "  Frontend setup"
echo "--------------------------------------------"
cd frontend
if [ ! -f .env ]; then
    echo "Creating frontend/.env with defaults..."
    cat > .env <<EOF
REACT_APP_BACKEND_URL=http://localhost:8001
WDS_SOCKET_PORT=0
EOF
    echo "[OK] frontend/.env created"
else
    echo "[OK] frontend/.env already exists - keeping it"
fi

echo "Installing frontend dependencies (this can take several minutes)..."
yarn install
cd ..

echo
echo "============================================"
echo "  Install complete!"
echo "============================================"
echo
echo "Next step: run ./start.sh to launch the app."
echo
