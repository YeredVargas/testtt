"""Script de empaquetado de produccion para KREM Headcount Planner.

Vive dentro de 'backend' porque es justo donde esta el entorno virtual
(.venv) que PyInstaller necesita para empaquetar las dependencias correctas.

Automatiza:
    1. Limpieza de compilaciones anteriores.
    2. Compilacion del frontend React (CRA/craco -> carpeta build).
    3. Empaquetado del backend FastAPI con PyInstaller (--onedir).
    4. Ensamblaje de la carpeta final de distribucion con el ejecutable,
       el frontend compilado (como 'dist') y el archivo .env.

Uso (desde la carpeta backend):
    .venv\\Scripts\\python.exe build.py

El script puede ejecutarse tantas veces como se necesite: siempre limpia
la carpeta 'release' y los directorios temporales de PyInstaller antes de
volver a compilar, para evitar mezclar artefactos de builds anteriores.
"""
from __future__ import annotations

import platform
import shutil
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Paso 1: Rutas base
# ---------------------------------------------------------------------------

BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BACKEND_DIR.parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"

APP_NAME = "krem_planner"

PYINSTALLER_SPEC_DIR = BACKEND_DIR / "build_meta"
PYINSTALLER_WORK_DIR = PYINSTALLER_SPEC_DIR / "work"
RELEASE_DIR = PROJECT_ROOT / "release"
OUTPUT_DIR = RELEASE_DIR / APP_NAME

IS_WINDOWS = platform.system() == "Windows"


def _venv_python() -> Path:
    if IS_WINDOWS:
        return BACKEND_DIR / ".venv" / "Scripts" / "python.exe"
    return BACKEND_DIR / ".venv" / "bin" / "python"


def _npm_executable() -> str:
    return "npm.cmd" if IS_WINDOWS else "npm"


def _run(cmd: list[str], cwd: Path) -> None:
    print(f"Ejecutando: {' '.join(cmd)}  (cwd={cwd})")
    result = subprocess.run(cmd, cwd=str(cwd))
    if result.returncode != 0:
        raise RuntimeError(f"El comando fallo con codigo {result.returncode}: {' '.join(cmd)}")


def clean() -> None:
    """Elimina por completo la carpeta 'release' y los directorios temporales
    de compilaciones anteriores para asegurar un empaquetado limpio."""
    print("Paso 1: Limpiando compilaciones anteriores...")
    for folder in (RELEASE_DIR, PYINSTALLER_SPEC_DIR):
        if folder.exists():
            shutil.rmtree(folder)
            print(f"  - Eliminado: {folder}")

    stray_spec = BACKEND_DIR / f"{APP_NAME}.spec"
    if stray_spec.exists():
        stray_spec.unlink()
        print(f"  - Eliminado: {stray_spec}")

    PYINSTALLER_SPEC_DIR.mkdir(parents=True, exist_ok=True)
    print("Limpieza completada.\n")


# ---------------------------------------------------------------------------
# Paso 2: Compilar el frontend (React)
# ---------------------------------------------------------------------------

def build_frontend() -> Path:
    print("Paso 2: Compilando frontend (React)...")
    _run([_npm_executable(), "run", "build"], cwd=FRONTEND_DIR)

    build_output = FRONTEND_DIR / "build"
    if not build_output.exists():
        dist_fallback = FRONTEND_DIR / "dist"
        if dist_fallback.exists():
            build_output = dist_fallback
        else:
            raise RuntimeError(
                f"No se encontro la carpeta compilada del frontend en {build_output}"
            )

    print(f"Frontend compilado correctamente en: {build_output}\n")
    return build_output


# ---------------------------------------------------------------------------
# Paso 3: Empaquetar el backend (FastAPI) con PyInstaller
# ---------------------------------------------------------------------------

HIDDEN_IMPORTS = [
    "uvicorn",
    "uvicorn.logging",
    "uvicorn.loops",
    "uvicorn.loops.auto",
    "uvicorn.protocols",
    "uvicorn.protocols.http",
    "uvicorn.protocols.http.auto",
    "uvicorn.protocols.websockets",
    "uvicorn.protocols.websockets.auto",
    "uvicorn.lifespan",
    "uvicorn.lifespan.on",
    "motor",
    "motor.motor_asyncio",
    "pymongo",
    "pydantic",
    "starlette",
    "openpyxl",
    "reportlab",
    "multipart",
]


def compile_backend() -> Path:
    print("Paso 3: Empaquetando backend (FastAPI) con PyInstaller...")

    python_exe = _venv_python()
    if not python_exe.exists():
        print(
            f"  Aviso: no se encontro el interprete del entorno virtual en {python_exe}. "
            f"Usando el Python activo ({sys.executable}) como respaldo."
        )
        python_exe = Path(sys.executable)

    server_entry = BACKEND_DIR / "server.py"
    if not server_entry.exists():
        raise RuntimeError(f"No se encontro el punto de entrada del backend: {server_entry}")

    cmd = [
        str(python_exe),
        "-m",
        "PyInstaller",
        str(server_entry),
        "--name", APP_NAME,
        "--onedir",
        "--noconsole",
        "--noconfirm",
        "--specpath", str(PYINSTALLER_SPEC_DIR),
        "--distpath", str(RELEASE_DIR),
        "--workpath", str(PYINSTALLER_WORK_DIR),
    ]
    for hidden_import in HIDDEN_IMPORTS:
        cmd.extend(["--hidden-import", hidden_import])

    _run(cmd, cwd=BACKEND_DIR)

    if not OUTPUT_DIR.exists():
        raise RuntimeError(f"PyInstaller no genero la carpeta esperada: {OUTPUT_DIR}")

    print(f"Backend empaquetado correctamente en: {OUTPUT_DIR}\n")
    return OUTPUT_DIR


# ---------------------------------------------------------------------------
# Paso 4: Ensamblaje final de la carpeta de distribucion
# ---------------------------------------------------------------------------

def post_build(frontend_build_dir: Path) -> None:
    print("Paso 4: Ensamblando carpeta final de distribucion...")

    dist_target = OUTPUT_DIR / "dist"
    if dist_target.exists():
        shutil.rmtree(dist_target)
    shutil.copytree(frontend_build_dir, dist_target)
    print(f"  - Frontend copiado a: {dist_target}")

    env_source = BACKEND_DIR / ".env"
    env_target = OUTPUT_DIR / ".env"
    if env_source.exists():
        shutil.copy2(env_source, env_target)
        print(f"  - .env copiado a: {env_target}")
    else:
        print("  - Aviso: no se encontro backend/.env; el ejecutable podria arrancar sin configuracion.")

    print(f"Carpeta final lista en: {OUTPUT_DIR}\n")


def main() -> None:
    clean()
    frontend_build_dir = build_frontend()
    compile_backend()
    post_build(frontend_build_dir)
    print("Digitalización completada: Proyecto empaquetado exitosamente")


if __name__ == "__main__":
    main()
