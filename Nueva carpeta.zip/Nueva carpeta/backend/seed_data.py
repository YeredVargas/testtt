"""Seed data for KREM plant headcount planning app."""

# (name, code, description)
SEED_AREAS = [
    ("SMT",  "SMT",  "Surface Mount Technology"),
    ("BE",   "BE",   "Back-End Assembly"),
    ("APF",  "APF",  "Automated Production Flow"),
    ("AQA",  "AQA",  "Analysis Quality Assurance"),
    ("AP1",  "AP1",  "Assembly Process 1"),
    ("APL",  "APL",  "Assembly Process Line"),
    ("AZ",   "AZ",   "AZ & MDM"),
    ("MAINT","MAINT","Maintenance"),
    ("LOG",  "LOG",  "Logistics"),
    ("MGMT", "MGMT", "Management"),
]

# (name, area_code, classification, shift)
SEED_POSITIONS = [
    # Management (IL)
    ("Manager",                   "MGMT",  "IL",    "N/A"),
    ("Production Leader",         "MGMT",  "IL",    "N/A"),
    ("Production Supervisor",     "MGMT",  "IL",    "1st"),

    # Indirect – SMT
    ("Line Leader SMT",           "SMT",   "IL",    "1st"),
    ("Technician SMT",            "SMT",   "IL",    "1st"),
    ("Process Engineer SMT",      "SMT",   "IL",    "N/A"),

    # Indirect – BE
    ("Line Leader BE",            "BE",    "IL",    "1st"),
    ("Technician BE",             "BE",    "IL",    "1st"),
    ("Process Engineer BE",       "BE",    "IL",    "N/A"),

    # Quality (AQA)
    ("Analysis Engineer",         "AQA",   "IL",    "N/A"),
    ("Analysis Technician",       "AQA",   "IL",    "1st"),
    ("Customer Quality Engineer", "AQA",   "IL",    "N/A"),
    ("Supplier Quality Engineer", "AQA",   "IL",    "N/A"),
    ("Production Quality",        "AQA",   "IL",    "N/A"),

    # Planning / Engineering
    ("Planner",                   "APF",   "IL",    "N/A"),
    ("Planning Engineer 1",       "APF",   "IL",    "N/A"),
    ("Planning Engineer 2",       "APF",   "IL",    "N/A"),
    ("Automation Engineer",       "AP1",   "IL",    "N/A"),
    ("Industrial Engineer 1",     "AP1",   "IL",    "N/A"),
    ("Industrial Engineer 2",     "AP1",   "IL",    "N/A"),
    ("Support KOI Vision Systems","AP1",   "IL",    "N/A"),
    ("Test Engineer 1",           "APL",   "IL",    "N/A"),
    ("Test Engineer 2",           "APL",   "IL",    "N/A"),
    ("Test Engineer Coordinator", "APL",   "IL",    "N/A"),
    ("MES Engineer",              "APL",   "IL",    "N/A"),

    # Maintenance
    ("Maintenance Chief",         "MAINT", "IL",    "N/A"),
    ("Maintenance Coordinator",   "MAINT", "IL",    "N/A"),
    ("Maintenance Engineer",      "MAINT", "IL",    "N/A"),
    ("Process Chief",             "MAINT", "IL",    "N/A"),

    # Logistics
    ("Logistics Coordinator",     "LOG",   "IL",    "N/A"),
    ("Logistics Operator",        "LOG",   "DLNUN", "1st"),
    ("Water Spider",              "LOG",   "DLNUN", "1st"),

    # Direct Labor – SMT
    ("Operator (SMT 1)",          "SMT",   "DL",    "1st"),
    ("Operator (SMT 2)",          "SMT",   "DL",    "1st"),
    ("Operator (SMT 3)",          "SMT",   "DL",    "2nd"),
    ("Operator (SMT 4)",          "SMT",   "DL",    "3rd"),

    # Direct Labor – BE stations
    ("Operator (PINNING 1)",      "BE",    "DL",    "1st"),
    ("Operator (PINNING 2)",      "BE",    "DL",    "2nd"),
    ("Operator (LASER 1)",        "BE",    "DL",    "1st"),
    ("Operator (LASER 2)",        "BE",    "DL",    "2nd"),
    ("Operator (LASER 3)",        "BE",    "DL",    "3rd"),
    ("Operator (ROUTER 1)",       "BE",    "DL",    "1st"),
    ("Operator (ROUTER 2)",       "BE",    "DL",    "2nd"),
    ("Operator (ROUTER 3)",       "BE",    "DL",    "3rd"),
    ("Operator (ROUTER 4)",       "BE",    "DL",    "N/A"),
    ("Operator (CONFORMAL 1)",    "BE",    "DL",    "1st"),
    ("Operator (CONFORMAL 2)",    "BE",    "DL",    "2nd"),
    ("Operator (ICT 1)",          "BE",    "DL",    "1st"),
    ("Operator (ICT 2)",          "BE",    "DL",    "1st"),
    ("Operator (ICT 3)",          "BE",    "DL",    "2nd"),
    ("Operator (ICT 4)",          "BE",    "DL",    "2nd"),
    ("Operator (ICT 5)",          "BE",    "DL",    "3rd"),
    ("Operator (ICT 6)",          "BE",    "DL",    "3rd"),
    ("Operator (SELECTIVE SOLDERING)", "BE","DL",  "1st"),
    ("Operator (M4)",             "BE",    "DL",    "1st"),
    ("Operator (Rework)",         "BE",    "DL",    "1st"),
]

# Default milestones – editable dates from UI later.
# (name, type, iso_date, year, cw, color)
SEED_MILESTONES = [
    ("Transfer",  "transfer",  "2025-08-25", 2025, 35, "#8B5CF6"),
    ("Trial Run", "trial_run", "2025-11-03", 2025, 45, "#EAB308"),
    ("SOP",       "sop",       "2026-02-02", 2026,  6, "#10B981"),
]
