"""Regression tests for the Org Chart hierarchy endpoint.

Focus:
- GET /api/positions/hierarchy returns roots[] with children[] and assigned[].
- Filter ?area_id=<id> filters positions to that area.
- PATCH /api/positions/{id} accepts org_level (1-7) and reports_to_position_id.
- PATCH validation: org_level out of range -> 400.
- reports_to must point to a strictly higher-ranked (lower org_level) position.
- Self-reporting and cycles are rejected.
"""
from __future__ import annotations

import os

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.strip().split("=", 1)[1].rstrip("/")
                break
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def client():
    return requests.Session()


@pytest.fixture(scope="module", autouse=True)
def seeded(client):
    r = client.post(f"{API}/seed", timeout=30)
    assert r.status_code == 200
    yield
    positions = client.get(f"{API}/positions").json()
    for p in positions:
        if p.get("name", "").startswith("TEST_"):
            client.delete(f"{API}/positions/{p['id']}")


class TestHierarchy:
    def test_hierarchy_shape(self, client):
        r = client.get(f"{API}/positions/hierarchy")
        assert r.status_code == 200
        data = r.json()
        assert "roots" in data
        assert isinstance(data["roots"], list)
        for root in data["roots"]:
            assert "children" in root and isinstance(root["children"], list)
            assert "assigned" in root and isinstance(root["assigned"], list)
            assert "area_name" in root

    def test_hierarchy_filter_by_area(self, client):
        areas = client.get(f"{API}/areas").json()
        area = areas[0]
        r = client.get(f"{API}/positions/hierarchy", params={"area_id": area["id"]})
        assert r.status_code == 200
        data = r.json()

        def walk(node):
            assert node["area_id"] == area["id"], node
            for c in node["children"]:
                walk(c)

        for root in data["roots"]:
            walk(root)

    def test_hierarchy_assigned_contains_people(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.post(f"{API}/people", json={"name": "TEST_HIER_Person", "position_id": pid})
        assert r.status_code == 200
        try:
            hdata = client.get(f"{API}/positions/hierarchy").json()

            def find(nodes, target_pid):
                for n in nodes:
                    if n["id"] == target_pid:
                        return n
                    got = find(n["children"], target_pid)
                    if got:
                        return got
                return None

            found = find(hdata["roots"], pid)
            assert found is not None, "position missing from hierarchy"
            names = [a["name"] for a in found["assigned"]]
            assert "TEST_HIER_Person" in names
        finally:
            client.delete(f"{API}/people/{r.json()['id']}")


class TestPositionOrgLevel:
    def test_patch_org_level_and_reports_to(self, client):
        areas = client.get(f"{API}/areas").json()
        aid = areas[0]["id"]
        r1 = client.post(f"{API}/positions", json={
            "name": "TEST_LVL_Root", "area_id": aid, "classification": "IL", "org_level": 1
        })
        assert r1.status_code == 200, r1.text
        root_id = r1.json()["id"]

        r2 = client.post(f"{API}/positions", json={
            "name": "TEST_LVL_Child", "area_id": aid, "classification": "IL"
        })
        assert r2.status_code == 200
        child_id = r2.json()["id"]

        r = client.patch(f"{API}/positions/{child_id}", json={
            "org_level": 3, "reports_to_position_id": root_id
        })
        assert r.status_code == 200, r.text
        got = r.json()
        assert got["org_level"] == 3
        assert got["reports_to_position_id"] == root_id

        # existing status field still works untouched
        r = client.patch(f"{API}/positions/{child_id}", json={"status": "vacant"})
        assert r.status_code == 200
        assert r.json().get("status") == "vacant"

        client.delete(f"{API}/positions/{child_id}")
        client.delete(f"{API}/positions/{root_id}")

    def test_patch_org_level_out_of_range_rejected(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.patch(f"{API}/positions/{pid}", json={"org_level": 99})
        assert r.status_code == 400

    def test_reports_to_self_rejected(self, client):
        areas = client.get(f"{API}/areas").json()
        aid = areas[0]["id"]
        r = client.post(f"{API}/positions", json={
            "name": "TEST_SELF", "area_id": aid, "classification": "IL", "org_level": 2
        })
        pid = r.json()["id"]
        try:
            r2 = client.patch(f"{API}/positions/{pid}", json={"reports_to_position_id": pid})
            assert r2.status_code == 400
        finally:
            client.delete(f"{API}/positions/{pid}")

    def test_reports_to_lower_rank_rejected(self, client):
        areas = client.get(f"{API}/areas").json()
        aid = areas[0]["id"]
        boss = client.post(f"{API}/positions", json={
            "name": "TEST_BOSS", "area_id": aid, "classification": "IL", "org_level": 5
        }).json()
        report = client.post(f"{API}/positions", json={
            "name": "TEST_REPORT", "area_id": aid, "classification": "IL", "org_level": 2
        }).json()
        try:
            # report (L2) trying to report to boss (L5) is a demotion -> rejected
            r = client.patch(f"{API}/positions/{report['id']}", json={
                "reports_to_position_id": boss["id"]
            })
            assert r.status_code == 400
        finally:
            client.delete(f"{API}/positions/{boss['id']}")
            client.delete(f"{API}/positions/{report['id']}")

    def test_delete_position_clears_children_reports_to(self, client):
        areas = client.get(f"{API}/areas").json()
        aid = areas[0]["id"]
        root = client.post(f"{API}/positions", json={
            "name": "TEST_CASCADE_ROOT", "area_id": aid, "classification": "IL", "org_level": 1
        }).json()
        child = client.post(f"{API}/positions", json={
            "name": "TEST_CASCADE_CHILD", "area_id": aid, "classification": "IL",
            "org_level": 2, "reports_to_position_id": root["id"],
        }).json()
        client.delete(f"{API}/positions/{root['id']}")
        try:
            positions = client.get(f"{API}/positions").json()
            got = next(p for p in positions if p["id"] == child["id"])
            assert got["reports_to_position_id"] is None
        finally:
            client.delete(f"{API}/positions/{child['id']}")
