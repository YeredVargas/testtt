# Linea FASSY — OBC MACH-E / P702 / RIVIAN

Linea de ensamble final del On Board Charger, modelada como **celda en U** a partir de los
rotulos del layout de piso. Se agrego de forma **aditiva** sobre el proyecto existente: la
linea SMT no se modifico.

## Que se agrego y que se toco

**Archivos nuevos (todo lo de FASSY vive aqui):**

| Archivo | Contenido |
| --- | --- |
| `src/types/fassy.ts` | Tipos propios de FASSY. Reexporta los de `factory.ts`, no los modifica. |
| `src/data/fassyLine.ts` | Estaciones, displays, props, colisiones y limites. Autocontenido. |
| `src/components/FassyLine.tsx` | Grupo de la linea + producto en transito + losa de piso. |
| `src/components/fassy/FassyEquipment.tsx` | Componentes 3D de estacion + despacho por tipo. |
| `src/components/fassy/FassyProps.tsx` | Arco del elevador, grua, gabinetes, carros, racks. |
| `public/screens/fassy-*.svg` | Tres pantallas de piso. |

**Archivos existentes modificados: dos.**

1. `src/data/smtLine.ts` — una constante: `floorSize` de `[188, 36]` a `[188, 50]`, para
   dar fondo a la franja trasera. Nada mas de ese archivo cambia.
2. `src/components/FactoryScene.tsx` — 6 lineas:

```
- import { sceneCollisionBoxes, walkableBounds } from '../data/smtLine'
+ import { sceneCollisionBoxes } from '../data/smtLine'
+ import { fassyCollisionBoxes, plantWalkableBounds } from '../data/fassyLine'
+ import { FassyLine } from './FassyLine'
...
  const sceneBlockers = [ ... , ...fassyCollisionBoxes ]
...
+           <FassyLine onOpenMedia={onOpenMedia} />
...
-             bounds={walkableBounds}  ->  bounds={plantWalkableBounds}
```

`fassyCollisionBoxes` se suma a la lista `sceneBlockers` que ya agrega SMT, backend,
conformal, glue, XRAY, ICT, router y arquitectura: no reemplaza ninguna.
`plantWalkableBounds` se deriva de `walkableBounds` de SMT y solo lo extiende hacia el
oeste, asi que si esos limites cambian, estos los siguen. `smtLine.ts`, `FactoryFloor` y
`factoryArchitecture` quedan intactos: el piso de 188 x 36 y el techo de la nave ya cubren
el area de la celda.

## Ubicacion en planta

La celda ocupa la **franja trasera de la nave, al este, detras del area de backend**:
`x = 34.2` a `x = 74.4`, `z = -21.8` a `z = -14.4`, con el elevador en `x = 33`.

```
   z = -25   ┌──────────────────────────────────────────────────────┐ borde nave
   z = -21   │                    [ FASSY tramo B  ST 150 -> ST 230 ]│
   z = -18   │            [elev]   ── pasillo interior ──            │
   z = -15   │                    [ FASSY tramo A  ST 010 -> ST 150 ]│
   z = -10   │   o  o  o  o  columnas traseras                       │
   z =   0   │      [ SMT x -23..23 ]      [ BACKEND x 26..84 ]      │
   z = +17   │      ──────── muro de rework ────────                 │
   z = +25   └──────────────────────────────────────────────────────┘
                        x 33  34.2 ....................... 74.4
```

Para que quepa, **el fondo de la nave paso de 36 a 50 m** (`floorSize` en `smtLine.ts`).
Ese unico valor alimenta el piso, la reticula, el techo, los muros y las luminarias de
`factoryArchitecture`, asi que toda la nave crecio con el. La celda con sus servicios llega
a `z = -23.6`, contra `z = -25` de nave.

El **tramo A (ST 010 -> ST 150 Cleaning) va en la fila del lado de la planta** (`z = -15.2`)
y el **tramo B de retorno (ST 150 Preheating -> ST 230) en la fila del fondo** (`z = -21`).
Los dos miran al pasillo interior en `z = -18.1`. Es decir: caminando por el pasillo
central, la fila que ves de frente es la del inicio del proceso. Verificado: **cero choques** entre las cajas de colision de
FASSY y las de SMT, backend, conformal, glue, XRAY, ICT, router, arquitectura y centro de
informacion.

## El elevador: entrada, inicio y final

El elevador es un **portico amarillo de esquinas rectas** que cruza la celda de lado a lado
sobre Z, en `x = 75.6`, en el extremo este de la celda. Es el eje alrededor del cual se acomodo toda la linea, y queda en el
**extremo oeste de la celda, por donde llega el visitante**: lo primero que ve el visitante es el
inicio del proceso, no el final.

- **Unico acceso a pie.** Se camina por debajo del vano, siguiendo el pasillo amarillo que
  llega desde el pasillo central. El prop lleva `solid: false`, asi que solo sus dos
  columnas generan colision.
- **Inicio del flujo.** Por la columna del lado del tramo A sube el producto y un conveyor
  corto lo entrega a ST 010 Cleaning.
- **Final del flujo.** Por la columna del lado del tramo B baja el producto terminado que
  entrega ST 230, hacia el Delivery Point W.H. que quedo junto a la entrada.

Para que la celda cierre ahi, el **tramo B calcula su separacion entre estaciones**
(`GAP_B` en `fassyLine.ts`): lleva 12 estaciones contra las 20 del tramo A, asi que se
reparte la diferencia para que ambos tramos midan lo mismo. Resultado verificado:
ST 010 Cleaning y ST 230 cierran los dos en `x = 74.40`, pegados al elevador.

La **GRUA** del retorno se dejo en el extremo cerrado (`x = 34.9`), en acero gris. El
elevador tambien es de aluminio con acentos negros y malla metalica, como el acceso real
de piso: en la nave el amarillo se reserva al pintado de circulacion.

## Estaciones

### Tramo A — ensamble (`z = 6.9`)

| Tag | Proceso (rotulo del layout) | Tipo | x |
| --- | --- | --- | --- |
| ST 010 | Cleaning | `cleaning-station` | 73.80 |
| ST 010 | Manual screwing | `manual-workstation` | 14.70 |
| ST 020 | Manual screwing | `manual-workstation` | 12.80 |
| ST 030 | Manual screwing | `manual-workstation` | 10.90 |
| ST 030 | Flipping | `flipping-cell` | 9.05 |
| ST 040 | Cleaning | `cleaning-station` | 7.40 |
| ST 040 | *(sin rotulo)* | `automated-cell` | 5.50 |
| ST 050 | IMS board screwing | `screwdriving-cell` | 3.35 |
| ST 060 | IMS board screwing | `screwdriving-cell` | 1.35 |
| ST 070 | IMS board screwing | `screwdriving-cell` | −0.65 |
| ST 080 | Cleaning | `cleaning-station` | −2.40 |
| ST 080 | Pick & Place Power Board | `pick-place-cell` | −4.20 |
| ST 090 | Press Power board / 5 positions check | `press-cell` | −6.60 |
| ST 100 | Power board screwing | `screwdriving-cell` | −8.95 |
| ST 110 | Power board screwing | `screwdriving-cell` | −10.95 |
| ST 120 | Cleaning | `cleaning-station` | −12.70 |
| ST 120 | *(sin rotulo)* | `automated-cell` | −14.70 |
| ST 130 | PFC choke press + screwing | `press-cell` | −17.05 |
| ST 140 | Cam. check and label scanning | `vision-cell` | −19.10 |
| ST 150 | Cleaning | `cleaning-station` | −20.80 |

### Retorno

`TR 01` en `x = −22.50`, bajo la GRUA. Corre sobre Z, por eso su `size` ya viene en ejes
de planta y no se rota: las cajas de colision estan alineadas a los ejes.

### Tramo B — potting y filtros (`z = 12.7`)

Separacion entre estaciones calculada (`GAP_B ≈ 1.24 m`) para cerrar en el elevador.

| Tag | Proceso (rotulo del layout) | Tipo | x |
| --- | --- | --- | --- |
| ST 150 | Preheating | `preheating-oven` | −20.10 |
| ST 150 | Potting | `potting-cell` | −17.30 |
| ST 150 | Curing | `curing-oven` | −14.30 |
| ST 160 | *(sin rotulo)* | `automated-cell` | −11.20 |
| ST 170 | AC filter board placing + sealing | `sealing-cell` | −8.60 |
| ST 180 | DC filter board placing + sealing | `sealing-cell` | −6.30 |
| ST 190 | AC filter board screwing | `screwdriving-cell` | −4.10 |
| ST 200-1 | AC/DC connector assembly | `manual-workstation` | −2.00 |
| ST 200-2 | AC/DC connector screwing | `screwdriving-cell` | 0.10 |
| ST 210 | Cleaning | `cleaning-station` | 1.90 |
| ST 220 | *(sin rotulo)* | `automated-cell` | 3.70 |
| ST 230 | *(sin rotulo)* | `automated-cell` | 5.80 |

Al cierre: **Delivery Point W.H.** (`rack-wall`).

## Servicios de piso

Del layout: Feeder (9), Aspiradora (5), Equipment (2), Bomba Vacio (2), Potting MPS,
Escalera, Supervisor, Rework (2), mas carros KLT, tarimas y bancos ESD. Todos usan un solo
componente parametrizado (`ServiceCabinet`), porque lo unico que los distingue es el rotulo.

## Detalle de las primeras 15 estaciones

Reconstruidas a partir de las fotos de piso:

- **Portico blanco** sobre cada estacion con la **placa azul** del tag real y la torreta
  roja/ambar/verde arriba a la izquierda.
- **Ejes verticales verdes** con corredera y cadena portacables negra, mas las columnas
  verdes de los montantes.
- **Dos HMI en brazo negro** articulado: diagrama de placa a la izquierda, palomita de
  "Pieza OK" a la derecha.
- **Cabinas de policarbonato** (`glass-cell`) para **ST 035, ST 040 y ST 090**: montantes de
  perfil con ranura negra, puertas abatibles con manija negra y bisagras, travesano con la
  placa azul y los rotulos de variante (`S / SC` en ST 035, `CC / SC` en ST 040).
- **ST 035** se agrego: aparece rotulada en piso aunque no viene en el layout.
- **Alimentador de tornillos** tipo easyfeed junto a las estaciones de atornillado.
- **Bandeja ESD rosa** con tarjetas verdes en ST 080 y en la estacion de vision.
- **Tapete antifatiga** negro y **escuadras amarillas** de posicion en el piso.
- Bajo la mesa: motor, caja roja, bolsa blanca de recoleccion, contenedor de basura y
  manguera de servicio.

## Detalle del tramo de retorno

Tambien reconstruido desde las fotos:

- **ST 150 Potting**: maquina bdtronic con cuerpo blanco de lamina, camara de vacio con
  **dos mirillas circulares atornilladas**, capota superior con ventana de proceso, columna
  lateral con HMI y torreta sobre poste.
- **ST 150 Curing**: **horno HOLS**, cuerpo gris con **seis camaras** de puertas con palanca
  negra y bisagras, logo rojo, columna de control con panel Beckhoff y dos ductos de
  extraccion en espiral al techo. Con su **escalerilla** de dos peldanos al costado.
- **ST 120, ST 160 y ST 200-2**: cabinas cerradas. ST 120 y ST 160 son de dispensado
  bdtronic con **etiquetas amarillas de canal** (CH1 a CH4) y sus mangueras; ST 160 es la
  cabina doble rotulada ST 160-1 / ST 160-2. ST 200-2 es la de atornillado con controladores.
- **ST 140** paso a cabina cerrada sobre ruedas con rotulo CC.
- **ST 170, ST 180 y ST 190** siguen como estaciones de portico abierto.
- **ST 200-1** se ensancho a 2.4 m, con la mampara de fondo.
- **Tambos rojos de residuos peligrosos** con bolsa negra y escuadras amarillas, en ST 170
  y ST 210, como en piso.

## Material del inicio de linea

Diez pilas de **contenedores KLT negros KOSTAL** sobre tarima, con etiqueta blanca y logo
ESD, repartidas en la entrada (contenedores vacios, finished goods) y a lo largo del
pasillo interior, mas un **carro vacio** de perfil de aluminio. Corresponden a las areas
*Empty Container*, *Empty Trolley* y *Finished Goods FASSY* del layout.

## ⚠ Pendiente de confirmar

- **ST 035, ST 040, ST 120, ST 160, ST 220 y ST 230** aparecen en el layout como cajas de estacion
  **sin rotulo de proceso**. Estan como celda automatica generica y su `description` lo dice.
  Para corregir: `name`, `shortName`, `description` y, si aplica, `type` en `fassyLine.ts`.
- Los anchos de estacion son proporcionales a las cajas del plano, no cotas medidas.
- Los `hazards` se infirieron del tipo de proceso, no del Mapa de Riesgos estacion por estacion.

## Verificacion

`npx tsc -b` sin errores · `npx vite build` 595 modulos · `npx oxlint` 0 errores.

Geometria comprobada sobre las cajas de colision reales: 33 equipos y 39 props, 0 solapes
por carril, corredor de entrada libre de `x = 25` a `x = 14` bajo el elevador, pasillo
interior transitable de punta a punta (97 de 98 puntos libres en `z = 9.8`), y camino
caminable desde el pasillo del SMT hasta el inicio en ST 010, el fondo de la celda y el
final en ST 230.

**Las coordenadas x de las tablas de arriba son de una version anterior.** La celda vive en la bahia
oeste y el tramo A crece hacia -X, asi que todas se desplazaron. El orden de estaciones y los procesos no cambiaron. La fuente de
verdad es `fassyLine.ts`.

## Pendiente opcional

La celda quedo detras de backend, a unos 18 m del pasillo principal. Si quieres saltar ahi desde el menu de pausa,
hay que agregar un destino en `src/data/navigationMenu.ts`; no se toco ese archivo para no
modificar nada del proyecto existente.
