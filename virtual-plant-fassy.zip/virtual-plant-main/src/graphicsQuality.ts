import { createContext, useContext } from 'react'
import type { GraphicsQuality } from './types/factory'

export interface GraphicsQualitySettings {
  quality: GraphicsQuality
  dpr: [number, number]
  shadowsEnabled: boolean
  shadowMapSize: number
  antialias: boolean
  pcbAnimationsEnabled: boolean
}

export const GRAPHICS_QUALITY_SETTINGS: Record<GraphicsQuality, GraphicsQualitySettings> = {
  low: {
    quality: 'low',
    dpr: [0.75, 1],
    shadowsEnabled: false,
    shadowMapSize: 512,
    antialias: false,
    pcbAnimationsEnabled: false,
  },
  medium: {
    quality: 'medium',
    dpr: [0.75, 1.25],
    shadowsEnabled: true,
    shadowMapSize: 1024,
    antialias: true,
    pcbAnimationsEnabled: true,
  },
  high: {
    quality: 'high',
    dpr: [1, 1.5],
    shadowsEnabled: true,
    shadowMapSize: 1536,
    antialias: true,
    pcbAnimationsEnabled: true,
  },
}

export const GraphicsQualityContext = createContext<GraphicsQualitySettings>(
  GRAPHICS_QUALITY_SETTINGS.medium,
)

export function useGraphicsQuality() {
  return useContext(GraphicsQualityContext)
}
