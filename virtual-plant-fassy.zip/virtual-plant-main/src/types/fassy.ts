import type { Bounds2D, CollisionBox, FloorDisplayStationConfig, Vec3 } from './factory'

export type { Bounds2D, CollisionBox, FloorDisplayStationConfig, Vec3 }

/** Tipos de equipo propios de la linea de ensamble final FASSY. */
export type FassyEquipmentType =
  | 'manual-workstation'
  | 'automated-cell'
  | 'cleaning-station'
  | 'flipping-cell'
  | 'pick-place-cell'
  | 'press-cell'
  | 'screwdriving-cell'
  | 'sealing-cell'
  | 'potting-cell'
  | 'preheating-oven'
  | 'curing-oven'
  | 'vision-cell'
  | 'glass-cell'
  | 'potting-machine'
  | 'hols-oven'
  | 'conveyor'

export type FassyHazard =
  | 'moving-parts'
  | 'electrical'
  | 'ergonomic'
  | 'noise'
  | 'hot-surface'
  | 'chemical'

export interface FassyEquipmentConfig {
  id: string
  /** Identificador de estacion del layout, ej. "ST 010". */
  tag: string
  /** Proceso segun el rotulo del layout. */
  name: string
  /** Texto de la placa fisica del equipo. */
  shortName: string
  type: FassyEquipmentType
  description?: string
  hazards?: FassyHazard[]
  position: Vec3
  rotation?: Vec3
  /** [ancho X, alto Y, profundidad Z] en metros. */
  size: Vec3
  accentColor?: string
  showTowerLight?: boolean
  /** Ducto de extraccion hacia el techo. */
  showExtraction?: boolean
  /** Rotulos azules de variante sobre el travesano, ej. ['CC', 'SC']. */
  variantSigns?: [string, string]
  /** Etiquetas amarillas de canal de dispensado, ej. ['CH1', 'CH2', 'CH3']. */
  channelTags?: string[]
}

/** Equipo sin posicion: la resuelve el constructor de tramo. */
export type FassyBlueprint = Omit<FassyEquipmentConfig, 'position' | 'rotation'> & {
  /**
   * Retranqueo en Z hacia el pasillo interior (se multiplica por `facing`).
   * Lo usan las casetas "ST 0X0 Cleaning", que en el layout van hacia el centro.
   */
  zOffset?: number
}

/** Tramo recto de linea sobre el eje X. */
export interface FassySegmentConfig {
  /** Borde de arranque del tramo, no el centro del primer equipo. */
  origin: Vec3
  /** Sentido de avance del producto sobre X. */
  direction: 1 | -1
  /** Hacia donde mira el frente del equipo: 1 => +Z, -1 => -Z. */
  facing: 1 | -1
  gap: number
  items: FassyBlueprint[]
}

export type FassyPropKind =
  | 'service-cabinet'
  | 'material-trolley'
  | 'pallet-stack'
  | 'esd-chair'
  | 'safety-board'
  | 'rack-wall'
  | 'overhead-crane'
  | 'elevator-arch'
  | 'klt-stack'
  | 'empty-trolley'
  | 'waste-drum'
  | 'step-ladder'

export interface FassyPropConfig {
  id: string
  kind: FassyPropKind
  position: Vec3
  rotation?: Vec3
  label?: string
  size?: Vec3
  accentColor?: string
  /** false => no bloquea el paso (arco del elevador, grua de portico). */
  solid?: boolean
}

export interface FassyPartConfig {
  id: string
  position: Vec3
  rotation?: Vec3
  animation?: {
    axis: 'x' | 'z' | 'y'
    from: number
    to: number
    speed: number
    pingPong?: boolean
  }
}
