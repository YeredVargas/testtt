import type { Bounds2D, CollisionBox, DisplayMedia, Vec3 } from './factory'

export type GlueEquipmentType = 'glue-table' | 'glue-machine' | 'glue-oia'

export interface GlueEquipmentConfig {
  id: string
  name: string
  shortName: string
  type: GlueEquipmentType
  position: Vec3
  rotation?: Vec3
  size: Vec3
  conveyorHeight?: number
  screenSource?: string
}

export interface GlueMonitorConfig {
  id: string
  title: string
  promptText: string
  position: Vec3
  rotation?: Vec3
  size: [number, number]
  media: DisplayMedia
}

export interface GlueConveyorConfig {
  id: string
  position: Vec3
  length: number
}

export interface GlueProcessCellConfig {
  id: string
  name: string
  area: 'backend'
  referenceProcessId: 'xray-inspection-cell'
  position: Vec3
  rotation: Vec3
  equipment: GlueEquipmentConfig[]
  monitor: GlueMonitorConfig
}

export interface GlueProcessCellLayout {
  safetyZone: Bounds2D
  processZones: Array<Bounds2D & { id: string }>
  collisionBoxes: CollisionBox[]
}
