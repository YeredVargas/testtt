import type { CollisionBox, DisplayMedia, Vec3 } from './factory'

export interface ColumnMountedDisplayConfig {
  id: string
  title: string
  position: Vec3
  rotation: Vec3
  width: number
  height: number
  depth: number
  media: DisplayMedia
}

export interface StructuralColumnConfig {
  id: string
  position: Vec3
  size: Vec3
  rotation?: Vec3
  display?: ColumnMountedDisplayConfig
}

export interface CeilingConfig {
  center: Vec3
  width: number
  depth: number
  height: number
  thickness: number
  tileSize: number
  gridLineWidth: number
  lightSpacingX: number
  lightSpacingZ: number
  lightMarginX: number
  lightMarginZ: number
  lightSize: Vec3
}

export interface VendingMachineConfig {
  id: string
  position: Vec3
  rotation: Vec3
  size: Vec3
  color: string
  accentColor: string
  label: string
  productRows: number
  productColumns: number
}

export interface ServiceWallConfig {
  id: string
  position: Vec3
  size: Vec3
  color: string
}

export interface FactoryArchitectureConfig {
  ceiling: CeilingConfig
  columns: StructuralColumnConfig[]
  vendingMachines: VendingMachineConfig[]
  walls: ServiceWallConfig[]
}

export interface FactoryArchitectureLayout {
  config: FactoryArchitectureConfig
  collisionBoxes: CollisionBox[]
  conformalOiaWorldPosition: Vec3
}
