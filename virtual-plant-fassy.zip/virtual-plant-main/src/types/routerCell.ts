import type { Bounds2D, CollisionBox, Vec3 } from './factory'

export type RouterCellEquipmentType = 'router-table' | 'router-machine' | 'waste-bin'

export interface RouterCellEquipmentConfig {
  id: string
  name: string
  type: RouterCellEquipmentType
  position: Vec3
  rotation?: Vec3
  size: Vec3
}

export interface RouterProcessCellConfig {
  id: string
  name: string
  area: 'backend'
  position: Vec3
  rotation: Vec3
  equipment: RouterCellEquipmentConfig[]
}

export interface RouterProcessCellLayout {
  safetyZone: Bounds2D
  collisionBoxes: CollisionBox[]
}
