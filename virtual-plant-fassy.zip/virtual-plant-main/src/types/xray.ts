import type { Bounds2D, CollisionBox, DisplayMedia, Vec3 } from './factory'

export type XrayCellEquipmentType = 'inspection-table' | 'xray' | 'xia'

export interface XrayCellEquipmentConfig {
  id: string
  name: string
  shortName: string
  type: XrayCellEquipmentType
  position: Vec3
  rotation?: Vec3
  size: Vec3
}

export interface XrayInspectionMonitorConfig {
  id: string
  title: string
  promptText: string
  position: Vec3
  rotation?: Vec3
  size: [number, number]
  media: DisplayMedia
}

export interface XrayInspectionCellConfig {
  id: string
  name: string
  area: 'backend'
  lineId: string
  referenceProcessId: 'backend-oia'
  position: Vec3
  rotation: Vec3
  equipment: XrayCellEquipmentConfig[]
  monitor: XrayInspectionMonitorConfig
  clearanceFromOia: number
  localBounds: Bounds2D
}

export interface XrayInspectionCellLayout {
  id: string
  referenceProcessPosition: Vec3
  safetyZone: Bounds2D
  collisionBoxes: CollisionBox[]
}
