export type Vec3 = [number, number, number]
export type Quat4 = [number, number, number, number]
export type GraphicsQuality = 'low' | 'medium' | 'high'

export type CameraDebugState = {
  locked: boolean
  position: Vec3
  rotation: Vec3
}

export type SmtEquipmentType =
  | 'laser'
  | 'solder-paste-printer'
  | 'conveyor'
  | 'spi'
  | 'pick-and-place'
  | 'reflow-oven'
  | 'aoi'
  | 'flashing'
  | 'ict-inline'
  | 'router'

export interface SmtEquipmentConfig {
  id: string
  name: string
  shortName: string
  type: SmtEquipmentType
  position: Vec3
  rotation?: Vec3
  size: Vec3
  accentColor?: string
  showTowerLight?: boolean
}

export type ScreenFit = 'contain' | 'cover'

export type DisplayMedia =
  | {
      type: 'auto' | 'image'
      source: string
      fallback?: string
      fit?: ScreenFit
    }
  | {
      type: 'video'
      source: string
      fallback?: string
      fit?: ScreenFit
      loop?: boolean
      muted?: boolean
      autoplay?: boolean
    }

export interface FloorDisplayStationConfig {
  id: string
  title: string
  processId?: string
  position: Vec3
  rotation?: Vec3
  width?: number
  height?: number
  promptText?: string
  media: DisplayMedia
}

export interface MediaModalData {
  id: string
  title: string
  source: string
  mediaType: 'image' | 'gif' | 'video'
}

export interface CameraSnapshot {
  position: Vec3
  quaternion: Quat4
}

export interface SceneControllerApi {
  lock: () => void
  unlock: () => void
  clearMovement: () => void
  saveCameraState: () => CameraSnapshot
  restoreCameraState: (snapshot: CameraSnapshot | null) => void
  teleportTo: (position: Vec3, lookAt: Vec3) => void
}

export interface NavigationDestination {
  id: string
  label: string
  description: string
  position: Vec3
  lookAt: Vec3
}

export interface NavigationSection {
  id: string
  title: string
  destinations: NavigationDestination[]
}

export interface Bounds2D {
  minX: number
  maxX: number
  minZ: number
  maxZ: number
}

export interface CollisionBox extends Bounds2D {
  id: string
}

export interface PcbAnimationConfig {
  startX: number
  endX: number
  speed: number
}

export interface PcbConfig {
  id: string
  position: Vec3
  rotation?: Vec3
  animation?: PcbAnimationConfig
}
