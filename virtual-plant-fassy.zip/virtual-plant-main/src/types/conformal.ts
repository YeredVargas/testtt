import type { Bounds2D, CollisionBox, Vec3 } from './factory'

export type ConformalEquipmentType =
  | 'conformal-coating'
  | 'uv-oven'
  | 'conformal-aoi'
  | 'conformal-oia'

export interface ConformalEquipmentConfig {
  id: string
  name: string
  shortName: string
  type: ConformalEquipmentType
  position: Vec3
  rotation?: Vec3
  size: Vec3
  conveyorHeight: number
  showTowerLight?: boolean
  accentColor?: string
}

export interface ConformalConveyorConfig {
  id: string
  position: Vec3
  length: number
}

export interface ConformalLineConfig {
  id: string
  name: string
  area: 'backend'
  referenceProcessId: string
  position: Vec3
  rotation: Vec3
  equipment: ConformalEquipmentConfig[]
}

export interface ConformalLineLayout {
  safetyZone: Bounds2D
  processZones: Array<Bounds2D & { id: string }>
  collisionBoxes: CollisionBox[]
}
