import type { Bounds2D, CollisionBox, Vec3 } from './factory'

export type IctBackendEquipmentType = 'ict-table' | 'ict-machine'

export interface IctBackendEquipmentConfig {
  id: string
  name: string
  type: IctBackendEquipmentType
  position: Vec3
  rotation?: Vec3
  size: Vec3
}

export interface IctBackendCellConfig {
  id: string
  name: string
  area: 'backend'
  position: Vec3
  rotation: Vec3
  equipment: IctBackendEquipmentConfig[]
}

export interface IctBackendCellLayout {
  safetyZone: Bounds2D
  collisionBoxes: CollisionBox[]
}
