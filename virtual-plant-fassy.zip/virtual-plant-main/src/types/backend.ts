import type { DisplayMedia, Vec3 } from './factory'

export interface ManualAssemblyStationConfig {
  id: string
  number: number
  name: string
  position: Vec3
  rotation?: Vec3
  monitorSide?: 'left' | 'right'
  monitorRotation?: Vec3
  accentColor?: string
  screenMedia: DisplayMedia
  enabled?: boolean
}

export interface ManualAssemblyLineConfig {
  id: string
  name: string
  shortName: string
  area: 'backend'
  position: Vec3
  rotation?: Vec3
  conveyorLength: number
  stations: ManualAssemblyStationConfig[]
}

export interface MaterialRackConfig {
  id: string
  position: Vec3
  rotation?: Vec3
  levels: number
  binsPerLevel: number
  width: number
  height: number
  depth: number
  labelPrefix?: string
}

export interface RearDisplayConfig {
  id: string
  title: string
  position: Vec3
  rotation?: Vec3
  source: string
  width: number
  height: number
  promptText?: string
}

export interface BackendRearAreaConfig {
  id: string
  stationId: 'massy-station-1'
  localOffset: Vec3
  display: RearDisplayConfig
  racks: MaterialRackConfig[]
}

export type BackendProcessType =
  | 'manual-assembly'
  | 'wave-solder'
  | 'backend-aoi'
  | 'oia-station'
  | 'backend-conveyor'

export interface BackendProcessConfig {
  id: string
  name: string
  shortName: string
  type: BackendProcessType
  position: Vec3
  rotation?: Vec3
  size: Vec3
  connectedFrom?: string
  connectedTo?: string
}
