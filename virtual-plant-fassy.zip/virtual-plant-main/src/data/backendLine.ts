import type { PcbConfig } from '../types/factory'
import type { ManualAssemblyLineConfig } from '../types/backend'
import { getSmtEquipment } from './smtLine'

export const SHOW_OPERATOR_PLACEHOLDERS = false
export const ENABLE_BACKEND_PCB_ANIMATION = true
export const BACKEND_TRANSFER_GAP = 4
export const BACKEND_LINE_AISLE_GAP = 1.4
export const MANUAL_ASSEMBLY_CONVEYOR_HEIGHT = 0.9
export const STATION_COUNT = 6
export const STATION_PITCH = 2.15
export const MANUAL_ASSEMBLY_CONVEYOR_WIDTH = 0.65
export const MASSY_LENGTH = STATION_PITCH * STATION_COUNT + 0.8
export const MASSY_OPERATOR_ZONE_Z = 1.95
export const MASSY_OPERATOR_LANE_MIN_Z = 1.28
export const MASSY_OPERATOR_LANE_MAX_Z = 2.62
const SECOND_LINE_REAR_CLEARANCE = 1.1

const router = getSmtEquipment('router')
const routerEndX = router.position[0] + router.size[0] / 2
const massyCenterX = routerEndX + BACKEND_TRANSFER_GAP + MASSY_LENGTH / 2

export const BACKEND_AREA_POSITION: [number, number, number] = [massyCenterX, 0, router.position[2]]
export const BACKEND_AREA_ROTATION: [number, number, number] = [0, 0, 0]
export const SECOND_BACKEND_LINE_Z =
  BACKEND_AREA_POSITION[2] + MASSY_OPERATOR_LANE_MAX_Z + BACKEND_LINE_AISLE_GAP + SECOND_LINE_REAR_CLEARANCE

const stationStartX = -((STATION_COUNT - 1) * STATION_PITCH) / 2

export const manualAssemblyLineConfig: ManualAssemblyLineConfig = {
  id: 'backend-massy-line-1',
  name: 'Backend Manual Assembly',
  shortName: 'MASSY',
  area: 'backend',
  position: BACKEND_AREA_POSITION,
  rotation: BACKEND_AREA_ROTATION,
  conveyorLength: MASSY_LENGTH,
  stations: Array.from({ length: STATION_COUNT }, (_, index) => ({
    id: `massy-station-${index + 1}`,
    number: index + 1,
    name: `ESTACION ${index + 1}`,
    position: [stationStartX + index * STATION_PITCH, 0, 0],
    monitorSide: 'right',
    monitorRotation: [-0.12, 0, 0],
    accentColor: '#234a78',
    screenMedia: {
      type: 'image',
      source: `/media/backend/station-${index + 1}.svg`,
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
    enabled: true,
  })),
}

export const secondManualAssemblyLineConfig: ManualAssemblyLineConfig = {
  ...manualAssemblyLineConfig,
  id: 'backend-massy-line-2',
  position: [BACKEND_AREA_POSITION[0], 0, SECOND_BACKEND_LINE_Z],
  rotation: BACKEND_AREA_ROTATION,
  stations: manualAssemblyLineConfig.stations.map((station) => ({
    ...station,
    id: station.id.replace('massy-', 'massy-line-2-'),
  })),
}

export const backendLineConfigs = [manualAssemblyLineConfig, secondManualAssemblyLineConfig] as const

export const backendPcbBoards: PcbConfig[] = [
  {
    id: 'backend-pcb-1',
    position: [stationStartX - 0.45, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT + 0.03, 0],
    animation: {
      startX: -MASSY_LENGTH / 2 + 0.4,
      endX: MASSY_LENGTH / 2 - 0.4,
      speed: 0.4,
    },
  },
  {
    id: 'backend-pcb-2',
    position: [stationStartX + STATION_PITCH * 1.25, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT + 0.03, 0],
  },
  {
    id: 'backend-pcb-3',
    position: [0, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT + 0.03, 0],
    animation: {
      startX: -MASSY_LENGTH / 2 + 2.2,
      endX: MASSY_LENGTH / 2 - 0.6,
      speed: 0.3,
    },
  },
  {
    id: 'backend-pcb-4',
    position: [stationStartX + STATION_PITCH * 3.2, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT + 0.03, 0],
  },
  {
    id: 'backend-pcb-5',
    position: [stationStartX + STATION_PITCH * 4.55, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT + 0.03, 0],
  },
  {
    id: 'backend-pcb-6',
    position: [MASSY_LENGTH / 2 - 0.55, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT + 0.03, 0],
  },
]

export const backendAreaBounds = {
  minX: BACKEND_AREA_POSITION[0] - MASSY_LENGTH / 2 - 1.2,
  maxX: BACKEND_AREA_POSITION[0] + MASSY_LENGTH / 2 + 43.0,
  minZ: BACKEND_AREA_POSITION[2] - 13.2,
  maxZ: SECOND_BACKEND_LINE_Z + 10.0,
}

export const transferAreaBounds = {
  minX: routerEndX + 0.5,
  maxX: BACKEND_AREA_POSITION[0] - MASSY_LENGTH / 2 - 0.5,
  minZ: router.position[2] - 1.2,
  maxZ: router.position[2] + 1.8,
}
