import { backendSocketToConformalConnection, backendStandaloneEquipment } from './backendStandaloneEquipment'
import { xrayInspectionCellConfigs, xrayInspectionCellLayouts } from './xrayInspectionCell'
import type { Vec3 } from '../types/factory'
import type {
  ConformalConveyorConfig,
  ConformalEquipmentConfig,
  ConformalLineConfig,
  ConformalLineLayout,
} from '../types/conformal'

export const CONFORMAL_CONVEYOR_HEIGHT = 0.9

const laserBackend = backendStandaloneEquipment.find((equipment) => equipment.id === 'backend-laser-standalone')
const socketInsertion = backendStandaloneEquipment.find((equipment) => equipment.id === 'backend-socket-insertion')
const primaryXrayCell = xrayInspectionCellConfigs[0]
const primaryXrayLayout = xrayInspectionCellLayouts[0]

if (!laserBackend || !socketInsertion || !primaryXrayCell || !primaryXrayLayout) {
  throw new Error('Missing backend references for conformal coating line')
}

const COATING_LENGTH = 2.65
const COATING_DEPTH = 1.68
const UV_OVEN_LENGTH = 5.8
const UV_OVEN_DEPTH = 1.72
const CONFORMAL_AOI_LENGTH = 1.82
const CONFORMAL_OIA_LENGTH = 1.86
const INSPECTION_DEPTH = 1.46
const BETWEEN_COATING_LENGTH = 0.72
const COATING_TO_UV_LENGTH = 0.78
const UV_TO_AOI_LENGTH = 0.74
const AOI_TO_OIA_LENGTH = 0.68
const OIA_OUTPUT_LENGTH = 0.82

const socketOutputX = socketInsertion.position[0] + socketInsertion.size[0] / 2
const conformalRearZ = laserBackend.position[2]
const xrayRearClearance = primaryXrayLayout.safetyZone.minZ - (conformalRearZ + COATING_DEPTH / 2)
const xrayTableStartX = primaryXrayCell.position[0] - primaryXrayCell.equipment[0].size[0] / 2

if (xrayRearClearance < 2.5) {
  throw new Error('Conformal line does not have enough clearance behind XRAY')
}

const conformalStartX = Math.max(
  socketOutputX + backendSocketToConformalConnection.length + COATING_LENGTH / 2,
  xrayTableStartX + COATING_LENGTH / 2,
)

function equipment(id: string, name: string, shortName: string, type: ConformalEquipmentType, position: Vec3, size: Vec3, accentColor?: string): ConformalEquipmentConfig {
  return {
    id,
    name,
    shortName,
    type,
    position,
    size,
    conveyorHeight: CONFORMAL_CONVEYOR_HEIGHT,
    showTowerLight: true,
    accentColor,
  }
}

type ConformalEquipmentType = ConformalEquipmentConfig['type']

const coating1Position: Vec3 = [0, 0, 0]
const coating2Position: Vec3 = [COATING_LENGTH / 2 + BETWEEN_COATING_LENGTH + COATING_LENGTH / 2, 0, 0]
const uvOvenPosition: Vec3 = [coating2Position[0] + COATING_LENGTH / 2 + COATING_TO_UV_LENGTH + UV_OVEN_LENGTH / 2, 0, 0]
const aoiPosition: Vec3 = [uvOvenPosition[0] + UV_OVEN_LENGTH / 2 + UV_TO_AOI_LENGTH + CONFORMAL_AOI_LENGTH / 2, 0, 0]
const oiaPosition: Vec3 = [aoiPosition[0] + CONFORMAL_AOI_LENGTH / 2 + AOI_TO_OIA_LENGTH + CONFORMAL_OIA_LENGTH / 2, 0, 0]

export const conformalLineConfig: ConformalLineConfig = {
  id: 'backend-conformal-coating-line',
  name: 'Conformal Coating Line',
  area: 'backend',
  referenceProcessId: socketInsertion.id,
  position: [conformalStartX, 0, conformalRearZ],
  rotation: [0, 0, 0],
  equipment: [
    equipment('conformal-coating-1', 'Conformal Coating 1', 'CONFORMAL COATING 1', 'conformal-coating', coating1Position, [COATING_LENGTH, 2.08, COATING_DEPTH], '#0f7ea3'),
    equipment('conformal-coating-2', 'Conformal Coating 2', 'CONFORMAL COATING 2', 'conformal-coating', coating2Position, [COATING_LENGTH, 2.06, COATING_DEPTH], '#2563eb'),
    equipment('conformal-uv-oven', 'UV Oven Conformal', 'UV OVEN CONFORMAL', 'uv-oven', uvOvenPosition, [UV_OVEN_LENGTH, 1.9, UV_OVEN_DEPTH], '#6d5bd0'),
    equipment('conformal-aoi', 'AOI Conformal', 'AOI CONFORMAL', 'conformal-aoi', aoiPosition, [CONFORMAL_AOI_LENGTH, 2.18, INSPECTION_DEPTH], '#39d26d'),
    equipment('conformal-oia', 'OIA Conformal', 'OIA CONFORMAL', 'conformal-oia', oiaPosition, [CONFORMAL_OIA_LENGTH, 2.12, INSPECTION_DEPTH], '#234a78'),
  ],
}

export const conformalConveyors: ConformalConveyorConfig[] = [
  {
    id: 'laser-to-conformal-1',
    position: [-(COATING_LENGTH / 2 + backendSocketToConformalConnection.length / 2), 0, 0],
    length: backendSocketToConformalConnection.length,
  },
  {
    id: 'conformal-1-to-2',
    position: [coating1Position[0] + COATING_LENGTH / 2 + BETWEEN_COATING_LENGTH / 2, 0, 0],
    length: BETWEEN_COATING_LENGTH,
  },
  {
    id: 'conformal-2-to-uv',
    position: [coating2Position[0] + COATING_LENGTH / 2 + COATING_TO_UV_LENGTH / 2, 0, 0],
    length: COATING_TO_UV_LENGTH,
  },
  {
    id: 'uv-to-aoi',
    position: [uvOvenPosition[0] + UV_OVEN_LENGTH / 2 + UV_TO_AOI_LENGTH / 2, 0, 0],
    length: UV_TO_AOI_LENGTH,
  },
  {
    id: 'aoi-to-oia',
    position: [aoiPosition[0] + CONFORMAL_AOI_LENGTH / 2 + AOI_TO_OIA_LENGTH / 2, 0, 0],
    length: AOI_TO_OIA_LENGTH,
  },
  {
    id: 'oia-output',
    position: [oiaPosition[0] + CONFORMAL_OIA_LENGTH / 2 + OIA_OUTPUT_LENGTH / 2, 0, 0],
    length: OIA_OUTPUT_LENGTH,
  },
]

export const conformalPcbPositions: Vec3[] = [
  [-COATING_LENGTH * 0.14, CONFORMAL_CONVEYOR_HEIGHT + 0.03, 0],
  [coating1Position[0] + COATING_LENGTH / 2 + BETWEEN_COATING_LENGTH / 2, CONFORMAL_CONVEYOR_HEIGHT + 0.03, 0],
  [coating2Position[0] + COATING_LENGTH * 0.08, CONFORMAL_CONVEYOR_HEIGHT + 0.03, 0],
  [uvOvenPosition[0] - UV_OVEN_LENGTH * 0.2, CONFORMAL_CONVEYOR_HEIGHT + 0.03, 0],
  [uvOvenPosition[0] + UV_OVEN_LENGTH * 0.16, CONFORMAL_CONVEYOR_HEIGHT + 0.03, 0],
  [aoiPosition[0], CONFORMAL_CONVEYOR_HEIGHT + 0.03, 0],
  [oiaPosition[0] + CONFORMAL_OIA_LENGTH / 2 + OIA_OUTPUT_LENGTH / 2, CONFORMAL_CONVEYOR_HEIGHT + 0.03, 0],
]

function worldRect(minX: number, maxX: number, minZ: number, maxZ: number) {
  return {
    minX: conformalLineConfig.position[0] + minX,
    maxX: conformalLineConfig.position[0] + maxX,
    minZ: conformalLineConfig.position[2] + minZ,
    maxZ: conformalLineConfig.position[2] + maxZ,
  }
}

const safetyLocal = {
  minX: -(COATING_LENGTH / 2 + backendSocketToConformalConnection.length + 0.55),
  maxX: oiaPosition[0] + CONFORMAL_OIA_LENGTH / 2 + OIA_OUTPUT_LENGTH + 0.7,
  minZ: -1.58,
  maxZ: 1.38,
}

export const conformalLineLayout: ConformalLineLayout = {
  safetyZone: worldRect(safetyLocal.minX, safetyLocal.maxX, safetyLocal.minZ, safetyLocal.maxZ),
  processZones: conformalLineConfig.equipment.map((process) => ({
    id: `${process.id}-zone`,
    ...worldRect(
      process.position[0] - process.size[0] / 2 - 0.36,
      process.position[0] + process.size[0] / 2 + 0.36,
      process.position[2] - process.size[2] / 2 - 0.48,
      process.position[2] + process.size[2] / 2 + 0.48,
    ),
  })),
  collisionBoxes: conformalLineConfig.equipment.map((process) => {
    const bounds = worldRect(
      process.position[0] - process.size[0] / 2 - 0.08,
      process.position[0] + process.size[0] / 2 + 0.08,
      process.position[2] - process.size[2] / 2 - 0.08,
      process.position[2] + process.size[2] / 2 + 0.08,
    )

    return {
      id: `${process.id}-blocker`,
      ...bounds,
    }
  }),
}
