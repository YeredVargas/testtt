import { routerProcessCellConfig, routerProcessCellLayout } from './routerProcessCell'
import type { Vec3 } from '../types/factory'
import type { IctBackendCellConfig, IctBackendCellLayout, IctBackendEquipmentConfig } from '../types/ictBackend'

const tableSize: Vec3 = [1.7, 0.92, 0.82]
const machineSize: Vec3 = [1.74, 1.42, 1.2]
const tableToMachineGap = 0.34
const routerToIctFrontGap = 2.4

const ictCellPosition: Vec3 = [
  routerProcessCellConfig.position[0] + 0.45,
  0,
  routerProcessCellLayout.safetyZone.maxZ + routerToIctFrontGap,
]

function equipment(id: string, name: string, type: IctBackendEquipmentConfig['type'], position: Vec3, size: Vec3): IctBackendEquipmentConfig {
  return { id, name, type, position, size }
}

const tablePosition: Vec3 = [0, 0, 0]
const machinePosition: Vec3 = [tableSize[0] / 2 + tableToMachineGap + machineSize[0] / 2, 0, 0]

export const ictBackendCellConfig: IctBackendCellConfig = {
  id: 'backend-ict-process-cell',
  name: 'ICT Backend',
  area: 'backend',
  position: ictCellPosition,
  rotation: [0, 0, 0],
  equipment: [
    equipment('ict-backend-table', 'ICT Backend Table', 'ict-table', tablePosition, tableSize),
    equipment('ict-backend-machine', 'ICT Backend Machine', 'ict-machine', machinePosition, machineSize),
  ],
}

function worldRect(minX: number, maxX: number, minZ: number, maxZ: number) {
  return {
    minX: ictBackendCellConfig.position[0] + minX,
    maxX: ictBackendCellConfig.position[0] + maxX,
    minZ: ictBackendCellConfig.position[2] + minZ,
    maxZ: ictBackendCellConfig.position[2] + maxZ,
  }
}

export const ictBackendCellLayout: IctBackendCellLayout = {
  safetyZone: worldRect(-tableSize[0] / 2 - 0.7, machinePosition[0] + machineSize[0] / 2 + 0.7, -0.95, 1.25),
  collisionBoxes: [
    { id: 'ict-backend-table-blocker', ...worldRect(-tableSize[0] / 2 - 0.08, tableSize[0] / 2 + 0.08, -tableSize[2] / 2 - 0.08, tableSize[2] / 2 + 0.08) },
    { id: 'ict-backend-machine-blocker', ...worldRect(machinePosition[0] - machineSize[0] / 2 - 0.08, machinePosition[0] + machineSize[0] / 2 + 0.08, -machineSize[2] / 2 - 0.08, machineSize[2] / 2 + 0.08) },
  ],
}
