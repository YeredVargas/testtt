import { glueProcessCellConfig, glueProcessCellLayout } from './glueProcessCell'
import type { RouterCellEquipmentConfig, RouterProcessCellConfig, RouterProcessCellLayout } from '../types/routerCell'
import type { Vec3 } from '../types/factory'

const tableSize: Vec3 = [1.7, 0.92, 0.82]
const machineSize: Vec3 = [2.4, 2.18, 1.74]
const binSize: Vec3 = [0.72, 0.82, 0.62]
const tableToMachineGap = 0.36
const glueToRouterFrontGap = 4.2

const routerCellPosition: Vec3 = [
  glueProcessCellConfig.position[0] + 1.2,
  0,
  glueProcessCellLayout.safetyZone.maxZ + glueToRouterFrontGap,
]

function equipment(id: string, name: string, type: RouterCellEquipmentConfig['type'], position: Vec3, size: Vec3): RouterCellEquipmentConfig {
  return { id, name, type, position, size }
}

const tablePosition: Vec3 = [0, 0, 0]
const machinePosition: Vec3 = [tableSize[0] / 2 + tableToMachineGap + machineSize[0] / 2, 0, 0]
const binPosition: Vec3 = [machinePosition[0] + machineSize[0] / 2 - 0.18, 0, 0.92]

export const routerProcessCellConfig: RouterProcessCellConfig = {
  id: 'backend-router-process-cell',
  name: 'Router Process Cell',
  area: 'backend',
  position: routerCellPosition,
  rotation: [0, 0, 0],
  equipment: [
    equipment('router-process-table', 'Router Green Table', 'router-table', tablePosition, tableSize),
    equipment('router-process-machine', 'Router Backend Machine', 'router-machine', machinePosition, machineSize),
    equipment('router-waste-bin', 'Router Waste Bin', 'waste-bin', binPosition, binSize),
  ],
}

function worldRect(minX: number, maxX: number, minZ: number, maxZ: number) {
  return {
    minX: routerProcessCellConfig.position[0] + minX,
    maxX: routerProcessCellConfig.position[0] + maxX,
    minZ: routerProcessCellConfig.position[2] + minZ,
    maxZ: routerProcessCellConfig.position[2] + maxZ,
  }
}

export const routerProcessCellLayout: RouterProcessCellLayout = {
  safetyZone: worldRect(-tableSize[0] / 2 - 0.8, machinePosition[0] + machineSize[0] / 2 + 0.8, -1.0, 1.6),
  collisionBoxes: [
    { id: 'router-table-blocker', ...worldRect(-tableSize[0] / 2 - 0.08, tableSize[0] / 2 + 0.08, -tableSize[2] / 2 - 0.08, tableSize[2] / 2 + 0.08) },
    { id: 'router-machine-blocker', ...worldRect(machinePosition[0] - machineSize[0] / 2 - 0.08, machinePosition[0] + machineSize[0] / 2 + 0.08, -machineSize[2] / 2 - 0.08, machineSize[2] / 2 + 0.08) },
    { id: 'router-bin-blocker', ...worldRect(binPosition[0] - binSize[0] / 2 - 0.04, binPosition[0] + binSize[0] / 2 + 0.04, binPosition[2] - binSize[2] / 2 - 0.04, binPosition[2] + binSize[2] / 2 + 0.04) },
  ],
}
