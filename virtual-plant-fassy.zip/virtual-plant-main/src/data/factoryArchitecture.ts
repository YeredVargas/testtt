import { conformalLineConfig } from './conformalLine'
import { ictBackendCellConfig } from './ictBackendCell'
import { backendSupportTables } from './backendSupportTables'
import { solderPasteSupportArea } from './solderPasteSupportArea'
import { floorSize, lineBounds } from './smtLine'
import type {
  FactoryArchitectureLayout,
  ServiceWallConfig,
  StructuralColumnConfig,
  VendingMachineConfig,
} from '../types/architecture'
import type { CollisionBox, Vec3 } from '../types/factory'

export const SHOW_FACTORY_CEILING = true
export const SHOW_STRUCTURAL_COLUMNS = true
export const SHOW_CEILING_LIGHTS = true

const CEILING_MARGIN = 1.5
const CEILING_HEIGHT = 6.0
const CEILING_THICKNESS = 0.18
const TILE_SIZE = 1.2
const REAR_COLUMN_ROW_Z = -9.75

function rotateY(point: Vec3, rotationY: number): Vec3 {
  const [x, y, z] = point
  const cos = Math.cos(rotationY)
  const sin = Math.sin(rotationY)

  return [x * cos + z * sin, y, -x * sin + z * cos]
}

function translateLocalPoint(origin: Vec3, rotationY: number, localPoint: Vec3): Vec3 {
  const rotated = rotateY(localPoint, rotationY)

  return [origin[0] + rotated[0], origin[1] + rotated[1], origin[2] + rotated[2]]
}

const conformalRotationY = conformalLineConfig.rotation[1] ?? 0
const conformalRearVector = rotateY([0, 0, -1], conformalRotationY)
const conformalFlowVector = rotateY([1, 0, 0], conformalRotationY)
const conformalOia = conformalLineConfig.equipment.find((equipment) => equipment.id === 'conformal-oia')
const ictBackendMachine = ictBackendCellConfig.equipment.find((equipment) => equipment.id === 'ict-backend-machine')

if (!conformalOia || !ictBackendMachine) {
  throw new Error('Missing backend references for factory architecture')
}

export const conformalOiaWorldPosition = translateLocalPoint(
  conformalLineConfig.position,
  conformalRotationY,
  conformalOia.position,
)

const ictBackendWorldPosition = translateLocalPoint(
  ictBackendCellConfig.position,
  ictBackendCellConfig.rotation[1] ?? 0,
  ictBackendMachine.position,
)

const FRONT_COLUMN_ROW_Z =
  ictBackendWorldPosition[2] + ictBackendMachine.size[2] / 2 + 2.55

const supportColumnPosition: Vec3 = [
  conformalOiaWorldPosition[0] + conformalFlowVector[0] * 0.5 + conformalRearVector[0] * 3.65,
  0,
  REAR_COLUMN_ROW_Z,
]

const backendIctEndX = ictBackendWorldPosition[0] + ictBackendMachine.size[0] / 2
const wallStartX = lineBounds.minX - 0.25
const wallEndX = backendIctEndX + 0.4
const reworkWall: ServiceWallConfig = {
  id: 'backend-rework-wall',
  position: [
    (wallStartX + wallEndX) / 2,
    2.75,
    backendSupportTables[0].position[2] + backendSupportTables[0].size[2] / 2 + 0.16,
  ],
  size: [wallEndX - wallStartX, 5.5, 0.18],
  color: '#f3f4f3',
}

const smtSupportColumnPosition: Vec3 = [
  solderPasteSupportArea.position[0] + solderPasteSupportArea.cabinet.position[0],
  0,
  REAR_COLUMN_ROW_Z,
]

const smtSupportColumn: StructuralColumnConfig = {
  id: 'smt-fifo-support-column',
  position: smtSupportColumnPosition,
  size: [0.58, CEILING_HEIGHT, 0.58],
  display: {
    id: 'smt-fifo-column-display',
    title: 'FIFO Pastas',
    position: [0.48, 3.45, 0],
    rotation: [0, Math.PI / 2, 0],
    width: 1.82,
    height: 1.02,
    depth: 0.09,
    media: {
      type: 'image',
      source: '/screens/fifo-pastas.png',
      fallback: '/media/screens/placeholder.svg',
      fit: 'contain',
    },
  },
}

const ictSupportColumnPosition: Vec3 = [ictBackendWorldPosition[0], 0, FRONT_COLUMN_ROW_Z]

const ictSupportColumn: StructuralColumnConfig = {
  id: 'backend-ict-support-column',
  position: ictSupportColumnPosition,
  size: [0.58, CEILING_HEIGHT, 0.58],
  display: {
    id: 'backend-ict-column-display',
    title: 'ICT Backend',
    position: [0.48, 3.45, 0],
    rotation: [0, Math.PI / 2, 0],
    width: 1.82,
    height: 1.02,
    depth: 0.09,
    media: {
      type: 'image',
      source: '/media/factory/column-display/factory-dashboard.svg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
}

const supportColumn: StructuralColumnConfig = {
  id: 'conformal-oia-support-column',
  position: supportColumnPosition,
  size: [0.58, CEILING_HEIGHT, 0.58],
  display: {
    id: 'conformal-oia-column-display',
    title: 'Factory Status',
    position: [0.48, 3.45, 0],
    rotation: [0, Math.PI / 2, 0],
    width: 1.82,
    height: 1.02,
    depth: 0.09,
    media: {
      type: 'image',
      source: '/media/factory/column-display/factory-dashboard.svg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
}

const distributedColumns: StructuralColumnConfig[] = [
  { id: 'factory-column-smt-rear-left', position: [-36, 0, REAR_COLUMN_ROW_Z], size: [0.58, CEILING_HEIGHT, 0.58] },
  { id: 'factory-column-smt-rear-center', position: [-2, 0, REAR_COLUMN_ROW_Z], size: [0.58, CEILING_HEIGHT, 0.58] },
  { id: 'factory-column-backend-rear-center', position: [33, 0, REAR_COLUMN_ROW_Z], size: [0.58, CEILING_HEIGHT, 0.58] },
  { id: 'factory-column-smt-front-left', position: [-36, 0, FRONT_COLUMN_ROW_Z], size: [0.58, CEILING_HEIGHT, 0.58] },
  { id: 'factory-column-backend-front-center', position: [18, 0, FRONT_COLUMN_ROW_Z], size: [0.58, CEILING_HEIGHT, 0.58] },
  { id: 'factory-column-backend-front-right', position: [68, 0, FRONT_COLUMN_ROW_Z], size: [0.58, CEILING_HEIGHT, 0.58] },
]

const vendingMachines: VendingMachineConfig[] = [
  {
    id: 'conformal-rear-vending-machine',
    position: [
      supportColumnPosition[0] + conformalFlowVector[0] * 1.55,
      0,
      supportColumnPosition[2],
    ],
    rotation: [0, Math.PI / 2, 0],
    size: [1.24, 2.18, 0.84],
    color: '#124f91',
    accentColor: '#0b3768',
    label: 'FACTORY SUPPLIES',
    productRows: 5,
    productColumns: 4,
  },
]

const columns = [...distributedColumns, smtSupportColumn, supportColumn, ictSupportColumn]

function createColumnCollisionBox(column: StructuralColumnConfig): CollisionBox {
  return {
    id: `${column.id}-blocker`,
    minX: column.position[0] - column.size[0] / 2 - 0.02,
    maxX: column.position[0] + column.size[0] / 2 + 0.02,
    minZ: column.position[2] - column.size[2] / 2 - 0.02,
    maxZ: column.position[2] + column.size[2] / 2 + 0.02,
  }
}

function createVendingCollisionBox(machine: VendingMachineConfig): CollisionBox {
  return {
    id: `${machine.id}-blocker`,
    minX: machine.position[0] - machine.size[0] / 2 - 0.04,
    maxX: machine.position[0] + machine.size[0] / 2 + 0.04,
    minZ: machine.position[2] - machine.size[2] / 2 - 0.04,
    maxZ: machine.position[2] + machine.size[2] / 2 + 0.04,
  }
}

function createWallCollisionBox(wall: ServiceWallConfig): CollisionBox {
  return {
    id: `${wall.id}-blocker`,
    minX: wall.position[0] - wall.size[0] / 2,
    maxX: wall.position[0] + wall.size[0] / 2,
    minZ: wall.position[2] - wall.size[2] / 2 - 0.05,
    maxZ: wall.position[2] + wall.size[2] / 2 + 0.05,
  }
}

export const factoryArchitecture: FactoryArchitectureLayout = {
  conformalOiaWorldPosition,
  collisionBoxes: [
    ...columns.map(createColumnCollisionBox),
    ...vendingMachines.map(createVendingCollisionBox),
    createWallCollisionBox(reworkWall),
  ],
  config: {
    ceiling: {
      center: [0, CEILING_HEIGHT, 0],
      width: floorSize[0] + CEILING_MARGIN * 2,
      depth: floorSize[1] + CEILING_MARGIN * 2,
      height: CEILING_HEIGHT,
      thickness: CEILING_THICKNESS,
      tileSize: TILE_SIZE,
      gridLineWidth: 0.035,
      lightSpacingX: 14.5,
      lightSpacingZ: 4.8,
      lightMarginX: 7.5,
      lightMarginZ: 3.6,
      lightSize: [1.42, 0.06, 0.42],
    },
    columns,
    vendingMachines,
    walls: [reworkWall],
  },
}
