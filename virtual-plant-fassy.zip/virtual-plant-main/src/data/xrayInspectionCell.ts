import { backendLineConfigs } from './backendLine'
import { backendProcesses } from './backendProcesses'
import type { ManualAssemblyLineConfig } from '../types/backend'
import type { Vec3 } from '../types/factory'
import type { XrayInspectionCellConfig, XrayInspectionCellLayout } from '../types/xray'

function rotateY(point: Vec3, rotationY: number): Vec3 {
  const [x, y, z] = point
  const cos = Math.cos(rotationY)
  const sin = Math.sin(rotationY)

  return [x * cos + z * sin, y, -x * sin + z * cos]
}

function translateLocalPoint(origin: Vec3, rotationY: number, localPoint: Vec3): Vec3 {
  const rotated = rotateY(localPoint, rotationY)

  return [origin[0] + rotated[0], origin[1] + rotated[1], origin[2] + rotated[2]]
}

const referenceProcess = backendProcesses.find((process) => process.id === 'backend-oia')

if (!referenceProcess) {
  throw new Error('Missing backend OIA process for XRAY inspection cell')
}

const backendOiaProcess = referenceProcess

const inspectionTableSize: Vec3 = [1.82, 0.92, 0.82]
const xrayMachineSize: Vec3 = [2.45, 2.82, 1.94]
const xiaMachineSize: Vec3 = [1.78, 2.26, 1.46]
const transferTrayLength = 0.68
const clearanceFromOia = 2.85
const firstEquipmentHalfLength = inspectionTableSize[0] / 2
const xrayCellOffset = backendOiaProcess.size[0] / 2 + clearanceFromOia + firstEquipmentHalfLength
const localBounds = {
  minX: -1.25,
  maxX: 6.45,
  minZ: -1.1,
  maxZ: 1.9,
}

function buildXrayInspectionCell(lineConfig: ManualAssemblyLineConfig, index: number) {
  const rotationY = lineConfig.rotation?.[1] ?? 0
  const referenceProcessPosition = translateLocalPoint(lineConfig.position, rotationY, backendOiaProcess.position)
  const processFlowVector = rotateY([1, 0, 0], rotationY)

  const position: Vec3 = [
    referenceProcessPosition[0] + processFlowVector[0] * xrayCellOffset,
    referenceProcessPosition[1],
    referenceProcessPosition[2] + processFlowVector[2] * xrayCellOffset,
  ]

  const config: XrayInspectionCellConfig = {
    id: `${lineConfig.id}-xray-inspection-cell`,
    name: 'XRAY Inspection Cell',
    area: 'backend',
    lineId: lineConfig.id,
    referenceProcessId: 'backend-oia',
    position,
    rotation: [0, rotationY, 0],
    clearanceFromOia,
    localBounds,
    monitor: {
      id: `${lineConfig.id}-xray-work-instructions-display`,
      title: 'XRAY — Instrucciones',
      promptText: 'E — Ver instrucciones XRAY',
      position: [0.02, 1.54, 0.18],
      rotation: [-0.1, -0.08, 0],
      size: [0.74, 0.42],
      media: {
        type: 'auto',
        source: '/media/backend/xray/xray-instructions.jpg',
        fallback: '/media/backend/xray/placeholder.svg',
        fit: 'contain',
      },
    },
    equipment: [
      {
        id: `${lineConfig.id}-xray-inspection-table`,
        name: 'Green Inspection Table',
        shortName: 'TABLE',
        type: 'inspection-table',
        position: [0, 0, 0],
        size: inspectionTableSize,
      },
      {
        id: `${lineConfig.id}-xray-machine`,
        name: 'XRAY Inspection Machine',
        shortName: 'XRAY',
        type: 'xray',
        position: [2.46, 0, 0.08],
        size: xrayMachineSize,
      },
      {
        id: `${lineConfig.id}-xia-machine`,
        name: 'XIA Analysis Machine',
        shortName: 'XIA',
        type: 'xia',
        position: [5.25, 0, 0.08],
        size: xiaMachineSize,
      },
    ],
  }

  function boundsToWorldCorners(minX: number, maxX: number, minZ: number, maxZ: number) {
    return [
      [minX, 0, minZ],
      [minX, 0, maxZ],
      [maxX, 0, minZ],
      [maxX, 0, maxZ],
    ].map((corner) => translateLocalPoint(config.position, rotationY, corner as Vec3))
  }

  function createEquipmentCollisionBox(id: string, center: Vec3, size: Vec3, paddingX = 0.08, paddingZ = 0.08) {
    const corners = boundsToWorldCorners(
      center[0] - size[0] / 2 - paddingX,
      center[0] + size[0] / 2 + paddingX,
      center[2] - size[2] / 2 - paddingZ,
      center[2] + size[2] / 2 + paddingZ,
    )

    return {
      id,
      minX: Math.min(...corners.map((corner) => corner[0])),
      maxX: Math.max(...corners.map((corner) => corner[0])),
      minZ: Math.min(...corners.map((corner) => corner[2])),
      maxZ: Math.max(...corners.map((corner) => corner[2])),
    }
  }

  const worldSafetyCorners = boundsToWorldCorners(localBounds.minX, localBounds.maxX, localBounds.minZ, localBounds.maxZ)

  const layout: XrayInspectionCellLayout = {
    id: `${config.id}-layout-${index + 1}`,
    referenceProcessPosition,
    safetyZone: {
      minX: Math.min(...worldSafetyCorners.map((corner) => corner[0])),
      maxX: Math.max(...worldSafetyCorners.map((corner) => corner[0])),
      minZ: Math.min(...worldSafetyCorners.map((corner) => corner[2])),
      maxZ: Math.max(...worldSafetyCorners.map((corner) => corner[2])),
    },
    collisionBoxes: [
      createEquipmentCollisionBox(`${config.id}-table-blocker`, [0, 0, 0], inspectionTableSize, 0.06, 0.04),
      createEquipmentCollisionBox(`${config.id}-machine-blocker`, [2.46, 0, 0.08], xrayMachineSize, 0.1, 0.1),
      createEquipmentCollisionBox(`${config.id}-xia-blocker`, [5.25, 0, 0.08], xiaMachineSize, 0.08, 0.08),
    ],
  }

  return { config, layout }
}

const xrayCells = backendLineConfigs.map((lineConfig, index) => buildXrayInspectionCell(lineConfig, index))

export const xrayInspectionCellConfigs = xrayCells.map((entry) => entry.config)
export const xrayInspectionCellLayouts = xrayCells.map((entry) => entry.layout)

export const xrayTransferTrayConfig = {
  position: [3.8, 0.92, 0.08] as Vec3,
  size: [transferTrayLength, 0.06, 0.34] as Vec3,
}
