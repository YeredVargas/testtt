import type {
  Bounds2D,
  CollisionBox,
  FloorDisplayStationConfig,
  PcbConfig,
  SmtEquipmentConfig,
} from '../types/factory'

export const CONVEYOR_HEIGHT = 0.9
export const ENABLE_PCB_ANIMATION = true
// Fondo ampliado de 36 a 50 m para alojar la celda FASSY en la franja trasera
// (z -25 a 25). El piso, la reticula, el techo, los muros y las luminarias de
// factoryArchitecture se derivan de este valor, asi que crecen con el.
export const floorSize: [number, number] = [188, 50]

const LINE_Z = -0.15
const LINE_GAP = 0.34

const equipmentBlueprints: Omit<SmtEquipmentConfig, 'position'>[] = [
  {
    id: 'laser',
    name: 'Laser',
    shortName: 'LASER',
    type: 'laser',
    size: [2.3, 2.0, 1.5],
    accentColor: '#0ea5e9',
    showTowerLight: true,
  },
  {
    id: 'solder-paste-printer',
    name: 'Solder Paste Printer',
    shortName: 'SOLDER PASTE PRINTER',
    type: 'solder-paste-printer',
    size: [3.1, 2.0, 1.6],
    accentColor: '#062c40',
    showTowerLight: true,
  },
  {
    id: 'conveyor-printer-spi',
    name: 'Conveyor',
    shortName: 'CONVEYOR',
    type: 'conveyor',
    size: [1.15, 1.05, 0.74],
  },
  {
    id: 'spi',
    name: 'Solder Paste Inspection',
    shortName: 'SPI',
    type: 'spi',
    size: [1.85, 2.1, 1.4],
    accentColor: '#0f172a',
    showTowerLight: true,
  },
  {
    id: 'pick-place-1',
    name: 'Pick & Place 1',
    shortName: 'PICK & PLACE 1',
    type: 'pick-and-place',
    size: [2.1, 2.1, 1.5],
    accentColor: '#c92828',
    showTowerLight: true,
  },
  {
    id: 'pick-place-2',
    name: 'Pick & Place 2',
    shortName: 'PICK & PLACE 2',
    type: 'pick-and-place',
    size: [2.12, 2.08, 1.5],
    accentColor: '#c92828',
    showTowerLight: false,
  },
  {
    id: 'pick-place-3',
    name: 'Pick & Place 3',
    shortName: 'PICK & PLACE 3',
    type: 'pick-and-place',
    size: [2.08, 2.14, 1.52],
    accentColor: '#c92828',
    showTowerLight: true,
  },
  {
    id: 'pick-place-4',
    name: 'Pick & Place 4',
    shortName: 'PICK & PLACE 4',
    type: 'pick-and-place',
    size: [2.15, 2.12, 1.5],
    accentColor: '#c92828',
    showTowerLight: false,
  },
  {
    id: 'conveyor-placement-oven',
    name: 'Conveyor',
    shortName: 'CONVEYOR',
    type: 'conveyor',
    size: [1.2, 1.05, 0.74],
  },
  {
    id: 'reflow-oven',
    name: 'Reflow Oven',
    shortName: 'REFLOW OVEN',
    type: 'reflow-oven',
    size: [9.5, 1.95, 1.7],
    accentColor: '#8d9499',
    showTowerLight: true,
  },
  {
    id: 'conveyor-oven-aoi',
    name: 'Conveyor',
    shortName: 'CONVEYOR',
    type: 'conveyor',
    size: [1.0, 1.05, 0.74],
  },
  {
    id: 'aoi',
    name: 'Automated Optical Inspection',
    shortName: 'AOI',
    type: 'aoi',
    size: [1.7, 2.1, 1.42],
    accentColor: '#062c40',
    showTowerLight: true,
  },
  {
    id: 'conveyor-aoi-flashing',
    name: 'Conveyor',
    shortName: 'CONVEYOR',
    type: 'conveyor',
    size: [0.9, 1.05, 0.74],
  },
  {
    id: 'flashing',
    name: 'Flashing',
    shortName: 'FLASHING',
    type: 'flashing',
    size: [2.0, 2.0, 1.5],
    accentColor: '#0f7ea3',
    showTowerLight: true,
  },
  {
    id: 'conveyor-flashing-ict',
    name: 'Conveyor',
    shortName: 'CONVEYOR',
    type: 'conveyor',
    size: [0.95, 1.05, 0.74],
  },
  {
    id: 'ict-inline',
    name: 'ICT In-Line',
    shortName: 'ICT IN-LINE',
    type: 'ict-inline',
    size: [2.35, 2.25, 1.7],
    accentColor: '#1d4ed8',
    showTowerLight: true,
  },
  {
    id: 'conveyor-ict-router',
    name: 'Conveyor',
    shortName: 'CONVEYOR',
    type: 'conveyor',
    size: [0.95, 1.05, 0.74],
  },
  {
    id: 'router',
    name: 'Router',
    shortName: 'ROUTER',
    type: 'router',
    size: [2.65, 2.25, 1.82],
    accentColor: '#0f766e',
    showTowerLight: true,
  },
]

function createEquipmentLine(items: Omit<SmtEquipmentConfig, 'position'>[]) {
  const totalLength =
    items.reduce((sum, item) => sum + item.size[0], 0) + LINE_GAP * (items.length - 1)
  let cursor = -totalLength / 2

  return items.map((item) => {
    const equipment: SmtEquipmentConfig = {
      ...item,
      position: [cursor + item.size[0] / 2, 0, LINE_Z],
    }

    cursor += item.size[0] + LINE_GAP
    return equipment
  })
}

export const smtEquipment = createEquipmentLine(equipmentBlueprints)

const equipmentById = new Map(smtEquipment.map((equipment) => [equipment.id, equipment]))

export function getSmtEquipment(id: string) {
  const equipment = equipmentById.get(id)

  if (!equipment) {
    throw new Error(`Missing SMT equipment config for ${id}`)
  }

  return equipment
}

function getEquipmentPosition(id: string) {
  return getSmtEquipment(id).position
}

export const lineBounds = {
  minX: smtEquipment[0].position[0] - smtEquipment[0].size[0] / 2,
  maxX:
    smtEquipment[smtEquipment.length - 1].position[0] +
    smtEquipment[smtEquipment.length - 1].size[0] / 2,
}

export const productionZoneBounds: Bounds2D = {
  minX: lineBounds.minX - 1.2,
  maxX: lineBounds.maxX + 1.2,
  minZ: -2.45,
  maxZ: 2.1,
}

export const walkableBounds: Bounds2D = {
  minX: -38,
  maxX: 92,
  minZ: -16,
  maxZ: 18,
}

export const displayStations: FloorDisplayStationConfig[] = [
  {
    id: 'solder-paste-display',
    title: 'Liberaciones',
    processId: 'solder-paste-printer',
    position: [getEquipmentPosition('solder-paste-printer')[0] - 0.2, 0, 3.1],
    width: 1.15,
    height: 0.65,
    media: {
      type: 'auto',
      source: '/screens/liberaciones.jpg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
  {
    id: 'display-pick-place',
    title: 'PICK & PLACE',
    processId: 'pick-place-3',
    position: [
      (getEquipmentPosition('pick-place-1')[0] + getEquipmentPosition('pick-place-4')[0]) / 2,
      0,
      3.25,
    ],
    width: 1.15,
    height: 0.65,
    media: {
      type: 'image',
      source: '/screens/pick-and-place.svg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
  {
    id: 'display-reflow',
    title: 'REFLOW OVEN',
    processId: 'reflow-oven',
    position: [getEquipmentPosition('reflow-oven')[0] - 0.35, 0, 3.1],
    width: 1.15,
    height: 0.65,
    media: {
      type: 'image',
      source: '/screens/reflow.svg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
]

export const pcbBoards: PcbConfig[] = [
  {
    id: 'pcb-laser-run',
    position: [getEquipmentPosition('laser')[0] + 0.15, CONVEYOR_HEIGHT + 0.03, LINE_Z],
    animation: {
      startX: getEquipmentPosition('laser')[0] + 0.15,
      endX: getEquipmentPosition('solder-paste-printer')[0] + 0.65,
      speed: 0.8,
    },
  },
  {
    id: 'pcb-placement-run',
    position: [getEquipmentPosition('pick-place-2')[0] - 0.25, CONVEYOR_HEIGHT + 0.03, LINE_Z],
    animation: {
      startX: getEquipmentPosition('pick-place-2')[0] - 0.25,
      endX: getEquipmentPosition('reflow-oven')[0] - 3.7,
      speed: 0.7,
    },
  },
  {
    id: 'pcb-post-aoi-run',
    position: [getEquipmentPosition('aoi')[0] + 0.25, CONVEYOR_HEIGHT + 0.03, LINE_Z],
    animation: {
      startX: getEquipmentPosition('aoi')[0] + 0.25,
      endX: getEquipmentPosition('router')[0] - 0.4,
      speed: 0.6,
    },
  },
  {
    id: 'pcb-static-router',
    position: [getEquipmentPosition('router')[0], CONVEYOR_HEIGHT + 0.03, LINE_Z],
  },
]

const equipmentBlockers: CollisionBox[] = smtEquipment.map((equipment) => ({
  id: equipment.id,
  minX: equipment.position[0] - equipment.size[0] / 2 - 0.18,
  maxX: equipment.position[0] + equipment.size[0] / 2 + 0.18,
  minZ: equipment.position[2] - equipment.size[2] / 2 - 0.3,
  maxZ: equipment.position[2] + equipment.size[2] / 2 + 1.0,
}))

const displayBlockers: CollisionBox[] = displayStations.map((display) => ({
  id: display.id,
  minX: display.position[0] - 0.55,
  maxX: display.position[0] + 0.55,
  minZ: display.position[2] - 0.35,
  maxZ: display.position[2] + 0.35,
}))

export const sceneCollisionBoxes: CollisionBox[] = [...equipmentBlockers, ...displayBlockers]
