import type { ManualAssemblyLineConfig } from '../types/backend'
import type { Vec3 } from '../types/factory'
import {
  backendAreaBounds,
  backendLineConfigs,
  MASSY_LENGTH,
  MASSY_OPERATOR_LANE_MAX_Z,
  MASSY_OPERATOR_LANE_MIN_Z,
} from './backendLine'
import { backendProcesses } from './backendProcesses'
import { backendRearAreaConfig } from './backendRearArea'
import { backendStandaloneEquipment } from './backendStandaloneEquipment'
import { conformalLineLayout } from './conformalLine'
import { glueProcessCellLayout } from './glueProcessCell'
import { ictBackendCellLayout } from './ictBackendCell'
import { routerProcessCellLayout } from './routerProcessCell'
import { backendDisplayStations as auxiliaryBackendDisplays } from './backendDisplayStations'
import { xrayInspectionCellLayouts } from './xrayInspectionCell'
import {
  solderPasteFifoDisplayWorldPosition,
  solderPasteSupportArea,
} from './solderPasteSupportArea'
import { pickAndPlaceMaterialArea } from './smtMaterialAreas'
import { displayStations, getSmtEquipment, smtEquipment } from './smtLine'

export interface SafetyRectangleConfig {
  id: string
  center: [number, number, number]
  width: number
  depth: number
  lineWidth?: number
}

export interface SafetySegmentConfig {
  id: string
  position: [number, number, number]
  length: number
  orientation: 'horizontal' | 'vertical'
  lineWidth?: number
}

const areaMarginX = 1
const areaMarginZ = 1.25
const processMarginX = 0.36
const processMarginZ = 0.52

function rectangleFromBounds(id: string, minX: number, maxX: number, minZ: number, maxZ: number): SafetyRectangleConfig {
  return {
    id,
    center: [(minX + maxX) / 2, 0.012, (minZ + maxZ) / 2],
    width: maxX - minX,
    depth: maxZ - minZ,
  }
}

function rotateY(point: Vec3, rotationY: number): Vec3 {
  const [x, y, z] = point
  const cos = Math.cos(rotationY)
  const sin = Math.sin(rotationY)

  return [x * cos + z * sin, y, -x * sin + z * cos]
}

function rectangleFromLocalBounds(
  id: string,
  lineConfig: ManualAssemblyLineConfig,
  minX: number,
  maxX: number,
  minZ: number,
  maxZ: number,
): SafetyRectangleConfig {
  const rotationY = lineConfig.rotation?.[1] ?? 0
  const corners: Vec3[] = [
    [minX, 0, minZ],
    [minX, 0, maxZ],
    [maxX, 0, minZ],
    [maxX, 0, maxZ],
  ]
  const worldCorners = corners.map((corner) => {
    const rotated = rotateY(corner, rotationY)

    return [
      lineConfig.position[0] + rotated[0],
      0,
      lineConfig.position[2] + rotated[2],
    ] as Vec3
  })

  return rectangleFromBounds(
    id,
    Math.min(...worldCorners.map((corner) => corner[0])),
    Math.max(...worldCorners.map((corner) => corner[0])),
    Math.min(...worldCorners.map((corner) => corner[2])),
    Math.max(...worldCorners.map((corner) => corner[2])),
  )
}

function segmentFromLocalBounds(
  id: string,
  lineConfig: ManualAssemblyLineConfig,
  centerX: number,
  centerZ: number,
  length: number,
  orientation: 'horizontal' | 'vertical',
): SafetySegmentConfig {
  const rotationY = lineConfig.rotation?.[1] ?? 0
  const rotated = rotateY([centerX, 0, centerZ], rotationY)

  return {
    id,
    position: [lineConfig.position[0] + rotated[0], 0.012, lineConfig.position[2] + rotated[2]],
    length,
    orientation,
  }
}

function zoneForEquipment(id: string, extra?: Partial<{ minX: number; maxX: number; minZ: number; maxZ: number }>) {
  const equipment = getSmtEquipment(id)
  const minX = equipment.position[0] - equipment.size[0] / 2 - processMarginX + (extra?.minX ?? 0)
  const maxX = equipment.position[0] + equipment.size[0] / 2 + processMarginX + (extra?.maxX ?? 0)
  const minZ = equipment.position[2] - equipment.size[2] / 2 - processMarginZ + (extra?.minZ ?? 0)
  const maxZ = equipment.position[2] + equipment.size[2] / 2 + processMarginZ + (extra?.maxZ ?? 0)

  return rectangleFromBounds(`${id}-zone`, minX, maxX, minZ, maxZ)
}

const smtAreaMinX = Math.min(
  ...smtEquipment.map((equipment) => equipment.position[0] - equipment.size[0] / 2),
  ...displayStations.map((station) => station.position[0] - 0.6),
) - areaMarginX

const smtAreaMaxX = Math.max(
  ...smtEquipment.map((equipment) => equipment.position[0] + equipment.size[0] / 2),
  ...displayStations.map((station) => station.position[0] + 0.6),
) + areaMarginX

const smtAreaMinZ = Math.min(...smtEquipment.map((equipment) => equipment.position[2] - equipment.size[2] / 2)) - areaMarginZ
const smtAreaMaxZ = Math.max(
  ...smtEquipment.map((equipment) => equipment.position[2] + equipment.size[2] / 2),
  ...displayStations.map((station) => station.position[2] + 0.4),
) + areaMarginZ

const pickPlaceStations = smtEquipment.filter((equipment) => equipment.type === 'pick-and-place')
const pickPlaceMinX = Math.min(...pickPlaceStations.map((equipment) => equipment.position[0] - equipment.size[0] / 2)) - processMarginX
const pickPlaceMaxX = Math.max(...pickPlaceStations.map((equipment) => equipment.position[0] + equipment.size[0] / 2)) + processMarginX
const pickPlaceMinZ = Math.min(...pickPlaceStations.map((equipment) => equipment.position[2] - equipment.size[2] / 2)) - processMarginZ
const pickPlaceMaxZ = Math.max(
  ...pickPlaceStations.map((equipment) => equipment.position[2] + equipment.size[2] / 2),
  displayStations.find((entry) => entry.id === 'display-pick-place')!.position[2] + 0.5,
) + 0.15

export const smtSafetyZones: SafetyRectangleConfig[] = [
  rectangleFromBounds('smt-area', smtAreaMinX, smtAreaMaxX, smtAreaMinZ, smtAreaMaxZ),
  zoneForEquipment('laser'),
  zoneForEquipment('solder-paste-printer'),
  rectangleFromBounds(
    'solder-paste-display-zone',
    displayStations[0].position[0] - 0.75,
    displayStations[0].position[0] + 0.75,
    displayStations[0].position[2] - 0.6,
    displayStations[0].position[2] + 0.55,
  ),
  rectangleFromBounds(
    'solder-paste-support-zone',
    solderPasteFifoDisplayWorldPosition[0] - 0.34,
    solderPasteFifoDisplayWorldPosition[0] + 0.82,
    solderPasteSupportArea.position[2] - 1.08,
    solderPasteSupportArea.position[2] + 1.2,
  ),
  zoneForEquipment('spi'),
  rectangleFromBounds('pick-place-area', pickPlaceMinX, pickPlaceMaxX, pickPlaceMinZ, pickPlaceMaxZ),
  zoneForEquipment('reflow-oven'),
  rectangleFromBounds(
    'reflow-display-zone',
    displayStations[2].position[0] - 0.78,
    displayStations[2].position[0] + 0.78,
    displayStations[2].position[2] - 0.6,
    displayStations[2].position[2] + 0.55,
  ),
  zoneForEquipment('aoi'),
  zoneForEquipment('flashing'),
  zoneForEquipment('ict-inline'),
  zoneForEquipment('router'),
  rectangleFromBounds(
    'pick-place-material-zone',
    pickAndPlaceMaterialArea.position[0] - 1.7,
    pickAndPlaceMaterialArea.position[0] + 1.7,
    pickAndPlaceMaterialArea.position[2] - 0.85,
    pickAndPlaceMaterialArea.position[2] + 0.85,
  ),
]

export const backendSafetyZones: SafetyRectangleConfig[] = [
  rectangleFromBounds(
    'backend-area',
    backendAreaBounds.minX - 0.4,
    backendAreaBounds.maxX + 0.4,
    backendAreaBounds.minZ - 0.35,
    backendAreaBounds.maxZ + 0.2,
  ),
  ...backendLineConfigs.flatMap((lineConfig) =>
    backendProcesses
      .filter(
        (process) =>
          process.type === 'wave-solder' || process.type === 'backend-aoi' || process.type === 'oia-station',
      )
      .map((process) =>
        rectangleFromLocalBounds(
          `${lineConfig.id}-${process.id}-zone`,
          lineConfig,
          process.position[0] - process.size[0] / 2 - 0.45,
          process.position[0] + process.size[0] / 2 + 0.45,
          process.position[2] - process.size[2] / 2 - 0.6,
          process.position[2] + process.size[2] / 2 + 0.6,
        ),
      ),
  ),
  ...auxiliaryBackendDisplays.map((display) =>
    rectangleFromBounds(
      `${display.id}-zone`,
      display.position[0] - 0.78,
      display.position[0] + 0.78,
      display.position[2] - 0.55,
      display.position[2] + 0.62,
    ),
  ),
  ...backendStandaloneEquipment.map((equipment) =>
    rectangleFromBounds(
      `${equipment.id}-zone`,
      equipment.position[0] - equipment.size[0] / 2 - 0.55,
      equipment.position[0] + equipment.size[0] / 2 + 0.55,
      equipment.position[2] - equipment.size[2] / 2 - 0.6,
      equipment.position[2] + equipment.size[2] / 2 + 0.6,
    ),
  ),
  rectangleFromBounds(
    'backend-conformal-line-zone',
    conformalLineLayout.safetyZone.minX,
    conformalLineLayout.safetyZone.maxX,
    conformalLineLayout.safetyZone.minZ,
    conformalLineLayout.safetyZone.maxZ,
  ),
  ...conformalLineLayout.processZones.map((zone) =>
    rectangleFromBounds(zone.id, zone.minX, zone.maxX, zone.minZ, zone.maxZ),
  ),
  rectangleFromBounds(
    'backend-glue-process-cell-zone',
    glueProcessCellLayout.safetyZone.minX,
    glueProcessCellLayout.safetyZone.maxX,
    glueProcessCellLayout.safetyZone.minZ,
    glueProcessCellLayout.safetyZone.maxZ,
  ),
  rectangleFromBounds(
    'backend-router-process-cell-zone',
    routerProcessCellLayout.safetyZone.minX,
    routerProcessCellLayout.safetyZone.maxX,
    routerProcessCellLayout.safetyZone.minZ,
    routerProcessCellLayout.safetyZone.maxZ,
  ),
  rectangleFromBounds(
    'backend-ict-process-cell-zone',
    ictBackendCellLayout.safetyZone.minX,
    ictBackendCellLayout.safetyZone.maxX,
    ictBackendCellLayout.safetyZone.minZ,
    ictBackendCellLayout.safetyZone.maxZ,
  ),
  ...xrayInspectionCellLayouts.map((layout) =>
    rectangleFromBounds(
      `${layout.id}-zone`,
      layout.safetyZone.minX,
      layout.safetyZone.maxX,
      layout.safetyZone.minZ,
      layout.safetyZone.maxZ,
    ),
  ),
]

export const backendRearStorageZone: SafetyRectangleConfig = rectangleFromBounds(
  'backend-rear-storage-zone',
  backendLineConfigs[0].position[0] + backendRearAreaConfig.localOffset[0] - 1.9,
  backendLineConfigs[0].position[0] + backendRearAreaConfig.localOffset[0] + 6.55,
  backendLineConfigs[0].position[2] - 5.35,
  backendLineConfigs[0].position[2] - 1.0,
)

const stationDividerBackZ = 1.22
const stationDividerFrontZ = 2.55

export const backendStationDividers: SafetySegmentConfig[] = backendLineConfigs.flatMap((lineConfig) =>
  Array.from({ length: lineConfig.stations.length - 1 }, (_, index) => {
    const left = lineConfig.stations[index]
    const right = lineConfig.stations[index + 1]

    return segmentFromLocalBounds(
      `${lineConfig.id}-station-divider-${index + 1}`,
      lineConfig,
      (left.position[0] + right.position[0]) / 2,
      (stationDividerBackZ + stationDividerFrontZ) / 2,
      stationDividerFrontZ - stationDividerBackZ,
      'vertical',
    )
  }),
)

export const backendOperatorLanes: SafetyRectangleConfig[] = backendLineConfigs.map((lineConfig) =>
  rectangleFromLocalBounds(
    `${lineConfig.id}-operator-zone`,
    lineConfig,
    -MASSY_LENGTH / 2 + 0.35,
    MASSY_LENGTH / 2 - 0.35,
    MASSY_OPERATOR_LANE_MIN_Z,
    MASSY_OPERATOR_LANE_MAX_Z,
  ),
)
