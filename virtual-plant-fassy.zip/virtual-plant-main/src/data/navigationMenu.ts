import { conformalLineConfig } from './conformalLine'
import { glueProcessCellConfig } from './glueProcessCell'
import { backendDisplayStations } from './backendDisplayStations'
import { manualAssemblyLineConfig } from './backendLine'
import { backendRearAreaConfig } from './backendRearArea'
import { xrayInspectionCellConfigs } from './xrayInspectionCell'
import { displayStations } from './smtLine'
import type { FloorDisplayStationConfig, NavigationSection, Vec3 } from '../types/factory'

function rotateY(point: Vec3, rotationY: number): Vec3 {
  const [x, y, z] = point
  const cos = Math.cos(rotationY)
  const sin = Math.sin(rotationY)

  return [x * cos + z * sin, y, -x * sin + z * cos]
}

function destinationForDisplay(id: string, label: string, description: string, display: FloorDisplayStationConfig) {
  const rotationY = display.rotation?.[1] ?? 0
  const forward = rotateY([0, 0, 1], rotationY)
  const cameraOffset = 2.15

  return {
    id,
    label,
    description,
    position: [
      display.position[0] + forward[0] * cameraOffset,
      1.7,
      display.position[2] + forward[2] * cameraOffset,
    ] as Vec3,
    lookAt: [display.position[0], 1.62, display.position[2]] as Vec3,
  }
}

function destinationForXrayCell(index: number) {
  const cell = xrayInspectionCellConfigs[index]

  return {
    id: `${cell.id}-nav`,
    label: `XRAY LINEA ${index + 1}`,
    description: 'Celda XRAY y XIA',
    position: [cell.position[0] - 0.8, 1.7, cell.position[2] + 2.4] as Vec3,
    lookAt: [cell.position[0] + 2.4, 1.4, cell.position[2] + 0.1] as Vec3,
  }
}

const conformalLineDestination = {
  id: 'nav-backend-conformal-line',
  label: 'Conformal Coating Line',
  description: 'Coating, UV, AOI y OIA',
  position: [conformalLineConfig.position[0] + 6.4, 1.7, conformalLineConfig.position[2] + 2.8] as Vec3,
  lookAt: [conformalLineConfig.position[0] + 7.8, 1.4, conformalLineConfig.position[2]] as Vec3,
}

const glueCellDestination = {
  id: 'nav-backend-glue-cell',
  label: 'Glue Process Cell',
  description: 'Mesa, Glue 1, Glue 2 y OIA',
  position: [glueProcessCellConfig.position[0] + 4.4, 1.7, glueProcessCellConfig.position[2] + 2.6] as Vec3,
  lookAt: [glueProcessCellConfig.position[0] + 5.2, 1.4, glueProcessCellConfig.position[2]] as Vec3,
}

const aoiImageDisplay = backendDisplayStations.find((display) => display.id === 'backend-oia-classificator-display')
const reworkAppDisplay = backendDisplayStations.find((display) => display.id === 'rework-app-display')

if (!aoiImageDisplay || !reworkAppDisplay) {
  throw new Error('Missing backend navigation display station')
}

export const navigationSections: NavigationSection[] = [
  {
    id: 'smt',
    title: 'SMT',
    destinations: [
      destinationForDisplay('nav-smt-release', 'Release Line', 'Liberaciones', displayStations[0]),
      destinationForDisplay('nav-smt-pnp', 'Pick & Place', 'Pantalla de proceso', displayStations[1]),
      destinationForDisplay('nav-smt-reflow', 'Reflow', 'Pantalla de horno', displayStations[2]),
    ],
  },
  {
    id: 'backend',
    title: 'Backend',
    destinations: [
      destinationForDisplay(
        'nav-backend-kanban',
        'Digital Kanban',
        'Pantalla BACKEND OPS',
        {
          id: backendRearAreaConfig.display.id,
          title: backendRearAreaConfig.display.title,
          position: [
            manualAssemblyLineConfig.position[0] + backendRearAreaConfig.localOffset[0] + backendRearAreaConfig.display.position[0],
            0,
            manualAssemblyLineConfig.position[2] + backendRearAreaConfig.localOffset[2] + backendRearAreaConfig.display.position[2],
          ],
          rotation: backendRearAreaConfig.display.rotation,
          width: backendRearAreaConfig.display.width,
          height: backendRearAreaConfig.display.height,
          media: {
            type: 'image',
            source: backendRearAreaConfig.display.source,
            fallback: '/media/screens/placeholder.svg',
            fit: 'cover',
          },
        },
      ),
      destinationForDisplay(
        'nav-backend-aoi-image',
        'AOI Image',
        'Clasificador frente a OIA',
        aoiImageDisplay,
      ),
      glueCellDestination,
      conformalLineDestination,
    ],
  },
  {
    id: 'rework',
    title: 'Rework',
    destinations: [
      destinationForDisplay('nav-rework-app', 'Rework App', 'Pantalla del area Rework', reworkAppDisplay),
      destinationForXrayCell(0),
      destinationForXrayCell(1),
    ],
  },
]
