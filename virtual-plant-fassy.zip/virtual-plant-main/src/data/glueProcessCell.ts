import { conformalLineLayout } from './conformalLine'
import { xrayInspectionCellConfigs, xrayInspectionCellLayouts } from './xrayInspectionCell'
import type { Vec3 } from '../types/factory'
import type {
  GlueConveyorConfig,
  GlueEquipmentConfig,
  GlueProcessCellConfig,
  GlueProcessCellLayout,
} from '../types/glue'

export const GLUE_CONVEYOR_HEIGHT = 0.9

function rotateY(point: Vec3, rotationY: number): Vec3 {
  const [x, y, z] = point
  const cos = Math.cos(rotationY)
  const sin = Math.sin(rotationY)

  return [x * cos + z * sin, y, -x * sin + z * cos]
}

const primaryXrayCell = xrayInspectionCellConfigs[0]
const primaryXrayLayout = xrayInspectionCellLayouts[0]

if (!primaryXrayCell || !primaryXrayLayout) {
  throw new Error('Missing XRAY references for glue process cell')
}

const tableSize: Vec3 = [1.82, 0.92, 0.82]
const glueMachineSize: Vec3 = [2.38, 2.62, 1.78]
const glueOiaSize: Vec3 = [1.86, 2.24, 1.48]
const tableToGlueGap = 0.34
const glueInternalGap = 0.36
const glueToOiaGap = 0.66
const outputLength = 0.76
const xrayToGlueSideGap = 3
const conformalToGlueGap = 3
const xrayRotationY = primaryXrayCell.rotation[1] ?? 0
const xrayFrontVector = rotateY([0, 0, 1], xrayRotationY)
const xraySideVector = rotateY([1, 0, 0], xrayRotationY)
const glueSafetyMinX = -tableSize[0] / 2 - 0.78
const glueSafetyMinZ = -1.2
const glueSideOffset = primaryXrayCell.localBounds.maxX + xrayToGlueSideGap - glueSafetyMinX
const glueFrontOffset = conformalLineLayout.safetyZone.maxZ + conformalToGlueGap - glueSafetyMinZ
const glueCellPosition: Vec3 = [
  primaryXrayCell.position[0] + xraySideVector[0] * glueSideOffset + xrayFrontVector[0] * glueFrontOffset,
  0,
  primaryXrayCell.position[2] + xraySideVector[2] * glueSideOffset + xrayFrontVector[2] * glueFrontOffset,
]

const glueTablePosition: Vec3 = [0, 0, 0]
const glue1Position: Vec3 = [tableSize[0] / 2 + tableToGlueGap + glueMachineSize[0] / 2, 0, 0]
const glue2Position: Vec3 = [glue1Position[0] + glueMachineSize[0] / 2 + glueInternalGap + glueMachineSize[0] / 2, 0, 0]
const glueOiaPosition: Vec3 = [glue2Position[0] + glueMachineSize[0] / 2 + glueToOiaGap + glueOiaSize[0] / 2, 0, 0]

function equipment(
  id: string,
  name: string,
  shortName: string,
  type: GlueEquipmentType,
  position: Vec3,
  size: Vec3,
  screenSource?: string,
): GlueEquipmentConfig {
  return {
    id,
    name,
    shortName,
    type,
    position,
    size,
    conveyorHeight: GLUE_CONVEYOR_HEIGHT,
    screenSource,
  }
}

type GlueEquipmentType = GlueEquipmentConfig['type']

export const glueProcessCellConfig: GlueProcessCellConfig = {
  id: 'backend-glue-process-cell',
  name: 'Glue Process Cell',
  area: 'backend',
  referenceProcessId: 'xray-inspection-cell',
  position: glueCellPosition,
  rotation: [0, xrayRotationY, 0],
  monitor: {
    id: 'glue-work-instructions-display',
    title: 'GLUE — Instrucciones',
    promptText: 'E — Ver instrucciones Glue',
    position: [0, 1.55, 0.18],
    rotation: [-0.1, -0.06, 0],
    size: [0.76, 0.44],
    media: {
      type: 'auto',
      source: '/media/backend/glue/glue-instructions.jpg',
      fallback: '/media/backend/glue/placeholder.svg',
      fit: 'contain',
    },
  },
  equipment: [
    equipment('glue-inspection-table', 'Mesa Verde Glue', 'MESA VERDE GLUE', 'glue-table', glueTablePosition, tableSize),
    equipment('glue-machine-1', 'Glue Machine 1', 'GLUE MACHINE 1', 'glue-machine', glue1Position, glueMachineSize, '/media/backend/glue/glue-machine-1-dashboard.svg'),
    equipment('glue-machine-2', 'Glue Machine 2', 'GLUE MACHINE 2', 'glue-machine', glue2Position, glueMachineSize, '/media/backend/glue/glue-machine-2-dashboard.svg'),
    equipment('glue-oia', 'OIA Glue', 'OIA GLUE', 'glue-oia', glueOiaPosition, glueOiaSize, '/media/backend/glue/glue-oia-dashboard.svg'),
  ],
}

export const glueConveyors: GlueConveyorConfig[] = [
  {
    id: 'glue-machine-1-to-2',
    position: [glue1Position[0] + glueMachineSize[0] / 2 + glueInternalGap / 2, 0, 0],
    length: glueInternalGap,
  },
  {
    id: 'glue-machine-2-to-oia',
    position: [glue2Position[0] + glueMachineSize[0] / 2 + glueToOiaGap / 2, 0, 0],
    length: glueToOiaGap,
  },
  {
    id: 'glue-oia-output',
    position: [glueOiaPosition[0] + glueOiaSize[0] / 2 + outputLength / 2, 0, 0],
    length: outputLength,
  },
]

export const gluePcbPositions: Vec3[] = [
  [0.24, GLUE_CONVEYOR_HEIGHT + 0.03, 0.1],
  [glue1Position[0], GLUE_CONVEYOR_HEIGHT + 0.03, 0],
  [glue1Position[0] + glueMachineSize[0] / 2 + glueInternalGap / 2, GLUE_CONVEYOR_HEIGHT + 0.03, 0],
  [glue2Position[0] + 0.08, GLUE_CONVEYOR_HEIGHT + 0.03, 0],
  [glueOiaPosition[0] + glueOiaSize[0] / 2 + outputLength / 2, GLUE_CONVEYOR_HEIGHT + 0.03, 0],
]

function worldRect(minX: number, maxX: number, minZ: number, maxZ: number) {
  return {
    minX: glueProcessCellConfig.position[0] + minX,
    maxX: glueProcessCellConfig.position[0] + maxX,
    minZ: glueProcessCellConfig.position[2] + minZ,
    maxZ: glueProcessCellConfig.position[2] + maxZ,
  }
}

const safetyLocal = {
  minX: glueSafetyMinX,
  maxX: glueOiaPosition[0] + glueOiaSize[0] / 2 + outputLength + 0.72,
  minZ: glueSafetyMinZ,
  maxZ: 1.72,
}

export const glueProcessCellLayout: GlueProcessCellLayout = {
  safetyZone: worldRect(safetyLocal.minX, safetyLocal.maxX, safetyLocal.minZ, safetyLocal.maxZ),
  processZones: [],
  collisionBoxes: [
    { id: 'glue-table-blocker', ...worldRect(glueTablePosition[0] - tableSize[0] / 2 - 0.08, glueTablePosition[0] + tableSize[0] / 2 + 0.08, -tableSize[2] / 2 - 0.08, tableSize[2] / 2 + 0.08) },
    { id: 'glue-machine-1-blocker', ...worldRect(glue1Position[0] - glueMachineSize[0] / 2 - 0.08, glue1Position[0] + glueMachineSize[0] / 2 + 0.08, -glueMachineSize[2] / 2 - 0.08, glueMachineSize[2] / 2 + 0.08) },
    { id: 'glue-machine-2-blocker', ...worldRect(glue2Position[0] - glueMachineSize[0] / 2 - 0.08, glue2Position[0] + glueMachineSize[0] / 2 + 0.08, -glueMachineSize[2] / 2 - 0.08, glueMachineSize[2] / 2 + 0.08) },
    { id: 'glue-oia-blocker', ...worldRect(glueOiaPosition[0] - glueOiaSize[0] / 2 - 0.08, glueOiaPosition[0] + glueOiaSize[0] / 2 + 0.08, -glueOiaSize[2] / 2 - 0.08, glueOiaSize[2] / 2 + 0.08) },
  ],
}

export const glueReference = {
  xrayPosition: primaryXrayCell.position,
  xrayRotation: primaryXrayCell.rotation,
  xrayFrontVector,
  gapFromXray: xrayToGlueSideGap,
}
