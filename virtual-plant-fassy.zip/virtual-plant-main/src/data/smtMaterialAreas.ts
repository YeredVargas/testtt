import type { MaterialRackConfig } from '../types/backend'
import { smtEquipment } from './smtLine'

export interface SmtMaterialAreaConfig {
  id: string
  processId: string
  position: [number, number, number]
  rotation?: [number, number, number]
  racks: MaterialRackConfig[]
}

const pickAndPlaceModules = smtEquipment.filter((equipment) => equipment.type === 'pick-and-place')
const pickAndPlaceCenterX =
  pickAndPlaceModules.reduce((sum, equipment) => sum + equipment.position[0], 0) /
  pickAndPlaceModules.length
const pickAndPlaceFrontZ = Math.max(
  ...pickAndPlaceModules.map((equipment) => equipment.position[2] + equipment.size[2] / 2),
) + 4.45

export const pickAndPlaceMaterialArea: SmtMaterialAreaConfig = {
  id: 'smt-pick-and-place-material-area',
  processId: 'pick-and-place',
  position: [pickAndPlaceCenterX, 0, pickAndPlaceFrontZ],
  racks: [
    {
      id: 'smt-pnp-rack-1',
      position: [-0.82, 0, 0],
      levels: 4,
      binsPerLevel: 3,
      width: 1.1,
      height: 1.58,
      depth: 0.62,
      labelPrefix: 'SMT',
    },
    {
      id: 'smt-pnp-rack-2',
      position: [0.82, 0, 0],
      levels: 4,
      binsPerLevel: 3,
      width: 1.1,
      height: 1.58,
      depth: 0.62,
      labelPrefix: 'SMT',
    },
  ],
}
