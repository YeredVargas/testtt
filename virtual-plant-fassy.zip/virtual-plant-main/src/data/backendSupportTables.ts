import { backendLineConfigs } from './backendLine'
import { backendProcesses } from './backendProcesses'
import { informationCenterPosition } from './informationCenter'
import { productionZoneBounds } from './smtLine'
import type { CollisionBox, Vec3 } from '../types/factory'

export type BackendSupportTableAccessory = 'cautin' | 'microoscopio' | 'pcb'

export interface BackendSupportTableConfig {
  id: string
  position: Vec3
  rotation: Vec3
  size: Vec3
  accessory: BackendSupportTableAccessory
}

const targetBackendLine = backendLineConfigs[1]
const targetOiaProcess = backendProcesses.find((process) => process.id === 'backend-oia')

if (!targetOiaProcess) {
  throw new Error('Missing backend OIA process for support tables')
}

const targetOiaWorldX = targetBackendLine.position[0] + targetOiaProcess.position[0]
const targetOiaWorldZ = targetBackendLine.position[2] + targetOiaProcess.position[2]
const smtKioskSeparation = informationCenterPosition[2] - productionZoneBounds.maxZ
const extraRearClearance = 1.8
const supportTableZ = targetOiaWorldZ + targetOiaProcess.size[2] / 2 + smtKioskSeparation + extraRearClearance
const supportTableSize: Vec3 = [2.55, 0.9, 0.88]
const supportTableSpacing = 3.15

const accessories: BackendSupportTableAccessory[] = ['cautin', 'microoscopio', 'pcb']

export const backendSupportTables: BackendSupportTableConfig[] = [-1, 0, 1].map((offset, index) => ({
  id: `backend-support-table-${index + 1}`,
  position: [targetOiaWorldX + offset * supportTableSpacing, 0, supportTableZ],
  rotation: [0, Math.PI, 0],
  size: supportTableSize,
  accessory: accessories[index],
}))

export const backendSupportTableCollisionBoxes: CollisionBox[] = backendSupportTables.map((table) => ({
  id: `${table.id}-blocker`,
  minX: table.position[0] - table.size[0] / 2 - 0.08,
  maxX: table.position[0] + table.size[0] / 2 + 0.08,
  minZ: table.position[2] - table.size[2] / 2 - 0.08,
  maxZ: table.position[2] + table.size[2] / 2 + 0.08,
}))
