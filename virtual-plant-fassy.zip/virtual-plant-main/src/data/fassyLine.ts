import { CONVEYOR_HEIGHT, walkableBounds } from './smtLine'
import type {
  Bounds2D,
  CollisionBox,
  FassyBlueprint,
  FassyEquipmentConfig,
  FassyPartConfig,
  FassyPropConfig,
  FassySegmentConfig,
  FloorDisplayStationConfig,
  Vec3,
} from '../types/fassy'

/**
 * Linea FASSY - Final Assembly OBC (On Board Charger) MACH-E / P702 / RIVIAN.
 *
 * Estaciones y procesos tomados de los rotulos del layout de piso. Celda en U
 * de dos tramos, colocada detras de las pantallas de la linea SMT:
 *
 *   - Tramo A: ST 010 -> ST 150 Cleaning, el producto avanza de -X hacia +X.
 *   - Retorno: transfer bajo la GRUA de portico, en el extremo -X.
 *   - Tramo B: ST 150 Preheating -> ST 230, en la fila del fondo.
 *   - Delivery Point W.H. al cierre del tramo B.
 *
 * La celda ocupa la franja trasera de la nave, detras del area de backend, en
 * Z negativa. El elevador queda en el extremo oeste, que es por donde se llega
 * caminando desde SMT y backend, porque es el inicio y el final del flujo: ahi
 * arranca ST 010 y ahi entrega ST 230.
 *
 * Este modulo es aditivo: no modifica ninguna otra area de la planta. Solo lee
 * de `smtLine` la altura de transporte y los limites caminables, para heredarlos.
 */

export const FASSY_LEG_A_Z = -15.2
export const FASSY_LEG_B_Z = -21.0
export const FASSY_AISLE_Z = (FASSY_LEG_A_Z + FASSY_LEG_B_Z) / 2
export const FASSY_ENTRY_X = 75.6

const GAP = 0.3
const START_X = FASSY_ENTRY_X - 1.2
const CLEANING_OFFSET = 0.62

const SCREW_ACCENT = '#0e7490'
const PRESS_ACCENT = '#1d4ed8'
const CLEAN_ACCENT = '#0f766e'

/**
 * Coloca los equipos de un tramo recto sobre X.
 * `origin` es el borde de arranque, asi el punto de entrada del producto no se
 * mueve cuando cambian los anchos de estacion.
 */
function buildSegment(segment: FassySegmentConfig): FassyEquipmentConfig[] {
  const baseYaw = segment.facing === 1 ? 0 : Math.PI
  let cursor = segment.origin[0]

  return segment.items.map((item) => {
    const halfWidth = item.size[0] / 2
    const centerX = cursor + segment.direction * halfWidth
    cursor = centerX + segment.direction * (halfWidth + segment.gap)

    const { zOffset, ...blueprint } = item

    return {
      ...blueprint,
      position: [centerX, segment.origin[1], segment.origin[2] + segment.facing * (zOffset ?? 0)] as Vec3,
      rotation: [0, baseYaw, 0] as Vec3,
    }
  })
}

function segmentLength(items: FassyBlueprint[], gap: number) {
  return items.reduce((total, item) => total + item.size[0], 0) + gap * (items.length - 1)
}

/** Caseta de limpieza previa a la estacion del mismo numero. */
function cleaning(id: string, tag: string): FassyBlueprint {
  return {
    id,
    tag,
    name: 'Cleaning',
    shortName: `${tag} CLEANING`,
    type: 'cleaning-station',
    description: 'Caseta de limpieza por aspiracion antes de la estacion siguiente.',
    hazards: ['noise'],
    size: [1.2, 2.0, 1.15],
    accentColor: CLEAN_ACCENT,
    zOffset: CLEANING_OFFSET,
  }
}

const legA: FassyBlueprint[] = [
  cleaning('fassy-st010-cleaning', 'ST 010'),
  {
    id: 'fassy-st010',
    tag: 'ST 010',
    name: 'Manual screwing',
    shortName: 'ST 010 - MANUAL SCREWING',
    type: 'manual-workstation',
    description: 'Atornillado manual de inicio de linea sobre el housing del OBC.',
    hazards: ['ergonomic'],
    size: [1.6, 2.0, 1.4],
  },
  {
    id: 'fassy-st020',
    tag: 'ST 020',
    name: 'Manual screwing',
    shortName: 'ST 020 - MANUAL SCREWING',
    type: 'manual-workstation',
    description: 'Segunda secuencia de atornillado manual.',
    hazards: ['ergonomic'],
    size: [1.6, 2.0, 1.4],
  },
  {
    id: 'fassy-st030',
    tag: 'ST 030',
    name: 'Manual screwing',
    shortName: 'ST 030 - MANUAL SCREWING',
    type: 'manual-workstation',
    description: 'Tercera secuencia de atornillado manual.',
    hazards: ['ergonomic'],
    size: [1.6, 2.0, 1.4],
  },
  {
    id: 'fassy-st030-flipping',
    tag: 'ST 030',
    name: 'Flipping',
    shortName: 'ST 030 - FLIPPING',
    type: 'flipping-cell',
    description: 'Volteo del conjunto para trabajar la cara opuesta del housing.',
    hazards: ['moving-parts'],
    size: [1.5, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st035',
    tag: 'ST 035',
    name: 'ST 035',
    shortName: 'ST 035',
    type: 'glass-cell',
    description:
      'Cabina cerrada con rotulos de variante S / SC (RIVIAN). Sin rotulo de proceso en el layout.',
    hazards: ['moving-parts'],
    size: [2.2, 2.5, 1.6],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
    variantSigns: ['S', 'SC'],
  },
  cleaning('fassy-st040-cleaning', 'ST 040'),
  {
    id: 'fassy-st040',
    tag: 'ST 040',
    name: 'ST 040',
    shortName: 'ST 040',
    type: 'glass-cell',
    description:
      'Cabina cerrada de dispensado con rotulos CC / SC. Sin rotulo de proceso en el layout.',
    hazards: ['moving-parts', 'chemical'],
    size: [2.3, 2.5, 1.6],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
    showExtraction: true,
    variantSigns: ['CC', 'SC'],
  },
  {
    id: 'fassy-st050',
    tag: 'ST 050',
    name: 'IMS board screwing',
    shortName: 'ST 050 - IMS SCREWING',
    type: 'screwdriving-cell',
    description: 'Atornillado de la tarjeta IMS con control de par y angulo.',
    hazards: ['moving-parts', 'noise'],
    size: [1.7, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st060',
    tag: 'ST 060',
    name: 'IMS board screwing',
    shortName: 'ST 060 - IMS SCREWING',
    type: 'screwdriving-cell',
    description: 'Segunda secuencia de atornillado de la tarjeta IMS.',
    hazards: ['moving-parts', 'noise'],
    size: [1.7, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st070',
    tag: 'ST 070',
    name: 'IMS board screwing',
    shortName: 'ST 070 - IMS SCREWING',
    type: 'screwdriving-cell',
    description: 'Tercera secuencia de atornillado de la tarjeta IMS.',
    hazards: ['moving-parts', 'noise'],
    size: [1.7, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  cleaning('fassy-st080-cleaning', 'ST 080'),
  {
    id: 'fassy-st080',
    tag: 'ST 080',
    name: 'Pick & Place Power Board',
    shortName: 'ST 080 - PICK & PLACE',
    type: 'pick-place-cell',
    description: 'Colocacion automatica de la power board sobre el conjunto.',
    hazards: ['moving-parts'],
    size: [1.8, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st090',
    tag: 'ST 090',
    name: 'Press Power board / 5 positions check',
    shortName: 'ST 090 - PRESS + CHECK',
    type: 'glass-cell',
    description: 'Prensado de la power board y verificacion de 5 posiciones.',
    hazards: ['moving-parts'],
    size: [2.4, 2.35, 1.6],
    accentColor: PRESS_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st100',
    tag: 'ST 100',
    name: 'Power board screwing',
    shortName: 'ST 100 - POWER SCREWING',
    type: 'screwdriving-cell',
    description: 'Atornillado de la power board.',
    hazards: ['moving-parts', 'noise'],
    size: [1.7, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st110',
    tag: 'ST 110',
    name: 'Power board screwing',
    shortName: 'ST 110 - POWER SCREWING',
    type: 'screwdriving-cell',
    description: 'Segunda secuencia de atornillado de la power board.',
    hazards: ['moving-parts', 'noise'],
    size: [1.7, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  cleaning('fassy-st120-cleaning', 'ST 120'),
  {
    id: 'fassy-st120',
    tag: 'ST 120',
    name: 'ST 120',
    shortName: 'ST 120',
    type: 'glass-cell',
    description:
      'Cabina bdtronic de dispensado con canales CH1 a CH4. Sin rotulo de proceso en el layout.',
    hazards: ['moving-parts', 'chemical'],
    size: [2.6, 2.5, 1.7],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
    showExtraction: true,
    channelTags: ['CH1', 'CH2', 'CH4'],
  },
  {
    id: 'fassy-st130',
    tag: 'ST 130',
    name: 'PFC choke press + screwing',
    shortName: 'ST 130 - PFC CHOKE',
    type: 'press-cell',
    description: 'Prensado y atornillado del choke de correccion de factor de potencia.',
    hazards: ['moving-parts', 'noise'],
    size: [1.9, 2.35, 1.5],
    accentColor: PRESS_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st140',
    tag: 'ST 140',
    name: 'Cam. check and label scanning',
    shortName: 'ST 140 - CAM CHECK',
    type: 'glass-cell',
    description: 'Verificacion por camara del ensamble y escaneo de etiqueta. Cabina cerrada sobre ruedas.',
    hazards: ['electrical'],
    size: [1.7, 2.4, 1.5],
    variantSigns: ['CC', 'CC'],
    accentColor: '#0f172a',
    showTowerLight: true,
  },
  cleaning('fassy-st150-cleaning', 'ST 150'),
]

const legB: FassyBlueprint[] = [
  {
    id: 'fassy-st150-preheating',
    tag: 'ST 150',
    name: 'Preheating',
    shortName: 'ST 150 - PREHEATING',
    type: 'preheating-oven',
    description: 'Precalentamiento del conjunto antes del potting.',
    hazards: ['hot-surface', 'electrical'],
    size: [2.6, 2.1, 1.6],
    accentColor: '#9ca3a8',
    showTowerLight: true,
    showExtraction: true,
  },
  {
    id: 'fassy-st150-potting',
    tag: 'ST 150',
    name: 'Potting',
    shortName: 'ST 150 - POTTING',
    type: 'potting-machine',
    description: 'Encapsulado con resina. Alimentado por la unidad Potting MPS y bombas de vacio.',
    hazards: ['chemical', 'moving-parts'],
    size: [2.4, 2.5, 1.6],
    accentColor: '#7c3aed',
    showTowerLight: true,
    showExtraction: true,
  },
  {
    id: 'fassy-st150-curing',
    tag: 'ST 150',
    name: 'Curing',
    shortName: 'ST 150 - CURING',
    type: 'hols-oven',
    description: 'Horno HOLS de curado, seis camaras con puertas de palanca y extraccion al techo.',
    hazards: ['hot-surface', 'electrical'],
    size: [3.2, 2.5, 1.7],
    accentColor: '#9ca3a8',
    showTowerLight: true,
    showExtraction: true,
  },
  {
    id: 'fassy-st160',
    tag: 'ST 160-1',
    name: 'ST 160',
    shortName: 'ST 160',
    type: 'glass-cell',
    description:
      'Cabina doble bdtronic (ST 160-1 y ST 160-2) de dispensado, canales CH2 a CH4. Sin rotulo de proceso en el layout.',
    hazards: ['moving-parts', 'chemical'],
    size: [3.4, 2.5, 1.7],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
    showExtraction: true,
    variantSigns: ['ST 160-1', 'ST 160-2'],
    channelTags: ['CH2', 'CH3', 'CH4'],
  },
  {
    id: 'fassy-st170',
    tag: 'ST 170',
    name: 'AC filter board placing + sealing',
    shortName: 'ST 170 - AC FILTER SEAL',
    type: 'sealing-cell',
    description: 'Colocacion de la tarjeta de filtro AC y aplicacion de sellador.',
    hazards: ['chemical', 'moving-parts'],
    size: [2.0, 2.35, 1.5],
    accentColor: '#0891b2',
    showTowerLight: true,
    showExtraction: true,
  },
  {
    id: 'fassy-st180',
    tag: 'ST 180',
    name: 'DC filter board placing + sealing',
    shortName: 'ST 180 - DC FILTER SEAL',
    type: 'sealing-cell',
    description: 'Colocacion de la tarjeta de filtro DC y aplicacion de sellador.',
    hazards: ['chemical', 'moving-parts'],
    size: [2.0, 2.35, 1.5],
    accentColor: '#0891b2',
    showTowerLight: true,
    showExtraction: true,
  },
  {
    id: 'fassy-st190',
    tag: 'ST 190',
    name: 'AC filter board screwing',
    shortName: 'ST 190 - AC FILTER SCREW',
    type: 'screwdriving-cell',
    description: 'Atornillado de la tarjeta de filtro AC.',
    hazards: ['moving-parts', 'noise'],
    size: [1.8, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st200-1',
    tag: 'ST 200-1',
    name: 'AC/DC connector assembly',
    shortName: 'ST 200-1 - CONNECTOR ASSY',
    type: 'manual-workstation',
    description: 'Ensamble manual de los conectores AC y DC, con mampara de fondo.',
    hazards: ['ergonomic'],
    size: [2.4, 2.0, 1.5],
  },
  {
    id: 'fassy-st200-2',
    tag: 'ST 200-2',
    name: 'AC/DC connector screwing',
    shortName: 'ST 200-2 - CONNECTOR SCREW',
    type: 'glass-cell',
    description: 'Cabina cerrada de atornillado con dos controladores DEPRAG.',
    hazards: ['moving-parts', 'noise'],
    size: [2.4, 2.5, 1.6],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  cleaning('fassy-st210-cleaning', 'ST 210'),
  {
    id: 'fassy-st220',
    tag: 'ST 220',
    name: 'ST 220',
    shortName: 'ST 220',
    type: 'automated-cell',
    description: 'Estacion sin rotulo de proceso en el layout. Pendiente de confirmar con piso.',
    size: [1.8, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
  {
    id: 'fassy-st230',
    tag: 'ST 230',
    name: 'ST 230',
    shortName: 'ST 230',
    type: 'automated-cell',
    description:
      'Ultima estacion antes de Finished Goods. Sin rotulo de proceso en el layout. Pendiente de confirmar.',
    size: [1.8, 2.35, 1.5],
    accentColor: SCREW_ACCENT,
    showTowerLight: true,
  },
]

const LEG_A_LENGTH = segmentLength(legA, GAP)
const LEG_A_END_X = START_X - LEG_A_LENGTH

/**
 * El tramo B lleva menos estaciones que el A, asi que su separacion se calcula
 * para que ambos tramos midan lo mismo. Con eso la celda cierra: ST 010 arranca
 * junto al elevador y ST 230 termina junto al elevador, que es entrada y salida.
 */
const GAP_B =
  (LEG_A_LENGTH - legB.reduce((total, item) => total + item.size[0], 0)) / (legB.length - 1)

const legAEquipment = buildSegment({
  origin: [START_X, 0, FASSY_LEG_A_Z],
  direction: -1,
  facing: -1,
  gap: GAP,
  items: legA,
})

const legBEquipment = buildSegment({
  origin: [LEG_A_END_X, 0, FASSY_LEG_B_Z],
  direction: 1,
  facing: 1,
  gap: GAP_B,
  items: legB,
})

/** El retorno corre sobre Z, por eso su tamano ya viene en ejes de planta. */
const transferTurn: FassyEquipmentConfig = {
  id: 'fassy-transfer-turn',
  tag: 'TR 01',
  name: 'Transfer de retorno',
  shortName: 'TRANSFER',
  type: 'conveyor',
  description: 'Traslada el pallet portador del tramo de ensamble al tramo de potting y filtros.',
  hazards: ['moving-parts'],
  position: [LEG_A_END_X - 1.1, 0, FASSY_AISLE_Z],
  size: [1.4, 1.5, Math.abs(FASSY_LEG_B_Z - FASSY_LEG_A_Z) + 1.5],
  accentColor: '#64748b',
  showTowerLight: true,
}

export const fassyEquipment: FassyEquipmentConfig[] = [
  ...legAEquipment,
  transferTurn,
  ...legBEquipment,
]

const equipmentById = new Map(fassyEquipment.map((item) => [item.id, item]))

function xOf(id: string) {
  const found = equipmentById.get(id)

  if (!found) {
    throw new Error(`Missing FASSY equipment config for ${id}`)
  }

  return found.position[0]
}

export const fassyBounds: Bounds2D = fassyEquipment.reduce<Bounds2D>(
  (bounds, item) => ({
    minX: Math.min(bounds.minX, item.position[0] - item.size[0] / 2),
    maxX: Math.max(bounds.maxX, item.position[0] + item.size[0] / 2),
    minZ: Math.min(bounds.minZ, item.position[2] - item.size[2] / 2),
    maxZ: Math.max(bounds.maxZ, item.position[2] + item.size[2] / 2),
  }),
  { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity },
)

export const fassyDisplays: FloorDisplayStationConfig[] = [
  {
    id: 'fassy-display-overview',
    title: 'FASSY Overview',
    processId: 'fassy-st060',
    position: [xOf('fassy-st060'), 0, FASSY_LEG_A_Z - 1.65],
    rotation: [0, Math.PI, 0],
    width: 1.15,
    height: 0.65,
    media: {
      type: 'image',
      source: '/screens/fassy-dashboard.svg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
  {
    id: 'fassy-display-screwing',
    title: 'Atornillado ST 110',
    processId: 'fassy-st110',
    position: [xOf('fassy-st110'), 0, FASSY_LEG_A_Z - 1.65],
    rotation: [0, Math.PI, 0],
    width: 1.15,
    height: 0.65,
    media: {
      type: 'image',
      source: '/screens/fassy-screwdriving.svg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
  {
    id: 'fassy-display-potting',
    title: 'Potting & Curing',
    processId: 'fassy-st150-curing',
    position: [xOf('fassy-st150-curing'), 0, FASSY_LEG_B_Z + 1.7],
    width: 1.15,
    height: 0.65,
    media: {
      type: 'image',
      source: '/screens/fassy-potting.svg',
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  },
]

export const fassyParts: FassyPartConfig[] = [
  {
    id: 'fassy-obc-leg-a-1',
    position: [xOf('fassy-st010'), CONVEYOR_HEIGHT + 0.04, FASSY_LEG_A_Z],
    animation: { axis: 'x', from: xOf('fassy-st010'), to: xOf('fassy-st070'), speed: 0.55 },
  },
  {
    id: 'fassy-obc-leg-a-2',
    position: [xOf('fassy-st080'), CONVEYOR_HEIGHT + 0.04, FASSY_LEG_A_Z],
    animation: { axis: 'x', from: xOf('fassy-st080'), to: xOf('fassy-st140'), speed: 0.5 },
  },
  {
    id: 'fassy-obc-turn',
    position: [transferTurn.position[0], CONVEYOR_HEIGHT + 0.04, FASSY_LEG_A_Z],
    animation: {
      axis: 'z',
      from: FASSY_LEG_A_Z,
      to: FASSY_LEG_B_Z,
      speed: 0.6,
      pingPong: true,
    },
  },
  {
    id: 'fassy-obc-leg-b-1',
    position: [xOf('fassy-st160'), CONVEYOR_HEIGHT + 0.04, FASSY_LEG_B_Z],
    rotation: [0, Math.PI, 0],
    animation: { axis: 'x', from: xOf('fassy-st160'), to: xOf('fassy-st200-2'), speed: 0.45 },
  },
  {
    id: 'fassy-obc-static-end',
    position: [xOf('fassy-st230'), CONVEYOR_HEIGHT + 0.04, FASSY_LEG_B_Z],
    rotation: [0, Math.PI, 0],
  },
]

function cabinet(
  id: string,
  label: string,
  x: number,
  z: number,
  size: Vec3 = [0.85, 1.35, 0.75],
  accentColor?: string,
): FassyPropConfig {
  return { id, kind: 'service-cabinet', label, position: [x, 0, z], size, accentColor }
}

const legAServiceZ = FASSY_LEG_A_Z + 1.5
const legBServiceZ = FASSY_LEG_B_Z - 1.5

export const fassyProps: FassyPropConfig[] = [
  /**
   * Arco del elevador: portico de esquinas rectas por donde entra el visitante
   * a la celda y por donde sube el producto hacia la linea. No bloquea el paso;
   * solo sus dos columnas generan colision.
   */
  {
    id: 'fassy-elevator-arch',
    kind: 'elevator-arch',
    label: 'ELEVADOR',
    position: [FASSY_ENTRY_X, 0, FASSY_AISLE_Z],
    size: [0.52, 3.4, Math.abs(FASSY_LEG_B_Z - FASSY_LEG_A_Z) + 1.8],
    solid: false,
  },
  {
    id: 'fassy-crane',
    kind: 'overhead-crane',
    label: 'GRUA',
    position: [transferTurn.position[0], 0, FASSY_AISLE_Z],
    size: [2.6, 3.9, FASSY_LEG_B_Z - FASSY_LEG_A_Z + 2.4],
    solid: false,
  },
  {
    id: 'fassy-safety-board',
    kind: 'safety-board',
    label: 'MAPA DE RIESGOS',
    position: [FASSY_ENTRY_X + 2.2, 0, FASSY_AISLE_Z - 1.9],
    rotation: [0, Math.PI / 2, 0],
  },
  {
    id: 'fassy-delivery-rack',
    kind: 'rack-wall',
    label: 'DELIVERY POINT W.H.',
    size: [4.6, 2.3, 1.0],
    position: [FASSY_ENTRY_X + 2.6, 0, FASSY_LEG_B_Z - 1.0],
    rotation: [0, Math.PI / 2, 0],
  },

  // Servicios del tramo A
  cabinet('fassy-aspiradora-010', 'ASPIRADORA', xOf('fassy-st010-cleaning'), legAServiceZ),
  cabinet('fassy-feeder-010', 'FEEDER', xOf('fassy-st010'), legAServiceZ),
  cabinet('fassy-feeder-020', 'FEEDER', xOf('fassy-st020'), legAServiceZ),
  cabinet('fassy-feeder-030', 'FEEDER', xOf('fassy-st030'), legAServiceZ),
  cabinet('fassy-supervisor', 'SUPERVISOR', xOf('fassy-st030-flipping') - 0.6, legAServiceZ, [1.5, 1.1, 0.8], '#f97316'),
  cabinet('fassy-equipment-040', 'EQUIPMENT', xOf('fassy-st040'), legAServiceZ, [1.2, 1.5, 0.85]),
  cabinet('fassy-feeder-050', 'FEEDER', xOf('fassy-st050'), legAServiceZ),
  cabinet('fassy-feeder-060', 'FEEDER', xOf('fassy-st060'), legAServiceZ),
  cabinet('fassy-feeder-070', 'FEEDER', xOf('fassy-st070'), legAServiceZ),
  cabinet('fassy-aspiradora-080', 'ASPIRADORA', xOf('fassy-st080-cleaning'), legAServiceZ),
  cabinet('fassy-feeder-100', 'FEEDER', xOf('fassy-st100'), legAServiceZ),
  cabinet('fassy-feeder-110', 'FEEDER', xOf('fassy-st110'), legAServiceZ),
  cabinet('fassy-aspiradora-120', 'ASPIRADORA', xOf('fassy-st120-cleaning'), legAServiceZ),
  cabinet('fassy-escalera', 'ESCALERA', xOf('fassy-st120') + 0.4, legAServiceZ - 0.5, [1.3, 1.9, 0.9]),
  cabinet('fassy-feeder-130', 'FEEDER', xOf('fassy-st130'), legAServiceZ),
  cabinet('fassy-aspiradora-140', 'ASPIRADORA', xOf('fassy-st140'), legAServiceZ),

  // Servicios del tramo B
  cabinet('fassy-bomba-vacio-1', 'BOMBA VACIO', xOf('fassy-st150-preheating') + 0.4, legBServiceZ, [1.0, 1.4, 0.9], '#1d4ed8'),
  cabinet('fassy-potting-mps', 'POTTING MPS', xOf('fassy-st150-potting'), legBServiceZ, [1.3, 1.8, 0.9], '#7c3aed'),
  cabinet('fassy-bomba-vacio-2', 'BOMBA VACIO', xOf('fassy-st150-curing') - 0.5, legBServiceZ, [1.0, 1.4, 0.9], '#1d4ed8'),
  cabinet('fassy-equipment-160', 'EQUIPMENT', xOf('fassy-st160'), legBServiceZ, [1.2, 1.5, 0.85]),
  cabinet('fassy-feeder-170', 'FEEDER', xOf('fassy-st170'), legBServiceZ),
  cabinet('fassy-feeder-180', 'FEEDER', xOf('fassy-st180'), legBServiceZ),
  cabinet('fassy-feeder-190', 'FEEDER', xOf('fassy-st190'), legBServiceZ),
  cabinet('fassy-feeder-200', 'FEEDER', xOf('fassy-st200-1'), legBServiceZ),
  cabinet('fassy-aspiradora-210', 'ASPIRADORA', xOf('fassy-st210-cleaning'), legBServiceZ),
  cabinet('fassy-rework-1', 'REWORK', xOf('fassy-st220'), legBServiceZ, [1.5, 1.1, 0.85], '#f59e0b'),
  cabinet('fassy-rework-2', 'REWORK', xOf('fassy-st230'), legBServiceZ, [1.5, 1.1, 0.85], '#f59e0b'),

  // Material del inicio de linea: contenedores vacios, carro vacio y finished goods
  { id: 'fassy-klt-entrada-1', kind: 'klt-stack', position: [FASSY_ENTRY_X + 1.5, 0, FASSY_LEG_A_Z + 0.4], size: [0.62, 4, 0.44] },
  { id: 'fassy-klt-entrada-2', kind: 'klt-stack', position: [FASSY_ENTRY_X + 1.5, 0, FASSY_LEG_A_Z - 0.5], size: [0.62, 5, 0.44] },
  { id: 'fassy-klt-entrada-3', kind: 'klt-stack', position: [FASSY_ENTRY_X + 2.5, 0, FASSY_LEG_A_Z + 0.4], size: [0.62, 3, 0.44] },
  { id: 'fassy-klt-entrada-4', kind: 'klt-stack', position: [FASSY_ENTRY_X + 2.5, 0, FASSY_LEG_A_Z - 0.5], size: [0.62, 4, 0.44] },
  { id: 'fassy-klt-entrada-5', kind: 'klt-stack', position: [FASSY_ENTRY_X + 3.6, 0, FASSY_LEG_A_Z - 0.1], size: [0.62, 5, 0.44] },
  {
    id: 'fassy-trolley-vacio',
    kind: 'empty-trolley',
    label: 'EMPTY TROLLEY',
    position: [FASSY_ENTRY_X + 1.6, 0, FASSY_AISLE_Z + 0.6],
    rotation: [0, Math.PI / 2, 0],
  },
  { id: 'fassy-klt-finished-1', kind: 'klt-stack', position: [FASSY_ENTRY_X + 1.6, 0, FASSY_LEG_B_Z + 0.5], size: [0.62, 4, 0.44] },
  { id: 'fassy-klt-finished-2', kind: 'klt-stack', position: [FASSY_ENTRY_X + 2.6, 0, FASSY_LEG_B_Z + 0.5], size: [0.62, 3, 0.44] },
  { id: 'fassy-klt-st010', kind: 'klt-stack', position: [xOf('fassy-st010') + 1.1, 0, FASSY_AISLE_Z + 0.9], size: [0.62, 3, 0.44] },
  { id: 'fassy-klt-st060', kind: 'klt-stack', position: [xOf('fassy-st060') - 0.9, 0, FASSY_AISLE_Z + 0.9], size: [0.62, 4, 0.44] },
  { id: 'fassy-klt-st100', kind: 'klt-stack', position: [xOf('fassy-st100') + 0.9, 0, FASSY_AISLE_Z + 0.9], size: [0.62, 3, 0.44] },

  // Residuos peligrosos y escalerilla, como en piso
  { id: 'fassy-drum-st170', kind: 'waste-drum', label: 'RESIDUOS PELIGROSOS', position: [xOf('fassy-st170') + 1.3, 0, FASSY_AISLE_Z + 1.0] },
  { id: 'fassy-drum-st210', kind: 'waste-drum', label: 'RESIDUOS PELIGROSOS', position: [xOf('fassy-st210-cleaning') - 1.0, 0, FASSY_AISLE_Z + 1.0] },
  { id: 'fassy-ladder-oven', kind: 'step-ladder', position: [xOf('fassy-st150-curing') + 2.2, 0, FASSY_AISLE_Z + 1.1] },

  // Material y mobiliario
  { id: 'fassy-trolley-st010', kind: 'material-trolley', position: [xOf('fassy-st010') + 0.1, 0, FASSY_AISLE_Z + 1.2] },
  { id: 'fassy-trolley-st090', kind: 'material-trolley', position: [xOf('fassy-st090'), 0, FASSY_AISLE_Z + 1.2] },
  {
    id: 'fassy-trolley-st170',
    kind: 'material-trolley',
    position: [xOf('fassy-st170'), 0, FASSY_AISLE_Z - 1.2],
    rotation: [0, Math.PI, 0],
  },
  { id: 'fassy-pallet-st200', kind: 'pallet-stack', position: [xOf('fassy-st200-1'), 0, FASSY_AISLE_Z - 1.2] },
  { id: 'fassy-pallet-finished', kind: 'pallet-stack', position: [FASSY_ENTRY_X + 1.4, 0, FASSY_LEG_B_Z + 1.2] },
  { id: 'fassy-chair-st010', kind: 'esd-chair', position: [xOf('fassy-st010') - 0.5, 0, FASSY_LEG_A_Z - 1.3] },
  { id: 'fassy-chair-st020', kind: 'esd-chair', position: [xOf('fassy-st020') - 0.5, 0, FASSY_LEG_A_Z - 1.3] },
  {
    id: 'fassy-chair-st200',
    kind: 'esd-chair',
    position: [xOf('fassy-st200-1') + 0.5, 0, FASSY_LEG_B_Z + 1.3],
    rotation: [0, Math.PI, 0],
  },
]

const PROP_FOOTPRINT: Record<string, [number, number]> = {
  'service-cabinet': [0.9, 0.8],
  'material-trolley': [1.0, 0.72],
  'pallet-stack': [1.3, 1.1],
  'esd-chair': [0.6, 0.6],
  'safety-board': [1.9, 0.35],
  'rack-wall': [4.6, 1.0],
  'klt-stack': [0.66, 0.48],
  'empty-trolley': [1.1, 0.72],
  'waste-drum': [0.62, 0.62],
  'step-ladder': [0.7, 0.9],
  'overhead-crane': [0.4, 0.4],
  'elevator-arch': [0.4, 0.4],
}

const equipmentBlockers: CollisionBox[] = fassyEquipment.map((item) => ({
  id: item.id,
  minX: item.position[0] - item.size[0] / 2 - 0.18,
  maxX: item.position[0] + item.size[0] / 2 + 0.18,
  minZ: item.position[2] - item.size[2] / 2 - 0.45,
  maxZ: item.position[2] + item.size[2] / 2 + 0.45,
}))

const displayBlockers: CollisionBox[] = fassyDisplays.map((display) => ({
  id: display.id,
  minX: display.position[0] - 0.45,
  maxX: display.position[0] + 0.45,
  minZ: display.position[2] - 0.3,
  maxZ: display.position[2] + 0.3,
}))

/**
 * El arco del elevador y la grua se pisan a proposito: solo sus columnas
 * bloquean, no el vano. Por eso se generan a mano en vez de por caja envolvente.
 */
/**
 * El elevador y la grua se atraviesan a proposito: solo sus columnas bloquean,
 * el vano queda libre para caminar. El elevador cruza la celda sobre Z (sus dos
 * columnas van en los extremos de Z) y la grua es un portico de cuatro patas.
 */
const structureBlockers: CollisionBox[] = fassyProps
  .filter((prop) => prop.solid === false)
  .flatMap((prop) => {
    const [width, , depth] = prop.size ?? [2.6, 3, 2.6]
    const half = 0.32

    const columns: [number, number][] =
      prop.kind === 'elevator-arch'
        ? [
            [0, -depth / 2],
            [0, depth / 2],
          ]
        : [
            [-width / 2, -depth / 2],
            [-width / 2, depth / 2],
            [width / 2, -depth / 2],
            [width / 2, depth / 2],
          ]

    return columns.map(([offsetX, offsetZ], index) => ({
      id: `${prop.id}-column-${index}`,
      minX: prop.position[0] + offsetX - half,
      maxX: prop.position[0] + offsetX + half,
      minZ: prop.position[2] + offsetZ - half,
      maxZ: prop.position[2] + offsetZ + half,
    }))
  })

const propBlockers: CollisionBox[] = fassyProps
  .filter((prop) => prop.solid !== false)
  .map((prop) => {
    const footprint = PROP_FOOTPRINT[prop.kind] ?? [0.8, 0.8]
    const width = prop.size ? prop.size[0] : footprint[0]
    const depth = prop.size ? prop.size[2] : footprint[1]
    const yaw = prop.rotation?.[1] ?? 0
    const swap = Math.abs(Math.sin(yaw)) > 0.5
    const halfX = (swap ? depth : width) / 2 + 0.12
    const halfZ = (swap ? width : depth) / 2 + 0.12

    return {
      id: prop.id,
      minX: prop.position[0] - halfX,
      maxX: prop.position[0] + halfX,
      minZ: prop.position[2] - halfZ,
      maxZ: prop.position[2] + halfZ,
    }
  })

/**
 * Muro de fondo de la celda. El piso de la nave termina en z = -25 y la celda
 * llega a -24.4, asi que sin el muro se veia el borde del piso y el vacio.
 */
export const FASSY_REAR_WALL_Z = -24.6

export const fassyRearWall = {
  center: [(fassyBounds.minX + fassyBounds.maxX) / 2 - 0.4, FASSY_REAR_WALL_Z] as [number, number],
  width: fassyBounds.maxX - fassyBounds.minX + 9,
}

const rearWallBlocker: CollisionBox = {
  id: 'fassy-rear-wall',
  minX: fassyRearWall.center[0] - fassyRearWall.width / 2,
  maxX: fassyRearWall.center[0] + fassyRearWall.width / 2,
  minZ: FASSY_REAR_WALL_Z - 0.2,
  maxZ: FASSY_REAR_WALL_Z + 0.2,
}

export const fassyCollisionBoxes: CollisionBox[] = [
  rearWallBlocker,
  ...equipmentBlockers,
  ...displayBlockers,
  ...structureBlockers,
  ...propBlockers,
]

/**
 * Limites caminables ampliados para alcanzar la celda.
 * Se derivan de los de la planta: si esos cambian, estos los siguen.
 */
export const plantWalkableBounds: Bounds2D = {
  ...walkableBounds,
  minX: Math.min(walkableBounds.minX, fassyBounds.minX - 4),
  maxX: Math.max(walkableBounds.maxX, fassyBounds.maxX + 4),
  // Se deriva del extremo real de la celda, no de un tramo: con LEG_A_Z el
  // limite caia dentro del pasillo interior y dejaba el tramo B inalcanzable.
  minZ: Math.min(walkableBounds.minZ, FASSY_REAR_WALL_Z + 0.6),
  maxZ: Math.max(walkableBounds.maxZ, Math.max(FASSY_LEG_A_Z, FASSY_LEG_B_Z) + 3.4),
}
