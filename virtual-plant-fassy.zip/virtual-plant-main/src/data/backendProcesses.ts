import type { BackendProcessConfig } from '../types/backend'
import {
  MANUAL_ASSEMBLY_CONVEYOR_HEIGHT,
  MANUAL_ASSEMBLY_CONVEYOR_WIDTH,
  MASSY_LENGTH,
} from './backendLine'

export const BACKEND_CONVEYOR_HEIGHT = MANUAL_ASSEMBLY_CONVEYOR_HEIGHT
export const ENABLE_WAVE_PCB_ANIMATION = true

const MASSY_OUTPUT_X = MASSY_LENGTH / 2
const MASSY_TO_WAVE_CONVEYOR_LENGTH = 1.0
const WAVE_SOLDER_LENGTH = 8.6
const WAVE_TO_AOI_CONVEYOR_LENGTH = 1.05
const BACKEND_AOI_LENGTH = 1.8
const AOI_TO_OIA_CONVEYOR_LENGTH = 1.15
const OIA_STATION_LENGTH = 3.1
const OIA_STATION_DEPTH = 2.2

const massyToWaveCenterX = MASSY_OUTPUT_X + MASSY_TO_WAVE_CONVEYOR_LENGTH / 2
const waveSolderCenterX = MASSY_OUTPUT_X + MASSY_TO_WAVE_CONVEYOR_LENGTH + WAVE_SOLDER_LENGTH / 2
const waveToAoiCenterX =
  waveSolderCenterX + WAVE_SOLDER_LENGTH / 2 + WAVE_TO_AOI_CONVEYOR_LENGTH / 2
const backendAoiCenterX =
  waveToAoiCenterX + WAVE_TO_AOI_CONVEYOR_LENGTH / 2 + BACKEND_AOI_LENGTH / 2
const backendAoiToOiaCenterX =
  backendAoiCenterX + BACKEND_AOI_LENGTH / 2 + AOI_TO_OIA_CONVEYOR_LENGTH / 2
const backendOiaCenterX =
  backendAoiToOiaCenterX + AOI_TO_OIA_CONVEYOR_LENGTH / 2 + OIA_STATION_LENGTH / 2

export const backendProcesses: BackendProcessConfig[] = [
  {
    id: 'backend-massy-transition',
    name: 'Massy Transition Conveyor',
    shortName: 'MASSY OUT',
    type: 'backend-conveyor',
    position: [massyToWaveCenterX, 0, 0],
    size: [MASSY_TO_WAVE_CONVEYOR_LENGTH, BACKEND_CONVEYOR_HEIGHT, MANUAL_ASSEMBLY_CONVEYOR_WIDTH],
    connectedFrom: 'massy',
    connectedTo: 'wave-solder-1',
  },
  {
    id: 'wave-solder-1',
    name: 'Wave Solder',
    shortName: 'WAVE SOLDER',
    type: 'wave-solder',
    position: [waveSolderCenterX, 0, 0],
    size: [WAVE_SOLDER_LENGTH, 1.72, 1.72],
    connectedFrom: 'backend-massy-transition',
    connectedTo: 'backend-wave-aoi-transition',
  },
  {
    id: 'backend-wave-aoi-transition',
    name: 'Wave to AOI Conveyor',
    shortName: 'WAVE TO AOI',
    type: 'backend-conveyor',
    position: [waveToAoiCenterX, 0, 0],
    size: [WAVE_TO_AOI_CONVEYOR_LENGTH, BACKEND_CONVEYOR_HEIGHT, MANUAL_ASSEMBLY_CONVEYOR_WIDTH],
    connectedFrom: 'wave-solder-1',
    connectedTo: 'backend-wave-aoi',
  },
  {
    id: 'backend-wave-aoi',
    name: 'Post-Wave AOI',
    shortName: 'AOI',
    type: 'backend-aoi',
    position: [backendAoiCenterX, 0, 0],
    size: [BACKEND_AOI_LENGTH, 2.15, 1.38],
    connectedFrom: 'backend-wave-aoi-transition',
    connectedTo: 'backend-aoi-output',
  },
  {
    id: 'backend-aoi-output',
    name: 'AOI to OIA Conveyor',
    shortName: 'AOI TO OIA',
    type: 'backend-conveyor',
    position: [backendAoiToOiaCenterX, 0, 0],
    size: [AOI_TO_OIA_CONVEYOR_LENGTH, BACKEND_CONVEYOR_HEIGHT, MANUAL_ASSEMBLY_CONVEYOR_WIDTH],
    connectedFrom: 'backend-wave-aoi',
    connectedTo: 'backend-oia',
  },
  {
    id: 'backend-oia',
    name: 'OIA Review Station',
    shortName: 'OIA',
    type: 'oia-station',
    position: [backendOiaCenterX, 0, 0],
    size: [OIA_STATION_LENGTH, 1.95, OIA_STATION_DEPTH],
    connectedFrom: 'backend-aoi-output',
  },
]

export const backendProcessBounds = {
  minX: MASSY_OUTPUT_X,
  maxX: backendOiaCenterX + OIA_STATION_LENGTH / 2,
}
