import { displayStations, lineBounds } from './smtLine'
import type { CollisionBox, DisplayMedia, FloorDisplayStationConfig, Vec3 } from '../types/factory'

const liberacionesStation = displayStations.find((station) => station.id === 'solder-paste-display')

if (!liberacionesStation) {
  throw new Error('Missing Liberaciones display station for information center')
}

export const informationCenterPosition: Vec3 = [lineBounds.minX + 15.4, 0, 10.35]
export const INFORMATION_CENTER_RADIUS = 1.46
export const INFORMATION_CENTER_HEIGHT = 2.56
export const INFORMATION_CENTER_SCREEN_WIDTH = 1.08
export const INFORMATION_CENTER_SCREEN_HEIGHT = 0.66
export const INFORMATION_CENTER_ROTATION_Y = Math.PI / 6

export const informationCenterMedia: DisplayMedia = liberacionesStation.media

export const informationCenterDisplays: FloorDisplayStationConfig[] = Array.from({ length: 6 }, (_, index) => ({
  id: `information-center-screen-${index + 1}`,
  title: 'Liberaciones',
  position: informationCenterPosition,
  rotation: [0, 0, 0],
  width: INFORMATION_CENTER_SCREEN_WIDTH,
  height: INFORMATION_CENTER_SCREEN_HEIGHT,
  media: informationCenterMedia,
}))

export const informationCenterCollisionBoxes: CollisionBox[] = [
  {
    id: 'information-center-kiosk',
    minX: informationCenterPosition[0] - 2.1,
    maxX: informationCenterPosition[0] + 2.1,
    minZ: informationCenterPosition[2] - 2.1,
    maxZ: informationCenterPosition[2] + 2.1,
  },
]
