import { backendLineConfigs } from './backendLine'
import { backendProcesses } from './backendProcesses'
import { backendSupportTables } from './backendSupportTables'
import type { CollisionBox, FloorDisplayStationConfig } from '../types/factory'

const targetBackendLine = backendLineConfigs[1]
const targetOiaProcess = backendProcesses.find((process) => process.id === 'backend-oia')

if (!targetOiaProcess) {
  throw new Error('Missing backend OIA process for backend display station')
}

const targetOiaWorldX = targetBackendLine.position[0] + targetOiaProcess.position[0]
const targetOiaWorldZ = targetBackendLine.position[2] + targetOiaProcess.position[2]
const centerReworkTable = backendSupportTables[1]

export const backendDisplayStations: FloorDisplayStationConfig[] = [
  {
    id: 'backend-oia-classificator-display',
    title: 'AOI IMAGE CLASSIFICATOR',
    position: [targetOiaWorldX - 0.2, 0, targetOiaWorldZ + targetOiaProcess.size[2] / 2 + 1.45],
    width: 1.15,
    height: 0.65,
    promptText: 'E — Ver clasificador AOI',
    media: {
      type: 'auto',
      source: '/screens/aoi-image-clasificator.png',
      fallback: '/media/screens/placeholder.svg',
      fit: 'contain',
    },
  },
  {
    id: 'rework-app-display',
    title: 'REWORK APP',
    position: [centerReworkTable.position[0] + 5.1, 0, centerReworkTable.position[2]],
    rotation: [0, Math.PI, 0],
    width: 1.15,
    height: 0.65,
    promptText: 'E — Ver Rework App',
    media: {
      type: 'auto',
      source: '/screens/rework-app.png',
      fallback: '/media/screens/placeholder.svg',
      fit: 'contain',
    },
  },
]

export const backendDisplayCollisionBoxes: CollisionBox[] = backendDisplayStations.map((display) => ({
  id: `${display.id}-blocker`,
  minX: display.position[0] - 0.55,
  maxX: display.position[0] + 0.55,
  minZ: display.position[2] - 0.35,
  maxZ: display.position[2] + 0.35,
}))
