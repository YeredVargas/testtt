import { backendLineConfigs } from './backendLine'
import { backendProcesses } from './backendProcesses'
import type { CollisionBox, Vec3 } from '../types/factory'

export interface BackendStandaloneEquipmentConfig {
  id: string
  name: string
  type: 'backend-laser' | 'socket-insertion'
  position: Vec3
  rotation: Vec3
  size: Vec3
}

const primaryBackendLine = backendLineConfigs[0]
const waveSolder = backendProcesses.find((process) => process.id === 'wave-solder-1')

if (!waveSolder) {
  throw new Error('Missing backend process for standalone equipment')
}

const rearLaneZ = primaryBackendLine.position[2] - 5.95
const laserSize: Vec3 = [2.65, 2.18, 1.72]
const socketSize: Vec3 = [2.2, 2.2, 1.58]
const laserPosition: Vec3 = [primaryBackendLine.position[0] + waveSolder.position[0] - 1.2, 0, rearLaneZ]
const laserToSocketLength = 1.65
const socketToConformalLength = 0.78
const socketPosition: Vec3 = [
  laserPosition[0] + laserSize[0] / 2 + laserToSocketLength + socketSize[0] / 2,
  0,
  rearLaneZ,
]

export const backendStandaloneEquipment: BackendStandaloneEquipmentConfig[] = [
  {
    id: 'backend-laser-standalone',
    name: 'LASER BACKEND',
    type: 'backend-laser',
    position: laserPosition,
    rotation: [0, 0, 0],
    size: laserSize,
  },
  {
    id: 'backend-socket-insertion',
    name: 'SOCKET INSERTION',
    type: 'socket-insertion',
    position: socketPosition,
    rotation: [0, 0, 0],
    size: socketSize,
  },
]

export const backendSocketToConformalConnection = {
  referenceProcessId: 'backend-socket-insertion',
  length: socketToConformalLength,
}

export const backendStandaloneCollisionBoxes: CollisionBox[] = backendStandaloneEquipment.map((equipment) => ({
  id: `${equipment.id}-blocker`,
  minX: equipment.position[0] - equipment.size[0] / 2 - 0.1,
  maxX: equipment.position[0] + equipment.size[0] / 2 + 0.1,
  minZ: equipment.position[2] - equipment.size[2] / 2 - 0.1,
  maxZ: equipment.position[2] + equipment.size[2] / 2 + 0.1,
}))
