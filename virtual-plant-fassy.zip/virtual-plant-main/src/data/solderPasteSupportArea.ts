import { getSmtEquipment } from './smtLine'
import type { CollisionBox, FloorDisplayStationConfig, Vec3 } from '../types/factory'

const solderPastePrinter = getSmtEquipment('solder-paste-printer')
const rearZ = solderPastePrinter.position[2] - solderPastePrinter.size[2] / 2 - 7.15

const solderPasteFifoDisplayLocalPosition: Vec3 = [-2.92, 0, 0.36]

export const solderPasteSupportArea = {
  position: [solderPastePrinter.position[0] + 0.15, 0, rearZ] as Vec3,
  cabinet: {
    position: [-1.95, 0, 0] as Vec3,
    size: [1.5, 2.18, 0.62] as Vec3,
  },
  table: {
    position: [0.1, 0, 0.02] as Vec3,
    size: [1.5, 0.9, 0.78] as Vec3,
  },
  fridge: {
    position: [0.1, 0.9, 0.02] as Vec3,
    size: [0.64, 1.0, 0.52] as Vec3,
  },
  workstationTable: {
    position: [2.55, 0, 0.08] as Vec3,
    size: [1.7, 0.9, 0.82] as Vec3,
  },
}

export const solderPasteFifoDisplay: FloorDisplayStationConfig = {
  id: 'solder-paste-fifo-display',
  title: 'FIFO PASTAS',
  position: solderPasteFifoDisplayLocalPosition,
  rotation: [0, 0, 0],
  width: 1.15,
  height: 0.65,
  media: {
    type: 'image',
    source: '/screens/fifo-pastas.png',
    fallback: '/media/screens/placeholder.svg',
    fit: 'contain',
  },
}

export const solderPasteFifoDisplayWorldPosition: Vec3 = [
  solderPasteSupportArea.position[0] + solderPasteFifoDisplay.position[0],
  solderPasteSupportArea.position[1] + solderPasteFifoDisplay.position[1],
  solderPasteSupportArea.position[2] + solderPasteFifoDisplay.position[2],
]

export const solderPasteSupportCollisionBoxes: CollisionBox[] = [
  {
    id: 'spp-support-cabinet-blocker',
    minX: solderPasteSupportArea.position[0] + solderPasteSupportArea.cabinet.position[0] - solderPasteSupportArea.cabinet.size[0] / 2,
    maxX: solderPasteSupportArea.position[0] + solderPasteSupportArea.cabinet.position[0] + solderPasteSupportArea.cabinet.size[0] / 2,
    minZ: solderPasteSupportArea.position[2] + solderPasteSupportArea.cabinet.position[2] - solderPasteSupportArea.cabinet.size[2] / 2,
    maxZ: solderPasteSupportArea.position[2] + solderPasteSupportArea.cabinet.position[2] + solderPasteSupportArea.cabinet.size[2] / 2,
  },
  {
    id: 'spp-support-table-blocker',
    minX: solderPasteSupportArea.position[0] + solderPasteSupportArea.table.position[0] - solderPasteSupportArea.table.size[0] / 2,
    maxX: solderPasteSupportArea.position[0] + solderPasteSupportArea.table.position[0] + solderPasteSupportArea.table.size[0] / 2,
    minZ: solderPasteSupportArea.position[2] + solderPasteSupportArea.table.position[2] - solderPasteSupportArea.table.size[2] / 2,
    maxZ: solderPasteSupportArea.position[2] + solderPasteSupportArea.table.position[2] + solderPasteSupportArea.table.size[2] / 2,
  },
  {
    id: 'spp-support-workstation-table-blocker',
    minX: solderPasteSupportArea.position[0] + solderPasteSupportArea.workstationTable.position[0] - solderPasteSupportArea.workstationTable.size[0] / 2,
    maxX: solderPasteSupportArea.position[0] + solderPasteSupportArea.workstationTable.position[0] + solderPasteSupportArea.workstationTable.size[0] / 2,
    minZ: solderPasteSupportArea.position[2] + solderPasteSupportArea.workstationTable.position[2] - solderPasteSupportArea.workstationTable.size[2] / 2,
    maxZ: solderPasteSupportArea.position[2] + solderPasteSupportArea.workstationTable.position[2] + solderPasteSupportArea.workstationTable.size[2] / 2,
  },
  {
    id: 'spp-support-fifo-display-blocker',
    minX: solderPasteFifoDisplayWorldPosition[0] - 0.55,
    maxX: solderPasteFifoDisplayWorldPosition[0] + 0.55,
    minZ: solderPasteFifoDisplayWorldPosition[2] - 0.35,
    maxZ: solderPasteFifoDisplayWorldPosition[2] + 0.35,
  },
]
