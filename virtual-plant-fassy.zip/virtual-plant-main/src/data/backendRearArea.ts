import type { BackendRearAreaConfig } from '../types/backend'
import { manualAssemblyLineConfig } from './backendLine'

const station1 = manualAssemblyLineConfig.stations[0]

export const backendRearAreaConfig: BackendRearAreaConfig = {
  id: 'backend-rear-station-1',
  stationId: 'massy-station-1',
  localOffset: [station1.position[0], 0, 0],
  display: {
    id: 'backend-rear-display-station-1',
    title: 'BACKEND OPS',
    position: [-0.4, 0, -1.75],
    rotation: [0, Math.PI, 0],
    source: '/screens/kanban.png',
    width: 1.15,
    height: 0.65,
    promptText: 'E — Ver BACKEND OPS',
  },
  racks: [
    {
      id: 'backend-massy-station-1-rack-1',
      position: [-0.9, 0, -4.1],
      levels: 4,
      binsPerLevel: 4,
      width: 1.85,
      height: 1.62,
      depth: 0.72,
      labelPrefix: 'MASSY',
    },
    {
      id: 'backend-massy-station-1-rack-2',
      position: [1.45, 0, -4.1],
      levels: 4,
      binsPerLevel: 4,
      width: 1.85,
      height: 1.62,
      depth: 0.72,
      labelPrefix: 'MASSY',
    },
    {
      id: 'backend-massy-station-1-rack-3',
      position: [3.8, 0, -4.1],
      levels: 4,
      binsPerLevel: 4,
      width: 1.85,
      height: 1.62,
      depth: 0.72,
      labelPrefix: 'MASSY',
    },
  ],
}
