import { solderPasteFifoDisplay, solderPasteSupportArea } from '../data/solderPasteSupportArea'
import { IndustrialScreen } from './IndustrialScreen'
import { WorkstationMonitor } from './backend/WorkstationMonitor'
import type { MediaModalData } from '../types/factory'

interface SolderPasteSupportAreaProps {
  onOpenMedia?: (media: MediaModalData) => void
}

function getMediaType(source: string): 'image' | 'gif' | 'video' {
  const extension = source.split('?')[0].toLowerCase().split('.').pop()

  if (extension === 'gif') {
    return 'gif'
  }

  if (extension === 'mp4' || extension === 'webm') {
    return 'video'
  }

  return 'image'
}

export function SolderPasteSupportArea({ onOpenMedia }: SolderPasteSupportAreaProps) {
  const { cabinet, fridge, position, table, workstationTable } = solderPasteSupportArea
  const mediaSource = solderPasteFifoDisplay.media.source
  const mediaType = getMediaType(mediaSource)

  return (
    <group position={position}>
      <group position={cabinet.position}>
        <mesh castShadow receiveShadow position={[0, cabinet.size[1] / 2, 0]}>
          <boxGeometry args={cabinet.size} />
          <meshStandardMaterial color="#d7dbde" roughness={0.76} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.34, cabinet.size[1] / 2, cabinet.size[2] / 2 + 0.02]}>
          <boxGeometry args={[0.64, 1.84, 0.03]} />
          <meshStandardMaterial color="#eceff1" roughness={0.82} metalness={0.04} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.34, cabinet.size[1] / 2, cabinet.size[2] / 2 + 0.02]}>
          <boxGeometry args={[0.64, 1.84, 0.03]} />
          <meshStandardMaterial color="#eceff1" roughness={0.82} metalness={0.04} />
        </mesh>
        <mesh position={[-0.02, 1.1, cabinet.size[2] / 2 + 0.04]}>
          <boxGeometry args={[0.03, 1.12, 0.02]} />
          <meshStandardMaterial color="#7b848c" roughness={0.44} metalness={0.42} />
        </mesh>
        <mesh position={[0.12, 1.1, cabinet.size[2] / 2 + 0.04]}>
          <boxGeometry args={[0.03, 1.12, 0.02]} />
          <meshStandardMaterial color="#7b848c" roughness={0.44} metalness={0.42} />
        </mesh>
      </group>

      <group position={table.position}>
        <mesh castShadow receiveShadow position={[0, table.size[1] - 0.025, 0]}>
          <boxGeometry args={[table.size[0], 0.05, table.size[2]]} />
          <meshStandardMaterial color="#2f7658" roughness={0.78} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, table.size[1] - 0.025, table.size[2] / 2 - 0.025]}>
          <boxGeometry args={[table.size[0], 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, table.size[1] - 0.025, -table.size[2] / 2 + 0.025]}>
          <boxGeometry args={[table.size[0], 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        {[-table.size[0] / 2 + 0.1, table.size[0] / 2 - 0.1].map((x) => (
          <group key={x} position={[x, 0, 0]}>
            {[-table.size[2] / 2 + 0.08, table.size[2] / 2 - 0.08].map((z) => (
              <mesh key={z} castShadow receiveShadow position={[0, table.size[1] / 2, z]}>
                <boxGeometry args={[0.07, table.size[1], 0.07]} />
                <meshStandardMaterial color="#7c848b" roughness={0.44} metalness={0.54} />
              </mesh>
            ))}
          </group>
        ))}
        <mesh castShadow receiveShadow position={[0, 0.22, 0]}>
          <boxGeometry args={[table.size[0] - 0.24, 0.04, table.size[2] - 0.16]} />
          <meshStandardMaterial color="#d5dadd" roughness={0.82} metalness={0.06} />
        </mesh>
      </group>

      <group position={fridge.position}>
        <mesh castShadow receiveShadow position={[0, fridge.size[1] / 2, 0]}>
          <boxGeometry args={fridge.size} />
          <meshStandardMaterial color="#c9d2da" roughness={0.62} metalness={0.12} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, fridge.size[1] / 2, fridge.size[2] / 2 + 0.016]}>
          <boxGeometry args={[fridge.size[0] * 0.82, fridge.size[1] * 0.86, 0.03]} />
          <meshStandardMaterial color="#4da3ff" transparent opacity={0.36} roughness={0.08} metalness={0.14} />
        </mesh>
        <mesh position={[fridge.size[0] * 0.26, fridge.size[1] / 2, fridge.size[2] / 2 + 0.035]}>
          <boxGeometry args={[0.03, fridge.size[1] * 0.72, 0.02]} />
          <meshStandardMaterial color="#dbe4ec" roughness={0.38} metalness={0.42} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 0.32, 0]}>
          <boxGeometry args={[fridge.size[0] * 0.72, 0.02, fridge.size[2] * 0.72]} />
          <meshStandardMaterial color="#edf2f7" roughness={0.74} metalness={0.04} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 0.62, 0]}>
          <boxGeometry args={[fridge.size[0] * 0.72, 0.02, fridge.size[2] * 0.72]} />
          <meshStandardMaterial color="#edf2f7" roughness={0.74} metalness={0.04} />
        </mesh>
      </group>

      <group position={workstationTable.position}>
        <mesh castShadow receiveShadow position={[0, workstationTable.size[1] - 0.025, 0]}>
          <boxGeometry args={[workstationTable.size[0], 0.05, workstationTable.size[2]]} />
          <meshStandardMaterial color="#2f7658" roughness={0.78} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, workstationTable.size[1] - 0.025, workstationTable.size[2] / 2 - 0.025]}>
          <boxGeometry args={[workstationTable.size[0], 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, workstationTable.size[1] - 0.025, -workstationTable.size[2] / 2 + 0.025]}>
          <boxGeometry args={[workstationTable.size[0], 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        {[-workstationTable.size[0] / 2 + 0.1, workstationTable.size[0] / 2 - 0.1].map((x) => (
          <group key={x} position={[x, 0, 0]}>
            {[-workstationTable.size[2] / 2 + 0.08, workstationTable.size[2] / 2 - 0.08].map((z) => (
              <mesh key={z} castShadow receiveShadow position={[0, workstationTable.size[1] / 2, z]}>
                <boxGeometry args={[0.07, workstationTable.size[1], 0.07]} />
                <meshStandardMaterial color="#7c848b" roughness={0.44} metalness={0.54} />
              </mesh>
            ))}
          </group>
        ))}
        <mesh castShadow receiveShadow position={[0, 0.22, 0]}>
          <boxGeometry args={[workstationTable.size[0] - 0.24, 0.04, workstationTable.size[2] - 0.18]} />
          <meshStandardMaterial color="#d5dadd" roughness={0.82} metalness={0.06} />
        </mesh>
        <WorkstationMonitor
          position={[0, 1.54, 0.18]}
          rotation={[-0.1, -0.06, 0]}
          width={0.72}
          height={0.42}
          media={{
            type: 'image',
            source: '/media/screens/placeholder.svg',
            fallback: '/media/screens/placeholder.svg',
            fit: 'cover',
          }}
        />
        <mesh castShadow receiveShadow position={[0.3, workstationTable.size[1] + 0.03, 0.06]}>
          <boxGeometry args={[0.36, 0.18, 0.24]} />
          <meshStandardMaterial color="#636b73" roughness={0.56} metalness={0.24} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.3, workstationTable.size[1] + 0.11, 0.11]}>
          <boxGeometry args={[0.22, 0.03, 0.01]} />
          <meshStandardMaterial color="#111827" roughness={0.32} metalness={0.14} />
        </mesh>
      </group>

      <group position={solderPasteFifoDisplay.position} rotation={solderPasteFifoDisplay.rotation}>
        <mesh castShadow receiveShadow position={[0, 0.78, -0.08]}>
          <boxGeometry args={[0.08, 1.2, 0.08]} />
          <meshStandardMaterial color="#97a1a9" roughness={0.48} metalness={0.42} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 1.48, -0.04]}>
          <boxGeometry args={[1.34, 0.82, 0.08]} />
          <meshStandardMaterial color="#111827" roughness={0.34} metalness={0.22} />
        </mesh>
        <mesh position={[0, 1.48, 0.01]}>
          <boxGeometry args={[1.2, 0.68, 0.02]} />
          <meshStandardMaterial color="#050505" roughness={0.24} metalness={0.18} />
        </mesh>
        <group position={[0, 1.48, 0.022]}>
          <IndustrialScreen media={solderPasteFifoDisplay.media} width={1.15} height={0.65} />
        </group>
        <mesh
          position={[0, 1.48, 0.04]}
          onClick={() => {
            onOpenMedia?.({
              id: solderPasteFifoDisplay.id,
              title: solderPasteFifoDisplay.title,
              source: mediaSource,
              mediaType,
            })
          }}
          userData={{
            interactive: true,
            interactionType: 'media-display',
            displayId: solderPasteFifoDisplay.id,
            title: solderPasteFifoDisplay.title,
            mediaSource,
            mediaType,
          }}
        >
          <planeGeometry args={[1.15, 0.65]} />
          <meshBasicMaterial transparent opacity={0} depthWrite={false} colorWrite={false} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 0.92, -0.06]}>
          <boxGeometry args={[0.38, 0.06, 0.18]} />
          <meshStandardMaterial color="#5f6973" roughness={0.56} metalness={0.26} />
        </mesh>
      </group>
    </group>
  )
}
