interface InstructionsProps {
  isPointerLocked: boolean
  showStartOverlay?: boolean
}

export function Instructions({ isPointerLocked, showStartOverlay = true }: InstructionsProps) {
  return (
    <>
      {!isPointerLocked && showStartOverlay && (
        <div className="start-overlay" aria-live="polite">
          <div className="start-card">
            <button id="start-tour-button" type="button" className="start-button">
              Haz clic para iniciar el recorrido
            </button>
            <p>Recorre la linea SMT en primera persona con mouse y teclado.</p>
          </div>
        </div>
      )}

      <div className="hud hud-bottom">
        <span className="hint-pill">WASD para moverte</span>
        <span className="hint-pill">Mouse para mirar</span>
        <span className="hint-pill">Shift para avanzar rapido</span>
        <span className="hint-pill">ESC para liberar el mouse</span>
      </div>

      <aside className="mobile-warning">
        Se recomienda usar computadora y teclado para esta experiencia.
      </aside>
    </>
  )
}
