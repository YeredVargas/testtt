import { Text } from '@react-three/drei'
import { BoxGeometry, MeshStandardMaterial } from 'three'

interface MaterialBinProps {
  position: [number, number, number]
  label?: string
  accentColor?: string
}

const binBodyGeometry = new BoxGeometry(0.26, 0.14, 0.18)
const binLabelGeometry = new BoxGeometry(0.18, 0.08, 0.01)
const binAccentGeometry = new BoxGeometry(0.04, 0.05, 0.006)
const binBodyMaterial = new MeshStandardMaterial({ color: '#0d0f12', metalness: 0.05, roughness: 0.8 })
const binLabelMaterial = new MeshStandardMaterial({ color: '#e9ecef', metalness: 0, roughness: 0.85 })
const accentMaterials = {
  '#35c6b2': new MeshStandardMaterial({ color: '#35c6b2', metalness: 0.04, roughness: 0.62 }),
  '#4da3ff': new MeshStandardMaterial({ color: '#4da3ff', metalness: 0.04, roughness: 0.62 }),
} as const

export function MaterialBin({
  position,
  label,
  accentColor = '#35c6b2',
}: MaterialBinProps) {
  const accentMaterial = accentMaterials[accentColor as keyof typeof accentMaterials] ?? accentMaterials['#35c6b2']

  return (
    <group position={position}>
      <mesh>
        <primitive object={binBodyGeometry} attach="geometry" />
        <primitive object={binBodyMaterial} attach="material" />
      </mesh>
      <mesh position={[0, 0.01, 0.086]}>
        <primitive object={binLabelGeometry} attach="geometry" />
        <primitive object={binLabelMaterial} attach="material" />
      </mesh>
      <mesh position={[-0.07, 0.015, 0.092]}>
        <primitive object={binAccentGeometry} attach="geometry" />
        <primitive object={accentMaterial} attach="material" />
      </mesh>
      {label ? (
        <Text position={[0.03, 0.015, 0.095]} fontSize={0.03} color="#111827" anchorX="center" anchorY="middle">
          {label}
        </Text>
      ) : null}
    </group>
  )
}
