import { Text } from '@react-three/drei'

interface StationSignProps {
  number: number
  position: [number, number, number]
}

export function StationSign({ number, position }: StationSignProps) {
  return (
    <group position={position}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[1.06, 0.32, 0.05]} />
        <meshStandardMaterial color="#234a78" roughness={0.52} metalness={0.16} />
      </mesh>
      <mesh position={[0, 0, 0.028]}>
        <boxGeometry args={[0.98, 0.24, 0.01]} />
        <meshStandardMaterial color="#f4f7fa" roughness={0.82} metalness={0.04} />
      </mesh>
      <Text position={[0, 0, 0.034]} fontSize={0.12} color="#234a78" anchorX="center" anchorY="middle">
        {`ESTACION ${number}`}
      </Text>
    </group>
  )
}
