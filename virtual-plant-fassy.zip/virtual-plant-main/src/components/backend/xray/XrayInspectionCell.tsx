import { xrayTransferTrayConfig } from '../../../data/xrayInspectionCell'
import type { MediaModalData } from '../../../types/factory'
import type { XrayInspectionCellConfig } from '../../../types/xray'
import { GreenInspectionTable } from './GreenInspectionTable'
import { InteractiveWorkMonitor } from './InteractiveWorkMonitor'
import { TableScanner } from './TableScanner'
import { XiaMachine } from './XiaMachine'
import { XrayMachine } from './XrayMachine'

interface XrayInspectionCellProps {
  config: XrayInspectionCellConfig
  onOpenMedia?: (media: MediaModalData) => void
}

export function XrayInspectionCell({ config, onOpenMedia }: XrayInspectionCellProps) {
  const table = config.equipment.find((equipment) => equipment.type === 'inspection-table')
  const xrayMachine = config.equipment.find((equipment) => equipment.type === 'xray')
  const xiaMachine = config.equipment.find((equipment) => equipment.type === 'xia')

  if (!table || !xrayMachine || !xiaMachine) {
    return null
  }

  return (
    <group position={config.position} rotation={config.rotation}>
      <GreenInspectionTable position={table.position} size={table.size} />

      <group position={table.position}>
        <mesh castShadow receiveShadow position={[-0.56, table.size[1] + 0.28, 0.28]}>
          <cylinderGeometry args={[0.03, 0.04, 0.58, 12]} />
          <meshStandardMaterial color="#8e969d" roughness={0.44} metalness={0.52} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.36, table.size[1] + 0.49, 0.18]} rotation={[0, 0, 0.22]}>
          <boxGeometry args={[0.44, 0.04, 0.04]} />
          <meshStandardMaterial color="#9ba3aa" roughness={0.46} metalness={0.44} />
        </mesh>

        <InteractiveWorkMonitor config={config.monitor} onOpenMedia={onOpenMedia} />
        <TableScanner position={[0.06, table.size[1] + 0.01, 0.04]} />
      </group>

      <XrayMachine position={xrayMachine.position} size={xrayMachine.size} />

      <mesh castShadow receiveShadow position={xrayTransferTrayConfig.position}>
        <boxGeometry args={xrayTransferTrayConfig.size} />
        <meshStandardMaterial color="#717a81" roughness={0.56} metalness={0.34} />
      </mesh>

      <XiaMachine position={xiaMachine.position} size={xiaMachine.size} />
    </group>
  )
}
