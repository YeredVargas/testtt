import { Text } from '@react-three/drei'
import { PcbBoard } from '../../PcbBoard'

interface XiaMachineProps {
  position: [number, number, number]
  size: [number, number, number]
}

export function XiaMachine({ position, size }: XiaMachineProps) {
  const [width, , depth] = size
  const mainDeskWidth = width * 0.72
  const sideDeskDepth = depth * 0.82

  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[-width * 0.34, 0.92, 0.08]}>
        <boxGeometry args={[0.72, 0.06, 0.34]} />
        <meshStandardMaterial color="#737b82" roughness={0.54} metalness={0.34} />
      </mesh>

      <mesh castShadow receiveShadow position={[-0.04, 0.78, -0.32]}>
        <boxGeometry args={[mainDeskWidth, 0.08, 0.68]} />
        <meshStandardMaterial color="#c7ced3" roughness={0.74} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.22, 0.78, 0.02]}>
        <boxGeometry args={[0.58, 0.08, sideDeskDepth]} />
        <meshStandardMaterial color="#c7ced3" roughness={0.74} metalness={0.08} />
      </mesh>

      {[
        [-0.58, 0.39, -0.62],
        [0.42, 0.39, -0.62],
        [0.56, 0.39, 0.52],
        [0.9, 0.39, 0.52],
        [0.9, 0.39, -0.48],
      ].map((leg) => (
        <mesh key={leg.join('-')} castShadow receiveShadow position={leg as [number, number, number]}>
          <boxGeometry args={[0.08, 0.74, 0.08]} />
          <meshStandardMaterial color="#6f7780" roughness={0.48} metalness={0.46} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0.12, 0.53, -0.06]}>
        <boxGeometry args={[0.48, 0.46, 0.38]} />
        <meshStandardMaterial color="#9ba3aa" roughness={0.84} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.62, 0.53, 0.22]}>
        <boxGeometry args={[0.24, 0.46, 0.72]} />
        <meshStandardMaterial color="#9ba3aa" roughness={0.84} metalness={0.04} />
      </mesh>

      {[
        { position: [-0.12, 1.16, -0.7] as [number, number, number], width: 0.54 },
        { position: [0.64, 1.16, -0.18] as [number, number, number], width: 0.48 },
      ].map((monitor) => (
        <group key={monitor.position.join('-')} position={monitor.position}>
          <mesh castShadow receiveShadow position={[0, -0.2, 0]}>
            <cylinderGeometry args={[0.03, 0.03, 0.32, 14]} />
            <meshStandardMaterial color="#6b7280" roughness={0.46} metalness={0.42} />
          </mesh>
          <mesh castShadow receiveShadow position={[0, -0.36, 0]}>
            <boxGeometry args={[0.18, 0.02, 0.13]} />
            <meshStandardMaterial color="#757f87" roughness={0.54} metalness={0.34} />
          </mesh>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[monitor.width, 0.3, 0.05]} />
            <meshStandardMaterial color="#111827" roughness={0.24} metalness={0.16} />
          </mesh>
          <mesh position={[0, 0, 0.028]}>
            <boxGeometry args={[monitor.width * 0.88, 0.22, 0.01]} />
            <meshStandardMaterial color="#0f172a" emissive="#39d26d" emissiveIntensity={0.16} roughness={0.2} metalness={0.08} />
          </mesh>
          <mesh position={[0, 0.09, 0.029]}>
            <boxGeometry args={[monitor.width * 0.54, 0.025, 0.01]} />
            <meshStandardMaterial color="#dfe8ef" emissive="#dfe8ef" emissiveIntensity={0.08} />
          </mesh>
        </group>
      ))}

      <mesh castShadow receiveShadow position={[-0.12, 0.85, -0.26]}>
        <boxGeometry args={[0.3, 0.02, 0.12]} />
        <meshStandardMaterial color="#2d3748" roughness={0.62} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.42, 0.85, -0.08]} rotation={[0, -0.35, 0]}>
        <boxGeometry args={[0.18, 0.018, 0.11]} />
        <meshStandardMaterial color="#111827" roughness={0.48} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.62, 0.846, -0.02]}>
        <boxGeometry args={[0.07, 0.014, 0.09]} />
        <meshStandardMaterial color="#111827" roughness={0.48} metalness={0.12} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.16, 0.85, 0.04]}>
        <cylinderGeometry args={[0.08, 0.08, 0.05, 20]} />
        <meshStandardMaterial color="#c7ced4" roughness={0.7} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.16, 0.85, 0.04]}>
        <cylinderGeometry args={[0.04, 0.04, 0.07, 20]} />
        <meshStandardMaterial color="#94a3b8" roughness={0.42} metalness={0.44} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.82, 1.88, -0.68]}>
        <boxGeometry args={[0.92, 0.28, 0.05]} />
        <meshStandardMaterial color="#234a78" roughness={0.5} metalness={0.16} />
      </mesh>
      <mesh position={[0.82, 1.88, -0.65]}>
        <boxGeometry args={[0.82, 0.2, 0.01]} />
        <meshStandardMaterial color="#f4f7fa" roughness={0.82} metalness={0.04} />
      </mesh>
      <Text position={[0.82, 1.88, -0.64]} fontSize={0.13} color="#234a78" anchorX="center" anchorY="middle">
        XIA
      </Text>

      <mesh castShadow receiveShadow position={[0.98, 1.72, -0.18]}>
        <cylinderGeometry args={[0.034, 0.034, 0.32, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#39d26d', y: 1.86 },
        { color: '#f2c500', y: 1.97 },
        { color: '#ef4444', y: 2.08 },
      ].map((light) => (
        <mesh key={light.color} position={[0.98, light.y, -0.18]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
        </mesh>
      ))}

      <mesh position={[0.98, 0.9, -0.14]}>
        <cylinderGeometry args={[0.045, 0.045, 0.04, 16]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.34} />
      </mesh>
      <mesh position={[0.98, 0.84, -0.14]}>
        <cylinderGeometry args={[0.075, 0.075, 0.05, 16]} />
        <meshStandardMaterial color="#f2c500" roughness={0.54} metalness={0.08} />
      </mesh>

      <PcbBoard board={{ id: 'xia-review-board', position: [-width * 0.34, 0.95, 0.08] }} />
    </group>
  )
}
