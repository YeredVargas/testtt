import { PcbBoard } from '../../PcbBoard'

interface GreenInspectionTableProps {
  position: [number, number, number]
  size: [number, number, number]
}

export function GreenInspectionTable({ position, size }: GreenInspectionTableProps) {
  const [width, height, depth] = size
  const topThickness = 0.05
  const legInsetX = width / 2 - 0.09
  const legInsetZ = depth / 2 - 0.08

  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, 0]}>
        <boxGeometry args={[width, topThickness, depth]} />
        <meshStandardMaterial color="#2f7658" roughness={0.78} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, depth / 2 - 0.025]}>
        <boxGeometry args={[width, 0.05, 0.05]} />
        <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, -depth / 2 + 0.025]}>
        <boxGeometry args={[width, 0.05, 0.05]} />
        <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
      </mesh>

      {[
        [-legInsetX, height / 2, -legInsetZ],
        [legInsetX, height / 2, -legInsetZ],
        [-legInsetX, height / 2, legInsetZ],
        [legInsetX, height / 2, legInsetZ],
      ].map((leg) => (
        <group key={leg.join('-')} position={leg as [number, number, number]}>
          <mesh castShadow receiveShadow position={[0, 0, 0]}>
            <boxGeometry args={[0.07, height, 0.07]} />
            <meshStandardMaterial color="#7c848b" roughness={0.44} metalness={0.54} />
          </mesh>
          <mesh castShadow receiveShadow position={[0, -height / 2 + 0.02, 0]}>
            <cylinderGeometry args={[0.03, 0.035, 0.04, 12]} />
            <meshStandardMaterial color="#8f979e" roughness={0.5} metalness={0.42} />
          </mesh>
        </group>
      ))}

      <mesh castShadow receiveShadow position={[0, 0.22, 0]}>
        <boxGeometry args={[width - 0.24, 0.04, depth - 0.18]} />
        <meshStandardMaterial color="#d5dadd" roughness={0.82} metalness={0.06} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.42, -depth / 2 + 0.03]}>
        <boxGeometry args={[width - 0.12, 0.04, 0.05]} />
        <meshStandardMaterial color="#aeb4b8" roughness={0.56} metalness={0.34} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.42, depth / 2 - 0.03]}>
        <boxGeometry args={[width - 0.12, 0.04, 0.05]} />
        <meshStandardMaterial color="#aeb4b8" roughness={0.56} metalness={0.34} />
      </mesh>

      <mesh castShadow receiveShadow position={[-0.48, height + 0.03, -0.12]}>
        <boxGeometry args={[0.24, 0.12, 0.18]} />
        <meshStandardMaterial color="#67717a" roughness={0.62} metalness={0.2} />
      </mesh>

      <mesh position={[-0.38, height + 0.09, -0.06]}>
        <cylinderGeometry args={[0.018, 0.018, 0.02, 12]} />
        <meshStandardMaterial color="#16a34a" emissive="#16a34a" emissiveIntensity={0.26} />
      </mesh>

      <mesh position={[-0.33, height + 0.09, -0.06]}>
        <cylinderGeometry args={[0.018, 0.018, 0.02, 12]} />
        <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.26} />
      </mesh>

      <mesh position={[-0.52, height + 0.09, -0.06]}>
        <cylinderGeometry args={[0.03, 0.03, 0.03, 14]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.32} />
      </mesh>

      <mesh position={[-0.52, height + 0.055, -0.06]}>
        <cylinderGeometry args={[0.05, 0.05, 0.03, 14]} />
        <meshStandardMaterial color="#f2c500" roughness={0.56} metalness={0.08} />
      </mesh>

      <PcbBoard board={{ id: 'xray-table-board', position: [0.28, height + 0.03, 0.12], rotation: [0, -0.18, 0] }} />
    </group>
  )
}
