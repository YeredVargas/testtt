import { Text } from '@react-three/drei'
import { IndustrialScreen } from '../../IndustrialScreen'

interface XrayMachineProps {
  position: [number, number, number]
  size: [number, number, number]
}

export function XrayMachine({ position, size }: XrayMachineProps) {
  const [width, height, depth] = size
  const front = depth / 2 + 0.03
  const rear = -depth / 2 - 0.03

  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width, 0.24, depth]} />
        <meshStandardMaterial color="#30363b" roughness={0.8} metalness={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#e2e5e4" roughness={0.72} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.35, height * 0.48, 0]}>
        <boxGeometry args={[width * 0.16, height * 0.82, depth * 0.88]} />
        <meshStandardMaterial color="#cdd1d2" roughness={0.74} metalness={0.06} />
      </mesh>

      <mesh castShadow receiveShadow position={[width * 0.18, height * 0.84, 0]}>
        <boxGeometry args={[width * 0.58, 0.26, depth * 0.78]} />
        <meshStandardMaterial color="#d7dbdc" roughness={0.66} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.1, height * 0.58, front]}>
        <boxGeometry args={[width * 0.82, height * 0.7, 0.06]} />
        <meshStandardMaterial color="#697177" roughness={0.58} metalness={0.26} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.1, height * 0.58, front + 0.028]}>
        <boxGeometry args={[width * 0.72, height * 0.58, 0.02]} />
        <meshStandardMaterial color="#ccd1d3" roughness={0.72} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.1, height * 0.59, front + 0.04]}>
        <boxGeometry args={[width * 0.38, height * 0.34, 0.03]} />
        <meshStandardMaterial color="#151a20" roughness={0.22} metalness={0.16} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.1, height * 0.25, front + 0.03]}>
        <boxGeometry args={[width * 0.62, 0.34, 0.04]} />
        <meshStandardMaterial color="#c5cbce" roughness={0.84} metalness={0.04} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.19, height * 0.78, front + 0.038]}>
        <boxGeometry args={[0.74, 0.22, 0.04]} />
        <meshStandardMaterial color="#28c75f" emissive="#1eb950" emissiveIntensity={0.7} roughness={0.38} metalness={0.12} />
      </mesh>
      <Text position={[-width * 0.19, height * 0.78, front + 0.064]} fontSize={0.11} color="#f2fff6" anchorX="center" anchorY="middle">
        XRAY ON
      </Text>

      <group position={[-width * 0.28, height * 0.48, front + 0.036]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[0.44, 0.38, 0.04]} />
          <meshStandardMaterial color="#1c242c" roughness={0.28} metalness={0.18} />
        </mesh>
        <group position={[0, 0.01, 0.024]}>
          <IndustrialScreen
            media={{
              type: 'image',
              source: '/media/backend/xray/xia-dashboard.svg',
              fallback: '/media/backend/xray/placeholder.svg',
              fit: 'cover',
            }}
            width={0.34}
            height={0.22}
          />
        </group>
        <Text position={[0, 0.15, 0.03]} fontSize={0.045} color="#39d26d" anchorX="center" anchorY="middle">
          XRAY INSPECTION
        </Text>
        <Text position={[0, -0.14, 0.03]} fontSize={0.034} color="#d8e0e6" anchorX="center" anchorY="middle">
          SYSTEM READY
        </Text>
      </group>

      {[-0.16, 0, 0.16].map((x, index) => (
        <mesh key={x} position={[-width * 0.28 + x, height * 0.33, front + 0.06]}>
          <cylinderGeometry args={[0.026, 0.026, 0.03, 12]} />
          <meshStandardMaterial
            color={index === 0 ? '#22c55e' : index === 1 ? '#f2c500' : '#ef4444'}
            emissive={index === 0 ? '#22c55e' : index === 1 ? '#f2c500' : '#ef4444'}
            emissiveIntensity={0.28}
          />
        </mesh>
      ))}
      <mesh position={[-width * 0.05, height * 0.27, front + 0.058]}>
        <boxGeometry args={[0.08, 0.05, 0.03]} />
        <meshStandardMaterial color="#9aa3a9" roughness={0.56} metalness={0.24} />
      </mesh>
      <mesh position={[-width * 0.39, 1.0, front + 0.055]}>
        <cylinderGeometry args={[0.044, 0.044, 0.04, 16]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.34} />
      </mesh>
      <mesh position={[-width * 0.39, 0.94, front + 0.055]}>
        <cylinderGeometry args={[0.073, 0.073, 0.05, 16]} />
        <meshStandardMaterial color="#f2c500" roughness={0.54} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[width * 0.28, height * 0.46, rear + 0.08]}>
        <boxGeometry args={[0.54, 0.92, 0.14]} />
        <meshStandardMaterial color="#d0d5d7" roughness={0.76} metalness={0.06} />
      </mesh>
      {[-0.26, 0, 0.26].map((z) => (
        <mesh key={z} castShadow receiveShadow position={[width * 0.28, height * 0.52 + z * 0.1, rear + 0.16 + z * 0.05]} rotation={[0, 0, 0]}>
          <boxGeometry args={[0.34, 0.04, 0.02]} />
          <meshStandardMaterial color="#89929a" roughness={0.74} metalness={0.14} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[-width * 0.12, height * 0.57, 0]}>
        <boxGeometry args={[width * 0.28, 0.08, depth * 0.56]} />
        <meshStandardMaterial color="#353b42" roughness={0.82} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[-width * 0.33, height * 0.57, 0]}>
        <boxGeometry args={[0.05, 0.14, depth * 0.46]} />
        <meshStandardMaterial color="#697177" roughness={0.56} metalness={0.28} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.08, height * 0.68, 0.08]}>
        <boxGeometry args={[0.4, 0.14, 0.24]} />
        <meshStandardMaterial color="#b8c0c4" roughness={0.48} metalness={0.38} />
      </mesh>
      <mesh castShadow receiveShadow position={[-width * 0.1, height * 0.58, -0.08]}>
        <boxGeometry args={[0.24, 0.04, 0.18]} />
        <meshStandardMaterial color="#1f6b44" roughness={0.6} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[width * 0.36, 1.88, -0.26]}>
        <cylinderGeometry args={[0.035, 0.035, 0.34, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#39d26d', y: 2.03 },
        { color: '#f2c500', y: 2.14 },
        { color: '#ef4444', y: 2.25 },
      ].map((light) => (
        <mesh key={light.color} position={[width * 0.36, light.y, -0.26]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.34} />
        </mesh>
      ))}

      <mesh position={[width * 0.06, 1.26, front + 0.032]} rotation={[0, 0, Math.PI / 4]}>
        <boxGeometry args={[0.16, 0.16, 0.02]} />
        <meshStandardMaterial color="#f2c500" roughness={0.56} metalness={0.08} />
      </mesh>
      <Text position={[width * 0.06, 1.26, front + 0.044]} fontSize={0.045} color="#172026" anchorX="center" anchorY="middle">
        !
      </Text>

      {[-width / 2 + 0.24, width / 2 - 0.24].map((x) => (
        <group key={x} position={[x, 0, 0]}>
          {[-depth / 2 + 0.22, depth / 2 - 0.22].map((z) => (
            <mesh key={z} castShadow receiveShadow position={[0, 0.06, z]}>
              <cylinderGeometry args={[0.04, 0.04, 0.12, 10]} />
              <meshStandardMaterial color="#8f979d" roughness={0.46} metalness={0.5} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  )
}
