import { IndustrialScreen } from '../../IndustrialScreen'
import type { MediaModalData } from '../../../types/factory'
import type { XrayInspectionMonitorConfig } from '../../../types/xray'

interface InteractiveWorkMonitorProps {
  config: XrayInspectionMonitorConfig
  onOpenMedia?: (media: MediaModalData) => void
}

function getMediaType(source: string): 'image' | 'gif' | 'video' {
  const extension = source.split('?')[0].toLowerCase().split('.').pop()

  if (extension === 'gif') {
    return 'gif'
  }

  if (extension === 'mp4' || extension === 'webm') {
    return 'video'
  }

  return 'image'
}

export function InteractiveWorkMonitor({ config, onOpenMedia }: InteractiveWorkMonitorProps) {
  const [width, height] = config.size
  const mediaSource = config.media.source
  const mediaType = getMediaType(mediaSource)

  return (
    <group position={config.position} rotation={config.rotation}>
      <mesh position={[0, 0, -0.05]}>
        <boxGeometry args={[width + 0.1, height + 0.08, 0.08]} />
        <meshStandardMaterial color="#101419" roughness={0.34} metalness={0.28} />
      </mesh>

      <mesh position={[0, 0, 0.008]}>
        <planeGeometry args={[width + 0.03, height + 0.03]} />
        <meshBasicMaterial color="#050505" toneMapped={false} />
      </mesh>

      <group position={[0, 0, 0.014]}>
        <IndustrialScreen media={config.media} width={width} height={height} />
      </group>

      <mesh position={[0, -0.16, -0.055]}>
        <boxGeometry args={[0.08, 0.14, 0.06]} />
        <meshStandardMaterial color="#8e979f" roughness={0.46} metalness={0.48} />
      </mesh>

      <mesh
        position={[0, 0, 0.038]}
        onClick={() => {
          onOpenMedia?.({
            id: config.id,
            title: config.title,
            source: mediaSource,
            mediaType,
          })
        }}
        userData={{
          interactive: true,
          interactionType: 'media-display',
          displayId: config.id,
          title: config.title,
          mediaSource,
          mediaType,
          promptText: config.promptText,
        }}
      >
        <planeGeometry args={[width, height]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} colorWrite={false} />
      </mesh>
    </group>
  )
}
