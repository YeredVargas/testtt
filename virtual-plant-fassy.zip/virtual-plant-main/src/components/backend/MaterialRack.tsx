import { memo, useMemo } from 'react'
import type { MaterialRackConfig } from '../../types/backend'
import { MaterialBin } from './MaterialBin'

const RACK_WHEEL_RADIUS = 0.06

interface MaterialRackProps {
  rack: MaterialRackConfig
}

function MaterialRackComponent({ rack }: MaterialRackProps) {
  const shelfStep = (rack.height - 0.26) / Math.max(rack.levels - 1, 1)
  const levelYs = useMemo(
    () => Array.from({ length: rack.levels }, (_, index) => 0.22 + index * shelfStep),
    [rack.levels, shelfStep],
  )
  const binXs = useMemo(
    () =>
      Array.from(
        { length: rack.binsPerLevel },
        (_, index) => -rack.width * 0.28 + index * ((rack.width * 0.56) / Math.max(rack.binsPerLevel - 1, 1)),
      ),
    [rack.binsPerLevel, rack.width],
  )
  const labelSeed = rack.labelPrefix ?? 'MAT'

  return (
    <group position={rack.position} rotation={rack.rotation}>
      {[-rack.width / 2 + 0.06, rack.width / 2 - 0.06].flatMap((x) =>
        [-rack.depth / 2 + 0.06, rack.depth / 2 - 0.06].map((z) => (
          <mesh key={`${x}-${z}`} castShadow receiveShadow position={[x, rack.height / 2 + RACK_WHEEL_RADIUS, z]}>
            <boxGeometry args={[0.05, rack.height, 0.05]} />
            <meshStandardMaterial color="#30363b" metalness={0.55} roughness={0.48} />
          </mesh>
        )),
      )}

      {levelYs.map((y) => (
        <mesh key={y} castShadow receiveShadow position={[0, y, 0]}>
          <boxGeometry args={[rack.width, 0.04, rack.depth]} />
          <meshStandardMaterial color="#30363b" metalness={0.55} roughness={0.48} />
        </mesh>
      ))}

      {[-rack.width / 2 + 0.04, rack.width / 2 - 0.04].map((x) => (
        <mesh key={`back-${x}`} castShadow receiveShadow position={[x, rack.height * 0.52 + RACK_WHEEL_RADIUS, -rack.depth / 2 + 0.025]}>
          <boxGeometry args={[0.03, rack.height * 0.96, 0.03]} />
          <meshStandardMaterial color="#30363b" metalness={0.55} roughness={0.48} />
        </mesh>
      ))}

      {[-rack.width / 2 + 0.1, rack.width / 2 - 0.1].flatMap((x) =>
        [-rack.depth / 2 + 0.1, rack.depth / 2 - 0.1].map((z) => (
          <mesh key={`wheel-${x}-${z}`} castShadow receiveShadow position={[x, RACK_WHEEL_RADIUS, z]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[RACK_WHEEL_RADIUS, RACK_WHEEL_RADIUS, 0.04, 14]} />
            <meshStandardMaterial color="#1f252a" metalness={0.24} roughness={0.66} />
          </mesh>
        )),
      )}

      {levelYs.flatMap((y, levelIndex) =>
        binXs.map((x, binIndex) => (
          <MaterialBin
            key={`${levelIndex}-${binIndex}`}
            position={[x, y + 0.1, rack.depth * 0.14]}
            label={levelIndex < 3 ? `${labelSeed}-${levelIndex + 1}${binIndex + 1}` : undefined}
            accentColor={binIndex % 2 === 0 ? '#35c6b2' : '#4da3ff'}
          />
        )),
      )}
    </group>
  )
}

export const MaterialRack = memo(MaterialRackComponent)
