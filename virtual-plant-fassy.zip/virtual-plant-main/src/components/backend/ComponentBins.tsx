interface ComponentBinsProps {
  position: [number, number, number]
  binCount?: number
}

export function ComponentBins({ position, binCount = 4 }: ComponentBinsProps) {
  return (
    <group position={position} rotation={[-0.22, 0, 0]}>
      <mesh castShadow receiveShadow position={[0, 0.04, -0.02]}>
        <boxGeometry args={[0.82, 0.08, 0.34]} />
        <meshStandardMaterial color="#6b7379" roughness={0.7} metalness={0.24} />
      </mesh>
      <mesh position={[0, 0.11, 0.11]}>
        <boxGeometry args={[0.82, 0.06, 0.03]} />
        <meshStandardMaterial color="#565e65" roughness={0.74} metalness={0.14} />
      </mesh>
      {Array.from({ length: binCount }).map((_, index) => (
        <mesh
          key={index}
          castShadow
          receiveShadow
          position={[-0.27 + index * 0.18, 0.11 + (index % 2) * 0.018, -0.01]}
        >
          <boxGeometry args={[0.14, 0.1, 0.12]} />
          <meshStandardMaterial
            color={index % 3 === 0 ? '#4b5563' : index % 3 === 1 ? '#2563eb' : '#9ca3af'}
            roughness={0.72}
            metalness={0.12}
          />
        </mesh>
      ))}
    </group>
  )
}
