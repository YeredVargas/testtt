import { Text } from '@react-three/drei'
import { BACKEND_CONVEYOR_HEIGHT } from '../../data/backendProcesses'
import { IndustrialScreen } from '../IndustrialScreen'
import { PcbBoard } from '../PcbBoard'

interface WaveSolderMachineProps {
  position: [number, number, number]
  size: [number, number, number]
}

export function WaveSolderMachine({ position, size }: WaveSolderMachineProps) {
  const [width, , depth] = size
  const front = depth / 2 + 0.03
  const rear = -depth / 2 - 0.03
  const moduleCount = 5

  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0.16, 0]}>
        <boxGeometry args={[width, 0.32, depth]} />
        <meshStandardMaterial color="#343a3f" roughness={0.72} metalness={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.96, 0]}>
        <boxGeometry args={[width, 1.28, depth]} />
        <meshStandardMaterial color="#d9dcdb" roughness={0.68} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.42, 0.88, 0]}>
        <boxGeometry args={[width * 0.14, 1.05, depth * 0.88]} />
        <meshStandardMaterial color="#c7cacc" roughness={0.72} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 2.04, rear + 0.34]}>
        <boxGeometry args={[width * 0.58, 0.2, 0.42]} />
        <meshStandardMaterial color="#aeb7bc" roughness={0.58} metalness={0.34} />
      </mesh>
      {[-width * 0.14, width * 0.08].map((x) => (
        <group key={x} position={[x, 2.26, rear + 0.34]}>
          <mesh castShadow receiveShadow position={[0, 0.16, 0]}>
            <cylinderGeometry args={[0.09, 0.09, 0.32, 16]} />
            <meshStandardMaterial color="#bcc5ca" roughness={0.42} metalness={0.6} />
          </mesh>
          <mesh castShadow receiveShadow position={[0, 0.38, 0]}>
            <boxGeometry args={[0.22, 0.08, 0.22]} />
            <meshStandardMaterial color="#8d989f" roughness={0.52} metalness={0.4} />
          </mesh>
        </group>
      ))}

      {Array.from({ length: moduleCount }).map((_, index) => {
        const moduleWidth = width * 0.13
        const gap = width * 0.03
        const startX = -width * 0.2
        const x = startX + index * (moduleWidth + gap)

        return (
          <group key={index} position={[x, 1.72, 0]}>
            <mesh castShadow receiveShadow>
              <boxGeometry args={[moduleWidth, 0.3, depth * 0.86]} />
              <meshStandardMaterial color="#cfd4d6" roughness={0.66} metalness={0.08} />
            </mesh>
            <mesh position={[0, 0.02, front - 0.15]}>
              <boxGeometry args={[moduleWidth * 0.72, 0.18, 0.04]} />
              <meshStandardMaterial color="#263238" roughness={0.26} metalness={0.1} transparent opacity={0.55} />
            </mesh>
            <mesh position={[0, -0.12, front - 0.1]}>
              <boxGeometry args={[moduleWidth * 0.24, 0.04, 0.05]} />
              <meshStandardMaterial color="#111827" roughness={0.5} metalness={0.18} />
            </mesh>
          </group>
        )
      })}

      {Array.from({ length: 3 }).map((_, index) => {
        const x = -width * 0.1 + index * (width * 0.22)
        return (
          <group key={index} position={[x, 2.08, -0.08]}>
            <mesh castShadow receiveShadow position={[0, 0.28, 0]}>
              <cylinderGeometry args={[0.08, 0.08, 0.56, 16]} />
              <meshStandardMaterial color="#aeb5b8" roughness={0.44} metalness={0.58} />
            </mesh>
            <mesh castShadow receiveShadow position={[0.1, 0.58, -0.12]} rotation={[0.2, 0, 1.05]}>
              <cylinderGeometry args={[0.05, 0.05, 0.42, 14]} />
              <meshStandardMaterial color="#173f6a" roughness={0.58} metalness={0.16} />
            </mesh>
          </group>
        )
      })}

      {[-width * 0.24, width * 0.04, width * 0.32].map((x) => (
        <mesh key={x} castShadow receiveShadow position={[x, 0.52, rear + 0.08]}>
          <boxGeometry args={[0.56, 0.46, 0.2]} />
          <meshStandardMaterial color="#9ba4aa" roughness={0.74} metalness={0.14} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[-width * 0.26, 0.98, rear + 0.02]}>
        <boxGeometry args={[1.34, 0.54, 0.08]} />
        <meshStandardMaterial color="#1f2937" roughness={0.32} metalness={0.16} transparent opacity={0.52} />
      </mesh>

      {[-width * 0.4, width * 0.42].map((x) => (
        <mesh key={x} castShadow receiveShadow position={[x, BACKEND_CONVEYOR_HEIGHT + 0.03, 0]}>
          <boxGeometry args={[0.34, 0.12, 0.48]} />
          <meshStandardMaterial color="#d2d7db" roughness={0.78} metalness={0.08} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[-width * 0.43, 1.22, front]}>
        <boxGeometry args={[0.56, 0.44, 0.05]} />
        <meshStandardMaterial color="#263238" roughness={0.26} metalness={0.1} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.44, 1.0, front + 0.14]}>
        <boxGeometry args={[0.34, 0.36, 0.22]} />
        <meshStandardMaterial color="#d9dcdb" roughness={0.7} metalness={0.06} />
      </mesh>
      <mesh position={[-width * 0.48, 1.06, front + 0.26]}>
        <boxGeometry args={[0.2, 0.18, 0.01]} />
        <meshStandardMaterial color="#050505" />
      </mesh>
      <group position={[-width * 0.48, 1.06, front + 0.268]}>
        <IndustrialScreen
          media={{
            type: 'image',
            source: '/media/backend/wave-solder-dashboard.svg',
            fallback: '/media/screens/placeholder.svg',
            fit: 'cover',
          }}
          width={0.18}
          height={0.16}
        />
      </group>
      {[-0.52, -0.44, -0.36].map((x) => (
        <mesh key={x} position={[x, 0.93, front + 0.26]}>
          <cylinderGeometry args={[0.025, 0.025, 0.04, 12]} />
          <meshStandardMaterial color={x === -0.52 ? '#22c55e' : x === -0.44 ? '#ef4444' : '#f2c500'} emissive={x === -0.52 ? '#22c55e' : x === -0.44 ? '#ef4444' : '#f2c500'} emissiveIntensity={0.28} />
        </mesh>
      ))}
      <mesh position={[-width * 0.34, 0.9, front + 0.26]}>
        <cylinderGeometry args={[0.05, 0.05, 0.05, 16]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[-width * 0.34, 0.84, front + 0.26]}>
        <cylinderGeometry args={[0.075, 0.075, 0.05, 18]} />
        <meshStandardMaterial color="#f2c500" roughness={0.54} metalness={0.08} />
      </mesh>

      {[-width * 0.28, -width * 0.02, width * 0.24].map((x) => (
        <mesh key={x} receiveShadow position={[x, 0.66, front + 0.005]}>
          <boxGeometry args={[width * 0.18, 0.9, 0.04]} />
          <meshStandardMaterial color="#d0d5d8" roughness={0.86} metalness={0.04} />
        </mesh>
      ))}

      <mesh receiveShadow position={[0, BACKEND_CONVEYOR_HEIGHT, 0]}>
        <boxGeometry args={[width * 0.94, 0.06, 0.36]} />
        <meshStandardMaterial color="#6e767c" roughness={0.54} metalness={0.36} />
      </mesh>

      <mesh position={[0, 0.88, front + 0.012]}>
        <boxGeometry args={[width * 0.82, 0.04, 0.02]} />
        <meshStandardMaterial color="#f2c500" roughness={0.5} metalness={0.1} />
      </mesh>

      <PcbBoard board={{ id: 'wave-board-1', position: [-width * 0.15, BACKEND_CONVEYOR_HEIGHT + 0.03, 0] }} />
      <PcbBoard board={{ id: 'wave-board-2', position: [width * 0.18, BACKEND_CONVEYOR_HEIGHT + 0.03, 0] }} />

      {[-width / 2 + 0.35, width / 2 - 0.35].map((x) => (
        <group key={x} position={[x, 0, 0]}>
          {[-0.45, 0.45].map((z) => (
            <mesh key={z} castShadow receiveShadow position={[0, 0.08, z]}>
              <cylinderGeometry args={[0.04, 0.04, 0.16, 12]} />
              <meshStandardMaterial color="#a9afb3" roughness={0.48} metalness={0.54} />
            </mesh>
          ))}
        </group>
      ))}

      {[-width * 0.38, width * 0.34].map((x) => (
        <group key={x} position={[x, 0, 0]}>
          <mesh castShadow receiveShadow position={[0, 1.55, -0.22]}>
            <cylinderGeometry args={[0.04, 0.04, 0.32, 10]} />
            <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
          </mesh>
          {[
            { color: '#2fc35a', y: 1.69 },
            { color: '#f59e0b', y: 1.79 },
            { color: '#ef4444', y: 1.89 },
          ].map((light) => (
            <mesh key={light.color} position={[0, light.y, -0.22]}>
              <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
              <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
            </mesh>
          ))}
        </group>
      ))}

      <mesh position={[width * 0.12, 0.95, front + 0.01]}>
        <boxGeometry args={[0.18, 0.18, 0.02]} />
        <meshStandardMaterial color="#f2c500" roughness={0.64} metalness={0.04} />
      </mesh>
      <mesh position={[width * 0.2, 0.95, front + 0.01]}>
        <boxGeometry args={[0.18, 0.18, 0.02]} />
        <meshStandardMaterial color="#f2c500" roughness={0.64} metalness={0.04} />
      </mesh>

      <Text position={[0, 1.18, front + 0.06]} fontSize={0.18} color="#111827" anchorX="center" anchorY="middle">
        WAVE SOLDER
      </Text>
    </group>
  )
}
