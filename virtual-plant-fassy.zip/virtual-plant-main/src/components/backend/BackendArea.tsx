import { memo } from 'react'
import { backendLineConfigs } from '../../data/backendLine'
import { backendDisplayStations } from '../../data/backendDisplayStations'
import { backendSupportTables } from '../../data/backendSupportTables'
import { ictBackendCellConfig } from '../../data/ictBackendCell'
import { backendStandaloneEquipment } from '../../data/backendStandaloneEquipment'
import { glueProcessCellConfig } from '../../data/glueProcessCell'
import { routerProcessCellConfig } from '../../data/routerProcessCell'
import { xrayInspectionCellConfigs } from '../../data/xrayInspectionCell'
import type { MediaModalData } from '../../types/factory'
import { FloorDisplayStation } from '../FloorDisplayStation'
import { BackendLaserMachine } from './BackendLaserMachine'
import { BackendSocketInsertionStation } from './BackendSocketInsertionStation'
import { ConformalLine } from './conformal/ConformalLine'
import { GlueProcessCell } from './glue/GlueProcessCell'
import { IctBackendProcessCell } from './IctBackendProcessCell'
import { ManualAssemblyLine } from './ManualAssemblyLine'
import { BackendProcessSection } from './BackendProcessSection'
import { LongGreenWorkTable } from './LongGreenWorkTable'
import { RouterProcessCell } from './RouterProcessCell'
import { XrayInspectionCell } from './xray/XrayInspectionCell'

interface BackendAreaProps {
  onOpenMedia?: (media: MediaModalData) => void
}

export const BackendArea = memo(function BackendArea({ onOpenMedia }: BackendAreaProps) {
  const backendLaserMachine = backendStandaloneEquipment.find((equipment) => equipment.type === 'backend-laser')
  const socketInsertion = backendStandaloneEquipment.find((equipment) => equipment.type === 'socket-insertion')

  return (
    <group>
      <ManualAssemblyLine config={backendLineConfigs[0]} showRearMaterialArea onOpenMedia={onOpenMedia} />
      <BackendProcessSection config={backendLineConfigs[0]} />
      {backendLaserMachine ? (
        <BackendLaserMachine
          position={backendLaserMachine.position}
          rotation={backendLaserMachine.rotation}
          size={backendLaserMachine.size}
        />
      ) : null}
      {socketInsertion ? (
        <BackendSocketInsertionStation
          position={socketInsertion.position}
          rotation={socketInsertion.rotation}
          size={socketInsertion.size}
        />
      ) : null}
      <ConformalLine />

      <ManualAssemblyLine config={backendLineConfigs[1]} onOpenMedia={onOpenMedia} />
      <BackendProcessSection config={backendLineConfigs[1]} />

      {backendDisplayStations.map((station) => (
        <FloorDisplayStation key={station.id} station={station} onSelect={onOpenMedia} />
      ))}

      {backendSupportTables.map((table) => (
        <LongGreenWorkTable
          key={table.id}
          position={table.position}
          rotation={table.rotation}
          size={table.size}
          accessory={table.accessory}
        />
      ))}

      <GlueProcessCell config={glueProcessCellConfig} onOpenMedia={onOpenMedia} />
      <RouterProcessCell config={routerProcessCellConfig} />
      <IctBackendProcessCell config={ictBackendCellConfig} />

      {xrayInspectionCellConfigs.map((config) => (
        <XrayInspectionCell key={config.id} config={config} onOpenMedia={onOpenMedia} />
      ))}
    </group>
  )
})
