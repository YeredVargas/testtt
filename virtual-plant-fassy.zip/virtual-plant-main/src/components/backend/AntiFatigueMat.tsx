interface AntiFatigueMatProps {
  position: [number, number, number]
}

export function AntiFatigueMat({ position }: AntiFatigueMatProps) {
  return (
    <group position={position}>
      <mesh receiveShadow>
        <boxGeometry args={[1.2, 0.02, 0.8]} />
        <meshStandardMaterial color="#17191c" roughness={0.94} metalness={0.02} />
      </mesh>
      {Array.from({ length: 4 }).map((_, row) =>
        Array.from({ length: 6 }).map((__, col) => (
          <mesh key={`${row}-${col}`} position={[-0.45 + col * 0.18, 0.012, -0.24 + row * 0.16]}>
            <cylinderGeometry args={[0.012, 0.012, 0.004, 10]} />
            <meshStandardMaterial color="#2a2e33" roughness={0.78} metalness={0.08} />
          </mesh>
        )),
      )}
    </group>
  )
}
