import { Text } from '@react-three/drei'
import { WorkstationMonitor } from './WorkstationMonitor'
import { PcbBoard } from '../PcbBoard'
import { ictBackendCellConfig } from '../../data/ictBackendCell'
import type { IctBackendCellConfig } from '../../types/ictBackend'

interface IctBackendProcessCellProps {
  config?: IctBackendCellConfig
}

export function IctBackendProcessCell({ config = ictBackendCellConfig }: IctBackendProcessCellProps) {
  const table = config.equipment.find((equipment) => equipment.type === 'ict-table')
  const machine = config.equipment.find((equipment) => equipment.type === 'ict-machine')

  if (!table || !machine) {
    return null
  }

  const [tableWidth, tableHeight, tableDepth] = table.size
  const [machineWidth, , machineDepth] = machine.size

  return (
    <group position={config.position} rotation={config.rotation}>
      <group position={table.position}>
        <mesh castShadow receiveShadow position={[0, tableHeight - 0.025, 0]}>
          <boxGeometry args={[tableWidth, 0.05, tableDepth]} />
          <meshStandardMaterial color="#2f7658" roughness={0.78} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, tableHeight - 0.025, tableDepth / 2 - 0.025]}>
          <boxGeometry args={[tableWidth, 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, tableHeight - 0.025, -tableDepth / 2 + 0.025]}>
          <boxGeometry args={[tableWidth, 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        {[-tableWidth / 2 + 0.1, tableWidth / 2 - 0.1].map((x) => (
          <group key={x} position={[x, 0, 0]}>
            {[-tableDepth / 2 + 0.08, tableDepth / 2 - 0.08].map((z) => (
              <mesh key={z} castShadow receiveShadow position={[0, tableHeight / 2, z]}>
                <boxGeometry args={[0.07, tableHeight, 0.07]} />
                <meshStandardMaterial color="#7c848b" roughness={0.44} metalness={0.54} />
              </mesh>
            ))}
          </group>
        ))}
        <mesh castShadow receiveShadow position={[0, 0.22, 0]}>
          <boxGeometry args={[tableWidth - 0.24, 0.04, tableDepth - 0.18]} />
          <meshStandardMaterial color="#d5dadd" roughness={0.82} metalness={0.06} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.56, tableHeight + 0.28, 0.24]}>
          <cylinderGeometry args={[0.03, 0.04, 0.58, 12]} />
          <meshStandardMaterial color="#8e969d" roughness={0.44} metalness={0.52} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.34, tableHeight + 0.49, 0.16]} rotation={[0, 0, 0.22]}>
          <boxGeometry args={[0.42, 0.04, 0.04]} />
          <meshStandardMaterial color="#9ba3aa" roughness={0.46} metalness={0.44} />
        </mesh>
        <WorkstationMonitor
          position={[0, 1.55, 0.18]}
          rotation={[-0.1, -0.06, 0]}
          width={0.72}
          height={0.42}
          media={{ type: 'image', source: '/media/screens/placeholder.svg', fallback: '/media/screens/placeholder.svg', fit: 'cover' }}
        />
      </group>

      <group position={machine.position}>
        <mesh castShadow receiveShadow position={[0, 0.36, 0]}>
          <boxGeometry args={[machineWidth, 0.72, machineDepth]} />
          <meshStandardMaterial color="#aeb4b6" roughness={0.76} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 0.92, 0]}>
          <boxGeometry args={[machineWidth * 0.92, 0.18, machineDepth * 0.88]} />
          <meshStandardMaterial color="#9ea5aa" roughness={0.54} metalness={0.24} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 0.88, 0]}>
          <boxGeometry args={[0.72, 0.05, 0.48]} />
          <meshStandardMaterial color="#59626d" roughness={0.5} metalness={0.24} />
        </mesh>
        {[-0.2, 0, 0.2].map((x) => (
          <mesh key={x} castShadow receiveShadow position={[x, 0.92, 0]}>
            <cylinderGeometry args={[0.022, 0.022, 0.06, 12]} />
            <meshStandardMaterial color="#c5ccd1" roughness={0.34} metalness={0.52} />
          </mesh>
        ))}
        <mesh castShadow receiveShadow position={[0, 0.96, 0]}>
          <boxGeometry args={[0.42, 0.03, 0.28]} />
          <meshStandardMaterial color="#1f6b44" roughness={0.62} metalness={0.08} />
        </mesh>
        <PcbBoard board={{ id: 'ict-backend-test-board', position: [0, 0.995, 0], rotation: [0, 0.14, 0] }} />
        <mesh castShadow receiveShadow position={[0, 0.965, 0]}>
          <boxGeometry args={[0.52, 0.02, 0.36]} />
          <meshStandardMaterial color="#2b3138" roughness={0.82} metalness={0.08} />
        </mesh>

        <group position={[-machineWidth / 2 + 0.06, 0.96, 0]}>
          <mesh castShadow receiveShadow position={[0.06, 0, 0]}>
            <boxGeometry args={[0.08, 0.06, 0.86]} />
            <meshStandardMaterial color="#6f7780" roughness={0.46} metalness={0.42} />
          </mesh>
          <mesh castShadow receiveShadow position={[machineWidth * 0.48, 0, 0]} rotation={[0, 0, 0.9]}>
            <boxGeometry args={[machineWidth * 0.96, 0.05, 0.82]} />
            <meshStandardMaterial color="#bcc3c8" roughness={0.58} metalness={0.22} />
          </mesh>
          <mesh castShadow receiveShadow position={[machineWidth * 0.48, 0.02, 0]} rotation={[0, 0, 0.9]}>
            <boxGeometry args={[machineWidth * 0.76, 0.02, 0.56]} />
            <meshStandardMaterial color="#5f666d" roughness={0.42} metalness={0.28} />
          </mesh>
          <mesh castShadow receiveShadow position={[machineWidth * 0.22, 0.09, 0]} rotation={[0, 0, 0.74]}>
            <boxGeometry args={[0.12, 0.03, 0.68]} />
            <meshStandardMaterial color="#98a1a8" roughness={0.46} metalness={0.28} />
          </mesh>
        </group>

        <mesh castShadow receiveShadow position={[-machineWidth / 2 + 0.06, 0.95, 0]}>
          <boxGeometry args={[0.06, 0.94, 0.9]} />
          <meshStandardMaterial color="#8e979f" roughness={0.54} metalness={0.26} />
        </mesh>
        <mesh castShadow receiveShadow position={[-machineWidth / 2 + 0.14, 1.08, 0]} rotation={[0, 0, 0.64]}>
          <cylinderGeometry args={[0.018, 0.018, 0.54, 10]} />
          <meshStandardMaterial color="#c2c8ce" roughness={0.38} metalness={0.48} />
        </mesh>
        <mesh castShadow receiveShadow position={[machineWidth * 0.1, 1.28, 0.26]}>
          <boxGeometry args={[0.12, 0.06, 0.08]} />
          <meshStandardMaterial color="#6d7680" roughness={0.56} metalness={0.24} />
        </mesh>
        <mesh castShadow receiveShadow position={[machineWidth * 0.1, 1.22, 0.26]}>
          <boxGeometry args={[0.1, 0.02, 0.06]} />
          <meshStandardMaterial color="#11161c" roughness={0.82} metalness={0.08} />
        </mesh>

        <mesh castShadow receiveShadow position={[0, 1.46, machineDepth / 2 + 0.02]}>
          <boxGeometry args={[0.92, 0.22, 0.04]} />
          <meshStandardMaterial color="#234a78" roughness={0.5} metalness={0.16} />
        </mesh>
        <Text position={[0, 1.46, machineDepth / 2 + 0.05]} fontSize={0.11} color="#f8fafc" anchorX="center" anchorY="middle">
          ICT BACKEND
        </Text>
      </group>
    </group>
  )
}
