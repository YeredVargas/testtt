import { Text } from '@react-three/drei'
import { BACKEND_CONVEYOR_HEIGHT } from '../../data/backendProcesses'
import { IndustrialScreen } from '../IndustrialScreen'

interface BackendAOIMachineProps {
  position: [number, number, number]
  size: [number, number, number]
}

export function BackendAOIMachine({ position, size }: BackendAOIMachineProps) {
  const [width, , depth] = size
  const front = depth / 2 + 0.025

  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#343a3f" roughness={0.74} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.08, 0]}>
        <boxGeometry args={[width, 1.66, depth]} />
        <meshStandardMaterial color="#eceeed" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.45, front]}>
        <boxGeometry args={[width * 0.62, 0.58, 0.05]} />
        <meshStandardMaterial color="#0f172a" roughness={0.26} metalness={0.18} />
      </mesh>
      <group position={[0, 1.45, front + 0.03]}>
        <IndustrialScreen
          media={{
            type: 'image',
            source: '/media/backend/backend-aoi-dashboard.svg',
            fallback: '/media/screens/placeholder.svg',
            fit: 'cover',
          }}
          width={0.82}
          height={0.46}
        />
      </group>
      <mesh castShadow receiveShadow position={[0, 0.86, front + 0.005]}>
        <boxGeometry args={[width * 0.44, 0.38, 0.04]} />
        <meshStandardMaterial color="#d9dcdb" roughness={0.84} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.9, front + 0.03]}>
        <boxGeometry args={[0.9, 0.24, 0.04]} />
        <meshStandardMaterial color="#234a78" roughness={0.5} metalness={0.14} />
      </mesh>
      <Text position={[0, 1.9, front + 0.056]} fontSize={0.14} color="#f8fafc" anchorX="center" anchorY="middle">
        AOI
      </Text>
      <mesh castShadow receiveShadow position={[0, BACKEND_CONVEYOR_HEIGHT, 0]}>
        <boxGeometry args={[width * 0.96, 0.06, 0.34]} />
        <meshStandardMaterial color="#6e767c" roughness={0.56} metalness={0.34} />
      </mesh>
      <mesh castShadow receiveShadow position={[-width * 0.34, 1.12, front + 0.16]}>
        <boxGeometry args={[0.16, 0.9, 0.16]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.86} metalness={0.04} />
      </mesh>
      {[-0.06, 0.08].map((x, index) => (
        <mesh key={x} position={[-width * 0.34 + x, 1.42 - index * 0.12, front + 0.25]}>
          <cylinderGeometry args={[0.024, 0.024, 0.035, 12]} />
          <meshStandardMaterial color={index === 0 ? '#22c55e' : '#ef4444'} emissive={index === 0 ? '#22c55e' : '#ef4444'} emissiveIntensity={0.28} />
        </mesh>
      ))}
      <mesh position={[-width * 0.28, 1.16, front + 0.25]}>
        <cylinderGeometry args={[0.05, 0.05, 0.05, 16]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.34} />
      </mesh>
      <mesh position={[-width * 0.28, 1.1, front + 0.25]}>
        <cylinderGeometry args={[0.075, 0.075, 0.05, 18]} />
        <meshStandardMaterial color="#f2c500" roughness={0.58} metalness={0.08} />
      </mesh>
      <mesh position={[width * 0.2, 1.84, -0.18]}>
        <cylinderGeometry args={[0.04, 0.04, 0.32, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#2fc35a', y: 1.99 },
        { color: '#f59e0b', y: 2.09 },
        { color: '#ef4444', y: 2.19 },
      ].map((light) => (
        <mesh key={light.color} position={[width * 0.2, light.y, -0.18]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
        </mesh>
      ))}
      {[-width / 2 + 0.22, width / 2 - 0.22].map((x) => (
        <group key={x} position={[x, 0, 0]}>
          {[-0.28, 0.28].map((z) => (
            <mesh key={z} castShadow receiveShadow position={[0, 0.08, z]}>
              <cylinderGeometry args={[0.04, 0.04, 0.16, 12]} />
              <meshStandardMaterial color="#a8afb3" roughness={0.48} metalness={0.54} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  )
}
