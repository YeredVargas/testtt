import { Text } from '@react-three/drei'
import { MachineControlPanel, TowerLight } from '../equipment/CommonParts'
import type { Vec3 } from '../../types/factory'

interface BackendSocketInsertionStationProps {
  position: Vec3
  rotation?: Vec3
  size: Vec3
}

export function BackendSocketInsertionStation({ position, rotation, size }: BackendSocketInsertionStationProps) {
  const [width, height, depth] = size
  const front = depth / 2 + 0.03
  const rear = -depth / 2 - 0.03

  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width, 0.24, depth]} />
        <meshStandardMaterial color="#30363b" roughness={0.8} metalness={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#e7eaeb" roughness={0.74} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.28, height * 0.48, 0]}>
        <boxGeometry args={[width * 0.2, height * 0.82, depth * 0.84]} />
        <meshStandardMaterial color="#d4d9db" roughness={0.78} metalness={0.06} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.1, height * 0.6, front]}>
        <boxGeometry args={[width * 0.72, height * 0.58, 0.06]} />
        <meshStandardMaterial color="#717983" roughness={0.58} metalness={0.24} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.1, height * 0.6, front + 0.028]}>
        <boxGeometry args={[width * 0.62, height * 0.48, 0.02]} />
        <meshStandardMaterial color="#d8dddf" roughness={0.76} metalness={0.04} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.1, height * 0.66, front + 0.04]}>
        <boxGeometry args={[width * 0.28, 0.34, 0.03]} />
        <meshStandardMaterial color="#151a20" roughness={0.24} metalness={0.16} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.1, height * 0.32, front + 0.032]}>
        <boxGeometry args={[width * 0.48, 0.26, 0.04]} />
        <meshStandardMaterial color="#c9d0d4" roughness={0.82} metalness={0.04} />
      </mesh>

      {[-0.52, -0.16, 0.2, 0.56].map((x) => (
        <mesh key={x} castShadow receiveShadow position={[x, 1.02, front - 0.08]}>
          <boxGeometry args={[0.24, 0.22, 0.18]} />
          <meshStandardMaterial color="#d3dade" roughness={0.78} metalness={0.04} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0.18, height * 0.86, rear + 0.16]}>
        <boxGeometry args={[width * 0.5, 0.24, 0.42]} />
        <meshStandardMaterial color="#d6dbdd" roughness={0.7} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.32, height * 0.5, front + 0.04]}>
        <boxGeometry args={[0.36, 0.42, 0.04]} />
        <meshStandardMaterial color="#1c242c" roughness={0.28} metalness={0.18} />
      </mesh>
      <mesh position={[-width * 0.32, height * 0.5, front + 0.062]}>
        <boxGeometry args={[0.26, 0.2, 0.01]} />
        <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={0.18} />
      </mesh>

      {[-0.1, 0.02, 0.14].map((x, index) => (
        <mesh key={x} position={[-width * 0.32 + x, height * 0.34, front + 0.06]}>
          <cylinderGeometry args={[0.024, 0.024, 0.03, 12]} />
          <meshStandardMaterial
            color={index === 0 ? '#22c55e' : index === 1 ? '#f59e0b' : '#ef4444'}
            emissive={index === 0 ? '#22c55e' : index === 1 ? '#f59e0b' : '#ef4444'}
            emissiveIntensity={0.26}
          />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0, height * 0.58, 0]}>
        <boxGeometry args={[width * 0.32, 0.08, depth * 0.52]} />
        <meshStandardMaterial color="#353b42" roughness={0.8} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.71, 0.06]}>
        <boxGeometry args={[0.42, 0.14, 0.24]} />
        <meshStandardMaterial color="#b7c0c4" roughness={0.5} metalness={0.34} />
      </mesh>

      <MachineControlPanel position={[width * 0.44, 0, depth / 2 + 0.24]} rotation={[0, 0, 0.16]} standHeight={0.82} />
      <TowerLight position={[width * 0.34, height - 0.16, depth * 0.18]} />

      <group position={[0, 1.84, front + 0.04]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1.52, 0.28, 0.05]} />
          <meshStandardMaterial color="#234a78" roughness={0.52} metalness={0.16} />
        </mesh>
        <mesh position={[0, 0, 0.03]}>
          <boxGeometry args={[1.36, 0.2, 0.01]} />
          <meshStandardMaterial color="#f4f7fa" roughness={0.82} metalness={0.04} />
        </mesh>
        <Text position={[0, 0, 0.036]} fontSize={0.115} color="#234a78" anchorX="center" anchorY="middle">
          SOCKET INSERTION
        </Text>
      </group>

      <Text position={[0.08, 0.64, front + 0.042]} fontSize={0.095} color="#0f7ea3" anchorX="center" anchorY="middle">
        SOCKET PROCESS
      </Text>
    </group>
  )
}
