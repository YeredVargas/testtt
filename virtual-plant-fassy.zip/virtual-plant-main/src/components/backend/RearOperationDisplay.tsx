import { FloorDisplayStation } from '../FloorDisplayStation'
import type { MediaModalData } from '../../types/factory'
import type { FloorDisplayStationConfig } from '../../types/factory'
import type { RearDisplayConfig } from '../../types/backend'

interface RearOperationDisplayProps {
  display: RearDisplayConfig
  onOpenMedia?: (media: MediaModalData) => void
}

export function RearOperationDisplay({ display, onOpenMedia }: RearOperationDisplayProps) {
  const station: FloorDisplayStationConfig = {
    id: display.id,
    title: display.title,
    position: display.position,
    rotation: display.rotation,
    width: display.width,
    height: display.height,
    promptText: display.promptText,
    media: {
      type: 'image',
      source: display.source,
      fallback: '/media/screens/placeholder.svg',
      fit: 'cover',
    },
  }

  return <FloorDisplayStation station={station} onSelect={onOpenMedia} interactive />
}
