import { PcbBoard } from '../../PcbBoard'
import type { MediaModalData } from '../../../types/factory'
import type { GlueEquipmentConfig, GlueMonitorConfig } from '../../../types/glue'
import { GlueScanner } from './GlueScanner'
import { InteractiveWorkMonitor } from '../xray/InteractiveWorkMonitor'

interface GlueInspectionTableProps {
  equipment: GlueEquipmentConfig
  monitor: GlueMonitorConfig
  onOpenMedia?: (media: MediaModalData) => void
}

export function GlueInspectionTable({ equipment, monitor, onOpenMedia }: GlueInspectionTableProps) {
  const [width, height, depth] = equipment.size
  const topThickness = 0.05
  const legInsetX = width / 2 - 0.09
  const legInsetZ = depth / 2 - 0.08

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, 0]}>
        <boxGeometry args={[width, topThickness, depth]} />
        <meshStandardMaterial color="#2f7658" roughness={0.78} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, depth / 2 - 0.025]}>
        <boxGeometry args={[width, 0.05, 0.05]} />
        <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, -depth / 2 + 0.025]}>
        <boxGeometry args={[width, 0.05, 0.05]} />
        <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
      </mesh>
      {[
        [-legInsetX, height / 2, -legInsetZ],
        [legInsetX, height / 2, -legInsetZ],
        [-legInsetX, height / 2, legInsetZ],
        [legInsetX, height / 2, legInsetZ],
      ].map((leg) => (
        <group key={leg.join('-')} position={leg as [number, number, number]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[0.07, height, 0.07]} />
            <meshStandardMaterial color="#7c848b" roughness={0.44} metalness={0.54} />
          </mesh>
          <mesh castShadow receiveShadow position={[0, -height / 2 + 0.02, 0]}>
            <cylinderGeometry args={[0.03, 0.035, 0.04, 12]} />
            <meshStandardMaterial color="#8f979e" roughness={0.5} metalness={0.42} />
          </mesh>
        </group>
      ))}
      <mesh castShadow receiveShadow position={[0, 0.22, 0]}>
        <boxGeometry args={[width - 0.24, 0.04, depth - 0.18]} />
        <meshStandardMaterial color="#d5dadd" roughness={0.82} metalness={0.06} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.42, -depth / 2 + 0.03]}>
        <boxGeometry args={[width - 0.12, 0.04, 0.05]} />
        <meshStandardMaterial color="#aeb4b8" roughness={0.56} metalness={0.34} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.42, depth / 2 - 0.03]}>
        <boxGeometry args={[width - 0.12, 0.04, 0.05]} />
        <meshStandardMaterial color="#aeb4b8" roughness={0.56} metalness={0.34} />
      </mesh>
      <mesh castShadow receiveShadow position={[-0.46, height + 0.03, -0.12]}>
        <boxGeometry args={[0.24, 0.12, 0.18]} />
        <meshStandardMaterial color="#67717a" roughness={0.62} metalness={0.2} />
      </mesh>
      <mesh position={[-0.36, height + 0.09, -0.06]}>
        <cylinderGeometry args={[0.018, 0.018, 0.02, 12]} />
        <meshStandardMaterial color="#16a34a" emissive="#16a34a" emissiveIntensity={0.26} />
      </mesh>
      <mesh position={[-0.31, height + 0.09, -0.06]}>
        <cylinderGeometry args={[0.018, 0.018, 0.02, 12]} />
        <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.26} />
      </mesh>
      <mesh position={[-0.5, height + 0.09, -0.06]}>
        <cylinderGeometry args={[0.03, 0.03, 0.03, 14]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.32} />
      </mesh>
      <mesh position={[-0.5, height + 0.055, -0.06]}>
        <cylinderGeometry args={[0.05, 0.05, 0.03, 14]} />
        <meshStandardMaterial color="#f2c500" roughness={0.56} metalness={0.08} />
      </mesh>

      <group>
        <mesh castShadow receiveShadow position={[-0.56, height + 0.28, 0.28]}>
          <cylinderGeometry args={[0.03, 0.04, 0.58, 12]} />
          <meshStandardMaterial color="#8e969d" roughness={0.44} metalness={0.52} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.36, height + 0.49, 0.18]} rotation={[0, 0, 0.22]}>
          <boxGeometry args={[0.44, 0.04, 0.04]} />
          <meshStandardMaterial color="#9ba3aa" roughness={0.46} metalness={0.44} />
        </mesh>
        <InteractiveWorkMonitor config={monitor} onOpenMedia={onOpenMedia} />
        <GlueScanner position={[0.06, height + 0.01, 0.04]} />
      </group>

      <PcbBoard board={{ id: 'glue-table-board', position: [0.28, height + 0.03, 0.12], rotation: [0, -0.18, 0] }} />
    </group>
  )
}
