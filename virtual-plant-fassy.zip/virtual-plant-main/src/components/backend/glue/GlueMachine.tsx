import { Text } from '@react-three/drei'
import { GlueControlPanel } from './GlueControlPanel'
import type { GlueEquipmentConfig } from '../../../types/glue'

interface GlueMachineProps {
  equipment: GlueEquipmentConfig
  variant: 'blue' | 'green'
}

export function GlueMachine({ equipment, variant }: GlueMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.03
  const accent = variant === 'blue' ? '#2d78a7' : '#3b8f77'
  const panelX = variant === 'blue' ? width * 0.36 : -width * 0.36

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.11, 0]}>
        <boxGeometry args={[width, 0.22, depth]} />
        <meshStandardMaterial color="#30363b" roughness={0.78} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#aeb4b6" roughness={0.74} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.72, 0]}>
        <boxGeometry args={[width * 0.74, 0.28, depth * 0.76]} />
        <meshStandardMaterial color="#c5c9ca" roughness={0.68} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height * 0.54, front]}>
        <boxGeometry args={[width * 0.76, height * 0.58, 0.06]} />
        <meshStandardMaterial color="#41494f" roughness={0.56} metalness={0.24} />
      </mesh>
      <mesh castShadow receiveShadow position={[-0.34, height * 0.54, front + 0.03]}>
        <boxGeometry args={[0.62, 1.08, 0.02]} />
        <meshStandardMaterial color="#11161c" roughness={0.24} metalness={0.16} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.34, height * 0.54, front + 0.03]}>
        <boxGeometry args={[0.62, 1.08, 0.02]} />
        <meshStandardMaterial color="#11161c" roughness={0.24} metalness={0.16} />
      </mesh>
      <mesh position={[0, height * 0.54, front + 0.032]}>
        <boxGeometry args={[0.04, 1.08, 0.02]} />
        <meshStandardMaterial color="#2f3840" roughness={0.56} metalness={0.24} />
      </mesh>
      {[-0.16, 0.16].map((x) => (
        <mesh key={x} position={[x, height * 0.54, front + 0.048]}>
          <boxGeometry args={[0.04, 0.3, 0.02]} />
          <meshStandardMaterial color="#8e979f" roughness={0.4} metalness={0.42} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0, height * 0.58, 0]}>
        <boxGeometry args={[width * 0.32, 0.08, depth * 0.56]} />
        <meshStandardMaterial color="#353b42" roughness={0.82} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.72, 0.02]}>
        <boxGeometry args={[0.56, 0.14, 0.22]} />
        <meshStandardMaterial color="#b7c0c4" roughness={0.48} metalness={0.36} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.16, height * 0.6, -0.08]}>
        <boxGeometry args={[0.08, 0.34, 0.08]} />
        <meshStandardMaterial color="#87909a" roughness={0.42} metalness={0.46} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.78, -0.08]}>
        <boxGeometry args={[0.58, 0.04, 0.04]} />
        <meshStandardMaterial color="#8b95a0" roughness={0.48} metalness={0.42} />
      </mesh>
      <mesh castShadow receiveShadow position={[-0.12, height * 0.72, -0.02]} rotation={[0, 0, -0.26]}>
        <cylinderGeometry args={[0.024, 0.024, 0.2, 12]} />
        <meshStandardMaterial color="#9da7b0" roughness={0.38} metalness={0.52} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.04, height * 0.6, 0.02]}>
        <boxGeometry args={[0.2, 0.04, 0.14]} />
        <meshStandardMaterial color="#1f6b44" roughness={0.6} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.42, 0]}>
        <boxGeometry args={[width * 0.88, 0.46, depth * 0.8]} />
        <meshStandardMaterial color="#c5c9ca" roughness={0.82} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[variant === 'blue' ? width * 0.42 : -width * 0.42, 0.84, 0]}>
        <boxGeometry args={[0.18, 0.82, depth * 0.52]} />
        <meshStandardMaterial color="#c8cdcf" roughness={0.8} metalness={0.04} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height * 0.86, front + 0.018]}>
        <boxGeometry args={[0.92, 0.2, 0.03]} />
        <meshStandardMaterial color={accent} roughness={0.48} metalness={0.14} />
      </mesh>
      <Text position={[0, height * 0.86, front + 0.042]} fontSize={0.11} color="#f8fafc" anchorX="center" anchorY="middle">
        GLUE
      </Text>

      <GlueControlPanel
        position={[panelX, 0, front + 0.26]}
        rotation={[0, 0, 0]}
        media={{
          type: 'image',
          source: equipment.screenSource ?? '/media/backend/glue/placeholder.svg',
          fallback: '/media/backend/glue/placeholder.svg',
          fit: 'cover',
        }}
      />

      <mesh castShadow receiveShadow position={[variant === 'blue' ? width * 0.34 : -width * 0.34, height - 0.12, depth * 0.16]}>
        <cylinderGeometry args={[0.035, 0.035, 0.32, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#22c55e', y: height + 0.02 },
        { color: '#f59e0b', y: height + 0.12 },
        { color: '#ef4444', y: height + 0.22 },
      ].map((light) => (
        <mesh key={light.color} position={[variant === 'blue' ? width * 0.34 : -width * 0.34, light.y, depth * 0.16]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
        </mesh>
      ))}
    </group>
  )
}
