import { GLUE_CONVEYOR_HEIGHT } from '../../../data/glueProcessCell'

interface GlueConveyorProps {
  position: [number, number, number]
  length: number
}

export function GlueConveyor({ position, length }: GlueConveyorProps) {
  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, GLUE_CONVEYOR_HEIGHT - 0.045, 0]}>
        <boxGeometry args={[length, 0.08, 0.56]} />
        <meshStandardMaterial color="#20252b" roughness={0.84} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, GLUE_CONVEYOR_HEIGHT, 0.22]}>
        <boxGeometry args={[length, 0.04, 0.05]} />
        <meshStandardMaterial color="#8d9499" roughness={0.54} metalness={0.44} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, GLUE_CONVEYOR_HEIGHT, -0.22]}>
        <boxGeometry args={[length, 0.04, 0.05]} />
        <meshStandardMaterial color="#8d9499" roughness={0.54} metalness={0.44} />
      </mesh>
      {length > 0.5
        ? [-length / 2 + 0.14, length / 2 - 0.14].map((x) => (
            <group key={x} position={[x, 0, 0]}>
              {[-0.18, 0.18].map((z) => (
                <mesh key={z} castShadow receiveShadow position={[0, 0.42, z]}>
                  <boxGeometry args={[0.06, 0.84, 0.06]} />
                  <meshStandardMaterial color="#a8afb3" metalness={0.46} roughness={0.46} />
                </mesh>
              ))}
            </group>
          ))
        : null}
    </group>
  )
}
