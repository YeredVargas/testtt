import { IndustrialScreen } from '../../IndustrialScreen'
import type { DisplayMedia } from '../../../types/factory'

interface GlueControlPanelProps {
  position: [number, number, number]
  rotation?: [number, number, number]
  media: DisplayMedia
}

export function GlueControlPanel({ position, rotation = [0, 0, 0], media }: GlueControlPanelProps) {
  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow receiveShadow position={[0, 0.52, 0]}>
        <boxGeometry args={[0.08, 1.04, 0.08]} />
        <meshStandardMaterial color="#8d9499" roughness={0.52} metalness={0.55} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.16, 0]}>
        <boxGeometry args={[0.52, 0.48, 0.14]} />
        <meshStandardMaterial color="#1b2430" roughness={0.36} metalness={0.24} />
      </mesh>
      <group position={[0, 1.16, 0.076]}>
        <IndustrialScreen media={media} width={0.34} height={0.22} />
      </group>
      <mesh position={[-0.16, 0.92, 0.03]}>
        <cylinderGeometry args={[0.03, 0.03, 0.03, 12]} />
        <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.24} />
      </mesh>
      <mesh position={[-0.06, 0.92, 0.03]}>
        <cylinderGeometry args={[0.03, 0.03, 0.03, 12]} />
        <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.24} />
      </mesh>
      <mesh position={[0.04, 0.92, 0.03]}>
        <cylinderGeometry args={[0.03, 0.03, 0.03, 12]} />
        <meshStandardMaterial color="#f2c500" emissive="#f2c500" emissiveIntensity={0.24} />
      </mesh>
      <mesh position={[0.17, 0.94, 0.03]}>
        <cylinderGeometry args={[0.045, 0.045, 0.04, 14]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.28} />
      </mesh>
      <mesh position={[0.17, 0.89, 0.03]}>
        <cylinderGeometry args={[0.068, 0.068, 0.04, 16]} />
        <meshStandardMaterial color="#f2c500" roughness={0.54} metalness={0.08} />
      </mesh>
      <mesh position={[0.02, 0.72, 0.03]}>
        <boxGeometry args={[0.09, 0.03, 0.03]} />
        <meshStandardMaterial color="#dce1e6" roughness={0.42} metalness={0.28} />
      </mesh>
    </group>
  )
}
