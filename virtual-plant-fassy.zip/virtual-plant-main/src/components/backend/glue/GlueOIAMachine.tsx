import { IndustrialScreen } from '../../IndustrialScreen'
import { PcbBoard } from '../../PcbBoard'
import type { GlueEquipmentConfig } from '../../../types/glue'

interface GlueOIAMachineProps {
  equipment: GlueEquipmentConfig
}

export function GlueOIAMachine({ equipment }: GlueOIAMachineProps) {
  const [width, , depth] = equipment.size
  const mainDeskWidth = width * 0.72
  const sideDeskDepth = depth * 0.82

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[-width * 0.34, 0.92, 0.08]}>
        <boxGeometry args={[0.72, 0.06, 0.34]} />
        <meshStandardMaterial color="#737b82" roughness={0.54} metalness={0.34} />
      </mesh>

      <mesh castShadow receiveShadow position={[-0.04, 0.78, -0.3]}>
        <boxGeometry args={[mainDeskWidth, 0.08, 0.68]} />
        <meshStandardMaterial color="#c7ced3" roughness={0.74} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.2, 0.78, 0.04]}>
        <boxGeometry args={[0.56, 0.08, sideDeskDepth]} />
        <meshStandardMaterial color="#c7ced3" roughness={0.74} metalness={0.08} />
      </mesh>

      {[
        [-0.56, 0.39, -0.6],
        [0.38, 0.39, -0.6],
        [0.5, 0.39, 0.5],
        [0.84, 0.39, 0.5],
        [0.84, 0.39, -0.46],
      ].map((leg) => (
        <mesh key={leg.join('-')} castShadow receiveShadow position={leg as [number, number, number]}>
          <boxGeometry args={[0.08, 0.74, 0.08]} />
          <meshStandardMaterial color="#6f7780" roughness={0.48} metalness={0.46} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0.1, 0.53, -0.04]}>
        <boxGeometry args={[0.46, 0.46, 0.36]} />
        <meshStandardMaterial color="#9ba3aa" roughness={0.84} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.58, 0.53, 0.22]}>
        <boxGeometry args={[0.22, 0.46, 0.68]} />
        <meshStandardMaterial color="#9ba3aa" roughness={0.84} metalness={0.04} />
      </mesh>

      <group position={[-0.1, 1.16, -0.68]}>
        <mesh castShadow receiveShadow position={[0, -0.2, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 0.32, 14]} />
          <meshStandardMaterial color="#6b7280" roughness={0.46} metalness={0.42} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, -0.36, 0]}>
          <boxGeometry args={[0.18, 0.02, 0.13]} />
          <meshStandardMaterial color="#757f87" roughness={0.54} metalness={0.34} />
        </mesh>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[0.56, 0.3, 0.05]} />
          <meshStandardMaterial color="#111827" roughness={0.24} metalness={0.16} />
        </mesh>
        <group position={[0, 0, 0.028]}>
          <IndustrialScreen
            media={{
              type: 'image',
              source: equipment.screenSource ?? '/media/backend/glue/placeholder.svg',
              fallback: '/media/backend/glue/placeholder.svg',
              fit: 'cover',
            }}
            width={0.48}
            height={0.22}
          />
        </group>
      </group>

      <group position={[0.62, 1.16, -0.16]}>
        <mesh castShadow receiveShadow position={[0, -0.2, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 0.32, 14]} />
          <meshStandardMaterial color="#6b7280" roughness={0.46} metalness={0.42} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, -0.36, 0]}>
          <boxGeometry args={[0.16, 0.02, 0.12]} />
          <meshStandardMaterial color="#757f87" roughness={0.54} metalness={0.34} />
        </mesh>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[0.42, 0.26, 0.05]} />
          <meshStandardMaterial color="#111827" roughness={0.24} metalness={0.16} />
        </mesh>
        <mesh position={[0, 0, 0.028]}>
          <boxGeometry args={[0.34, 0.18, 0.01]} />
          <meshStandardMaterial color="#0f172a" emissive="#60a5fa" emissiveIntensity={0.14} />
        </mesh>
      </group>

      <mesh castShadow receiveShadow position={[-0.12, 0.85, -0.24]}>
        <boxGeometry args={[0.3, 0.02, 0.12]} />
        <meshStandardMaterial color="#2d3748" roughness={0.62} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.4, 0.85, -0.06]} rotation={[0, -0.35, 0]}>
        <boxGeometry args={[0.18, 0.018, 0.11]} />
        <meshStandardMaterial color="#111827" roughness={0.48} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.58, 0.846, 0]}>
        <boxGeometry args={[0.07, 0.014, 0.09]} />
        <meshStandardMaterial color="#111827" roughness={0.48} metalness={0.12} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.16, 0.85, 0.08]}>
        <cylinderGeometry args={[0.08, 0.08, 0.05, 20]} />
        <meshStandardMaterial color="#c7ced4" roughness={0.7} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.16, 0.85, 0.08]}>
        <cylinderGeometry args={[0.04, 0.04, 0.07, 20]} />
        <meshStandardMaterial color="#94a3b8" roughness={0.42} metalness={0.44} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.96, 1.72, -0.16]}>
        <cylinderGeometry args={[0.034, 0.034, 0.32, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#22c55e', y: 1.86 },
        { color: '#60a5fa', y: 1.97 },
        { color: '#ef4444', y: 2.08 },
      ].map((light) => (
        <mesh key={light.color} position={[0.96, light.y, -0.16]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
        </mesh>
      ))}

      <PcbBoard board={{ id: 'glue-oia-review-board', position: [-width * 0.34, 0.95, 0.08] }} />
    </group>
  )
}
