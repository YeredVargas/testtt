interface GlueScannerProps {
  position: [number, number, number]
}

export function GlueScanner({ position }: GlueScannerProps) {
  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0.02, 0]}>
        <boxGeometry args={[0.18, 0.04, 0.16]} />
        <meshStandardMaterial color="#111317" roughness={0.58} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.02, 0.15, -0.01]}>
        <boxGeometry args={[0.05, 0.24, 0.05]} />
        <meshStandardMaterial color="#6f7880" roughness={0.46} metalness={0.5} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.02, 0.28, 0.02]}>
        <boxGeometry args={[0.2, 0.12, 0.1]} />
        <meshStandardMaterial color="#1a2027" roughness={0.42} metalness={0.24} />
      </mesh>
      <mesh position={[0.02, 0.28, -0.032]}>
        <boxGeometry args={[0.14, 0.05, 0.01]} />
        <meshStandardMaterial color="#7f0f16" emissive="#d71f26" emissiveIntensity={0.36} />
      </mesh>
      <mesh position={[0.1, 0.29, 0.04]}>
        <sphereGeometry args={[0.012, 12, 12]} />
        <meshStandardMaterial color="#39d26d" emissive="#39d26d" emissiveIntensity={0.35} />
      </mesh>
      <mesh castShadow receiveShadow position={[-0.05, 0.03, -0.08]} rotation={[0.22, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.012, 0.012, 0.18, 10]} />
        <meshStandardMaterial color="#2f343b" roughness={0.62} metalness={0.16} />
      </mesh>
    </group>
  )
}
