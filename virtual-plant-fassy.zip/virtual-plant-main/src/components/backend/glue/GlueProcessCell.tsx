import { PcbBoard } from '../../PcbBoard'
import { glueConveyors, gluePcbPositions, glueProcessCellConfig } from '../../../data/glueProcessCell'
import type { MediaModalData } from '../../../types/factory'
import type { GlueProcessCellConfig } from '../../../types/glue'
import { GlueConveyor } from './GlueConveyor'
import { GlueInspectionTable } from './GlueInspectionTable'
import { GlueMachine } from './GlueMachine'
import { GlueOIAMachine } from './GlueOIAMachine'

interface GlueProcessCellProps {
  config?: GlueProcessCellConfig
  onOpenMedia?: (media: MediaModalData) => void
}

export function GlueProcessCell({ config = glueProcessCellConfig, onOpenMedia }: GlueProcessCellProps) {
  const table = config.equipment.find((equipment) => equipment.type === 'glue-table')
  const machines = config.equipment.filter((equipment) => equipment.type === 'glue-machine')
  const oia = config.equipment.find((equipment) => equipment.type === 'glue-oia')

  if (!table || machines.length !== 2 || !oia) {
    return null
  }

  return (
    <group position={config.position} rotation={config.rotation}>
      <GlueInspectionTable equipment={table} monitor={config.monitor} onOpenMedia={onOpenMedia} />
      <GlueMachine equipment={machines[0]} variant="blue" />
      <GlueMachine equipment={machines[1]} variant="green" />
      <GlueOIAMachine equipment={oia} />

      {glueConveyors.map((conveyor) => (
        <GlueConveyor key={conveyor.id} position={conveyor.position} length={conveyor.length} />
      ))}

      {gluePcbPositions.map((position, index) => (
        <PcbBoard key={`glue-board-${index + 1}`} board={{ id: `glue-board-${index + 1}`, position }} />
      ))}
    </group>
  )
}
