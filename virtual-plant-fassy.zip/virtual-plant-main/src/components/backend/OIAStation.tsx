import { Text } from '@react-three/drei'
import { BACKEND_CONVEYOR_HEIGHT } from '../../data/backendProcesses'
import { PcbBoard } from '../PcbBoard'

interface OIAStationProps {
  position: [number, number, number]
  size: [number, number, number]
}

export function OIAStation({ position, size }: OIAStationProps) {
  const [width, , depth] = size
  const mainDeskWidth = width * 0.72
  const returnDeskDepth = depth * 0.78

  return (
    <group position={position}>
      <mesh receiveShadow position={[-width * 0.32, BACKEND_CONVEYOR_HEIGHT, 0]}>
        <boxGeometry args={[0.82, 0.06, 0.36]} />
        <meshStandardMaterial color="#737b82" roughness={0.54} metalness={0.34} />
      </mesh>

      <mesh castShadow receiveShadow position={[-0.12, 0.78, -0.54]}>
        <boxGeometry args={[mainDeskWidth, 0.08, 0.72]} />
        <meshStandardMaterial color="#c6ccd2" roughness={0.74} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.22, 0.78, -0.08]}>
        <boxGeometry args={[0.72, 0.08, returnDeskDepth]} />
        <meshStandardMaterial color="#c6ccd2" roughness={0.74} metalness={0.08} />
      </mesh>

      {[
        [-0.86, 0.39, -0.78],
        [0.46, 0.39, -0.78],
        [0.62, 0.39, 0.56],
        [1.0, 0.39, 0.56],
        [1.0, 0.39, -0.62],
      ].map((leg) => (
        <mesh key={leg.join('-')} castShadow receiveShadow position={leg as [number, number, number]}>
          <boxGeometry args={[0.08, 0.74, 0.08]} />
          <meshStandardMaterial color="#6f7780" roughness={0.48} metalness={0.46} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0.06, 0.53, -0.02]}>
        <boxGeometry args={[0.52, 0.48, 0.44]} />
        <meshStandardMaterial color="#9ba3aa" roughness={0.84} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.7, 0.53, 0.28]}>
        <boxGeometry args={[0.3, 0.48, 0.9]} />
        <meshStandardMaterial color="#9ba3aa" roughness={0.84} metalness={0.04} />
      </mesh>

      {[
        { position: [-0.28, 1.17, -0.84] as [number, number, number], rotation: [0, 0, 0] as [number, number, number], width: 0.62 },
        { position: [0.88, 1.17, -0.22] as [number, number, number], rotation: [0, -Math.PI / 2, 0] as [number, number, number], width: 0.54 },
      ].map((monitor) => (
        <group key={monitor.position.join('-')} position={monitor.position} rotation={monitor.rotation}>
          <mesh castShadow receiveShadow position={[0, -0.2, 0]}>
            <cylinderGeometry args={[0.03, 0.03, 0.34, 14]} />
            <meshStandardMaterial color="#6b7280" roughness={0.46} metalness={0.42} />
          </mesh>
          <mesh castShadow receiveShadow position={[0, -0.37, 0]}>
            <boxGeometry args={[0.2, 0.02, 0.14]} />
            <meshStandardMaterial color="#757f87" roughness={0.54} metalness={0.34} />
          </mesh>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[monitor.width, 0.34, 0.05]} />
            <meshStandardMaterial color="#111827" roughness={0.24} metalness={0.16} />
          </mesh>
          <mesh position={[0, 0, 0.028]}>
            <boxGeometry args={[monitor.width * 0.9, 0.26, 0.01]} />
            <meshStandardMaterial color="#0ea5e9" emissive="#0ea5e9" emissiveIntensity={0.3} roughness={0.2} metalness={0.08} />
          </mesh>
          <mesh position={[0, 0.12, 0.029]}>
            <boxGeometry args={[monitor.width * 0.56, 0.03, 0.01]} />
            <meshStandardMaterial color="#e2e8f0" emissive="#e2e8f0" emissiveIntensity={0.08} />
          </mesh>
        </group>
      ))}

      <mesh castShadow receiveShadow position={[-0.18, 0.85, -0.48]}>
        <boxGeometry args={[0.36, 0.02, 0.14]} />
        <meshStandardMaterial color="#2d3748" roughness={0.62} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.08, 0.84, -0.5]}>
        <cylinderGeometry args={[0.035, 0.035, 0.016, 16]} />
        <meshStandardMaterial color="#1f2937" roughness={0.56} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.12, 0.845, -0.45]} rotation={[-0.2, 0.22, 0.28]}>
        <boxGeometry args={[0.18, 0.024, 0.024]} />
        <meshStandardMaterial color="#ef4444" roughness={0.52} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.22, 0.842, -0.42]} rotation={[0.12, 0.18, 0.18]}>
        <coneGeometry args={[0.012, 0.09, 12]} />
        <meshStandardMaterial color="#bfc7ce" roughness={0.38} metalness={0.56} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.62, 0.85, -0.18]}>
        <cylinderGeometry args={[0.08, 0.08, 0.05, 20]} />
        <meshStandardMaterial color="#c7ced4" roughness={0.7} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.62, 0.85, -0.18]}>
        <cylinderGeometry args={[0.04, 0.04, 0.07, 20]} />
        <meshStandardMaterial color="#94a3b8" roughness={0.42} metalness={0.44} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.5, 0.86, 0.12]} rotation={[0, -0.4, 0]}>
        <boxGeometry args={[0.22, 0.018, 0.12]} />
        <meshStandardMaterial color="#111827" roughness={0.48} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.72, 0.848, 0.18]}>
        <boxGeometry args={[0.07, 0.014, 0.1]} />
        <meshStandardMaterial color="#111827" roughness={0.48} metalness={0.12} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.12, 1.9, -0.84]}>
        <boxGeometry args={[1.04, 0.3, 0.05]} />
        <meshStandardMaterial color="#234a78" roughness={0.5} metalness={0.16} />
      </mesh>
      <mesh position={[0.12, 1.9, -0.81]}>
        <boxGeometry args={[0.94, 0.22, 0.01]} />
        <meshStandardMaterial color="#f4f7fa" roughness={0.82} metalness={0.04} />
      </mesh>
      <Text position={[0.12, 1.9, -0.8]} fontSize={0.14} color="#234a78" anchorX="center" anchorY="middle">
        OIA
      </Text>

      <PcbBoard board={{ id: 'backend-oia-board', position: [-width * 0.32, BACKEND_CONVEYOR_HEIGHT + 0.03, 0] }} />
    </group>
  )
}
