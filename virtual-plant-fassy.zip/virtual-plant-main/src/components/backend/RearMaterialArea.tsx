import { backendRearAreaConfig } from '../../data/backendRearArea'
import type { MediaModalData } from '../../types/factory'
import { MaterialRack } from './MaterialRack'
import { PalletStack } from './PalletStack'
import { RearOperationDisplay } from './RearOperationDisplay'

interface RearMaterialAreaProps {
  onOpenMedia?: (media: MediaModalData) => void
}

export function RearMaterialArea({ onOpenMedia }: RearMaterialAreaProps) {
  return (
    <group position={backendRearAreaConfig.localOffset}>
      <RearOperationDisplay display={backendRearAreaConfig.display} onOpenMedia={onOpenMedia} />
      {backendRearAreaConfig.racks.map((rack) => (
        <MaterialRack key={rack.id} rack={rack} />
      ))}
      <PalletStack position={[5.95, 0, -4.05]} />
    </group>
  )
}
