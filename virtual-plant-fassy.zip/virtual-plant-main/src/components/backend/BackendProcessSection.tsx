import { backendProcesses } from '../../data/backendProcesses'
import type { ManualAssemblyLineConfig } from '../../types/backend'
import { PcbBoard } from '../PcbBoard'
import { BackendAOIMachine } from './BackendAOIMachine'
import { OIAStation } from './OIAStation'
import { BackendTransitionConveyor } from './BackendTransitionConveyor'
import { WaveSolderMachine } from './WaveSolderMachine'

interface BackendProcessSectionProps {
  config: ManualAssemblyLineConfig
}

export function BackendProcessSection({ config }: BackendProcessSectionProps) {
  return (
    <group position={config.position} rotation={config.rotation}>
      {backendProcesses.map((process) => {
        if (process.type === 'backend-conveyor') {
          return (
            <BackendTransitionConveyor
              key={process.id}
              position={process.position}
              length={process.size[0]}
            />
          )
        }

        if (process.type === 'wave-solder') {
          return <WaveSolderMachine key={process.id} position={process.position} size={process.size} />
        }

        if (process.type === 'backend-aoi') {
          return <BackendAOIMachine key={process.id} position={process.position} size={process.size} />
        }

        if (process.type === 'oia-station') {
          return <OIAStation key={process.id} position={process.position} size={process.size} />
        }

        return null
      })}

      <PcbBoard board={{ id: 'backend-wave-aoi-link', position: [18.3, 0.93, 0] }} />
      <PcbBoard board={{ id: 'backend-aoi-output-board', position: [19.95, 0.93, 0] }} />
    </group>
  )
}
