import { Text } from '@react-three/drei'
import { PcbBoard } from '../../PcbBoard'
import { conformalConveyors, conformalLineConfig, conformalPcbPositions } from '../../../data/conformalLine'
import type { ConformalLineConfig } from '../../../types/conformal'
import { ConformalAOIMachine } from './ConformalAOIMachine'
import { ConformalConveyor } from './ConformalConveyor'
import { ConformalCoatingMachine } from './ConformalCoatingMachine'
import { ConformalOIAMachine } from './ConformalOIAMachine'
import { ConformalUvOven } from './ConformalUvOven'

interface ConformalLineProps {
  config?: ConformalLineConfig
}

export function ConformalLine({ config = conformalLineConfig }: ConformalLineProps) {
  return (
    <group position={config.position} rotation={config.rotation}>
      <group position={[-1.62, 0, 1.04]}>
        <mesh castShadow receiveShadow position={[0, 1.2, 0]}>
          <boxGeometry args={[0.08, 2.4, 0.08]} />
          <meshStandardMaterial color="#8d959d" roughness={0.5} metalness={0.42} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.9, 2.02, 0]}>
          <boxGeometry args={[1.8, 0.54, 0.05]} />
          <meshStandardMaterial color="#234a78" roughness={0.52} metalness={0.16} />
        </mesh>
        <mesh position={[0.9, 2.02, 0.03]}>
          <boxGeometry args={[1.64, 0.38, 0.01]} />
          <meshStandardMaterial color="#6d5bd0" roughness={0.72} metalness={0.04} />
        </mesh>
        <Text position={[0.9, 2.08, 0.038]} fontSize={0.095} color="#f8fafc" anchorX="center" anchorY="middle">
          CONFORMAL COATING LINE
        </Text>
        <Text position={[0.9, 1.92, 0.038]} fontSize={0.07} color="#dbeafe" anchorX="center" anchorY="middle">
          BACKEND
        </Text>
      </group>

      {conformalConveyors.map((conveyor) => (
        <ConformalConveyor key={conveyor.id} position={conveyor.position} length={conveyor.length} />
      ))}

      {config.equipment.map((equipment, index) => {
        if (equipment.type === 'conformal-coating') {
          return (
            <ConformalCoatingMachine
              key={equipment.id}
              equipment={equipment}
              variant={index === 0 ? 'left' : 'right'}
            />
          )
        }

        if (equipment.type === 'uv-oven') {
          return <ConformalUvOven key={equipment.id} equipment={equipment} />
        }

        if (equipment.type === 'conformal-aoi') {
          return <ConformalAOIMachine key={equipment.id} equipment={equipment} />
        }

        if (equipment.type === 'conformal-oia') {
          return <ConformalOIAMachine key={equipment.id} equipment={equipment} />
        }

        return null
      })}

      {conformalPcbPositions.map((position, index) => (
        <PcbBoard key={`conformal-board-${index + 1}`} board={{ id: `conformal-board-${index + 1}`, position }} />
      ))}
    </group>
  )
}
