import { Text } from '@react-three/drei'
import type { ConformalEquipmentConfig } from '../../../types/conformal'
import { ConformalControlPanel } from './ConformalControlPanel'
import { ConformalExhaust } from './ConformalExhaust'

interface ConformalCoatingMachineProps {
  equipment: ConformalEquipmentConfig
  variant: 'left' | 'right'
}

export function ConformalCoatingMachine({ equipment, variant }: ConformalCoatingMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.03
  const rear = -depth / 2 - 0.03
  const panelX = variant === 'left' ? -width * 0.38 : width * 0.38
  const hoseDirection = variant === 'left' ? 1 : -1

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width, 0.24, depth]} />
        <meshStandardMaterial color="#30363b" roughness={0.8} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#e4e6e5" roughness={0.74} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height * 0.56, front]}>
        <boxGeometry args={[width * 0.78, height * 0.62, 0.06]} />
        <meshStandardMaterial color="#6d7780" roughness={0.56} metalness={0.24} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.56, front + 0.03]}>
        <boxGeometry args={[width * (variant === 'left' ? 0.52 : 0.54), height * 0.36, 0.02]} />
        <meshStandardMaterial color="#151a20" roughness={0.24} metalness={0.16} />
      </mesh>
      {variant === 'right' ? (
        <mesh castShadow receiveShadow position={[0, height * 0.56, front + 0.032]}>
          <boxGeometry args={[0.06, height * 0.36, 0.02]} />
          <meshStandardMaterial color="#cfd6d9" roughness={0.8} metalness={0.04} />
        </mesh>
      ) : null}

      <mesh castShadow receiveShadow position={[0, height * 0.28, front + 0.03]}>
        <boxGeometry args={[width * 0.62, 0.28, 0.04]} />
        <meshStandardMaterial color="#d0d6d8" roughness={0.82} metalness={0.04} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height * 0.58, 0]}>
        <boxGeometry args={[width * 0.3, 0.08, depth * 0.56]} />
        <meshStandardMaterial color="#31363d" roughness={0.82} metalness={0.12} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.7, 0.02]}>
        <boxGeometry args={[0.52, 0.14, 0.24]} />
        <meshStandardMaterial color="#b8c0c6" roughness={0.48} metalness={0.4} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.16, height * 0.58, -0.08]}>
        <boxGeometry args={[0.05, 0.38, 0.05]} />
        <meshStandardMaterial color="#87909a" roughness={0.42} metalness={0.46} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.76, -0.08]}>
        <boxGeometry args={[0.54, 0.05, 0.05]} />
        <meshStandardMaterial color="#8b95a0" roughness={0.48} metalness={0.42} />
      </mesh>
      <mesh castShadow receiveShadow position={[-0.14, height * 0.68, -0.04]} rotation={[0, 0, -0.28]}>
        <cylinderGeometry args={[0.025, 0.025, 0.22, 12]} />
        <meshStandardMaterial color="#9da7b0" roughness={0.38} metalness={0.52} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.02, height * 0.6, 0]}>
        <boxGeometry args={[0.24, 0.04, 0.16]} />
        <meshStandardMaterial color="#1f6b44" roughness={0.6} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[panelX * 0.86, 0.88, rear + 0.08]}>
        <boxGeometry args={[0.26, 0.72, 0.12]} />
        <meshStandardMaterial color="#d3d8da" roughness={0.82} metalness={0.04} />
      </mesh>

      {variant === 'right' ? (
        <mesh castShadow receiveShadow position={[width * 0.44, 0.84, 0]}>
          <boxGeometry args={[0.16, 0.8, depth * 0.5]} />
          <meshStandardMaterial color="#d6dadd" roughness={0.8} metalness={0.04} />
        </mesh>
      ) : null}

      <ConformalControlPanel
        position={[panelX, 0, front + 0.28]}
        rotation={[0, 0, variant === 'left' ? -0.14 : 0.14]}
        media={{
          type: 'image',
          source: variant === 'left' ? '/media/backend/conformal/coating-1-dashboard.svg' : '/media/backend/conformal/coating-2-dashboard.svg',
          fallback: '/media/backend/xray/placeholder.svg',
          fit: 'cover',
        }}
      />
      <ConformalExhaust position={[variant === 'left' ? -0.34 : 0.34, height + 0.04, 0]} hoseDirection={hoseDirection} />

      <mesh castShadow receiveShadow position={[width * 0.3, height - 0.1, depth * 0.16]}>
        <cylinderGeometry args={[0.035, 0.035, 0.34, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#22c55e', y: height + 0.05 },
        { color: '#f59e0b', y: height + 0.15 },
        { color: '#ef4444', y: height + 0.25 },
      ].map((light) => (
        <mesh key={light.color} position={[width * 0.3, light.y, depth * 0.16]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
        </mesh>
      ))}

      <group position={[0, 1.84, front + 0.04]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1.64, 0.28, 0.05]} />
          <meshStandardMaterial color="#234a78" roughness={0.5} metalness={0.16} />
        </mesh>
        <Text position={[0, 0, 0.036]} fontSize={0.105} color="#f8fafc" anchorX="center" anchorY="middle" maxWidth={1.46}>
          {equipment.shortName}
        </Text>
      </group>
    </group>
  )
}
