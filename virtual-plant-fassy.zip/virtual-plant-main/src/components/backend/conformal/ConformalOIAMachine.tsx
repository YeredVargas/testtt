import { Text } from '@react-three/drei'
import { IndustrialScreen } from '../../IndustrialScreen'
import type { ConformalEquipmentConfig } from '../../../types/conformal'

interface ConformalOIAMachineProps {
  equipment: ConformalEquipmentConfig
}

export function ConformalOIAMachine({ equipment }: ConformalOIAMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.03

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width, 0.24, depth]} />
        <meshStandardMaterial color="#30363b" roughness={0.8} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#edf0ef" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.12, height * 0.68, front]} rotation={[-0.18, 0, 0]}>
        <boxGeometry args={[width * 0.72, 0.58, 0.08]} />
        <meshStandardMaterial color="#101827" roughness={0.24} metalness={0.16} />
      </mesh>
      <group position={[0.22, height * 0.7, front + 0.03]} rotation={[-0.18, 0, 0]}>
        <IndustrialScreen
          media={{
            type: 'image',
            source: '/media/backend/conformal/oia-conformal-dashboard.svg',
            fallback: '/media/backend/xray/placeholder.svg',
            fit: 'cover',
          }}
          width={0.82}
          height={0.42}
        />
      </group>
      <mesh castShadow receiveShadow position={[-width * 0.2, height * 0.46, front + 0.04]}>
        <boxGeometry args={[width * 0.28, 0.26, 0.04]} />
        <meshStandardMaterial color="#151a20" roughness={0.24} metalness={0.16} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.34, height * 0.42, front + 0.11]}>
        <boxGeometry args={[0.18, 0.82, 0.18]} />
        <meshStandardMaterial color="#d5dade" roughness={0.82} metalness={0.04} />
      </mesh>
      <mesh position={[width * 0.3, 0.92, front + 0.13]}>
        <cylinderGeometry args={[0.045, 0.045, 0.04, 16]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.34} />
      </mesh>
      <mesh position={[width * 0.3, 0.86, front + 0.13]}>
        <cylinderGeometry args={[0.075, 0.075, 0.05, 16]} />
        <meshStandardMaterial color="#f2c500" roughness={0.54} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.36, 0]}>
        <boxGeometry args={[width * 0.86, 0.42, depth * 0.82]} />
        <meshStandardMaterial color="#f5f6f7" roughness={0.8} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.22, 0.92, 0]}>
        <boxGeometry args={[0.5, 0.06, 0.38]} />
        <meshStandardMaterial color="#6e767c" roughness={0.54} metalness={0.34} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.4, 1.66, -0.14]}>
        <cylinderGeometry args={[0.035, 0.035, 0.34, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#22c55e', y: 1.8 },
        { color: '#60a5fa', y: 1.9 },
        { color: '#ef4444', y: 2.0 },
      ].map((light) => (
        <mesh key={light.color} position={[width * 0.4, light.y, -0.14]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
        </mesh>
      ))}
      <group position={[0, 1.86, front + 0.032]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1.18, 0.24, 0.04]} />
          <meshStandardMaterial color="#234a78" roughness={0.48} metalness={0.14} />
        </mesh>
        <Text position={[0, 0, 0.028]} fontSize={0.105} color="#f8fafc" anchorX="center" anchorY="middle">
          OIA CONFORMAL
        </Text>
      </group>
    </group>
  )
}
