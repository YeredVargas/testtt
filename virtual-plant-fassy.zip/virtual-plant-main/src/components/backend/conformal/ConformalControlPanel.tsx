import { IndustrialScreen } from '../../IndustrialScreen'
import type { DisplayMedia } from '../../../types/factory'

interface ConformalControlPanelProps {
  position: [number, number, number]
  rotation?: [number, number, number]
  media: DisplayMedia
}

export function ConformalControlPanel({ position, rotation = [0, 0, 0], media }: ConformalControlPanelProps) {
  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow receiveShadow position={[0, 0.44, 0]}>
        <boxGeometry args={[0.08, 0.88, 0.08]} />
        <meshStandardMaterial color="#8d9499" roughness={0.52} metalness={0.55} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.02, 0]} rotation={[-0.28, 0, 0]}>
        <boxGeometry args={[0.44, 0.42, 0.12]} />
        <meshStandardMaterial color="#1b2430" roughness={0.36} metalness={0.24} />
      </mesh>
      <group position={[0, 1.05, 0.05]} rotation={[-0.28, 0, 0]}>
        <IndustrialScreen media={media} width={0.3} height={0.2} />
      </group>
      <mesh position={[-0.14, 0.82, 0.02]}>
        <cylinderGeometry args={[0.032, 0.032, 0.03, 12]} />
        <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.24} />
      </mesh>
      <mesh position={[-0.04, 0.82, 0.02]}>
        <cylinderGeometry args={[0.032, 0.032, 0.03, 12]} />
        <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.24} />
      </mesh>
      <mesh position={[0.12, 0.84, 0.03]}>
        <cylinderGeometry args={[0.045, 0.045, 0.04, 14]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.28} />
      </mesh>
      <mesh position={[0.12, 0.79, 0.03]}>
        <cylinderGeometry args={[0.068, 0.068, 0.04, 16]} />
        <meshStandardMaterial color="#f2c500" roughness={0.54} metalness={0.08} />
      </mesh>
      <mesh position={[0.02, 0.64, 0.025]}>
        <boxGeometry args={[0.08, 0.03, 0.03]} />
        <meshStandardMaterial color="#dce1e6" roughness={0.42} metalness={0.28} />
      </mesh>
    </group>
  )
}
