import { Text } from '@react-three/drei'
import { IndustrialScreen } from '../../IndustrialScreen'
import type { ConformalEquipmentConfig } from '../../../types/conformal'

interface ConformalAOIMachineProps {
  equipment: ConformalEquipmentConfig
}

export function ConformalAOIMachine({ equipment }: ConformalAOIMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.03

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width, 0.24, depth]} />
        <meshStandardMaterial color="#30363b" roughness={0.8} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#edf0ef" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.64, front]}>
        <boxGeometry args={[width * 0.68, 0.62, 0.05]} />
        <meshStandardMaterial color="#111827" roughness={0.24} metalness={0.16} />
      </mesh>
      <group position={[0, height * 0.64, front + 0.028]}>
        <IndustrialScreen
          media={{
            type: 'image',
            source: '/media/backend/conformal/aoi-conformal-dashboard.svg',
            fallback: '/media/backend/xray/placeholder.svg',
            fit: 'cover',
          }}
          width={0.76}
          height={0.42}
        />
      </group>
      <mesh castShadow receiveShadow position={[0, height * 0.34, front + 0.03]}>
        <boxGeometry args={[width * 0.5, 0.3, 0.04]} />
        <meshStandardMaterial color="#d8dddf" roughness={0.82} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[-width * 0.34, height * 0.48, front + 0.11]}>
        <boxGeometry args={[0.16, 0.88, 0.16]} />
        <meshStandardMaterial color="#d5dade" roughness={0.82} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.38, 1.72, -0.14]}>
        <cylinderGeometry args={[0.035, 0.035, 0.34, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#22c55e', y: 1.86 },
        { color: '#f59e0b', y: 1.96 },
        { color: '#ef4444', y: 2.06 },
      ].map((light) => (
        <mesh key={light.color} position={[width * 0.38, light.y, -0.14]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.32} />
        </mesh>
      ))}
      <group position={[0, 1.9, front + 0.03]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1.14, 0.24, 0.04]} />
          <meshStandardMaterial color="#39d26d" roughness={0.5} metalness={0.14} />
        </mesh>
        <Text position={[0, 0, 0.028]} fontSize={0.11} color="#f8fafc" anchorX="center" anchorY="middle">
          AOI CONFORMAL
        </Text>
      </group>
      <mesh castShadow receiveShadow position={[0, 0.9, 0]}>
        <boxGeometry args={[width * 0.88, 0.06, 0.36]} />
        <meshStandardMaterial color="#6e767c" roughness={0.54} metalness={0.34} />
      </mesh>
    </group>
  )
}
