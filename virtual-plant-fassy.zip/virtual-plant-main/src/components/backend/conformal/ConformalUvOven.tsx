import { Text } from '@react-three/drei'
import type { ConformalEquipmentConfig } from '../../../types/conformal'
import { ConformalControlPanel } from './ConformalControlPanel'

interface ConformalUvOvenProps {
  equipment: ConformalEquipmentConfig
}

export function ConformalUvOven({ equipment }: ConformalUvOvenProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.03
  const moduleXs = [-width * 0.26, -width * 0.08, width * 0.1, width * 0.28]

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width, 0.24, depth]} />
        <meshStandardMaterial color="#30363b" roughness={0.8} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#e4e6e5" roughness={0.72} metalness={0.08} />
      </mesh>

      {moduleXs.map((x) => (
        <group key={x} position={[x, 1.82, 0]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[width * 0.13, 0.26, depth * 0.84]} />
            <meshStandardMaterial color="#d7dbde" roughness={0.68} metalness={0.08} />
          </mesh>
          <mesh position={[0, -0.02, front - 0.14]}>
            <boxGeometry args={[width * 0.08, 0.14, 0.04]} />
            <meshStandardMaterial color="#19182c" roughness={0.24} metalness={0.16} />
          </mesh>
        </group>
      ))}

      {[-width * 0.36, -width * 0.12, width * 0.12, width * 0.36].map((x) => (
        <mesh key={x} castShadow receiveShadow position={[x, 0.52, front + 0.01]}>
          <boxGeometry args={[width * 0.16, 0.44, 0.04]} />
          <meshStandardMaterial color="#d1d6d9" roughness={0.8} metalness={0.04} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0, 1.12, front]}>
        <boxGeometry args={[width * 0.82, 0.42, 0.05]} />
        <meshStandardMaterial color="#19182c" roughness={0.26} metalness={0.16} />
      </mesh>
      <mesh position={[0, 1.12, front + 0.028]}>
        <boxGeometry args={[width * 0.18, 0.2, 0.01]} />
        <meshStandardMaterial color="#8b7cff" emissive="#8b7cff" emissiveIntensity={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.22, 1.52, front + 0.012]}>
        <boxGeometry args={[0.74, 0.16, 0.03]} />
        <meshStandardMaterial color="#6d5bd0" roughness={0.48} metalness={0.16} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.18, 1.52, front + 0.012]}>
        <boxGeometry args={[0.56, 0.16, 0.03]} />
        <meshStandardMaterial color="#c8cfda" roughness={0.74} metalness={0.04} />
      </mesh>
      <Text position={[-width * 0.22, 1.52, front + 0.034]} fontSize={0.07} color="#f8fafc" anchorX="center" anchorY="middle">
        UV CURING
      </Text>
      <Text position={[width * 0.18, 1.52, front + 0.034]} fontSize={0.07} color="#6d5bd0" anchorX="center" anchorY="middle">
        UV ACTIVE
      </Text>

      <mesh castShadow receiveShadow position={[0, 0.9, 0]}>
        <boxGeometry args={[width * 0.9, 0.06, 0.38]} />
        <meshStandardMaterial color="#6e767c" roughness={0.54} metalness={0.34} />
      </mesh>

      <ConformalControlPanel
        position={[width * 0.42, 0, front + 0.28]}
        rotation={[0, 0, 0.14]}
        media={{
          type: 'image',
          source: '/media/backend/conformal/uv-oven-dashboard.svg',
          fallback: '/media/backend/xray/placeholder.svg',
          fit: 'cover',
        }}
      />

      <mesh castShadow receiveShadow position={[width * 0.38, height - 0.06, 0.18]}>
        <cylinderGeometry args={[0.035, 0.035, 0.34, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#22c55e', y: height + 0.08 },
        { color: '#8b7cff', y: height + 0.19 },
        { color: '#ef4444', y: height + 0.3 },
      ].map((light) => (
        <mesh key={light.color} position={[width * 0.38, light.y, 0.18]}>
          <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.3} />
        </mesh>
      ))}

      <group position={[0, 1.64, front + 0.05]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[1.94, 0.28, 0.05]} />
          <meshStandardMaterial color="#234a78" roughness={0.5} metalness={0.16} />
        </mesh>
        <Text position={[0, 0, 0.036]} fontSize={0.1} color="#f8fafc" anchorX="center" anchorY="middle" maxWidth={1.7}>
          UV OVEN CONFORMAL
        </Text>
      </group>
    </group>
  )
}
