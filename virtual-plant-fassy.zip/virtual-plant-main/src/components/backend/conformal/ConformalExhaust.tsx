interface ConformalExhaustProps {
  position: [number, number, number]
  hoseDirection?: 1 | -1
}

export function ConformalExhaust({ position, hoseDirection = 1 }: ConformalExhaustProps) {
  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <cylinderGeometry args={[0.1, 0.1, 0.28, 16]} />
        <meshStandardMaterial color="#aeb7bc" roughness={0.46} metalness={0.52} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.28, 0.12 * hoseDirection]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 0.22, 14]} />
        <meshStandardMaterial color="#bfc7cd" roughness={0.42} metalness={0.56} />
      </mesh>
      {Array.from({ length: 5 }).map((_, index) => (
        <mesh
          key={index}
          castShadow
          receiveShadow
          position={[0.1 + index * 0.08, 0.2 + index * 0.06, 0.2 * hoseDirection + index * 0.02 * hoseDirection]}
          rotation={[0, 0, -0.34 * hoseDirection]}
        >
          <torusGeometry args={[0.055, 0.012, 10, 18, Math.PI]} />
          <meshStandardMaterial color="#2563eb" roughness={0.62} metalness={0.18} />
        </mesh>
      ))}
    </group>
  )
}
