import { PcbBoard } from '../PcbBoard'
import { WorkstationMonitor } from './WorkstationMonitor'
import type { BackendSupportTableAccessory } from '../../data/backendSupportTables'

interface LongGreenWorkTableProps {
  position: [number, number, number]
  rotation?: [number, number, number]
  size: [number, number, number]
  accessory: BackendSupportTableAccessory
}

function TableAccessory({ accessory, topY }: { accessory: BackendSupportTableAccessory; topY: number }) {
  if (accessory === 'cautin') {
    return (
      <group>
        <mesh castShadow receiveShadow position={[-0.46, topY + 0.014, 0.14]}>
          <boxGeometry args={[0.28, 0.028, 0.11]} />
          <meshStandardMaterial color="#434b55" roughness={0.62} metalness={0.18} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.38, topY + 0.05, 0.15]}>
          <boxGeometry args={[0.03, 0.08, 0.03]} />
          <meshStandardMaterial color="#aeb6be" roughness={0.46} metalness={0.42} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.08, topY + 0.03, 0.08]} rotation={[-0.18, 0.2, 0.18]}>
          <boxGeometry args={[0.3, 0.03, 0.03]} />
          <meshStandardMaterial color="#ef4444" roughness={0.52} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.1, topY + 0.026, 0.12]} rotation={[0.1, 0.16, 0.1]}>
          <coneGeometry args={[0.013, 0.1, 12]} />
          <meshStandardMaterial color="#c5ced4" roughness={0.38} metalness={0.56} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.28, topY + 0.022, 0.04]}>
          <boxGeometry args={[0.08, 0.018, 0.05]} />
          <meshStandardMaterial color="#f4f5f7" roughness={0.74} metalness={0.04} />
        </mesh>
        <mesh position={[-0.28, topY + 0.034, 0.04]}>
          <boxGeometry args={[0.07, 0.004, 0.018]} />
          <meshStandardMaterial color="#d9b15d" roughness={0.54} metalness={0.12} />
        </mesh>
      </group>
    )
  }

  if (accessory === 'microoscopio') {
    return (
      <group>
        <mesh castShadow receiveShadow position={[0.18, topY + 0.03, 0.08]}>
          <cylinderGeometry args={[0.08, 0.08, 0.06, 18]} />
          <meshStandardMaterial color="#5d6670" roughness={0.54} metalness={0.3} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.18, topY + 0.19, 0.08]}>
          <cylinderGeometry args={[0.026, 0.026, 0.26, 14]} />
          <meshStandardMaterial color="#8e97a0" roughness={0.46} metalness={0.44} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.06, topY + 0.28, 0.08]} rotation={[0, 0, 0.58]}>
          <cylinderGeometry args={[0.018, 0.018, 0.28, 12]} />
          <meshStandardMaterial color="#7c858e" roughness={0.46} metalness={0.44} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.24, topY + 0.34, 0.1]} rotation={[0.22, 0, 0]}>
          <cylinderGeometry args={[0.06, 0.06, 0.2, 16]} />
          <meshStandardMaterial color="#1a2027" roughness={0.34} metalness={0.28} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.18, topY + 0.28, 0.18]}>
          <boxGeometry args={[0.26, 0.03, 0.14]} />
          <meshStandardMaterial color="#2e3741" roughness={0.6} metalness={0.18} />
        </mesh>
        <mesh position={[0.24, topY + 0.37, 0.2]}>
          <sphereGeometry args={[0.02, 12, 12]} />
          <meshStandardMaterial color="#8fd9ff" emissive="#8fd9ff" emissiveIntensity={0.24} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.03, topY + 0.03, -0.02]} rotation={[0, 0.32, 0]}>
          <boxGeometry args={[0.3, 0.02, 0.18]} />
          <meshStandardMaterial color="#1f6b44" roughness={0.62} metalness={0.08} />
        </mesh>
      </group>
    )
  }

  return (
    <group>
      <PcbBoard board={{ id: `support-table-${accessory}-board`, position: [0.04, topY + 0.03, 0.08], rotation: [0, 0.18, 0] }} />
      <mesh castShadow receiveShadow position={[-0.22, topY + 0.018, 0.12]}>
        <boxGeometry args={[0.22, 0.018, 0.1]} />
        <meshStandardMaterial color="#e5e7eb" roughness={0.78} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.3, topY + 0.03, -0.02]}>
        <boxGeometry args={[0.12, 0.06, 0.12]} />
        <meshStandardMaterial color="#59626d" roughness={0.62} metalness={0.2} />
      </mesh>
      <mesh position={[0.3, topY + 0.07, -0.02]}>
        <sphereGeometry args={[0.012, 12, 12]} />
        <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.24} />
      </mesh>
    </group>
  )
}

export function LongGreenWorkTable({ position, rotation, size, accessory }: LongGreenWorkTableProps) {
  const [width, height, depth] = size
  const topThickness = 0.05
  const upperShelfDepth = depth * 0.28
  const upperShelfWidth = width * 0.68
  const legInsetX = width / 2 - 0.12
  const legInsetZ = depth / 2 - 0.08
  const topY = height

  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, 0]}>
        <boxGeometry args={[width, topThickness, depth]} />
        <meshStandardMaterial color="#2f7658" roughness={0.78} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, depth / 2 - 0.025]}>
        <boxGeometry args={[width, 0.05, 0.05]} />
        <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height - topThickness / 2, -depth / 2 + 0.025]}>
        <boxGeometry args={[width, 0.05, 0.05]} />
        <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, height + 0.13, -depth / 2 + upperShelfDepth / 2 + 0.05]}>
        <boxGeometry args={[upperShelfWidth, 0.04, upperShelfDepth]} />
        <meshStandardMaterial color="#2f7658" roughness={0.76} metalness={0.08} />
      </mesh>

      {[-upperShelfWidth / 2 + 0.12, upperShelfWidth / 2 - 0.12].map((x) => (
        <mesh key={x} castShadow receiveShadow position={[x, height + 0.065, -depth / 2 + upperShelfDepth / 2 + 0.05]}>
          <boxGeometry args={[0.05, 0.22, 0.05]} />
          <meshStandardMaterial color="#98a1a8" roughness={0.48} metalness={0.44} />
        </mesh>
      ))}

      {[
        [-legInsetX, height / 2, -legInsetZ],
        [legInsetX, height / 2, -legInsetZ],
        [-legInsetX, height / 2, legInsetZ],
        [legInsetX, height / 2, legInsetZ],
      ].map((leg) => (
        <mesh key={leg.join('-')} castShadow receiveShadow position={leg as [number, number, number]}>
          <boxGeometry args={[0.07, height, 0.07]} />
          <meshStandardMaterial color="#7c848b" roughness={0.44} metalness={0.54} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0, 0.26, 0]}>
        <boxGeometry args={[width - 0.28, 0.04, depth - 0.2]} />
        <meshStandardMaterial color="#d5dadd" roughness={0.82} metalness={0.06} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, topY + 0.36, -depth / 2 + 0.03]}>
        <boxGeometry args={[width, 0.72, 0.04]} />
        <meshStandardMaterial color="#7b5637" roughness={0.88} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[-width / 2 + 0.04, topY + 0.16, -depth / 2 + 0.03]}>
        <boxGeometry args={[0.05, 0.32, 0.04]} />
        <meshStandardMaterial color="#906749" roughness={0.82} metalness={0.04} />
      </mesh>
      <mesh castShadow receiveShadow position={[width / 2 - 0.04, topY + 0.16, -depth / 2 + 0.03]}>
        <boxGeometry args={[0.05, 0.32, 0.04]} />
        <meshStandardMaterial color="#906749" roughness={0.82} metalness={0.04} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.44, -depth / 2 + 0.03]}>
        <boxGeometry args={[width - 0.18, 0.04, 0.05]} />
        <meshStandardMaterial color="#aeb4b8" roughness={0.56} metalness={0.34} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.44, depth / 2 - 0.03]}>
        <boxGeometry args={[width - 0.18, 0.04, 0.05]} />
        <meshStandardMaterial color="#aeb4b8" roughness={0.56} metalness={0.34} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.28, height + 0.025, 0.02]}>
        <boxGeometry args={[0.26, 0.08, 0.16]} />
        <meshStandardMaterial color="#6d7680" roughness={0.64} metalness={0.2} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.48, height + 0.025, -0.02]}>
        <boxGeometry args={[0.42, 0.02, 0.16]} />
        <meshStandardMaterial color="#29323a" roughness={0.6} metalness={0.14} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.26, height + 0.03, 0.14]}>
        <cylinderGeometry args={[0.07, 0.07, 0.05, 16]} />
        <meshStandardMaterial color="#c7ced4" roughness={0.68} metalness={0.08} />
      </mesh>

      <WorkstationMonitor
        position={[0, height + 0.5, -depth / 2 + 0.11]}
        rotation={[-0.12, 0, 0]}
        width={0.82}
        height={0.46}
        media={{
          type: 'image',
          source: '/media/screens/placeholder.svg',
          fallback: '/media/screens/placeholder.svg',
          fit: 'cover',
        }}
      />

      <TableAccessory accessory={accessory} topY={topY} />
    </group>
  )
}
