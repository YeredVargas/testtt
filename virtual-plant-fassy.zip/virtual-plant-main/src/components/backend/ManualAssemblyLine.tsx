import { Text } from '@react-three/drei'
import {
  backendPcbBoards,
  ENABLE_BACKEND_PCB_ANIMATION,
  MASSY_LENGTH,
  STATION_COUNT,
  STATION_PITCH,
} from '../../data/backendLine'
import type { MediaModalData } from '../../types/factory'
import type { ManualAssemblyLineConfig } from '../../types/backend'
import { PcbBoard } from '../PcbBoard'
import { AluminumFrame } from './AluminumFrame'
import { ManualAssemblyConveyor } from './ManualAssemblyConveyor'
import { ManualAssemblyStation } from './ManualAssemblyStation'
import { RearMaterialArea } from './RearMaterialArea'

interface ManualAssemblyLineProps {
  config: ManualAssemblyLineConfig
  showRearMaterialArea?: boolean
  onOpenMedia?: (media: MediaModalData) => void
}

export function ManualAssemblyLine({ config, showRearMaterialArea = false, onOpenMedia }: ManualAssemblyLineProps) {
  const postOffsets = Array.from({ length: STATION_COUNT + 1 }, (_, index) => -MASSY_LENGTH / 2 + 0.4 + index * STATION_PITCH)

  return (
    <group position={config.position} rotation={config.rotation}>
      <ManualAssemblyConveyor length={config.conveyorLength} />

      <AluminumFrame position={[0, 2.36, -0.52]} size={[MASSY_LENGTH, 0.06, 0.06]} />
      <AluminumFrame position={[0, 1.85, -0.22]} size={[MASSY_LENGTH, 0.05, 0.05]} castShadow={false} />
      <AluminumFrame position={[0, 1.02, 0.62]} size={[MASSY_LENGTH - 0.4, 0.05, 0.05]} castShadow={false} />

      {postOffsets.map((offset) => (
        <group key={offset} position={[offset, 0, 0]}>
          <AluminumFrame position={[0, 1.18, -0.52]} size={[0.06, 2.36, 0.06]} />
          <AluminumFrame position={[0, 0.52, 0.46]} size={[0.06, 0.92, 0.06]} castShadow={false} />
        </group>
      ))}

      <AluminumFrame position={[-MASSY_LENGTH / 2 - 0.18, 1.56, 0.9]} size={[0.06, 1.18, 0.06]} />
      <AluminumFrame position={[-MASSY_LENGTH / 2 + 0.44, 1.56, 0.9]} size={[0.06, 1.18, 0.06]} />
      <mesh castShadow receiveShadow position={[-MASSY_LENGTH / 2 + 0.13, 2.14, 0.9]}>
        <boxGeometry args={[1.34, 0.42, 0.06]} />
        <meshStandardMaterial color="#234a78" roughness={0.56} metalness={0.12} />
      </mesh>
      <Text position={[-MASSY_LENGTH / 2 + 0.13, 2.2, 0.94]} fontSize={0.1} color="#f8fafc" anchorX="center" anchorY="middle">
        BACKEND
      </Text>
      <Text position={[-MASSY_LENGTH / 2 + 0.13, 2.08, 0.94]} fontSize={0.07} color="#dbeafe" anchorX="center" anchorY="middle">
        MASSY - MANUAL ASSEMBLY
      </Text>

      {config.stations.filter((station) => station.enabled !== false).map((station) => (
        <ManualAssemblyStation key={station.id} station={station} />
      ))}

      {showRearMaterialArea ? <RearMaterialArea onOpenMedia={onOpenMedia} /> : null}

      {backendPcbBoards.map((board) => (
        <PcbBoard
          key={board.id}
          board={ENABLE_BACKEND_PCB_ANIMATION ? board : { ...board, animation: undefined }}
        />
      ))}

      {[-MASSY_LENGTH / 2 + 0.2, MASSY_LENGTH / 2 - 0.2].map((offsetX) => (
        <group key={offsetX} position={[offsetX, 0, 0]}>
          <mesh castShadow receiveShadow position={[0, 1.54, -0.08]}>
            <cylinderGeometry args={[0.04, 0.04, 0.35, 10]} />
            <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
          </mesh>
          {[
            { color: '#22c55e', y: 1.7 },
            { color: '#f59e0b', y: 1.8 },
            { color: '#ef4444', y: 1.9 },
          ].map((light) => (
            <mesh key={light.color} position={[0, light.y, -0.08]}>
              <cylinderGeometry args={[0.05, 0.05, 0.07, 14]} />
              <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.34} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  )
}
