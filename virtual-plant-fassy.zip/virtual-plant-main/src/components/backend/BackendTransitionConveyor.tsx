import { BACKEND_CONVEYOR_HEIGHT } from '../../data/backendProcesses'

interface BackendTransitionConveyorProps {
  length: number
  position: [number, number, number]
}

export function BackendTransitionConveyor({
  length,
  position,
}: BackendTransitionConveyorProps) {
  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, BACKEND_CONVEYOR_HEIGHT - 0.05, 0]}>
        <boxGeometry args={[length, 0.08, 0.65]} />
        <meshStandardMaterial color="#20252b" roughness={0.84} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, BACKEND_CONVEYOR_HEIGHT, 0.28]}>
        <boxGeometry args={[length, 0.04, 0.05]} />
        <meshStandardMaterial color="#8d9499" roughness={0.54} metalness={0.44} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, BACKEND_CONVEYOR_HEIGHT, -0.28]}>
        <boxGeometry args={[length, 0.04, 0.05]} />
        <meshStandardMaterial color="#8d9499" roughness={0.54} metalness={0.44} />
      </mesh>
      {[-length / 2 + 0.16, length / 2 - 0.16].map((offsetX) => (
        <group key={offsetX} position={[offsetX, 0, 0]}>
          {[-0.22, 0.22].map((z) => (
            <mesh key={z} castShadow receiveShadow position={[0, 0.4, z]}>
              <boxGeometry args={[0.07, 0.8, 0.07]} />
              <meshStandardMaterial color="#a8afb3" metalness={0.46} roughness={0.46} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  )
}
