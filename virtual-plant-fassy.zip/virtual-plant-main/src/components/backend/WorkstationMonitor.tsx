import { IndustrialScreen } from '../IndustrialScreen'
import type { DisplayMedia } from '../../types/factory'

interface WorkstationMonitorProps {
  position: [number, number, number]
  rotation?: [number, number, number]
  media: DisplayMedia
  width?: number
  height?: number
}

export function WorkstationMonitor({
  position,
  rotation = [-0.12, 0, 0],
  media,
  width = 0.64,
  height = 0.36,
}: WorkstationMonitorProps) {
  return (
    <group position={position} rotation={rotation}>
      <mesh position={[0, 0, -0.045]}>
        <boxGeometry args={[width + 0.06, height + 0.06, 0.06]} />
        <meshStandardMaterial color="#1f2937" roughness={0.48} metalness={0.22} />
      </mesh>
      <mesh position={[0, 0, 0.006]}>
        <planeGeometry args={[width + 0.02, height + 0.02]} />
        <meshBasicMaterial color="#050505" toneMapped={false} />
      </mesh>
      <group position={[0, 0, 0.014]}>
        <IndustrialScreen media={media} width={width} height={height} />
      </group>
      <mesh position={[0, -0.15, -0.05]}>
        <boxGeometry args={[0.07, 0.16, 0.06]} />
        <meshStandardMaterial color="#9098a0" roughness={0.46} metalness={0.52} />
      </mesh>
    </group>
  )
}
