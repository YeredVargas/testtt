import { Text } from '@react-three/drei'
import { MachineControlPanel, TowerLight } from '../equipment/CommonParts'
import type { Vec3 } from '../../types/factory'

interface BackendLaserMachineProps {
  position: Vec3
  rotation?: Vec3
  size: Vec3
}

export function BackendLaserMachine({ position, rotation, size }: BackendLaserMachineProps) {
  const [width, height, depth] = size
  const front = depth / 2 + 0.025

  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#30343a" roughness={0.74} metalness={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 1.02, 0]}>
        <boxGeometry args={[width, 1.54, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.72} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.14, 1.28, front]}>
        <boxGeometry args={[width * 0.62, 0.88, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.2} metalness={0.16} />
      </mesh>

      <mesh castShadow receiveShadow position={[-width * 0.24, 0.96, front + 0.005]}>
        <boxGeometry args={[width * 0.18, 1.04, 0.04]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.86} metalness={0.04} />
      </mesh>

      <mesh castShadow receiveShadow position={[0.18, 1.78, 0]}>
        <boxGeometry args={[width * 0.58, 0.24, depth * 0.7]} />
        <meshStandardMaterial color="#eef0ed" roughness={0.68} metalness={0.06} />
      </mesh>

      <mesh position={[0.08, 1.12, 0]}>
        <boxGeometry args={[width * 0.28, 0.24, depth * 0.28]} />
        <meshStandardMaterial color="#0f172a" roughness={0.3} metalness={0.18} />
      </mesh>
      <mesh position={[0.08, 1.12, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.06, 0.06, depth * 0.18, 14]} />
        <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.36} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.54, front + 0.01]}>
        <boxGeometry args={[width * 0.72, 0.2, 0.04]} />
        <meshStandardMaterial color="#d3d8db" roughness={0.8} metalness={0.06} />
      </mesh>

      <mesh position={[-0.12, 1.54, front + 0.008]}>
        <boxGeometry args={[width * 0.42, 0.11, 0.03]} />
        <meshStandardMaterial color="#0f7ea3" emissive="#0f7ea3" emissiveIntensity={0.24} roughness={0.42} metalness={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0.92, -depth * 0.26]}>
        <boxGeometry args={[width * 0.12, 1.04, depth * 0.34]} />
        <meshStandardMaterial color="#d3d8db" roughness={0.82} metalness={0.06} />
      </mesh>

      <MachineControlPanel position={[width * 0.44, 0, depth / 2 + 0.26]} rotation={[0, 0, 0.16]} standHeight={0.82} />
      <TowerLight position={[width * 0.34, height - 0.08, depth * 0.22]} />

      <group position={[0, 1.6, front + 0.05]}>
        <mesh>
          <boxGeometry args={[Math.min(width * 0.72, 2.5), 0.28, 0.03]} />
          <meshStandardMaterial color="#d9dde0" roughness={0.8} metalness={0.08} />
        </mesh>
        <Text position={[0, 0, 0.021]} fontSize={0.14} color="#101317" anchorX="center" anchorY="middle" maxWidth={2.2}>
          LASER BACKEND
        </Text>
      </group>

      <Text position={[0.02, 0.66, front + 0.05]} fontSize={0.105} color="#0f7ea3" anchorX="center" anchorY="middle">
        LASER MARKING
      </Text>
    </group>
  )
}
