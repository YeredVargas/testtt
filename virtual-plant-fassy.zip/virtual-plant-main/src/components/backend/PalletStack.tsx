interface PalletStackProps {
  position: [number, number, number]
}

export function PalletStack({ position }: PalletStackProps) {
  const boxLayout = [
    [-0.32, 0.19, -0.08],
    [0, 0.19, -0.08],
    [0.32, 0.19, -0.08],
    [-0.16, 0.43, 0.08],
    [0.16, 0.43, 0.08],
    [0, 0.67, 0],
  ] as [number, number, number][]

  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0.08, 0]}>
        <boxGeometry args={[1.15, 0.16, 0.95]} />
        <meshStandardMaterial color="#8b5a2b" roughness={0.82} metalness={0.08} />
      </mesh>
      {boxLayout.map((boxPosition, index) => (
        <group key={index} position={boxPosition}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[0.3, 0.18, 0.24]} />
            <meshStandardMaterial color="#0d0f12" roughness={0.8} metalness={0.04} />
          </mesh>
          <mesh position={[0, 0.02, 0.121]}>
            <boxGeometry args={[0.2, 0.08, 0.01]} />
            <meshStandardMaterial color="#f1f5f9" roughness={0.84} metalness={0} />
          </mesh>
        </group>
      ))}
    </group>
  )
}
