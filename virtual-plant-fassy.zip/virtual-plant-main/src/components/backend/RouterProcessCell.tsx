import { Text } from '@react-three/drei'
import { IndustrialScreen } from '../IndustrialScreen'
import { PcbBoard } from '../PcbBoard'
import { routerProcessCellConfig } from '../../data/routerProcessCell'
import type { RouterProcessCellConfig } from '../../types/routerCell'

interface RouterProcessCellProps {
  config?: RouterProcessCellConfig
}

export function RouterProcessCell({ config = routerProcessCellConfig }: RouterProcessCellProps) {
  const table = config.equipment.find((equipment) => equipment.type === 'router-table')
  const machine = config.equipment.find((equipment) => equipment.type === 'router-machine')
  const wasteBin = config.equipment.find((equipment) => equipment.type === 'waste-bin')

  if (!table || !machine || !wasteBin) {
    return null
  }

  const [tableWidth, tableHeight, tableDepth] = table.size
  const [machineWidth, machineHeight, machineDepth] = machine.size
  const front = machineDepth / 2 + 0.03

  return (
    <group position={config.position} rotation={config.rotation}>
      <group position={table.position}>
        <mesh castShadow receiveShadow position={[0, tableHeight - 0.025, 0]}>
          <boxGeometry args={[tableWidth, 0.05, tableDepth]} />
          <meshStandardMaterial color="#2f7658" roughness={0.78} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, tableHeight - 0.025, tableDepth / 2 - 0.025]}>
          <boxGeometry args={[tableWidth, 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, tableHeight - 0.025, -tableDepth / 2 + 0.025]}>
          <boxGeometry args={[tableWidth, 0.05, 0.05]} />
          <meshStandardMaterial color="#1f503d" roughness={0.74} metalness={0.1} />
        </mesh>
        {[-tableWidth / 2 + 0.1, tableWidth / 2 - 0.1].map((x) => (
          <group key={x} position={[x, 0, 0]}>
            {[-tableDepth / 2 + 0.08, tableDepth / 2 - 0.08].map((z) => (
              <mesh key={z} castShadow receiveShadow position={[0, tableHeight / 2, z]}>
                <boxGeometry args={[0.07, tableHeight, 0.07]} />
                <meshStandardMaterial color="#7c848b" roughness={0.44} metalness={0.54} />
              </mesh>
            ))}
          </group>
        ))}
        <mesh castShadow receiveShadow position={[0, 0.22, 0]}>
          <boxGeometry args={[tableWidth - 0.24, 0.04, tableDepth - 0.18]} />
          <meshStandardMaterial color="#d5dadd" roughness={0.82} metalness={0.06} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.56, tableHeight + 0.28, 0.24]}>
          <cylinderGeometry args={[0.03, 0.04, 0.58, 12]} />
          <meshStandardMaterial color="#8e969d" roughness={0.44} metalness={0.52} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.34, tableHeight + 0.49, 0.16]} rotation={[0, 0, 0.22]}>
          <boxGeometry args={[0.42, 0.04, 0.04]} />
          <meshStandardMaterial color="#9ba3aa" roughness={0.46} metalness={0.44} />
        </mesh>
        <group position={[0, 1.55, 0.18]} rotation={[-0.1, -0.06, 0]}>
          <mesh castShadow receiveShadow position={[0, 0, -0.05]}>
            <boxGeometry args={[0.82, 0.52, 0.08]} />
            <meshStandardMaterial color="#101419" roughness={0.34} metalness={0.28} />
          </mesh>
          <mesh position={[0, 0, 0.008]}>
            <planeGeometry args={[0.75, 0.47]} />
            <meshBasicMaterial color="#050505" toneMapped={false} />
          </mesh>
          <group position={[0, 0, 0.014]}>
            <IndustrialScreen
              media={{
                type: 'image',
                source: '/media/screens/placeholder.svg',
                fallback: '/media/screens/placeholder.svg',
                fit: 'cover',
              }}
              width={0.72}
              height={0.42}
            />
          </group>
          <mesh castShadow receiveShadow position={[0, -0.16, -0.055]}>
            <boxGeometry args={[0.08, 0.14, 0.06]} />
            <meshStandardMaterial color="#8e979f" roughness={0.46} metalness={0.48} />
          </mesh>
        </group>
        <PcbBoard board={{ id: 'router-process-table-board', position: [0.18, tableHeight + 0.03, 0.04] }} />
      </group>

      <group position={machine.position}>
        <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
          <boxGeometry args={[machineWidth, 0.24, machineDepth]} />
          <meshStandardMaterial color="#30363b" roughness={0.78} metalness={0.18} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, machineHeight / 2, 0]}>
          <boxGeometry args={[machineWidth, machineHeight, machineDepth]} />
          <meshStandardMaterial color="#e8e9e7" roughness={0.72} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 1.18, front]}>
          <boxGeometry args={[machineWidth * 0.58, 0.96, 0.05]} />
          <meshStandardMaterial color="#101317" roughness={0.2} metalness={0.18} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.32, 1.88, 0]}>
          <boxGeometry args={[0.54, 0.24, 0.42]} />
          <meshStandardMaterial color="#c5ccd1" roughness={0.56} metalness={0.24} />
        </mesh>
        <mesh castShadow receiveShadow position={[-0.44, 0.92, 0]}>
          <boxGeometry args={[0.18, 1.18, machineDepth * 0.6]} />
          <meshStandardMaterial color="#d9dde0" roughness={0.78} metalness={0.04} />
        </mesh>
        <mesh position={[0, 1.0, front - 0.08]}>
          <boxGeometry args={[machineWidth * 0.44, 0.08, 0.2]} />
          <meshStandardMaterial color="#6b7280" roughness={0.52} metalness={0.44} />
        </mesh>
        <mesh position={[0.05, 1.18, front - 0.11]}>
          <boxGeometry args={[0.12, 0.42, 0.12]} />
          <meshStandardMaterial color="#8d9499" roughness={0.48} metalness={0.5} />
        </mesh>
        <mesh position={[0.05, 0.92, front - 0.11]}>
          <cylinderGeometry args={[0.03, 0.03, 0.16, 14]} />
          <meshStandardMaterial color="#cfd2d3" roughness={0.34} metalness={0.52} />
        </mesh>
        <mesh position={[-0.04, 0.9, front - 0.18]}>
          <boxGeometry args={[0.34, 0.02, 0.24]} />
          <meshStandardMaterial color="#1f6b44" roughness={0.58} metalness={0.08} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.26, 1.1, front - 0.14]}>
          <boxGeometry args={[0.22, 0.32, 0.14]} />
          <meshStandardMaterial color="#aeb7bd" roughness={0.44} metalness={0.38} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, 0.9, 0]}>
          <boxGeometry args={[machineWidth * 0.88, 0.06, 0.38]} />
          <meshStandardMaterial color="#6e767c" roughness={0.54} metalness={0.34} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.38, 2.03, 0]}>
          <boxGeometry args={[0.26, 0.22, 0.32]} />
          <meshStandardMaterial color="#c5ccd1" roughness={0.54} metalness={0.28} />
        </mesh>
        <mesh castShadow receiveShadow position={[0.38, 2.18, -0.22]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.08, 0.08, 0.36, 14]} />
          <meshStandardMaterial color="#8d9499" roughness={0.44} metalness={0.56} />
        </mesh>
        <mesh castShadow receiveShadow position={[machineWidth * 0.45, 0.4, machineDepth / 2 + 0.22]}>
          <boxGeometry args={[0.08, 0.8, 0.08]} />
          <meshStandardMaterial color="#8d9499" roughness={0.52} metalness={0.55} />
        </mesh>
        <mesh castShadow receiveShadow position={[machineWidth * 0.45, 1.0, machineDepth / 2 + 0.22]}>
          <boxGeometry args={[0.3, 0.42, 0.08]} />
          <meshStandardMaterial color="#1b2430" roughness={0.38} metalness={0.25} />
        </mesh>
        <mesh position={[machineWidth * 0.45, 1.01, machineDepth / 2 + 0.263]}>
          <boxGeometry args={[0.22, 0.26, 0.01]} />
          <meshStandardMaterial color="#062c40" emissive="#0f7ea3" emissiveIntensity={0.34} />
        </mesh>
        <mesh castShadow receiveShadow position={[machineWidth * 0.32, machineHeight - 0.02, machineDepth * 0.22]}>
          <cylinderGeometry args={[0.035, 0.04, 0.36, 10]} />
          <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
        </mesh>
        {[
          { color: '#22c55e', y: machineHeight + 0.16 },
          { color: '#f59e0b', y: machineHeight + 0.26 },
          { color: '#ef4444', y: machineHeight + 0.36 },
        ].map((light) => (
          <mesh key={light.color} castShadow position={[machineWidth * 0.32, light.y, machineDepth * 0.22]}>
            <cylinderGeometry args={[0.055, 0.055, 0.075, 14]} />
            <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.36} />
          </mesh>
        ))}
        <group position={[0, 1.86, front + 0.05]}>
          <mesh>
            <boxGeometry args={[Math.min(machineWidth * 0.66, 2.5), 0.28, 0.03]} />
            <meshStandardMaterial color="#d9dde0" roughness={0.8} metalness={0.08} />
          </mesh>
          <Text position={[0, 0, 0.021]} fontSize={0.15} color="#101317" anchorX="center" anchorY="middle">
            ROUTER
          </Text>
        </group>
        <mesh castShadow receiveShadow position={[machineWidth / 2 - 0.02, 0.88, 0.42]} rotation={[0.38, 0, 0]}>
          <boxGeometry args={[0.28, 0.08, 0.52]} />
          <meshStandardMaterial color="#969fa8" roughness={0.42} metalness={0.42} />
        </mesh>
        <mesh castShadow receiveShadow position={[machineWidth / 2 - 0.12, 0.92, 0.52]}>
          <boxGeometry args={[0.14, 0.24, 0.34]} />
          <meshStandardMaterial color="#565f67" roughness={0.58} metalness={0.18} />
        </mesh>
        <mesh castShadow receiveShadow position={[machineWidth / 2 + 0.08, 0.74, 0.76]} rotation={[0.28, 0, 0]}>
          <boxGeometry args={[0.18, 0.08, 0.34]} />
          <meshStandardMaterial color="#a1aab1" roughness={0.42} metalness={0.42} />
        </mesh>
        <mesh position={[machineWidth / 2 + 0.02, 1.02, 0.26]}>
          <boxGeometry args={[0.08, 0.14, 0.08]} />
          <meshStandardMaterial color="#1f2328" roughness={0.56} metalness={0.18} />
        </mesh>
      </group>

      <group position={wasteBin.position}>
        <mesh castShadow receiveShadow position={[0, wasteBin.size[1] / 2, 0]}>
          <boxGeometry args={wasteBin.size} />
          <meshStandardMaterial color="#111317" roughness={0.76} metalness={0.12} />
        </mesh>
        <mesh castShadow receiveShadow position={[0, wasteBin.size[1] - 0.04, 0]}>
          <boxGeometry args={[wasteBin.size[0] * 0.9, 0.04, wasteBin.size[2] * 0.9]} />
          <meshStandardMaterial color="#1f2328" roughness={0.72} metalness={0.14} />
        </mesh>
        <mesh position={[0, wasteBin.size[1] - 0.08, 0]}>
          <boxGeometry args={[wasteBin.size[0] * 0.54, 0.02, wasteBin.size[2] * 0.54]} />
          <meshStandardMaterial color="#050505" roughness={0.9} metalness={0.04} />
        </mesh>
      </group>
    </group>
  )
}
