interface AluminumFrameProps {
  position: [number, number, number]
  size: [number, number, number]
  rotation?: [number, number, number]
  castShadow?: boolean
}

export function AluminumFrame({
  position,
  size,
  rotation = [0, 0, 0],
  castShadow = true,
}: AluminumFrameProps) {
  return (
    <mesh castShadow={castShadow} receiveShadow position={position} rotation={rotation}>
      <boxGeometry args={size} />
      <meshStandardMaterial color="#adb3b7" metalness={0.6} roughness={0.4} />
    </mesh>
  )
}
