import {
  MANUAL_ASSEMBLY_CONVEYOR_HEIGHT,
  MANUAL_ASSEMBLY_CONVEYOR_WIDTH,
} from '../../data/backendLine'

interface ManualAssemblyConveyorProps {
  length: number
}

export function ManualAssemblyConveyor({ length }: ManualAssemblyConveyorProps) {
  const supportOffsets = Array.from({ length: 7 }, (_, index) => -length / 2 + 1 + index * ((length - 2) / 6))
  const rollerOffsets = Array.from({ length: 14 }, (_, index) => -length / 2 + 0.6 + index * ((length - 1.2) / 13))

  return (
    <group>
      <mesh castShadow receiveShadow position={[0, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT - 0.045, 0]}>
        <boxGeometry args={[length, 0.08, MANUAL_ASSEMBLY_CONVEYOR_WIDTH]} />
        <meshStandardMaterial color="#20252b" roughness={0.84} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT, MANUAL_ASSEMBLY_CONVEYOR_WIDTH / 2 - 0.04]}>
        <boxGeometry args={[length, 0.04, 0.05]} />
        <meshStandardMaterial color="#8d9499" roughness={0.54} metalness={0.44} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT, -MANUAL_ASSEMBLY_CONVEYOR_WIDTH / 2 + 0.04]}>
        <boxGeometry args={[length, 0.04, 0.05]} />
        <meshStandardMaterial color="#8d9499" roughness={0.54} metalness={0.44} />
      </mesh>
      {rollerOffsets.map((offset) => (
        <mesh key={offset} position={[offset, MANUAL_ASSEMBLY_CONVEYOR_HEIGHT - 0.002, 0]}>
          <boxGeometry args={[0.05, 0.012, MANUAL_ASSEMBLY_CONVEYOR_WIDTH - 0.16]} />
          <meshStandardMaterial color="#31363d" roughness={0.76} metalness={0.08} />
        </mesh>
      ))}
      {supportOffsets.map((offset) => (
        <group key={offset} position={[offset, 0, 0]}>
          {[-0.25, 0.25].map((z) => (
            <mesh key={z} castShadow receiveShadow position={[0, 0.43, z]}>
              <boxGeometry args={[0.07, 0.86, 0.07]} />
              <meshStandardMaterial color="#adb3b7" metalness={0.52} roughness={0.42} />
            </mesh>
          ))}
          <mesh castShadow receiveShadow position={[0, 0.18, 0]}>
            <boxGeometry args={[0.54, 0.05, 0.06]} />
            <meshStandardMaterial color="#7c848b" metalness={0.42} roughness={0.48} />
          </mesh>
        </group>
      ))}
    </group>
  )
}
