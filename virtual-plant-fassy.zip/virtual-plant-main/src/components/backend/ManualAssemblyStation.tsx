import { SHOW_OPERATOR_PLACEHOLDERS } from '../../data/backendLine'
import type { ManualAssemblyStationConfig } from '../../types/backend'
import { AluminumFrame } from './AluminumFrame'
import { AntiFatigueMat } from './AntiFatigueMat'
import { ComponentBins } from './ComponentBins'
import { StationSign } from './StationSign'
import { WorkstationMonitor } from './WorkstationMonitor'

interface ManualAssemblyStationProps {
  station: ManualAssemblyStationConfig
}

function OperatorPlaceholder() {
  if (!SHOW_OPERATOR_PLACEHOLDERS) {
    return null
  }

  return (
    <group position={[0, 0, 1.9]}>
      <mesh position={[0, 1.42, 0]}>
        <sphereGeometry args={[0.15, 18, 18]} />
        <meshStandardMaterial color="#f1f5f9" roughness={0.82} metalness={0.02} />
      </mesh>
      <mesh position={[0, 0.88, 0]}>
        <boxGeometry args={[0.34, 0.64, 0.2]} />
        <meshStandardMaterial color="#d7dde2" roughness={0.82} metalness={0.04} />
      </mesh>
    </group>
  )
}

export function ManualAssemblyStation({ station }: ManualAssemblyStationProps) {
  const monitorCenterY = 1.58
  const monitorCenterZ = 0.62

  const binCount = 3 + (station.number % 3)

  return (
    <group position={station.position} rotation={station.rotation}>
      <AluminumFrame position={[-0.84, 2.18, -0.52]} size={[0.05, 0.3, 0.05]} />
      <AluminumFrame position={[0.84, 2.18, -0.52]} size={[0.05, 0.3, 0.05]} />
      <StationSign number={station.number} position={[0, 2.18, 0.42]} />

      <AluminumFrame position={[0, 1.86, 0.28]} size={[0.4, 0.04, 0.04]} rotation={[0.22, 0, 0]} castShadow={false} />
      <AluminumFrame position={[0, 1.72, 0.42]} size={[0.06, 0.24, 0.06]} castShadow={false} />
      <WorkstationMonitor position={[0, monitorCenterY, monitorCenterZ]} rotation={station.monitorRotation} media={station.screenMedia} />

      <ComponentBins position={[0, 1.05, 0.78]} binCount={binCount} />

      <mesh castShadow receiveShadow position={[0, 0.98, 0.48]}>
        <boxGeometry args={[1.24, 0.05, 0.28]} />
        <meshStandardMaterial color="#e7e8e6" roughness={0.82} metalness={0.05} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.68, 1.0, 0.58]}>
        <boxGeometry args={[0.18, 0.16, 0.14]} />
        <meshStandardMaterial color="#717981" roughness={0.66} metalness={0.24} />
      </mesh>
      <mesh position={[0.64, 1.03, 0.67]}>
        <cylinderGeometry args={[0.024, 0.024, 0.03, 12]} />
        <meshStandardMaterial color="#16a34a" emissive="#16a34a" emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[0.7, 1.03, 0.67]}>
        <cylinderGeometry args={[0.024, 0.024, 0.03, 12]} />
        <meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[0.76, 1.035, 0.67]}>
        <cylinderGeometry args={[0.04, 0.04, 0.04, 16]} />
        <meshStandardMaterial color="#d71f26" emissive="#d71f26" emissiveIntensity={0.34} />
      </mesh>
      <mesh position={[0.76, 0.985, 0.67]}>
        <cylinderGeometry args={[0.062, 0.062, 0.04, 18]} />
        <meshStandardMaterial color="#f2c500" roughness={0.58} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 2.0, 0.68]}>
        <boxGeometry args={[1.18, 0.06, 0.16]} />
        <meshStandardMaterial color="#f3f4f6" emissive="#dbeafe" emissiveIntensity={0.28} />
      </mesh>

      <AntiFatigueMat position={[0, 0.01, 1.95]} />
      <OperatorPlaceholder />
    </group>
  )
}
