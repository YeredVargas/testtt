import { memo } from 'react'
import {
  factoryArchitecture,
  SHOW_FACTORY_CEILING,
  SHOW_STRUCTURAL_COLUMNS,
} from '../../../data/factoryArchitecture'
import { BlueVendingMachine } from './BlueVendingMachine'
import { IndustrialCeiling } from './IndustrialCeiling'
import { ServiceWall } from './ServiceWall'
import { StructuralColumn } from './StructuralColumn'

export const FactoryArchitecture = memo(function FactoryArchitecture() {
  const { ceiling, columns, vendingMachines, walls } = factoryArchitecture.config

  return (
    <group>
      {SHOW_FACTORY_CEILING ? <IndustrialCeiling config={ceiling} /> : null}
      {walls.map((wall) => (
        <ServiceWall key={wall.id} wall={wall} />
      ))}
      {SHOW_STRUCTURAL_COLUMNS ? columns.map((column) => <StructuralColumn key={column.id} column={column} />) : null}
      {vendingMachines.map((machine) => (
        <BlueVendingMachine key={machine.id} machine={machine} />
      ))}
    </group>
  )
})
