import { useLayoutEffect, useMemo, useRef } from 'react'
import { Object3D, type InstancedMesh } from 'three'
import { SHOW_CEILING_LIGHTS } from '../../../data/factoryArchitecture'
import type { CeilingConfig } from '../../../types/architecture'

interface IndustrialCeilingProps {
  config: CeilingConfig
}

const GRID_BAR_HEIGHT = 0.008
const dummy = new Object3D()

function buildAxisPositions(span: number, step: number) {
  const count = Math.ceil(span / step)
  const start = -((count - 1) * step) / 2

  return Array.from({ length: count }, (_, index) => start + index * step)
}

function buildLightAxisPositions(span: number, spacing: number, margin: number) {
  const usableSpan = Math.max(span - margin * 2, spacing)
  const count = Math.floor(usableSpan / spacing) + 1
  const start = -((count - 1) * spacing) / 2

  return Array.from({ length: count }, (_, index) => start + index * spacing)
}

export function IndustrialCeiling({ config }: IndustrialCeilingProps) {
  const xGridPositions = useMemo(() => buildAxisPositions(config.width, config.tileSize), [config.tileSize, config.width])
  const zGridPositions = useMemo(() => buildAxisPositions(config.depth, config.tileSize), [config.depth, config.tileSize])
  const lightXPositions = useMemo(
    () => buildLightAxisPositions(config.width, config.lightSpacingX, config.lightMarginX),
    [config.lightMarginX, config.lightSpacingX, config.width],
  )
  const lightZPositions = useMemo(
    () => buildLightAxisPositions(config.depth, config.lightSpacingZ, config.lightMarginZ),
    [config.depth, config.lightMarginZ, config.lightSpacingZ],
  )
  const gridY = config.center[1] - config.thickness / 2 - 0.012
  const lightY = config.center[1] - config.thickness / 2 - config.lightSize[1] / 2 - 0.018
  const xGridRef = useRef<InstancedMesh | null>(null)
  const zGridRef = useRef<InstancedMesh | null>(null)
  const lightFrameRef = useRef<InstancedMesh | null>(null)
  const lightGlowRef = useRef<InstancedMesh | null>(null)
  const lightPositions = useMemo(
    () => lightXPositions.flatMap((x) => lightZPositions.map((z) => [config.center[0] + x, lightY, config.center[2] + z] as const)),
    [config.center, lightXPositions, lightY, lightZPositions],
  )

  useLayoutEffect(() => {
    if (xGridRef.current) {
      xGridPositions.forEach((x, index) => {
        dummy.position.set(config.center[0] + x, gridY, config.center[2])
        dummy.scale.set(config.gridLineWidth, GRID_BAR_HEIGHT, config.depth)
        dummy.updateMatrix()
        xGridRef.current?.setMatrixAt(index, dummy.matrix)
      })
      xGridRef.current.instanceMatrix.needsUpdate = true
    }

    if (zGridRef.current) {
      zGridPositions.forEach((z, index) => {
        dummy.position.set(config.center[0], gridY, config.center[2] + z)
        dummy.scale.set(config.width, GRID_BAR_HEIGHT, config.gridLineWidth)
        dummy.updateMatrix()
        zGridRef.current?.setMatrixAt(index, dummy.matrix)
      })
      zGridRef.current.instanceMatrix.needsUpdate = true
    }

    if (lightFrameRef.current && lightGlowRef.current) {
      lightPositions.forEach((position, index) => {
        dummy.position.set(...position)
        dummy.scale.set(config.lightSize[0], config.lightSize[1], config.lightSize[2])
        dummy.updateMatrix()
        lightFrameRef.current?.setMatrixAt(index, dummy.matrix)

        dummy.position.set(position[0], position[1] - 0.002, position[2])
        dummy.scale.set(config.lightSize[0] - 0.12, config.lightSize[1] * 0.36, config.lightSize[2] - 0.08)
        dummy.updateMatrix()
        lightGlowRef.current?.setMatrixAt(index, dummy.matrix)
      })
      lightFrameRef.current.instanceMatrix.needsUpdate = true
      lightGlowRef.current.instanceMatrix.needsUpdate = true
    }
  }, [config.center, config.depth, config.gridLineWidth, config.lightSize, config.width, gridY, lightPositions, xGridPositions, zGridPositions])

  return (
    <group>
      <mesh position={config.center}>
        <boxGeometry args={[config.width, config.thickness, config.depth]} />
        <meshStandardMaterial color="#deded8" roughness={0.92} metalness={0.02} />
      </mesh>

      <instancedMesh ref={xGridRef} args={[undefined, undefined, xGridPositions.length]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#b7b8b3" roughness={0.94} metalness={0.02} />
      </instancedMesh>

      <instancedMesh ref={zGridRef} args={[undefined, undefined, zGridPositions.length]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#b7b8b3" roughness={0.94} metalness={0.02} />
      </instancedMesh>

      {SHOW_CEILING_LIGHTS ? (
        <>
          <instancedMesh ref={lightFrameRef} args={[undefined, undefined, lightPositions.length]}>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial color="#d0d2cf" roughness={0.72} metalness={0.08} />
          </instancedMesh>
          <instancedMesh ref={lightGlowRef} args={[undefined, undefined, lightPositions.length]}>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial
              color="#fffdf2"
              emissive="#fff4d6"
              emissiveIntensity={0.72}
              roughness={0.22}
              metalness={0.02}
            />
          </instancedMesh>
        </>
      ) : null}
    </group>
  )
}
