import type { StructuralColumnConfig } from '../../../types/architecture'
import { ColumnMountedDisplay } from './ColumnMountedDisplay'

interface StructuralColumnProps {
  column: StructuralColumnConfig
}

export function StructuralColumn({ column }: StructuralColumnProps) {
  return (
    <group position={column.position} rotation={column.rotation}>
      <mesh castShadow receiveShadow position={[0, column.size[1] / 2, 0]}>
        <boxGeometry args={column.size} />
        <meshStandardMaterial color="#e4e3dd" roughness={0.88} metalness={0} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, column.size[1] - 0.06, 0]}>
        <boxGeometry args={[column.size[0] + 0.06, 0.06, column.size[2] + 0.06]} />
        <meshStandardMaterial color="#d5d3cd" roughness={0.84} metalness={0} />
      </mesh>
      {column.display ? <ColumnMountedDisplay display={column.display} /> : null}
    </group>
  )
}
