import type { Vec3 } from '../../../types/factory'

interface CeilingLightPanelProps {
  position: Vec3
  size: Vec3
}

export function CeilingLightPanel({ position, size }: CeilingLightPanelProps) {
  return (
    <group position={position}>
      <mesh receiveShadow>
        <boxGeometry args={size} />
        <meshStandardMaterial color="#d0d2cf" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh position={[0, -0.002, 0]}>
        <boxGeometry args={[size[0] - 0.12, size[1] * 0.36, size[2] - 0.08]} />
        <meshStandardMaterial
          color="#fffdf2"
          emissive="#fff4d6"
          emissiveIntensity={0.72}
          roughness={0.22}
          metalness={0.02}
        />
      </mesh>
    </group>
  )
}
