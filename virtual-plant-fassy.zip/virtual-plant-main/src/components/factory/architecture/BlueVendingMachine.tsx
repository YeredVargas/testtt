import { Text } from '@react-three/drei'
import { useMemo } from 'react'
import type { VendingMachineConfig } from '../../../types/architecture'

interface BlueVendingMachineProps {
  machine: VendingMachineConfig
}

const productPalette = ['#e8eef4', '#7dd3fc', '#fbbf24', '#86efac', '#c4b5fd', '#fca5a5']

export function BlueVendingMachine({ machine }: BlueVendingMachineProps) {
  const productItems = useMemo(() => {
    return Array.from({ length: machine.productRows }, (_, row) =>
      Array.from({ length: machine.productColumns }, (_, column) => ({
        id: `${row}-${column}`,
        x:
          -machine.size[0] * 0.23 +
          (column / Math.max(machine.productColumns - 1, 1)) * machine.size[0] * 0.46,
        y: -0.38 + row * 0.24,
        width: 0.14 + ((row + column) % 2) * 0.04,
        height: 0.08 + (row % 2) * 0.02,
        depth: 0.12,
        color: productPalette[(row * machine.productColumns + column) % productPalette.length],
      })),
    )
  }, [machine.productColumns, machine.productRows, machine.size])

  const [width, height, depth] = machine.size
  const front = depth / 2
  const windowWidth = width * 0.62
  const panelWidth = width * 0.22

  return (
    <group position={machine.position} rotation={machine.rotation}>
      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color={machine.color} roughness={0.56} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.06, 0]}>
        <boxGeometry args={[width + 0.08, 0.12, depth + 0.04]} />
        <meshStandardMaterial color={machine.accentColor} roughness={0.68} metalness={0.14} />
      </mesh>
      {[-1, 1].flatMap((xSign) =>
        [-1, 1].map((zSign) => (
          <mesh
            key={`foot-${xSign}-${zSign}`}
            castShadow
            receiveShadow
            position={[xSign * (width / 2 - 0.12), 0.1, zSign * (depth / 2 - 0.1)]}
          >
            <boxGeometry args={[0.08, 0.08, 0.08]} />
            <meshStandardMaterial color="#3b4752" roughness={0.64} metalness={0.16} />
          </mesh>
        )),
      )}
      <mesh castShadow receiveShadow position={[-width * 0.14, height * 0.6, front + 0.012]}>
        <boxGeometry args={[windowWidth, height * 0.62, 0.05]} />
        <meshStandardMaterial color="#14191f" roughness={0.28} metalness={0.22} />
      </mesh>
      <mesh position={[-width * 0.14, height * 0.6, front + 0.036]}>
        <boxGeometry args={[windowWidth - 0.08, height * 0.58, 0.018]} />
        <meshStandardMaterial color="#101820" roughness={0.14} metalness={0.08} transparent opacity={0.88} />
      </mesh>
      <mesh position={[-width * 0.14, height * 0.6, front - 0.06]}>
        <boxGeometry args={[windowWidth - 0.14, height * 0.56, 0.1]} />
        <meshStandardMaterial color="#d8e4ed" emissive="#dbeafe" emissiveIntensity={0.18} roughness={0.74} metalness={0.04} />
      </mesh>

      {productItems.flatMap((row) =>
        row.map((product) => (
          <mesh
            key={product.id}
            position={[-width * 0.14 + product.x, height * 0.6 + product.y, front - 0.01]}
          >
            <boxGeometry args={[product.width, product.height, product.depth]} />
            <meshStandardMaterial color={product.color} roughness={0.56} metalness={0.08} />
          </mesh>
        )),
      )}

      {Array.from({ length: machine.productRows - 1 }, (_, index) => (
        <mesh key={`shelf-${index}`} position={[-width * 0.14, height * 0.33 + index * 0.24, front - 0.02]}>
          <boxGeometry args={[windowWidth - 0.12, 0.02, 0.16]} />
          <meshStandardMaterial color="#64748b" roughness={0.72} metalness={0.1} />
        </mesh>
      ))}

      <group position={[width * 0.31, height * 0.63, front + 0.02]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[panelWidth, height * 0.58, 0.04]} />
          <meshStandardMaterial color="#d8dde1" roughness={0.82} metalness={0.06} />
        </mesh>
        <mesh position={[0, 0.36, 0.025]}>
          <boxGeometry args={[panelWidth * 0.78, 0.12, 0.012]} />
          <meshStandardMaterial color="#1e3a5f" emissive="#60a5fa" emissiveIntensity={0.22} roughness={0.26} metalness={0.14} />
        </mesh>
        {Array.from({ length: 12 }, (_, index) => {
          const row = Math.floor(index / 3)
          const column = index % 3

          return (
            <mesh key={`key-${index + 1}`} position={[-0.07 + column * 0.07, 0.18 - row * 0.08, 0.025]}>
              <boxGeometry args={[0.045, 0.045, 0.01]} />
              <meshStandardMaterial color="#20252a" roughness={0.42} metalness={0.18} />
            </mesh>
          )
        })}
        <mesh position={[0.07, 0.28, 0.028]}>
          <cylinderGeometry args={[0.015, 0.015, 0.012, 14]} />
          <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.48} />
        </mesh>
        <mesh position={[0, -0.2, 0.025]}>
          <boxGeometry args={[panelWidth * 0.68, 0.035, 0.01]} />
          <meshStandardMaterial color="#374151" roughness={0.54} metalness={0.16} />
        </mesh>
        <mesh position={[0, -0.33, 0.026]}>
          <boxGeometry args={[panelWidth * 0.72, 0.11, 0.012]} />
          <meshStandardMaterial color="#0f172a" roughness={0.42} metalness={0.12} />
        </mesh>
      </group>

      <mesh castShadow receiveShadow position={[0, 0.35, front + 0.014]}>
        <boxGeometry args={[width * 0.42, 0.18, 0.04]} />
        <meshStandardMaterial color="#14191f" roughness={0.34} metalness={0.18} />
      </mesh>
      <Text
        position={[0, height - 0.18, front + 0.028]}
        fontSize={0.09}
        color="#eaf2f8"
        anchorX="center"
        anchorY="middle"
        maxWidth={width * 0.86}
      >
        {machine.label}
      </Text>
    </group>
  )
}
