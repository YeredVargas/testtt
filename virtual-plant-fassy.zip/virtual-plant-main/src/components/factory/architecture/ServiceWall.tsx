import type { ServiceWallConfig } from '../../../types/architecture'

interface ServiceWallProps {
  wall: ServiceWallConfig
}

export function ServiceWall({ wall }: ServiceWallProps) {
  const [width, height, depth] = wall.size
  const pipeY = height - 0.6
  const serviceFaceZ = depth / 2 + 0.08

  return (
    <group position={wall.position}>
      <mesh receiveShadow position={[0, 0, 0]}>
        <boxGeometry args={wall.size} />
        <meshStandardMaterial color={wall.color} roughness={0.92} metalness={0.02} />
      </mesh>

      <mesh position={[0, 0.02, depth / 2 + 0.006]}>
        <boxGeometry args={[width - 0.24, 0.06, 0.01]} />
        <meshStandardMaterial color="#d6d9db" roughness={0.88} metalness={0.04} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, pipeY, serviceFaceZ]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.07, 0.07, width - 0.9, 18]} />
        <meshStandardMaterial color="#a7b0b7" roughness={0.46} metalness={0.42} />
      </mesh>

      {[-width * 0.28, 0, width * 0.28].map((x) => (
        <mesh key={`drop-pipe-${x}`} castShadow receiveShadow position={[x, pipeY - 0.62, serviceFaceZ]}>
          <cylinderGeometry args={[0.034, 0.034, 1.24, 14]} />
          <meshStandardMaterial color="#b7c0c8" roughness={0.44} metalness={0.48} />
        </mesh>
      ))}

      {[-width * 0.22, width * 0.22].map((x) => (
        <group key={`ac-${x}`} position={[x, height * 0.19, serviceFaceZ + 0.01]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[1.24, 0.5, 0.34]} />
            <meshStandardMaterial color="#dfe4e7" roughness={0.82} metalness={0.04} />
          </mesh>
          <mesh position={[0, 0, 0.18]}>
            <boxGeometry args={[1.0, 0.22, 0.02]} />
            <meshStandardMaterial color="#a6afb7" roughness={0.54} metalness={0.24} />
          </mesh>
          {[-0.3, -0.1, 0.1, 0.3].map((ventX) => (
            <mesh key={ventX} position={[ventX, 0, 0.19]}>
              <boxGeometry args={[0.08, 0.18, 0.01]} />
              <meshStandardMaterial color="#7f8891" roughness={0.54} metalness={0.18} />
            </mesh>
          ))}
        </group>
      ))}

      {[-width * 0.34, width * 0.34].map((x) => (
        <group key={`humidifier-${x}`} position={[x, -height * 0.08, serviceFaceZ + 0.02]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[0.54, 0.72, 0.26]} />
            <meshStandardMaterial color="#cad4db" roughness={0.76} metalness={0.08} />
          </mesh>
          <mesh position={[0, 0.2, 0.14]}>
            <boxGeometry args={[0.36, 0.26, 0.02]} />
            <meshStandardMaterial color="#94a3b8" roughness={0.42} metalness={0.26} />
          </mesh>
          <mesh position={[0, -0.22, 0.14]}>
            <cylinderGeometry args={[0.055, 0.055, 0.03, 14]} />
            <meshStandardMaterial color="#60a5fa" emissive="#93c5fd" emissiveIntensity={0.28} />
          </mesh>
        </group>
      ))}
    </group>
  )
}
