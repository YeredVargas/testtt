import type { ColumnMountedDisplayConfig } from '../../../types/architecture'
import { IndustrialScreen } from '../../IndustrialScreen'

interface ColumnMountedDisplayProps {
  display: ColumnMountedDisplayConfig
}

export function ColumnMountedDisplay({ display }: ColumnMountedDisplayProps) {
  return (
    <group position={display.position} rotation={display.rotation}>
      <mesh castShadow receiveShadow position={[0, 0, -display.depth / 2 + 0.01]}>
        <boxGeometry args={[0.24, 0.24, 0.06]} />
        <meshStandardMaterial color="#7b838b" roughness={0.52} metalness={0.34} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0, -display.depth / 2 + 0.045]}>
        <boxGeometry args={[0.68, 0.18, 0.05]} />
        <meshStandardMaterial color="#666f77" roughness={0.54} metalness={0.3} />
      </mesh>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[display.width, display.height, display.depth]} />
        <meshStandardMaterial color="#12161c" roughness={0.32} metalness={0.2} />
      </mesh>
      <mesh position={[0, 0, display.depth / 2 - 0.018]}>
        <boxGeometry args={[display.width - 0.08, display.height - 0.08, 0.014]} />
        <meshStandardMaterial color="#050505" roughness={0.18} metalness={0.08} />
      </mesh>
      <group position={[0, 0, display.depth / 2 - 0.008]}>
        <IndustrialScreen media={display.media} width={display.width - 0.12} height={display.height - 0.12} />
      </group>
    </group>
  )
}
