import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineControlPanel, MachineLabel, TowerLight } from './CommonParts'

interface ReflowOvenProps {
  equipment: SmtEquipmentConfig
}

export function ReflowOven({ equipment }: ReflowOvenProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.025

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#8d9499" roughness={0.6} metalness={0.22} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.93, 0]}>
        <boxGeometry args={[width, 1.3, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.68} metalness={0.08} />
      </mesh>
      {Array.from({ length: 5 }).map((_, index) => {
        const offsetX = -width * 0.36 + index * (width * 0.18)

        return (
          <group key={offsetX} position={[offsetX, 1.69, 0]}>
            <mesh castShadow receiveShadow>
              <boxGeometry args={[width * 0.16, 0.28, depth * 0.8]} />
              <meshStandardMaterial color="#d5dadb" roughness={0.66} metalness={0.08} />
            </mesh>
            <mesh position={[0, 0.18, 0]}>
              <boxGeometry args={[width * 0.11, 0.1, depth * 0.62]} />
              <meshStandardMaterial color="#c4cbd0" roughness={0.62} metalness={0.12} />
            </mesh>
          </group>
        )
      })}
      {Array.from({ length: 7 }).map((_, index) => {
        const offsetX = -width * 0.42 + index * (width * 0.14)

        return (
          <mesh key={offsetX} receiveShadow position={[offsetX, 1.18, front + 0.005]}>
            <boxGeometry args={[width * 0.08, 0.82, 0.04]} />
            <meshStandardMaterial color="#d9dde0" roughness={0.84} metalness={0.04} />
          </mesh>
        )
      })}
      {Array.from({ length: 5 }).map((_, index) => {
        const offsetX = -width * 0.35 + index * (width * 0.175)

        return (
          <mesh key={`vent-${offsetX}`} position={[offsetX, 1.52, -depth * 0.2]}>
            <boxGeometry args={[width * 0.08, 0.04, depth * 0.48]} />
            <meshStandardMaterial color="#9ca3a8" roughness={0.44} metalness={0.54} />
          </mesh>
        )
      })}
      <ConveyorChannel width={width * 0.97} depth={depth} />
      <MachineControlPanel position={[-width * 0.44, 0, depth / 2 + 0.24]} rotation={[0, 0, 0.12]} standHeight={0.84} />
      {equipment.showTowerLight ? <TowerLight position={[-width * 0.43, height - 0.02, depth * 0.3]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.46, front + 0.05]} />
    </group>
  )
}
