import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineControlPanel, MachineLabel, TowerLight } from './CommonParts'

interface PickAndPlaceMachineProps {
  equipment: SmtEquipmentConfig
  moduleIndex: number
}

export function PickAndPlaceMachine({
  equipment,
  moduleIndex,
}: PickAndPlaceMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.025
  const hoodDepth = moduleIndex % 2 === 0 ? depth * 0.7 : depth * 0.64
  const towerX = moduleIndex % 2 === 0 ? width * 0.34 : -width * 0.34

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.15, 0]}>
        <boxGeometry args={[width, 0.3, depth]} />
        <meshStandardMaterial color="#30343a" roughness={0.74} metalness={0.16} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.04, 0]}>
        <boxGeometry args={[width, 1.48, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.7, 0]}>
        <boxGeometry args={[width * 0.78, 0.24, hoodDepth]} />
        <meshStandardMaterial color="#d6dbdc" roughness={0.7} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.16, front]}>
        <boxGeometry args={[width * 0.62, 0.78, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.18} metalness={0.18} />
      </mesh>
      <mesh receiveShadow position={[0, 0.9, front + 0.005]}>
        <boxGeometry args={[width * 0.92, 0.12, 0.04]} />
        <meshStandardMaterial color={equipment.accentColor ?? '#c92828'} roughness={0.44} metalness={0.18} />
      </mesh>
      <mesh receiveShadow position={[width * 0.27, 0.58, front]}>
        <boxGeometry args={[width * 0.18, 0.96, 0.04]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.86} metalness={0.04} />
      </mesh>
      <ConveyorChannel width={width * 0.96} depth={depth} />
      {Array.from({ length: 8 }).map((_, index) => {
        const offsetX = -width * 0.35 + index * ((width * 0.7) / 7)
        const offsetY = 0.42 + (index % 2) * 0.035

        return (
          <mesh key={offsetX} castShadow receiveShadow position={[offsetX, offsetY, front + 0.13]} rotation={[-0.2, 0, 0]}>
            <boxGeometry args={[0.13, 0.09, 0.2]} />
            <meshStandardMaterial color="#858c92" roughness={0.5} metalness={0.48} />
          </mesh>
        )
      })}
      {moduleIndex % 3 === 0 ? (
        <MachineControlPanel position={[width * 0.46, 0, depth / 2 + 0.18]} rotation={[0, 0, 0.12]} standHeight={0.74} />
      ) : null}
      {equipment.showTowerLight ? <TowerLight position={[towerX, height - 0.04, depth * 0.22]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.84, front + 0.05]} />
    </group>
  )
}
