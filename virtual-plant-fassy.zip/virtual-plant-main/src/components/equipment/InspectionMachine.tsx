import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineControlPanel, MachineLabel, TowerLight } from './CommonParts'

interface InspectionMachineProps {
  equipment: SmtEquipmentConfig
}

export function InspectionMachine({ equipment }: InspectionMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.025
  const isSpi = equipment.type === 'spi'

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width * 0.9, 0.24, depth * 0.92]} />
        <meshStandardMaterial color="#30343a" roughness={0.72} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.48, 0]}>
        <boxGeometry args={[width, height * 0.88, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.7} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.78, front]}>
        <boxGeometry args={[width * 0.54, height * 0.42, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.22} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, height * 0.97, 0]}>
        <boxGeometry args={[width * 0.78, 0.18, depth * 0.78]} />
        <meshStandardMaterial color={isSpi ? '#d8dde0' : '#d1d6d8'} roughness={0.68} metalness={0.08} />
      </mesh>
      <mesh receiveShadow position={[-width * 0.22, 0.6, front]}>
        <boxGeometry args={[width * 0.2, 0.72, 0.04]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.84} metalness={0.04} />
      </mesh>
      <mesh receiveShadow position={[width * 0.18, 0.6, front]}>
        <boxGeometry args={[width * 0.26, 0.72, 0.04]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.84} metalness={0.04} />
      </mesh>
      <ConveyorChannel width={width * 0.92} depth={depth} />
      <MachineControlPanel position={[width * 0.42, 0, depth / 2 + 0.24]} rotation={[0, 0, 0.16]} standHeight={0.8} />
      {equipment.showTowerLight ? <TowerLight position={[width * 0.26, height - 0.02, depth * 0.24]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.52, front + 0.05]} />
    </group>
  )
}
