import { Text } from '@react-three/drei'
import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineLabel, TowerLight } from './CommonParts'

interface ICTInlineMachineProps {
  equipment: SmtEquipmentConfig
}

export function ICTInlineMachine({ equipment }: ICTInlineMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.025

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#30343a" roughness={0.74} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.05, 0]}>
        <boxGeometry args={[width, 1.62, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.03, 1.15, front]}>
        <boxGeometry args={[width * 0.56, 0.92, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.2} metalness={0.18} />
      </mesh>
      <mesh position={[-0.22, 1.12, front - 0.03]}>
        <boxGeometry args={[0.22, 0.26, 0.12]} />
        <meshStandardMaterial color="#1f2937" roughness={0.42} metalness={0.3} />
      </mesh>
      <mesh position={[0.22, 1.12, front - 0.03]}>
        <boxGeometry args={[0.22, 0.26, 0.12]} />
        <meshStandardMaterial color="#1f2937" roughness={0.42} metalness={0.3} />
      </mesh>
      <mesh position={[-width * 0.3, 1.02, front + 0.005]}>
        <boxGeometry args={[0.16, 1.08, 0.04]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.86} metalness={0.04} />
      </mesh>
      <mesh position={[-width * 0.3, 1.46, front + 0.03]}>
        <sphereGeometry args={[0.06, 16, 16]} />
        <meshStandardMaterial color="#dc2626" emissive="#dc2626" emissiveIntensity={0.45} />
      </mesh>
      {[-0.16, 0.16].map((offsetX) => (
        <mesh key={offsetX} position={[offsetX, 0.64, front + 0.005]}>
          <boxGeometry args={[0.18, 0.86, 0.04]} />
          <meshStandardMaterial color="#d7dbde" roughness={0.86} metalness={0.04} />
        </mesh>
      ))}
      <ConveyorChannel width={width * 0.94} depth={depth} />
      <mesh castShadow receiveShadow position={[width * 0.5, 1.38, 0]}>
        <boxGeometry args={[0.12, 0.12, 0.48]} />
        <meshStandardMaterial color="#7f8790" roughness={0.5} metalness={0.54} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.68, 1.52, 0]}>
        <boxGeometry args={[0.46, 0.04, 0.16]} />
        <meshStandardMaterial color="#7f8790" roughness={0.5} metalness={0.54} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.89, 1.52, 0]}>
        <boxGeometry args={[0.08, 0.08, 0.18]} />
        <meshStandardMaterial color="#7f8790" roughness={0.5} metalness={0.54} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 1.03, 1.52, 0]}>
        <boxGeometry args={[0.54, 0.32, 0.05]} />
        <meshStandardMaterial color="#0f172a" roughness={0.32} metalness={0.18} />
      </mesh>
      <mesh position={[width * 1.03, 1.52, 0.031]}>
        <boxGeometry args={[0.48, 0.24, 0.01]} />
        <meshStandardMaterial color="#0b5f9a" emissive="#0f7ea3" emissiveIntensity={0.35} />
      </mesh>
      <mesh castShadow receiveShadow position={[width * 0.97, 1.22, 0.05]}>
        <boxGeometry args={[0.42, 0.03, 0.22]} />
        <meshStandardMaterial color="#8d9499" roughness={0.56} metalness={0.45} />
      </mesh>
      {equipment.showTowerLight ? <TowerLight position={[width * 0.34, height - 0.02, depth * 0.22]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.82, front + 0.05]} />
      <Text position={[0, 0.56, front + 0.05]} fontSize={0.1} color="#1d4ed8" anchorX="center" anchorY="middle">
        IN-CIRCUIT TEST
      </Text>
    </group>
  )
}
