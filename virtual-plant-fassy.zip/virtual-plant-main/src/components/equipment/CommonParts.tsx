import { Text } from '@react-three/drei'
import { CONVEYOR_HEIGHT } from '../../data/smtLine'

interface TowerLightProps {
  position: [number, number, number]
}

export function TowerLight({ position }: TowerLightProps) {
  return (
    <group position={position}>
      <mesh position={[0, 0.18, 0]}>
        <cylinderGeometry args={[0.035, 0.04, 0.36, 10]} />
        <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
      </mesh>
      {[
        { color: '#22c55e', y: 0.4 },
        { color: '#f59e0b', y: 0.5 },
        { color: '#ef4444', y: 0.6 },
      ].map((light) => (
        <mesh key={light.color} position={[0, light.y, 0]}>
          <cylinderGeometry args={[0.055, 0.055, 0.075, 14]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.36} />
        </mesh>
      ))}
    </group>
  )
}

interface MachineLabelProps {
  label: string
  width: number
  position: [number, number, number]
}

export function MachineLabel({ label, width, position }: MachineLabelProps) {
  return (
    <group position={position}>
      <mesh>
        <boxGeometry args={[Math.min(width * 0.66, 2.5), 0.28, 0.03]} />
        <meshStandardMaterial color="#d9dde0" roughness={0.8} metalness={0.08} />
      </mesh>
      <Text
        position={[0, 0, 0.021]}
        fontSize={0.15}
        color="#101317"
        anchorX="center"
        anchorY="middle"
        maxWidth={Math.min(width * 0.58, 2.2)}
      >
        {label}
      </Text>
    </group>
  )
}

interface MachineControlPanelProps {
  position: [number, number, number]
  rotation?: [number, number, number]
  standHeight?: number
}

export function MachineControlPanel({
  position,
  rotation = [0, 0, 0],
  standHeight = 0.85,
}: MachineControlPanelProps) {
  return (
    <group position={position} rotation={rotation}>
      <mesh castShadow receiveShadow position={[0, standHeight / 2, 0]}>
        <boxGeometry args={[0.08, standHeight, 0.08]} />
        <meshStandardMaterial color="#8d9499" roughness={0.52} metalness={0.55} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, standHeight + 0.2, 0]}>
        <boxGeometry args={[0.3, 0.42, 0.08]} />
        <meshStandardMaterial color="#1b2430" roughness={0.38} metalness={0.25} />
      </mesh>
      <mesh position={[0, standHeight + 0.21, 0.043]}>
        <boxGeometry args={[0.22, 0.26, 0.01]} />
        <meshStandardMaterial color="#062c40" emissive="#0f7ea3" emissiveIntensity={0.34} />
      </mesh>
    </group>
  )
}

interface ConveyorChannelProps {
  width: number
  depth: number
}

export function ConveyorChannel({ width, depth }: ConveyorChannelProps) {
  return (
    <group position={[0, CONVEYOR_HEIGHT, 0]}>
      <mesh receiveShadow>
        <boxGeometry args={[width, 0.05, depth * 0.4]} />
        <meshStandardMaterial color="#858c92" roughness={0.48} metalness={0.42} />
      </mesh>
      <mesh receiveShadow position={[0, 0.04, depth * 0.24]}>
        <boxGeometry args={[width, 0.04, 0.05]} />
        <meshStandardMaterial color="#30343a" roughness={0.72} metalness={0.18} />
      </mesh>
      <mesh receiveShadow position={[0, 0.04, -depth * 0.24]}>
        <boxGeometry args={[width, 0.04, 0.05]} />
        <meshStandardMaterial color="#30343a" roughness={0.72} metalness={0.18} />
      </mesh>
    </group>
  )
}
