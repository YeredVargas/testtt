import { Text } from '@react-three/drei'
import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineControlPanel, MachineLabel, TowerLight } from './CommonParts'

interface RouterMachineProps {
  equipment: SmtEquipmentConfig
}

export function RouterMachine({ equipment }: RouterMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.025

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#30343a" roughness={0.74} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.06, 0]}>
        <boxGeometry args={[width, 1.64, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.18, front]}>
        <boxGeometry args={[width * 0.58, 0.96, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.2} metalness={0.18} />
      </mesh>
      <mesh position={[0, 1.0, front - 0.08]}>
        <boxGeometry args={[width * 0.44, 0.08, 0.2]} />
        <meshStandardMaterial color="#6b7280" roughness={0.52} metalness={0.44} />
      </mesh>
      <mesh position={[0.05, 1.18, front - 0.11]}>
        <boxGeometry args={[0.12, 0.42, 0.12]} />
        <meshStandardMaterial color="#8d9499" roughness={0.48} metalness={0.5} />
      </mesh>
      <mesh position={[0.05, 0.92, front - 0.11]}>
        <cylinderGeometry args={[0.03, 0.03, 0.16, 14]} />
        <meshStandardMaterial color="#cfd2d3" roughness={0.34} metalness={0.52} />
      </mesh>
      <mesh position={[-0.04, 0.9, front - 0.18]}>
        <boxGeometry args={[0.34, 0.02, 0.24]} />
        <meshStandardMaterial color="#1f6b44" roughness={0.58} metalness={0.08} />
      </mesh>
      <ConveyorChannel width={width * 0.94} depth={depth} />
      <mesh castShadow receiveShadow position={[0.38, 2.03, 0]}>
        <boxGeometry args={[0.26, 0.22, 0.32]} />
        <meshStandardMaterial color="#c5ccd1" roughness={0.54} metalness={0.28} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.38, 2.18, -0.22]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 0.36, 14]} />
        <meshStandardMaterial color="#8d9499" roughness={0.44} metalness={0.56} />
      </mesh>
      <MachineControlPanel position={[width * 0.45, 0, depth / 2 + 0.22]} rotation={[0, 0, 0.15]} standHeight={0.8} />
      {equipment.showTowerLight ? <TowerLight position={[width * 0.32, height - 0.02, depth * 0.22]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.86, front + 0.05]} />
      <Text position={[0, 0.56, front + 0.05]} fontSize={0.1} color="#0f766e" anchorX="center" anchorY="middle">
        PCB DEPANELING
      </Text>
    </group>
  )
}
