import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineControlPanel, MachineLabel, TowerLight } from './CommonParts'

interface SolderPastePrinterProps {
  equipment: SmtEquipmentConfig
}

export function SolderPastePrinter({ equipment }: SolderPastePrinterProps) {
  const [width, , depth] = equipment.size
  const front = depth / 2 + 0.025

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#30343a" roughness={0.72} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.05, 0]}>
        <boxGeometry args={[width, 1.54, depth]} />
        <meshStandardMaterial color="#cfd2d3" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0.18, 1.84, 0]}>
        <boxGeometry args={[width * 0.68, 0.28, depth * 0.74]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.7} metalness={0.06} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.2, front]}>
        <boxGeometry args={[width * 0.6, 0.72, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.2} metalness={0.18} />
      </mesh>
      {[-0.95, 0, 0.95].map((offsetX) => (
        <mesh key={offsetX} receiveShadow position={[offsetX, 0.64, front]}>
          <boxGeometry args={[0.78, 0.82, 0.04]} />
          <meshStandardMaterial color="#dfe2e4" roughness={0.8} metalness={0.06} />
        </mesh>
      ))}
      <mesh receiveShadow position={[-0.98, 1.75, front + 0.01]}>
        <boxGeometry args={[0.46, 0.18, 0.03]} />
        <meshStandardMaterial color="#062c40" emissive="#0b4f6d" emissiveIntensity={0.26} />
      </mesh>
      <ConveyorChannel width={width * 0.94} depth={depth} />
      <MachineControlPanel position={[width * 0.45, 0, depth / 2 + 0.28]} rotation={[0, 0, 0.18]} />
      {equipment.showTowerLight ? <TowerLight position={[width * 0.38, 1.86, depth * 0.28]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.6, front + 0.05]} />
    </group>
  )
}
