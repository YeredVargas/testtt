import { Text } from '@react-three/drei'
import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineControlPanel, MachineLabel, TowerLight } from './CommonParts'

interface LaserMachineProps {
  equipment: SmtEquipmentConfig
}

export function LaserMachine({ equipment }: LaserMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.025

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#30343a" roughness={0.74} metalness={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 1.0, 0]}>
        <boxGeometry args={[width, 1.42, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.72} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 1.18, front]}>
        <boxGeometry args={[width * 0.56, 0.7, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.2} metalness={0.16} />
      </mesh>

      <mesh receiveShadow position={[-width * 0.24, 1.0, front + 0.005]}>
        <boxGeometry args={[width * 0.14, 0.96, 0.04]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.86} metalness={0.04} />
      </mesh>

      <mesh receiveShadow position={[0, 1.54, front + 0.005]}>
        <boxGeometry args={[width * 0.44, 0.1, 0.04]} />
        <meshStandardMaterial color={equipment.accentColor ?? '#0ea5e9'} roughness={0.42} metalness={0.18} />
      </mesh>

      <ConveyorChannel width={width * 0.94} depth={depth} />

      <mesh position={[0, 1.15, 0]}>
        <boxGeometry args={[width * 0.26, 0.26, depth * 0.3]} />
        <meshStandardMaterial color="#0f172a" roughness={0.3} metalness={0.18} />
      </mesh>
      <mesh position={[0, 1.15, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.05, 0.05, depth * 0.2, 12]} />
        <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.42} />
      </mesh>

      <MachineControlPanel position={[width * 0.43, 0, depth / 2 + 0.24]} rotation={[0, 0, 0.18]} standHeight={0.78} />
      {equipment.showTowerLight ? <TowerLight position={[width * 0.34, height - 0.05, depth * 0.22]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.58, front + 0.05]} />

      <Text
        position={[0, 0.62, front + 0.05]}
        fontSize={0.11}
        color="#0f7ea3"
        anchorX="center"
        anchorY="middle"
      >
        LASER MARKING
      </Text>
    </group>
  )
}
