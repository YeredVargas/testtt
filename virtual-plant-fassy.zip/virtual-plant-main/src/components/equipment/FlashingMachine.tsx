import { Text } from '@react-three/drei'
import type { SmtEquipmentConfig } from '../../types/factory'
import { ConveyorChannel, MachineControlPanel, MachineLabel, TowerLight } from './CommonParts'

interface FlashingMachineProps {
  equipment: SmtEquipmentConfig
}

export function FlashingMachine({ equipment }: FlashingMachineProps) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.025

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.14, 0]}>
        <boxGeometry args={[width, 0.28, depth]} />
        <meshStandardMaterial color="#30343a" roughness={0.74} metalness={0.18} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.98, 0]}>
        <boxGeometry args={[width, 1.42, depth]} />
        <meshStandardMaterial color="#e8e9e7" roughness={0.72} metalness={0.08} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.12, front]}>
        <boxGeometry args={[width * 0.6, 0.72, 0.05]} />
        <meshStandardMaterial color="#101317" roughness={0.2} metalness={0.18} />
      </mesh>
      {[-0.28, -0.09, 0.1, 0.29].map((offsetX, index) => (
        <mesh key={offsetX} position={[offsetX, 1.06 + (index % 2) * 0.04, front - 0.03]}>
          <boxGeometry args={[0.1, 0.22, 0.08]} />
          <meshStandardMaterial color={index % 2 === 0 ? '#0f7ea3' : '#22c55e'} emissive={index % 2 === 0 ? '#0f7ea3' : '#22c55e'} emissiveIntensity={0.36} />
        </mesh>
      ))}
      <mesh receiveShadow position={[-width * 0.3, 0.68, front]}>
        <boxGeometry args={[width * 0.18, 0.8, 0.04]} />
        <meshStandardMaterial color="#d7dbde" roughness={0.86} metalness={0.04} />
      </mesh>
      <ConveyorChannel width={width * 0.94} depth={depth} />
      <MachineControlPanel position={[width * 0.43, 0, depth / 2 + 0.22]} rotation={[0, 0, 0.18]} standHeight={0.76} />
      {equipment.showTowerLight ? <TowerLight position={[width * 0.34, height - 0.04, depth * 0.22]} /> : null}
      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.58, front + 0.05]} />
      <Text position={[0, 0.56, front + 0.05]} fontSize={0.1} color="#0f7ea3" anchorX="center" anchorY="middle">
        PROGRAMMING
      </Text>
    </group>
  )
}
