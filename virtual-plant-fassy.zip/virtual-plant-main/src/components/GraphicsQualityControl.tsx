import type { GraphicsQuality } from '../types/factory'

interface GraphicsQualityControlProps {
  quality: GraphicsQuality
  onChange: (quality: GraphicsQuality) => void
  visible: boolean
}

const OPTIONS: Array<{ value: GraphicsQuality; label: string }> = [
  { value: 'low', label: 'Baja' },
  { value: 'medium', label: 'Media' },
  { value: 'high', label: 'Alta' },
]

export function GraphicsQualityControl({ quality, onChange, visible }: GraphicsQualityControlProps) {
  if (!visible) {
    return null
  }

  return (
    <section className="graphics-quality-control" aria-label="Calidad grafica">
      <span className="graphics-quality-label">Calidad</span>
      <div className="graphics-quality-buttons">
        {OPTIONS.map((option) => (
          <button
            key={option.value}
            type="button"
            className={`graphics-quality-button${quality === option.value ? ' is-active' : ''}`}
            onClick={() => onChange(option.value)}
          >
            {option.label}
          </button>
        ))}
      </div>
    </section>
  )
}
