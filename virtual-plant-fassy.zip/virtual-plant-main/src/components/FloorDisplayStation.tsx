import { Text } from '@react-three/drei'
import { IndustrialScreen } from './IndustrialScreen'
import type { FloorDisplayStationConfig, MediaModalData } from '../types/factory'

function getMediaType(source: string): 'image' | 'gif' | 'video' {
  const extension = source.split('?')[0].toLowerCase().split('.').pop()

  if (extension === 'gif') {
    return 'gif'
  }

  if (extension === 'mp4' || extension === 'webm') {
    return 'video'
  }

  return 'image'
}

interface FloorDisplayStationProps {
  station: FloorDisplayStationConfig
  onSelect?: (media: MediaModalData) => void
  interactive?: boolean
}

export function FloorDisplayStation({ station, onSelect, interactive = true }: FloorDisplayStationProps) {
  const screenWidth = station.width ?? 1.15
  const screenHeight = station.height ?? 0.65
  const screenCenterY = 1.68
  const baseTopY = 0.08
  const screenBottomY = screenCenterY - screenHeight / 2
  const postHeight = screenBottomY - baseTopY
  const postCenterY = baseTopY + postHeight / 2
  const postZ = -0.14
  const housingBackZ = -0.055
  const armZ = -0.1
  const frameZ = 0
  const screenBackgroundZ = 0.021
  const screenFrontZ = 0.031
  const interactionZ = 0.04
  const mediaSource = station.media.source
  const mediaType = getMediaType(mediaSource)

  return (
    <group position={station.position} rotation={station.rotation}>
      <mesh receiveShadow position={[0, 0.04, 0]}>
        <boxGeometry args={[0.48, 0.08, 0.38]} />
        <meshStandardMaterial color="#50555d" roughness={0.68} metalness={0.24} />
      </mesh>

      <mesh position={[0, postCenterY, postZ]} renderOrder={1}>
        <cylinderGeometry args={[0.05, 0.06, postHeight, 14]} />
        <meshStandardMaterial color="#9ca3a8" roughness={0.46} metalness={0.62} />
      </mesh>

      <mesh position={[0, screenBottomY + 0.08, armZ]} renderOrder={1}>
        <boxGeometry args={[0.12, 0.12, 0.12]} />
        <meshStandardMaterial color="#737b82" roughness={0.52} metalness={0.44} />
      </mesh>

      <mesh position={[0, screenCenterY, housingBackZ]} renderOrder={1}>
        <boxGeometry args={[screenWidth + 0.12, screenHeight + 0.12, 0.06]} />
        <meshStandardMaterial color="#1f2937" roughness={0.56} metalness={0.26} />
      </mesh>

      <mesh position={[0, screenCenterY, frameZ]} renderOrder={2}>
        <boxGeometry args={[screenWidth + 0.16, screenHeight + 0.16, 0.08]} />
        <meshStandardMaterial color="#111111" roughness={0.42} metalness={0.28} />
      </mesh>

      <mesh position={[0, screenCenterY, screenBackgroundZ]} renderOrder={2}>
        <boxGeometry args={[screenWidth + 0.04, screenHeight + 0.04, 0.02]} />
        <meshStandardMaterial color="#050505" roughness={0.24} metalness={0.18} />
      </mesh>

      <group position={[0, screenCenterY, screenFrontZ]}>
        <IndustrialScreen media={station.media} width={screenWidth} height={screenHeight} />
      </group>

      {interactive ? (
        <mesh
          position={[0, screenCenterY, interactionZ]}
          onClick={() => {
            onSelect?.({
              id: station.id,
              title: station.title,
              source: mediaSource,
              mediaType,
            })
          }}
          userData={{
            interactive: true,
            interactionType: 'media-display',
            displayId: station.id,
            title: station.title,
            mediaSource,
            mediaType,
            promptText: station.promptText,
          }}
        >
          <planeGeometry args={[screenWidth, screenHeight]} />
          <meshBasicMaterial transparent opacity={0} depthWrite={false} colorWrite={false} />
        </mesh>
      ) : null}

      <mesh position={[0, 1.07, 0.015]} renderOrder={2}>
        <boxGeometry args={[Math.min(screenWidth * 0.72, 0.96), 0.17, 0.025]} />
        <meshStandardMaterial color="#1f2937" roughness={0.58} metalness={0.18} />
      </mesh>

      <Text
        position={[0, 1.07, 0.031]}
        fontSize={0.1}
        color="#f8fafc"
        anchorX="center"
        anchorY="middle"
        maxWidth={Math.min(screenWidth * 0.62, 0.84)}
      >
        {station.title}
      </Text>
    </group>
  )
}
