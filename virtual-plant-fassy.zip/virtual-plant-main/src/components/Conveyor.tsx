import { CONVEYOR_HEIGHT } from '../data/smtLine'
import type { SmtEquipmentConfig } from '../types/factory'

interface ConveyorProps {
  equipment: SmtEquipmentConfig
}

export function Conveyor({ equipment }: ConveyorProps) {
  const [length, , depth] = equipment.size
  const rollerCount = Math.max(5, Math.round(length * 2.2))
  const supportHeight = CONVEYOR_HEIGHT - 0.1
  const supportCenterY = supportHeight / 2

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, CONVEYOR_HEIGHT - 0.07, 0]}>
        <boxGeometry args={[length, 0.06, depth * 0.42]} />
        <meshStandardMaterial color="#858c92" metalness={0.42} roughness={0.46} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, CONVEYOR_HEIGHT - 0.02, depth * 0.23]}>
        <boxGeometry args={[length, 0.05, 0.05]} />
        <meshStandardMaterial color="#30343a" metalness={0.18} roughness={0.76} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, CONVEYOR_HEIGHT - 0.02, -depth * 0.23]}>
        <boxGeometry args={[length, 0.05, 0.05]} />
        <meshStandardMaterial color="#30343a" metalness={0.18} roughness={0.76} />
      </mesh>

      {Array.from({ length: rollerCount }).map((_, index) => {
        const offsetX = -length / 2 + (length * (index + 0.5)) / rollerCount

        return (
          <mesh key={offsetX} castShadow position={[offsetX, CONVEYOR_HEIGHT - 0.03, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.045, 0.045, depth * 0.62, 14]} />
            <meshStandardMaterial color="#d7dbde" metalness={0.32} roughness={0.36} />
          </mesh>
        )
      })}

      {[-length / 2 + 0.22, length / 2 - 0.22].map((offsetX) => (
        <group key={offsetX} position={[offsetX, 0, 0]}>
          {[-0.18, 0.18].map((offsetZ) => (
            <mesh key={offsetZ} castShadow receiveShadow position={[0, supportCenterY, offsetZ]}>
              <boxGeometry args={[0.08, supportHeight, 0.08]} />
              <meshStandardMaterial color="#6b7280" metalness={0.18} roughness={0.74} />
            </mesh>
          ))}
        </group>
      ))}

      <mesh receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[length * 0.7, 0.06, depth * 0.18]} />
        <meshStandardMaterial color="#5c646d" roughness={0.68} metalness={0.22} />
      </mesh>
    </group>
  )
}
