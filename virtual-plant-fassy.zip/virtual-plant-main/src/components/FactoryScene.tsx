import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { memo, Suspense, useEffect, useRef } from 'react'
import { PCFShadowMap, Raycaster, Vector2, type Object3D } from 'three'
import type {
  CameraDebugState,
  GraphicsQuality,
  MediaModalData,
  SceneControllerApi,
} from '../types/factory'
import { GRAPHICS_QUALITY_SETTINGS } from '../graphicsQuality'
import { sceneCollisionBoxes } from '../data/smtLine'
import { fassyCollisionBoxes, plantWalkableBounds } from '../data/fassyLine'
import { backendDisplayCollisionBoxes } from '../data/backendDisplayStations'
import { backendSupportTableCollisionBoxes } from '../data/backendSupportTables'
import { backendStandaloneCollisionBoxes } from '../data/backendStandaloneEquipment'
import { conformalLineLayout } from '../data/conformalLine'
import { glueProcessCellLayout } from '../data/glueProcessCell'
import { informationCenterCollisionBoxes } from '../data/informationCenter'
import { ictBackendCellLayout } from '../data/ictBackendCell'
import { routerProcessCellLayout } from '../data/routerProcessCell'
import { solderPasteSupportCollisionBoxes } from '../data/solderPasteSupportArea'
import { factoryArchitecture } from '../data/factoryArchitecture'
import { xrayInspectionCellLayouts } from '../data/xrayInspectionCell'
import { BackendArea } from './backend/BackendArea'
import { FactoryArchitecture } from './factory/architecture/FactoryArchitecture'
import { FactoryFloor } from './FactoryFloor'
import { FassyLine } from './FassyLine'
import { FirstPersonController } from './FirstPersonController'
import { InformationCenter } from './InformationCenter'
import { SmtLine } from './SmtLine'

const DEBUG_SCENE = false
const ENABLE_PERFORMANCE_DEBUG = false
const MAX_INTERACTION_DISTANCE = 4
const sceneBlockers = [
  ...sceneCollisionBoxes,
  ...factoryArchitecture.collisionBoxes,
  ...solderPasteSupportCollisionBoxes,
  ...backendStandaloneCollisionBoxes,
  ...conformalLineLayout.collisionBoxes,
  ...glueProcessCellLayout.collisionBoxes,
  ...ictBackendCellLayout.collisionBoxes,
  ...routerProcessCellLayout.collisionBoxes,
  ...backendDisplayCollisionBoxes,
  ...backendSupportTableCollisionBoxes,
  ...informationCenterCollisionBoxes,
  ...xrayInspectionCellLayouts.flatMap((layout) => layout.collisionBoxes),
  ...fassyCollisionBoxes,
]

interface FactorySceneProps {
  modalOpen: boolean
  graphicsQuality: GraphicsQuality
  onPointerLockChange: (isLocked: boolean) => void
  onCameraDebugChange?: (debug: CameraDebugState) => void
  onControllerReady: (controller: SceneControllerApi) => void
  onOpenMedia: (media: MediaModalData) => void
  onPromptChange: (prompt: string | null) => void
}

function SceneDiagnostics() {
  if (!DEBUG_SCENE) {
    return null
  }

  return (
    <group>
      <mesh position={[0, 1.7, 0]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshBasicMaterial color="red" />
      </mesh>
      <gridHelper args={[50, 50, '#555555', '#999999']} />
      <axesHelper args={[5]} />
    </group>
  )
}

interface DisplayInteractionControllerProps {
  modalOpen: boolean
  onPromptChange: (prompt: string | null) => void
  onOpenMedia: (media: MediaModalData) => void
}

function PerformanceSampler({ quality }: { quality: GraphicsQuality }) {
  const { camera, gl } = useThree()
  const lastSampleTimeRef = useRef(0)
  const frameCounterRef = useRef(0)
  const averageBufferRef = useRef<number[]>([])

  useFrame((state) => {
    const now = state.clock.elapsedTime
    frameCounterRef.current += 1

    if (now - lastSampleTimeRef.current < 0.333) {
      return
    }

    const elapsed = Math.max(now - lastSampleTimeRef.current, 0.001)
    const fps = frameCounterRef.current / elapsed
    const averageBuffer = averageBufferRef.current
    averageBuffer.push(fps)

    if (averageBuffer.length > 12) {
      averageBuffer.shift()
    }

    const averageFps = averageBuffer.reduce((sum, value) => sum + value, 0) / averageBuffer.length
    const glInfo = gl.info
    ;(window as Window & { __SMT_PERF_SNAPSHOT?: unknown }).__SMT_PERF_SNAPSHOT = {
      fps,
      averageFps,
      frameTimeMs: 1000 / Math.max(fps, 0.001),
      drawCalls: glInfo.render.calls,
      triangles: glInfo.render.triangles,
      geometries: glInfo.memory.geometries,
      textures: glInfo.memory.textures,
      programs: gl.info.programs?.length ?? null,
      cameraPosition: [camera.position.x, camera.position.y, camera.position.z],
      quality,
    }

    frameCounterRef.current = 0
    lastSampleTimeRef.current = now
  })

  return null
}

function DisplayInteractionController({
  modalOpen,
  onPromptChange,
  onOpenMedia,
}: DisplayInteractionControllerProps) {
  const { camera, scene } = useThree()
  const raycasterRef = useRef(new Raycaster())
  const centerRef = useRef(new Vector2(0, 0))
  const activeMediaRef = useRef<MediaModalData | null>(null)
  const lockedRef = useRef(false)
  const promptRef = useRef<string | null>(null)
  const debugLocked =
    import.meta.env.DEV &&
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('debugLock') === '1'
  const interactiveObjectsRef = useRef<Set<Object3D>>(new Set())
  const interactiveObjectsArrayRef = useRef<Object3D[]>([])

  const updatePrompt = (nextPrompt: string | null) => {
    if (promptRef.current === nextPrompt) {
      return
    }

    promptRef.current = nextPrompt
    onPromptChange(nextPrompt)
  }

  useEffect(() => {
    const interactiveObjects = interactiveObjectsRef.current
    interactiveObjects.clear()
    scene.traverse((object) => {
      if (object.userData?.interactive === true) {
        interactiveObjects.add(object)
      }
    })
    interactiveObjectsArrayRef.current = Array.from(interactiveObjects)
    ;(window as Window & { __SMT_INTERACTIVE_COUNT?: number }).__SMT_INTERACTIVE_COUNT =
      interactiveObjectsArrayRef.current.length

    return () => {
      interactiveObjects.clear()
      interactiveObjectsArrayRef.current = []
    }
  }, [scene])

  useEffect(() => {
    const handlePointerLockChange = () => {
      lockedRef.current = debugLocked || document.pointerLockElement instanceof Element
    }

    handlePointerLockChange()
    document.addEventListener('pointerlockchange', handlePointerLockChange)

    return () => {
      document.removeEventListener('pointerlockchange', handlePointerLockChange)
    }
  }, [])

  useEffect(() => {
    if (!modalOpen) {
      return undefined
    }

    updatePrompt(null)
    activeMediaRef.current = null

    return undefined
  }, [modalOpen, onPromptChange])

  useEffect(() => {
    const interact = () => {
      if (!lockedRef.current || modalOpen || !activeMediaRef.current) {
        return
      }

      onOpenMedia(activeMediaRef.current)
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.code === 'KeyE' && !event.repeat) {
        interact()
      }
    }

    const handleMouseDown = (event: MouseEvent) => {
      if (event.button === 0) {
        interact()
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    window.addEventListener('mousedown', handleMouseDown)

    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      window.removeEventListener('mousedown', handleMouseDown)
    }
  }, [modalOpen, onOpenMedia])

  useFrame(() => {
    if (modalOpen || !lockedRef.current) {
      if (activeMediaRef.current) {
        activeMediaRef.current = null
      }

      updatePrompt(null)
      return
    }

    const raycaster = raycasterRef.current
    raycaster.far = MAX_INTERACTION_DISTANCE
    raycaster.setFromCamera(centerRef.current, camera)

    const hit = raycaster
      .intersectObjects(interactiveObjectsArrayRef.current, true)
      .find((intersection) => intersection.distance <= MAX_INTERACTION_DISTANCE)

    if (!hit) {
      activeMediaRef.current = null
      updatePrompt(null)
      return
    }

    const userData = hit.object.userData
    activeMediaRef.current = {
      id: userData.displayId as string,
      title: userData.title as string,
      source: userData.mediaSource as string,
      mediaType: userData.mediaType as MediaModalData['mediaType'],
    }
    updatePrompt((userData.promptText as string | undefined) ?? `E - Ver ${userData.title as string}`)
  })

  return null
}

export const FactoryScene = memo(function FactoryScene({
  modalOpen,
  graphicsQuality,
  onPointerLockChange,
  onCameraDebugChange,
  onControllerReady,
  onOpenMedia,
  onPromptChange,
}: FactorySceneProps) {
  const performanceDebugEnabled =
    typeof window !== 'undefined' &&
    (new URLSearchParams(window.location.search).get('perfDebug') === '1' || ENABLE_PERFORMANCE_DEBUG)
  const graphicsSettings = GRAPHICS_QUALITY_SETTINGS[graphicsQuality]

  return (
    <div className="scene-canvas">
      <Canvas
        onCreated={({ camera, gl, scene }) => {
          ;(
            window as Window & {
              __SMT_CAMERA?: unknown
              __SMT_GL?: unknown
              __SMT_SCENE?: unknown
            }
          ).__SMT_CAMERA = camera
          ;(
            window as Window & {
              __SMT_CAMERA?: unknown
              __SMT_GL?: unknown
              __SMT_SCENE?: unknown
            }
          ).__SMT_GL = gl
          ;(
            window as Window & {
              __SMT_CAMERA?: unknown
              __SMT_GL?: unknown
              __SMT_SCENE?: unknown
            }
          ).__SMT_SCENE = scene
        }}
        gl={{ antialias: graphicsSettings.antialias, alpha: false, stencil: false, powerPreference: 'high-performance' }}
        shadows={graphicsSettings.shadowsEnabled ? { type: PCFShadowMap } : false}
        dpr={graphicsSettings.dpr}
        camera={{ position: [-25, 1.7, 8.6], fov: 65, near: 0.1, far: 260 }}
      >
        <color attach="background" args={['#cfd9df']} />
        <fog attach="fog" args={['#d4dde2', 36, 110]} />

        <hemisphereLight intensity={1.1} color="#eef6fb" groundColor="#b6c0c6" />
        <ambientLight intensity={0.52} />
        <directionalLight
          castShadow={graphicsSettings.shadowsEnabled}
          intensity={1.18}
          position={[-10, 18, 16]}
          shadow-mapSize-width={graphicsSettings.shadowMapSize}
          shadow-mapSize-height={graphicsSettings.shadowMapSize}
          shadow-camera-near={1}
          shadow-camera-far={140}
          shadow-camera-left={-52}
          shadow-camera-right={52}
          shadow-camera-top={28}
          shadow-camera-bottom={-28}
        />
        <directionalLight intensity={0.32} position={[20, 8, -8]} />

        <Suspense fallback={null}>
          <SceneDiagnostics />
          <FactoryFloor />
          <FactoryArchitecture />
          <SmtLine onOpenMedia={onOpenMedia} />
          <InformationCenter onOpenMedia={onOpenMedia} />
          <BackendArea onOpenMedia={onOpenMedia} />
          <FassyLine onOpenMedia={onOpenMedia} />
          {performanceDebugEnabled ? <PerformanceSampler quality={graphicsQuality} /> : null}
          <DisplayInteractionController
            modalOpen={modalOpen}
            onPromptChange={onPromptChange}
            onOpenMedia={onOpenMedia}
          />
          <FirstPersonController
            bounds={plantWalkableBounds}
            blockers={sceneBlockers}
            movementEnabled={!modalOpen}
            onLockChange={onPointerLockChange}
            onDebugChange={onCameraDebugChange}
            onControllerReady={onControllerReady}
          />
        </Suspense>
      </Canvas>
    </div>
  )
})
