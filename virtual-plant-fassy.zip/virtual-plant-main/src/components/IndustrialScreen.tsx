import { Html } from '@react-three/drei'
import { memo, useEffect, useMemo, useState } from 'react'
import {
  DoubleSide,
  LinearFilter,
  SRGBColorSpace,
  Texture,
  TextureLoader,
  VideoTexture,
} from 'three'
import type { DisplayMedia } from '../types/factory'

interface IndustrialScreenProps {
  media: DisplayMedia
  width: number
  height: number
}

type ResolvedKind = 'image' | 'gif' | 'video'

const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp']
const VIDEO_EXTENSIONS = ['mp4', 'webm']
const textureLoader = new TextureLoader()
const textureCache = new Map<string, Texture>()

function getExtension(source: string) {
  const cleanSource = source.split('?')[0].toLowerCase()
  const extension = cleanSource.split('.').pop()

  return extension ?? ''
}

function getMediaKind(media: DisplayMedia, source: string): ResolvedKind {
  if (media.type === 'video') {
    return 'video'
  }

  const extension = getExtension(source)

  if (extension === 'gif') {
    return 'gif'
  }

  if (VIDEO_EXTENSIONS.includes(extension)) {
    return 'video'
  }

  if (IMAGE_EXTENSIONS.includes(extension)) {
    return 'image'
  }

  return 'image'
}

function IndustrialScreenComponent({ media, width, height }: IndustrialScreenProps) {
  const [texture, setTexture] = useState<Texture | null>(null)
  const [currentSource, setCurrentSource] = useState(media.source)
  const [imageFailed, setImageFailed] = useState(false)
  const fit = media.fit ?? 'cover'
  const fallbackSource = media.fallback
  const mediaSource = media.source
  const videoLoop = media.type === 'video' ? media.loop ?? true : true
  const videoMuted = media.type === 'video' ? media.muted ?? true : true
  const videoAutoplay = media.type === 'video' ? media.autoplay ?? true : true
  const mediaKind = useMemo(() => getMediaKind(media, currentSource), [currentSource, mediaSource, media.type])

  useEffect(() => {
    setCurrentSource(mediaSource)
    setImageFailed(false)
  }, [mediaSource, fallbackSource])

  useEffect(() => {
    if (mediaKind !== 'video') {
      return undefined
    }

    let disposed = false
    let video: HTMLVideoElement | null = document.createElement('video')
    let videoTexture: VideoTexture | null = null

    const handleFallback = () => {
      if (fallbackSource && currentSource !== fallbackSource) {
        setCurrentSource(fallbackSource)
        return
      }

      setTexture(null)
    }

    video.src = currentSource
    video.crossOrigin = 'anonymous'
    video.loop = videoLoop
    video.muted = videoMuted
    video.autoplay = videoAutoplay
    video.playsInline = true

    const onLoadedData = () => {
      if (!video || disposed) {
        return
      }

      void video.play().catch(() => undefined)

      videoTexture = new VideoTexture(video)
      videoTexture.colorSpace = SRGBColorSpace
      videoTexture.minFilter = LinearFilter
      videoTexture.magFilter = LinearFilter

      setTexture(videoTexture)
    }

    const onError = () => handleFallback()

    video.addEventListener('loadeddata', onLoadedData)
    video.addEventListener('error', onError)
    video.load()

    return () => {
      disposed = true
      video?.pause()
      video?.removeEventListener('loadeddata', onLoadedData)
      video?.removeEventListener('error', onError)
      if (video) {
        video.src = ''
      }
      setTexture((currentTexture) => (currentTexture === videoTexture ? null : currentTexture))
      videoTexture?.dispose()
      video = null
    }
  }, [currentSource, fallbackSource, media.type, mediaKind, videoAutoplay, videoLoop, videoMuted])

  useEffect(() => {
    if (mediaKind !== 'image') {
      return undefined
    }

    let disposed = false

    const cachedTexture = textureCache.get(currentSource)

    if (cachedTexture) {
      setTexture(cachedTexture)
      setImageFailed(false)
      return undefined
    }

    textureLoader.load(
      currentSource,
      (nextTexture) => {
        if (disposed) {
          nextTexture.dispose()
          return
        }

        nextTexture.colorSpace = SRGBColorSpace
        nextTexture.minFilter = LinearFilter
        nextTexture.magFilter = LinearFilter
        textureCache.set(currentSource, nextTexture)
        setImageFailed(false)
        setTexture(nextTexture)
      },
      undefined,
      () => {
        if (fallbackSource && currentSource !== fallbackSource) {
          setCurrentSource(fallbackSource)
          return
        }

        setImageFailed(true)
        setTexture(null)
      },
    )

    return () => {
      disposed = true
    }
  }, [currentSource, fallbackSource, mediaKind])

  useEffect(() => {
    if (mediaKind === 'video' || mediaKind === 'image') {
      return undefined
    }

    const image = new Image()
    image.onload = () => {
      setImageFailed(false)
    }
    image.onerror = () => {
      if (fallbackSource && currentSource !== fallbackSource) {
        setCurrentSource(fallbackSource)
        return
      }

      setImageFailed(true)
    }
    image.src = currentSource

    return () => {
      image.onload = null
      image.onerror = null
    }
  }, [currentSource, fallbackSource, mediaKind])

  if ((mediaKind === 'video' || mediaKind === 'image') && texture) {
    return (
      <mesh position={[0, 0, 0]} renderOrder={3}>
        <planeGeometry args={[width, height]} />
        <meshBasicMaterial
          map={texture}
          toneMapped={false}
          color="#ffffff"
          transparent={false}
          opacity={1}
          side={DoubleSide}
          depthWrite
          depthTest
        />
      </mesh>
    )
  }

  if (mediaKind === 'gif') {
    return (
      <Html
        transform
        occlude
        pointerEvents="none"
        position={[0, 0, 0]}
        style={{ pointerEvents: 'none' }}
      >
        <div
          style={{
            width: `${Math.round(width * 260)}px`,
            height: `${Math.round(height * 260)}px`,
            background: '#020617',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '4px',
          }}
        >
          {imageFailed ? (
            <div
              style={{
                color: '#e2e8f0',
                fontFamily: 'Inter, Segoe UI, sans-serif',
                fontSize: '12px',
                textAlign: 'center',
                padding: '12px',
              }}
            >
              MEDIA NOT FOUND
            </div>
          ) : (
            <img
              src={currentSource}
              alt="display media"
              onError={() => {
                if (fallbackSource && currentSource !== fallbackSource) {
                  setCurrentSource(fallbackSource)
                  return
                }

                setImageFailed(true)
              }}
              style={{
                width: '100%',
                height: '100%',
                objectFit: fit,
                display: 'block',
                background: '#020617',
              }}
            />
          )}
        </div>
      </Html>
    )
  }

  return (
    <mesh position={[0, 0, 0]} renderOrder={3}>
      <planeGeometry args={[width, height]} />
      <meshBasicMaterial color="#050505" toneMapped={false} side={DoubleSide} depthWrite depthTest />
    </mesh>
  )
}

export const IndustrialScreen = memo(
  IndustrialScreenComponent,
  (previous, next) =>
    previous.width === next.width &&
    previous.height === next.height &&
    previous.media.source === next.media.source &&
    previous.media.fallback === next.media.fallback &&
    previous.media.fit === next.media.fit &&
    previous.media.type === next.media.type &&
    (previous.media.type !== 'video' || next.media.type !== 'video'
      ? true
      : previous.media.loop === next.media.loop &&
        previous.media.muted === next.media.muted &&
        previous.media.autoplay === next.media.autoplay),
)
