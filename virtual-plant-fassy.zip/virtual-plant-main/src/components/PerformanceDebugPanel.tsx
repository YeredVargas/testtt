import { useEffect, useState } from 'react'

export interface PerformanceSnapshot {
  fps: number
  averageFps: number
  frameTimeMs: number
  drawCalls: number
  triangles: number
  geometries: number
  textures: number
  programs: number | null
  cameraPosition: [number, number, number]
  quality: string
}

interface PerformanceDebugPanelProps {
  enabled: boolean
}

const INITIAL_SNAPSHOT: PerformanceSnapshot = {
  fps: 0,
  averageFps: 0,
  frameTimeMs: 0,
  drawCalls: 0,
  triangles: 0,
  geometries: 0,
  textures: 0,
  programs: null,
  cameraPosition: [0, 0, 0],
  quality: 'unknown',
}

export function PerformanceDebugPanel({ enabled }: PerformanceDebugPanelProps) {
  const [snapshot, setSnapshot] = useState<PerformanceSnapshot>(INITIAL_SNAPSHOT)

  useEffect(() => {
    if (!enabled || typeof window === 'undefined') {
      return undefined
    }

    const update = () => {
      const nextSnapshot = (window as Window & { __SMT_PERF_SNAPSHOT?: PerformanceSnapshot }).__SMT_PERF_SNAPSHOT

      if (nextSnapshot) {
        setSnapshot(nextSnapshot)
      }
    }

    update()
    const intervalId = window.setInterval(update, 333)

    return () => {
      window.clearInterval(intervalId)
    }
  }, [enabled])

  if (!enabled) {
    return null
  }

  return (
    <aside className="performance-debug-panel" aria-live="polite">
      <div>FPS: {snapshot.fps.toFixed(1)}</div>
      <div>AVG FPS: {snapshot.averageFps.toFixed(1)}</div>
      <div>Frame: {snapshot.frameTimeMs.toFixed(1)} ms</div>
      <div>Draw calls: {snapshot.drawCalls}</div>
      <div>Triangles: {snapshot.triangles}</div>
      <div>Geometries: {snapshot.geometries}</div>
      <div>Textures: {snapshot.textures}</div>
      <div>Programs: {snapshot.programs ?? 'n/a'}</div>
      <div>
        Cam: {snapshot.cameraPosition.map((value) => value.toFixed(2)).join(', ')}
      </div>
      <div>Quality: {snapshot.quality}</div>
    </aside>
  )
}
