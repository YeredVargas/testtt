import { FlashingMachine } from './equipment/FlashingMachine'
import { ICTInlineMachine } from './equipment/ICTInlineMachine'
import { InspectionMachine } from './equipment/InspectionMachine'
import { LaserMachine } from './equipment/LaserMachine'
import { PickAndPlaceMachine } from './equipment/PickAndPlaceMachine'
import { ReflowOven } from './equipment/ReflowOven'
import { RouterMachine } from './equipment/RouterMachine'
import { SolderPastePrinter } from './equipment/SolderPastePrinter'
import type { SmtEquipmentConfig } from '../types/factory'

interface IndustrialMachineProps {
  equipment: SmtEquipmentConfig
}

export function IndustrialMachine({ equipment }: IndustrialMachineProps) {
  if (equipment.type === 'laser') {
    return <LaserMachine equipment={equipment} />
  }

  if (equipment.type === 'solder-paste-printer') {
    return <SolderPastePrinter equipment={equipment} />
  }

  if (equipment.type === 'spi' || equipment.type === 'aoi') {
    return <InspectionMachine equipment={equipment} />
  }

  if (equipment.type === 'pick-and-place') {
    const match = equipment.id.match(/(\d+)$/)
    const moduleIndex = match ? Number(match[1]) - 1 : 0

    return <PickAndPlaceMachine equipment={equipment} moduleIndex={moduleIndex} />
  }

  if (equipment.type === 'reflow-oven') {
    return <ReflowOven equipment={equipment} />
  }

  if (equipment.type === 'flashing') {
    return <FlashingMachine equipment={equipment} />
  }

  if (equipment.type === 'ict-inline') {
    return <ICTInlineMachine equipment={equipment} />
  }

  if (equipment.type === 'router') {
    return <RouterMachine equipment={equipment} />
  }

  return null
}
