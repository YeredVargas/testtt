import type { CameraDebugState } from '../types/factory'

interface CameraDebugProps {
  debug: CameraDebugState
}

export function CameraDebug({ debug }: CameraDebugProps) {
  return (
    <aside className="camera-debug" aria-live="polite">
      <strong>{debug.locked ? 'LOCKED' : 'UNLOCKED'}</strong>
      <span>x: {debug.position[0].toFixed(2)}</span>
      <span>y: {debug.position[1].toFixed(2)}</span>
      <span>z: {debug.position[2].toFixed(2)}</span>
      <span>rx: {debug.rotation[0].toFixed(3)}</span>
      <span>ry: {debug.rotation[1].toFixed(3)}</span>
      <span>rz: {debug.rotation[2].toFixed(3)}</span>
    </aside>
  )
}
