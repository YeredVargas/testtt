import { useFrame } from '@react-three/fiber'
import { memo, useMemo, useRef } from 'react'
import { BoxGeometry, Group, MeshStandardMaterial } from 'three'
import { useGraphicsQuality } from '../graphicsQuality'
import { ENABLE_PCB_ANIMATION } from '../data/smtLine'
import type { PcbConfig } from '../types/factory'

interface PcbBoardProps {
  board: PcbConfig
}

const boardGeometry = new BoxGeometry(0.35, 0.02, 0.25)
const chipGeometries = [
  new BoxGeometry(0.06, 0.02, 0.05),
  new BoxGeometry(0.08, 0.02, 0.06),
  new BoxGeometry(0.03, 0.018, 0.04),
]
const boardMaterial = new MeshStandardMaterial({ color: '#1f6b44', roughness: 0.58, metalness: 0.08 })
const chipMaterial = new MeshStandardMaterial({ color: '#d9dde0', roughness: 0.42, metalness: 0.32 })

function PcbBoardComponent({ board }: PcbBoardProps) {
  const groupRef = useRef<Group | null>(null)
  const { pcbAnimationsEnabled } = useGraphicsQuality()
  const chips = useMemo(
    () => [
      {
        position: [-0.08, 0.018, -0.04] as [number, number, number],
        geometry: chipGeometries[0],
      },
      {
        position: [0.03, 0.018, 0.01] as [number, number, number],
        geometry: chipGeometries[1],
      },
      {
        position: [0.1, 0.018, -0.06] as [number, number, number],
        geometry: chipGeometries[2],
      },
    ],
    [],
  )

  useFrame((state) => {
    if (!ENABLE_PCB_ANIMATION || !pcbAnimationsEnabled || !board.animation || !groupRef.current) {
      return
    }

    const { startX, endX, speed } = board.animation
    const span = endX - startX
    const loop = ((state.clock.elapsedTime * speed) % span + span) % span
    groupRef.current.position.x = startX + loop
  })

  return (
    <group ref={groupRef} position={board.position} rotation={board.rotation}>
      <mesh>
        <primitive object={boardGeometry} attach="geometry" />
        <primitive object={boardMaterial} attach="material" />
      </mesh>
      {chips.map((chip) => (
        <mesh key={chip.position.join('-')} position={chip.position}>
          <primitive object={chip.geometry} attach="geometry" />
          <primitive object={chipMaterial} attach="material" />
        </mesh>
      ))}
    </group>
  )
}

export const PcbBoard = memo(PcbBoardComponent)
