import { pickAndPlaceMaterialArea } from '../data/smtMaterialAreas'
import { MaterialRack } from './backend/MaterialRack'

export function SmtMaterialArea() {
  return (
    <group position={pickAndPlaceMaterialArea.position} rotation={pickAndPlaceMaterialArea.rotation}>
      {pickAndPlaceMaterialArea.racks.map((rack) => (
        <MaterialRack key={rack.id} rack={rack} />
      ))}
    </group>
  )
}
