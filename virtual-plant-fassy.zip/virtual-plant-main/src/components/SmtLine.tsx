import { memo } from 'react'
import { displayStations, pcbBoards, smtEquipment } from '../data/smtLine'
import { Conveyor } from './Conveyor'
import { FloorDisplayStation } from './FloorDisplayStation'
import { IndustrialMachine } from './IndustrialMachine'
import { PcbBoard } from './PcbBoard'
import { SolderPasteSupportArea } from './SolderPasteSupportArea'
import { SmtMaterialArea } from './SmtMaterialArea'
import type { MediaModalData } from '../types/factory'

interface SmtLineProps {
  onOpenMedia?: (media: MediaModalData) => void
}

export const SmtLine = memo(function SmtLine({ onOpenMedia }: SmtLineProps) {
  return (
    <group>
      {smtEquipment.map((equipment) =>
        equipment.type === 'conveyor' ? (
          <Conveyor key={equipment.id} equipment={equipment} />
        ) : (
          <IndustrialMachine key={equipment.id} equipment={equipment} />
        ),
      )}

      {pcbBoards.map((board) => (
        <PcbBoard key={board.id} board={board} />
      ))}

      {displayStations.map((station) => (
        <FloorDisplayStation key={station.id} station={station} onSelect={onOpenMedia} />
      ))}

      <SmtMaterialArea />
      <SolderPasteSupportArea onOpenMedia={onOpenMedia} />
    </group>
  )
})
