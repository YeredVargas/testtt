import type { SafetyRectangleConfig, SafetySegmentConfig } from '../data/safetyZones'
import { BoxGeometry, MeshStandardMaterial } from 'three'

const DEFAULT_LINE_WIDTH = 0.07
const TAPE_HEIGHT = 0.008
const sharedTapeGeometry = new BoxGeometry(1, 1, 1)
const sharedTapeMaterial = new MeshStandardMaterial({ color: '#f2c500', roughness: 0.88, metalness: 0 })

export function SafetyTapeSegment({
  position,
  length,
  orientation,
  lineWidth = DEFAULT_LINE_WIDTH,
}: SafetySegmentConfig) {
  const size: [number, number, number] =
    orientation === 'horizontal'
      ? [length, TAPE_HEIGHT, lineWidth]
      : [lineWidth, TAPE_HEIGHT, length]

  return (
    <mesh receiveShadow={false} castShadow={false} position={position} scale={size}>
      <primitive object={sharedTapeGeometry} attach="geometry" />
      <primitive object={sharedTapeMaterial} attach="material" />
    </mesh>
  )
}

export function SafetyTapeRectangle({
  center,
  width,
  depth,
  lineWidth = DEFAULT_LINE_WIDTH,
}: SafetyRectangleConfig) {
  return (
    <group position={center}>
      <SafetyTapeSegment
        id="front"
        position={[0, 0, depth / 2]}
        length={width}
        orientation="horizontal"
        lineWidth={lineWidth}
      />
      <SafetyTapeSegment
        id="back"
        position={[0, 0, -depth / 2]}
        length={width}
        orientation="horizontal"
        lineWidth={lineWidth}
      />
      <SafetyTapeSegment
        id="left"
        position={[-width / 2, 0, 0]}
        length={depth}
        orientation="vertical"
        lineWidth={lineWidth}
      />
      <SafetyTapeSegment
        id="right"
        position={[width / 2, 0, 0]}
        length={depth}
        orientation="vertical"
        lineWidth={lineWidth}
      />
    </group>
  )
}
