import { PointerLockControls } from '@react-three/drei'
import { useFrame, useThree } from '@react-three/fiber'
import { useEffect, useRef } from 'react'
import { MathUtils, Vector3, type Vector3Tuple } from 'three'
import type { PointerLockControls as PointerLockControlsImpl } from 'three-stdlib'
import type {
  Bounds2D,
  CameraDebugState,
  CameraSnapshot,
  CollisionBox,
  SceneControllerApi,
} from '../types/factory'

interface FirstPersonControllerProps {
  bounds: Bounds2D
  blockers: CollisionBox[]
  onLockChange: (isLocked: boolean) => void
  onDebugChange?: (debug: CameraDebugState) => void
  movementEnabled?: boolean
  onControllerReady?: (controller: SceneControllerApi) => void
}

const PLAYER_HEIGHT = 1.7
const PLAYER_RADIUS = 0.42
const WALK_SPEED = 3.6
const RUN_SPEED = 6.1
const UP = new Vector3(0, 1, 0)
const DEBUG_LOGS = false

function isBlocked(candidate: Vector3, blockers: CollisionBox[]) {
  return blockers.some(
    (blocker) =>
      candidate.x > blocker.minX - PLAYER_RADIUS &&
      candidate.x < blocker.maxX + PLAYER_RADIUS &&
      candidate.z > blocker.minZ - PLAYER_RADIUS &&
      candidate.z < blocker.maxZ + PLAYER_RADIUS,
  )
}

export function FirstPersonController({
  bounds,
  blockers,
  onLockChange,
  onDebugChange,
  movementEnabled = true,
  onControllerReady,
}: FirstPersonControllerProps) {
  const { camera } = useThree()
  const controlsRef = useRef<PointerLockControlsImpl | null>(null)
  const keysRef = useRef<Record<string, boolean>>({})
  const directionRef = useRef(new Vector3())
  const forwardRef = useRef(new Vector3())
  const rightRef = useRef(new Vector3())
  const candidateRef = useRef(new Vector3())
  const lastDebugUpdateRef = useRef(0)

  const clearMovement = () => {
    keysRef.current = {}
  }

  const saveCameraState = (): CameraSnapshot => ({
    position: [camera.position.x, camera.position.y, camera.position.z],
    quaternion: [camera.quaternion.x, camera.quaternion.y, camera.quaternion.z, camera.quaternion.w],
  })

  const restoreCameraState = (snapshot: CameraSnapshot | null) => {
    if (!snapshot) {
      return
    }

    camera.position.set(...snapshot.position)
    camera.quaternion.set(...snapshot.quaternion)
  }

  const teleportTo = (position: Vector3Tuple, lookAt: Vector3Tuple) => {
    camera.position.set(...position)
    camera.lookAt(...lookAt)
    camera.position.y = PLAYER_HEIGHT
  }

  useEffect(() => {
    if (!onControllerReady) {
      return
    }

    onControllerReady({
      lock: () => controlsRef.current?.lock(),
      unlock: () => controlsRef.current?.unlock(),
      clearMovement,
      saveCameraState,
      restoreCameraState,
      teleportTo,
    })
  }, [onControllerReady])

  useEffect(() => {
    camera.position.set(-22.5, PLAYER_HEIGHT, -3)
    camera.lookAt(-19, 1.3, -8.1)
    onDebugChange?.({
      locked: false,
      position: [camera.position.x, camera.position.y, camera.position.z],
      rotation: [camera.rotation.x, camera.rotation.y, camera.rotation.z],
    })
  }, [camera, onDebugChange])

  useEffect(() => {
    const controls = controlsRef.current

    if (!controls) {
      return undefined
    }

    const handleLock = () => {
      onLockChange(true)

      if (DEBUG_LOGS) {
        console.log('Pointer locked')
        console.log('Camera position:', camera.position.toArray())
        console.log('Camera rotation:', [camera.rotation.x, camera.rotation.y, camera.rotation.z])
      }
    }

    const handleUnlock = () => {
      keysRef.current = {}
      onLockChange(false)
    }

    controls.addEventListener('lock', handleLock)
    controls.addEventListener('unlock', handleUnlock)

    return () => {
      controls.removeEventListener('lock', handleLock)
      controls.removeEventListener('unlock', handleUnlock)
    }
  }, [camera, onLockChange])

  useEffect(() => {
    if (movementEnabled) {
      return
    }

    clearMovement()
  }, [movementEnabled])

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      keysRef.current[event.code] = true
    }

    const handleKeyUp = (event: KeyboardEvent) => {
      keysRef.current[event.code] = false
    }

    window.addEventListener('keydown', handleKeyDown)
    window.addEventListener('keyup', handleKeyUp)

    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      window.removeEventListener('keyup', handleKeyUp)
    }
  }, [])

  useFrame((state, delta) => {
    const controls = controlsRef.current
    const safeDelta = Math.min(delta, 0.05)

    if (!controls?.isLocked || !movementEnabled) {
      camera.position.y = PLAYER_HEIGHT

      if (onDebugChange && state.clock.elapsedTime - lastDebugUpdateRef.current > 0.25) {
        lastDebugUpdateRef.current = state.clock.elapsedTime
        onDebugChange({
          locked: false,
          position: [camera.position.x, camera.position.y, camera.position.z],
          rotation: [camera.rotation.x, camera.rotation.y, camera.rotation.z],
        })
      }

      return
    }

    const forward = Number(keysRef.current.KeyW) - Number(keysRef.current.KeyS)
    const strafe = Number(keysRef.current.KeyD) - Number(keysRef.current.KeyA)

    camera.getWorldDirection(forwardRef.current)
    forwardRef.current.y = 0

    if (forwardRef.current.lengthSq() > 0) {
      forwardRef.current.normalize()
    }

    rightRef.current.crossVectors(forwardRef.current, UP).normalize()
    directionRef.current.set(0, 0, 0)

    if (forward > 0) {
      directionRef.current.add(forwardRef.current)
    }

    if (forward < 0) {
      directionRef.current.sub(forwardRef.current)
    }

    if (strafe > 0) {
      directionRef.current.add(rightRef.current)
    }

    if (strafe < 0) {
      directionRef.current.sub(rightRef.current)
    }

    if (directionRef.current.lengthSq() > 0) {
      const speed = keysRef.current.ShiftLeft || keysRef.current.ShiftRight ? RUN_SPEED : WALK_SPEED
      directionRef.current.normalize().multiplyScalar(speed * safeDelta)

      candidateRef.current.copy(camera.position)
      candidateRef.current.x = MathUtils.clamp(
        candidateRef.current.x + directionRef.current.x,
        bounds.minX,
        bounds.maxX,
      )

      if (!isBlocked(candidateRef.current, blockers)) {
        camera.position.x = candidateRef.current.x
      }

      candidateRef.current.copy(camera.position)
      candidateRef.current.z = MathUtils.clamp(
        candidateRef.current.z + directionRef.current.z,
        bounds.minZ,
        bounds.maxZ,
      )

      if (!isBlocked(candidateRef.current, blockers)) {
        camera.position.z = candidateRef.current.z
      }
    }

    if (onDebugChange && state.clock.elapsedTime - lastDebugUpdateRef.current > 0.25) {
      lastDebugUpdateRef.current = state.clock.elapsedTime
      onDebugChange({
        locked: true,
        position: [camera.position.x, camera.position.y, camera.position.z],
        rotation: [camera.rotation.x, camera.rotation.y, camera.rotation.z],
      })
    }

    camera.position.y = PLAYER_HEIGHT
  })

  return <PointerLockControls ref={controlsRef} selector="#start-tour-button" />
}
