import { useEffect, useMemo, useRef } from 'react'
import type { MediaModalData } from '../types/factory'

interface MediaModalProps {
  data: MediaModalData
  onClose: () => void
  onCloseAndContinue: () => void
}

export function MediaModal({ data, onClose, onCloseAndContinue }: MediaModalProps) {
  const closeButtonRef = useRef<HTMLButtonElement | null>(null)
  const titleId = useMemo(() => `media-modal-title-${data.id}`, [data.id])

  useEffect(() => {
    closeButtonRef.current?.focus()

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        onClose()
      }
    }

    window.addEventListener('keydown', handleKeyDown)

    return () => {
      window.removeEventListener('keydown', handleKeyDown)
    }
  }, [onClose])

  return (
    <div
      className="media-modal-backdrop"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          onClose()
        }
      }}
    >
      <section className="media-modal" role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <button
          ref={closeButtonRef}
          type="button"
          className="media-modal-close"
          aria-label="Cerrar modal"
          onClick={onClose}
        >
          x
        </button>

        <header className="media-modal-header">
          <h2 id={titleId}>{data.title}</h2>
          <p>Presiona ESC para cerrar</p>
        </header>

        <div className="media-modal-body">
          {data.mediaType === 'video' ? (
            <video className="media-modal-image" src={data.source} controls autoPlay loop muted playsInline />
          ) : (
            <img className="media-modal-image" src={data.source} alt={data.title} draggable={false} />
          )}
        </div>

        <footer className="media-modal-actions">
          <button type="button" className="media-modal-secondary" onClick={onClose}>
            Cerrar
          </button>
          <button type="button" className="media-modal-primary" onClick={onCloseAndContinue}>
            Cerrar y continuar recorrido
          </button>
        </footer>
      </section>
    </div>
  )
}
