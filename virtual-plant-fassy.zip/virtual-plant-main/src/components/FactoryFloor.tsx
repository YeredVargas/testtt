import { memo } from 'react'
import { backendOperatorLanes, backendRearStorageZone, backendSafetyZones, backendStationDividers, smtSafetyZones } from '../data/safetyZones'
import { floorSize, lineBounds } from '../data/smtLine'
import { SafetyTapeRectangle, SafetyTapeSegment } from './SafetyTape'

const statusPostPositions: [number, number, number][] = [
  [0, 0, -4.9],
  [lineBounds.maxX - 1.2, 0, -4.9],
]

function StatusPost({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0.45, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 0.9, 12]} />
        <meshStandardMaterial color="#6b7280" metalness={0.35} roughness={0.42} />
      </mesh>
      {['#ef4444', '#f59e0b', '#22c55e'].map((color, index) => (
        <mesh key={color} position={[0, 0.86 + index * 0.16, 0.11]} castShadow>
          <sphereGeometry args={[0.055, 16, 16]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.55} />
        </mesh>
      ))}
    </group>
  )
}

export const FactoryFloor = memo(function FactoryFloor() {
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={floorSize} />
        <meshStandardMaterial color="#d8dde1" roughness={0.96} metalness={0.04} />
      </mesh>

      <gridHelper args={[floorSize[0], floorSize[0], '#c6ced4', '#d3d9de']} position={[0, 0.01, 0]} />

      {Array.from({ length: 10 }).map((_, index) => {
        const offsetX = -54 + index * 12

        return (
          <mesh key={offsetX} receiveShadow position={[offsetX, 0.013, 0]}>
            <boxGeometry args={[0.06, 0.02, floorSize[1] - 1.2]} />
            <meshStandardMaterial color="#c5ccd1" />
          </mesh>
        )
      })}

      {smtSafetyZones.map((zone) => (
        <SafetyTapeRectangle key={zone.id} {...zone} />
      ))}

      {backendSafetyZones.map((zone) => (
        <SafetyTapeRectangle key={zone.id} {...zone} />
      ))}

      {backendOperatorLanes.map((zone) => (
        <SafetyTapeRectangle key={zone.id} {...zone} />
      ))}
      <SafetyTapeRectangle {...backendRearStorageZone} />

      {backendStationDividers.map((segment) => (
        <SafetyTapeSegment key={segment.id} {...segment} />
      ))}

      {statusPostPositions.map((position) => (
        <StatusPost key={position.join('-')} position={position} />
      ))}
    </group>
  )
})
