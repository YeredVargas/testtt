import type { NavigationSection } from '../types/factory'

interface PauseMenuProps {
  sections: NavigationSection[]
  onResume: () => void
  onNavigate: (destinationId: string) => void
}

export function PauseMenu({ sections, onResume, onNavigate }: PauseMenuProps) {
  return (
    <div className="pause-overlay" aria-live="polite">
      <section className="pause-card" aria-label="Menu de pausa">
        <div className="pause-header">
          <div>
            <p className="pause-kicker">Pausa</p>
            <h2>Ir rapido a otra area</h2>
          </div>
          <button type="button" className="pause-resume-button" onClick={onResume}>
            Reanudar recorrido
          </button>
        </div>

        <div className="pause-grid">
          {sections.map((section) => (
            <section key={section.id} className="pause-section">
              <h3>{section.title}</h3>
              <div className="pause-links">
                {section.destinations.map((destination) => (
                  <button
                    key={destination.id}
                    type="button"
                    className="pause-link"
                    onClick={() => onNavigate(destination.id)}
                  >
                    <strong>{destination.label}</strong>
                    <span>{destination.description}</span>
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>

        <p className="pause-help">Presiona ESC nuevamente para continuar el recorrido.</p>
      </section>
    </div>
  )
}
