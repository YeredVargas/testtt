import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import { Group } from 'three'
import {
  FASSY_AISLE_Z,
  FASSY_REAR_WALL_Z,
  fassyRearWall,
  FASSY_ENTRY_X,
  FASSY_LEG_A_Z,
  FASSY_LEG_B_Z,
  fassyDisplays,
  fassyEquipment,
  fassyParts,
  fassyProps,
} from '../data/fassyLine'
import { FloorDisplayStation } from './FloorDisplayStation'
import { FassyMachine } from './fassy/FassyEquipment'
import { FassyProp } from './fassy/FassyProps'
import type { MediaModalData } from '../types/factory'
import type { FassyPartConfig } from '../types/fassy'

interface FassyLineProps {
  onOpenMedia?: (media: MediaModalData) => void
}

/** Housing de aluminio del OBC sobre su pallet portador. */
function ObcHousing({ part }: { part: FassyPartConfig }) {
  const groupRef = useRef<Group | null>(null)

  useFrame((state) => {
    const animation = part.animation

    if (!animation || !groupRef.current) {
      return
    }

    const span = animation.to - animation.from

    if (Math.abs(span) < 0.001) {
      return
    }

    const distance = Math.abs(span)
    const elapsed = state.clock.elapsedTime * animation.speed
    let progress: number

    if (animation.pingPong) {
      const cycle = distance * 2
      const phase = elapsed % cycle
      progress = (phase <= distance ? phase : cycle - phase) / distance
    } else {
      progress = (elapsed % distance) / distance
    }

    const value = animation.from + span * progress

    if (animation.axis === 'x') {
      groupRef.current.position.x = value
    } else if (animation.axis === 'z') {
      groupRef.current.position.z = value
    } else {
      groupRef.current.position.y = value
    }
  })

  return (
    <group ref={groupRef} position={part.position} rotation={part.rotation}>
      <mesh castShadow receiveShadow position={[0, -0.03, 0]}>
        <boxGeometry args={[0.52, 0.05, 0.38]} />
        <meshStandardMaterial color="#111827" roughness={0.85} metalness={0.05} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.09, 0]}>
        <boxGeometry args={[0.44, 0.18, 0.32]} />
        <meshStandardMaterial color="#aab2b8" roughness={0.42} metalness={0.68} />
      </mesh>
      {Array.from({ length: 6 }).map((_, index) => (
        <mesh key={index} position={[-0.18 + index * 0.072, 0.185, 0]} castShadow>
          <boxGeometry args={[0.03, 0.03, 0.28]} />
          <meshStandardMaterial color="#c6ccd1" roughness={0.35} metalness={0.75} />
        </mesh>
      ))}
      <mesh castShadow position={[0.24, 0.09, 0]}>
        <boxGeometry args={[0.06, 0.1, 0.12]} />
        <meshStandardMaterial color="#ea580c" roughness={0.6} metalness={0.1} />
      </mesh>
    </group>
  )
}

/**
 * Senalizacion de piso de la entrada a la celda: pasillo amarillo que llega al
 * elevador y umbral rayado bajo el vano del portico.
 */
function EntranceMarkings() {
  const cellDepth = Math.abs(FASSY_LEG_B_Z - FASSY_LEG_A_Z) + 1.8
  const approachLength = 6.4

  return (
    <group>
      {/* Pasillo de acceso desde el pasillo central hasta el elevador */}
      {[FASSY_AISLE_Z - 1.1, FASSY_AISLE_Z + 1.1].map((z) => (
        <mesh key={`lane-${z}`} receiveShadow position={[FASSY_ENTRY_X + approachLength / 2, 0.017, z]}>
          <boxGeometry args={[approachLength, 0.007, 0.09]} />
          <meshStandardMaterial color="#f2c500" roughness={0.85} />
        </mesh>
      ))}

      {/* Umbral bajo el vano */}
      {[-0.28, 0.28].map((offsetX) => (
        <mesh key={`threshold-${offsetX}`} receiveShadow position={[FASSY_ENTRY_X + offsetX, 0.017, FASSY_AISLE_Z]}>
          <boxGeometry args={[0.09, 0.007, cellDepth - 0.9]} />
          <meshStandardMaterial color="#f2c500" roughness={0.85} />
        </mesh>
      ))}

      {/* Pasillo interior de la celda */}
      <mesh receiveShadow position={[FASSY_ENTRY_X - 20, 0.017, FASSY_AISLE_Z]}>
        <boxGeometry args={[38, 0.007, 0.09]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.9} />
      </mesh>
    </group>
  )
}

/**
 * Linea FASSY completa. Es aditiva sobre la escena existente: se monta al lado
 * de <SmtLine /> y <BackendArea />, dentro del piso y el techo que ya cubren
 * toda la nave.
 */
export function FassyLine({ onOpenMedia }: FassyLineProps) {
  return (
    <group name="fassy-line">
      <EntranceMarkings />

      {/* Muro de fondo de la nave detras de la celda */}
      <mesh
        position={[fassyRearWall.center[0], 2.95, FASSY_REAR_WALL_Z]}
        receiveShadow
      >
        <boxGeometry args={[fassyRearWall.width, 5.9, 0.22]} />
        <meshStandardMaterial color="#e6e4de" roughness={0.94} metalness={0.02} />
      </mesh>
      {/* Zoclo del muro */}
      <mesh position={[fassyRearWall.center[0], 0.09, FASSY_REAR_WALL_Z + 0.12]}>
        <boxGeometry args={[fassyRearWall.width, 0.18, 0.04]} />
        <meshStandardMaterial color="#cfcdc7" roughness={0.9} />
      </mesh>

      {/* Juntas de losa, para que el piso de la celda case con el resto */}
      {Array.from({ length: 5 }).map((_, index) => {
        const offsetX = 30 + index * 12

        return (
          <mesh key={offsetX} receiveShadow position={[offsetX, 0.014, FASSY_AISLE_Z]}>
            <boxGeometry args={[0.06, 0.006, 12]} />
            <meshStandardMaterial color="#c5ccd1" roughness={0.95} />
          </mesh>
        )
      })}

      {fassyEquipment.map((equipment) => (
        <FassyMachine key={equipment.id} equipment={equipment} />
      ))}

      {fassyParts.map((part) => (
        <ObcHousing key={part.id} part={part} />
      ))}

      {fassyProps.map((prop) => (
        <FassyProp key={prop.id} prop={prop} />
      ))}

      {fassyDisplays.map((station) => (
        <FloorDisplayStation key={station.id} station={station} onSelect={onOpenMedia} />
      ))}
    </group>
  )
}
