import { Text } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import { Group } from 'three'
import { factoryArchitecture } from '../../data/factoryArchitecture'
import { CONVEYOR_HEIGHT } from '../../data/smtLine'
import { ConveyorChannel, MachineLabel, TowerLight } from '../equipment/CommonParts'
import type { FassyEquipmentConfig, Vec3 } from '../../types/fassy'

/**
 * Cara inferior del plafon de la nave. Se deriva de `factoryArchitecture` para
 * que los ductos de extraccion lleguen al techo real y no queden colgando.
 */
const CEILING_Y =
  factoryArchitecture.config.ceiling.center[1] - factoryArchitecture.config.ceiling.thickness / 2

/* ------------------------------------------------------------------ *
 * Piezas compartidas por las celdas de FASSY
 * ------------------------------------------------------------------ */

interface CellFrameProps {
  width: number
  height: number
  depth: number
}

/** Bastidor de perfil de aluminio con paneles de policarbonato. */
export function CellFrame({ width, height, depth }: CellFrameProps) {
  const halfWidth = width / 2
  const halfDepth = depth / 2
  const profile = 0.075

  return (
    <group>
      {[-halfWidth + profile, halfWidth - profile].map((x) =>
        [-halfDepth + profile, halfDepth - profile].map((z) => (
          <mesh key={`post-${x}-${z}`} castShadow receiveShadow position={[x, height / 2, z]}>
            <boxGeometry args={[profile * 2, height, profile * 2]} />
            <meshStandardMaterial color="#b9c0c5" roughness={0.38} metalness={0.68} />
          </mesh>
        )),
      )}

      {[0.35, height - 0.08].map((y) => (
        <group key={`rail-${y}`} position={[0, y, 0]}>
          {[halfDepth - profile, -halfDepth + profile].map((z) => (
            <mesh key={`rx-${z}`} castShadow position={[0, 0, z]}>
              <boxGeometry args={[width - profile, profile * 1.6, profile * 1.6]} />
              <meshStandardMaterial color="#b9c0c5" roughness={0.38} metalness={0.68} />
            </mesh>
          ))}
          {[halfWidth - profile, -halfWidth + profile].map((x) => (
            <mesh key={`rz-${x}`} castShadow position={[x, 0, 0]}>
              <boxGeometry args={[profile * 1.6, profile * 1.6, depth - profile]} />
              <meshStandardMaterial color="#b9c0c5" roughness={0.38} metalness={0.68} />
            </mesh>
          ))}
        </group>
      ))}

      <mesh position={[0, height * 0.62, -halfDepth + 0.03]}>
        <planeGeometry args={[width - 0.16, height * 0.66]} />
        <meshPhysicalMaterial color="#dfe8ee" transparent opacity={0.24} roughness={0.12} />
      </mesh>
      {[-halfWidth + 0.03, halfWidth - 0.03].map((x) => (
        <mesh key={`side-${x}`} position={[x, height * 0.62, 0]} rotation={[0, Math.PI / 2, 0]}>
          <planeGeometry args={[depth - 0.16, height * 0.66]} />
          <meshPhysicalMaterial color="#dfe8ee" transparent opacity={0.22} roughness={0.12} />
        </mesh>
      ))}

      <group position={[0, height * 0.62, halfDepth - 0.02]}>
        {[-width * 0.24, width * 0.24].map((x) => (
          <group key={`door-${x}`} position={[x, 0, 0]}>
            <mesh>
              <planeGeometry args={[width * 0.44, height * 0.62]} />
              <meshPhysicalMaterial color="#e8f0f5" transparent opacity={0.3} roughness={0.1} />
            </mesh>
            <mesh castShadow position={[x > 0 ? -width * 0.2 : width * 0.2, 0, 0.02]}>
              <boxGeometry args={[0.05, 0.24, 0.05]} />
              <meshStandardMaterial color="#3f4650" roughness={0.5} metalness={0.4} />
            </mesh>
          </group>
        ))}
      </group>
    </group>
  )
}

interface ControlCabinetProps {
  width: number
  depth: number
  y: number
}

/** Gabinete de control sobre la celda, con rejillas, paro E1 e indicadores. */
export function ControlCabinet({ width, depth, y }: ControlCabinetProps) {
  const cabinetWidth = Math.min(width * 0.86, 1.7)
  const cabinetHeight = 0.72

  return (
    <group position={[0, y + cabinetHeight / 2, 0]}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[cabinetWidth, cabinetHeight, depth * 0.62]} />
        <meshStandardMaterial color="#c9ced2" roughness={0.62} metalness={0.24} />
      </mesh>

      {[-cabinetWidth * 0.3, cabinetWidth * 0.3].map((x) => (
        <mesh key={`vent-${x}`} position={[x, 0.02, depth * 0.311]}>
          <planeGeometry args={[cabinetWidth * 0.24, cabinetHeight * 0.5]} />
          <meshStandardMaterial color="#9aa2a8" roughness={0.7} metalness={0.3} />
        </mesh>
      ))}

      <mesh position={[0, 0.12, depth * 0.312]}>
        <planeGeometry args={[cabinetWidth * 0.2, 0.22]} />
        <meshStandardMaterial color="#f4f6f7" roughness={0.9} />
      </mesh>

      <group position={[cabinetWidth * 0.42, -0.16, depth * 0.315]} rotation={[Math.PI / 2, 0, 0]}>
        <mesh>
          <cylinderGeometry args={[0.075, 0.075, 0.02, 16]} />
          <meshStandardMaterial color="#facc15" roughness={0.6} />
        </mesh>
        <mesh position={[0, 0.025, 0]}>
          <cylinderGeometry args={[0.045, 0.045, 0.035, 16]} />
          <meshStandardMaterial color="#dc2626" roughness={0.45} />
        </mesh>
      </group>

      {[
        { color: '#22c55e', x: -cabinetWidth * 0.44 },
        { color: '#ef4444', x: -cabinetWidth * 0.44 + 0.11 },
      ].map((light) => (
        <mesh key={light.color} position={[light.x, 0.22, depth * 0.315]}>
          <sphereGeometry args={[0.032, 12, 12]} />
          <meshStandardMaterial color={light.color} emissive={light.color} emissiveIntensity={0.7} />
        </mesh>
      ))}
    </group>
  )
}

/** Ducto flexible de extraccion hacia el plenum del techo. */
export function ExtractionDuct({ fromY, position = [0, 0, 0] }: { fromY: number; position?: Vec3 }) {
  const length = Math.max(CEILING_Y - fromY, 0.4)

  return (
    <group position={position}>
      <mesh castShadow position={[0, fromY + length / 2, 0]}>
        <cylinderGeometry args={[0.11, 0.11, length, 12, 1, true]} />
        <meshStandardMaterial color="#b7bec4" roughness={0.42} metalness={0.72} />
      </mesh>
      <mesh position={[0, fromY + 0.08, 0]}>
        <cylinderGeometry args={[0.15, 0.15, 0.12, 12]} />
        <meshStandardMaterial color="#8d9499" roughness={0.5} metalness={0.6} />
      </mesh>
    </group>
  )
}

/** Hoja plastificada de instruccion de trabajo. */
export function InstructionSheet({ position, width = 0.34, height = 0.48 }: { position: Vec3; width?: number; height?: number }) {
  return (
    <group position={position}>
      <mesh>
        <planeGeometry args={[width, height]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.86} />
      </mesh>
      {Array.from({ length: 4 }).map((_, index) => (
        <mesh key={index} position={[0, height * 0.32 - index * height * 0.21, 0.002]}>
          <planeGeometry args={[width * 0.76, height * 0.12]} />
          <meshStandardMaterial color="#cbd5e1" roughness={0.9} />
        </mesh>
      ))}
    </group>
  )
}

export function HmiScreen({ position, width = 0.36, height = 0.26 }: { position: Vec3; width?: number; height?: number }) {
  return (
    <group position={position}>
      <mesh castShadow>
        <boxGeometry args={[width + 0.05, height + 0.05, 0.04]} />
        <meshStandardMaterial color="#20262e" roughness={0.4} metalness={0.3} />
      </mesh>
      <mesh position={[0, 0, 0.023]}>
        <planeGeometry args={[width, height]} />
        <meshStandardMaterial color="#062c40" emissive="#0f7ea3" emissiveIntensity={0.5} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Piezas comunes de estacion, tomadas de las fotos de piso
 * ------------------------------------------------------------------ */

/**
 * Portico superior de estacion: viga blanca con la placa azul de identificacion
 * ("ST. 010", "ST. 060", ...) al centro y la torreta roja/ambar/verde arriba a
 * la izquierda. Es la firma visual mas reconocible de la linea.
 */
export function StationPortal({
  width,
  depth,
  tag,
  showTowerLight = true,
}: {
  width: number
  depth: number
  tag: string
  showTowerLight?: boolean
}) {
  const beamY = 2.12
  const beamZ = -depth * 0.05
  const postZ = -depth * 0.32

  return (
    <group>
      {[-(width / 2 - 0.08), width / 2 - 0.08].map((x) => (
        <mesh key={`portal-post-${x}`} castShadow receiveShadow position={[x, beamY / 2, postZ]}>
          <boxGeometry args={[0.12, beamY, 0.12]} />
          <meshStandardMaterial color="#e8eaec" roughness={0.6} metalness={0.2} />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0, beamY, beamZ]}>
        <boxGeometry args={[width + 0.16, 0.2, 0.32]} />
        <meshStandardMaterial color="#eef0f1" roughness={0.62} metalness={0.16} />
      </mesh>
      {/* Perfil oscuro inferior de la viga */}
      <mesh position={[0, beamY - 0.11, beamZ]}>
        <boxGeometry args={[width + 0.14, 0.04, 0.3]} />
        <meshStandardMaterial color="#2c3138" roughness={0.6} metalness={0.2} />
      </mesh>

      {/* Placa azul de identificacion */}
      <mesh position={[0, beamY, beamZ + 0.17]}>
        <boxGeometry args={[0.56, 0.14, 0.02]} />
        <meshStandardMaterial color="#1e4c8a" roughness={0.5} metalness={0.15} />
      </mesh>
      <Text
        position={[0, beamY, beamZ + 0.182]}
        fontSize={0.085}
        color="#f8fafc"
        anchorX="center"
        anchorY="middle"
      >
        {tag}
      </Text>

      {showTowerLight ? <TowerLight position={[-width * 0.36, beamY + 0.1, beamZ]} /> : null}
    </group>
  )
}

/**
 * Eje vertical de servo con columna verde anodizada, corredera y cadena
 * portacables negra, como los de atornillado y pick & place.
 */
export function GreenAxis({ children }: { children?: React.ReactNode }) {
  return (
    <group>
      <mesh castShadow position={[0, 0.42, -0.05]}>
        <boxGeometry args={[0.13, 0.86, 0.13]} />
        <meshStandardMaterial color="#2f7d32" roughness={0.5} metalness={0.32} />
      </mesh>
      <mesh castShadow position={[0, 0.42, 0.06]}>
        <boxGeometry args={[0.09, 0.8, 0.05]} />
        <meshStandardMaterial color="#d6dade" roughness={0.34} metalness={0.6} />
      </mesh>
      {Array.from({ length: 7 }).map((_, index) => (
        <mesh key={index} castShadow position={[0.13, 0.78 - index * 0.1, -0.05]}>
          <boxGeometry args={[0.07, 0.07, 0.1]} />
          <meshStandardMaterial color="#15171a" roughness={0.8} metalness={0.05} />
        </mesh>
      ))}
      {children}
    </group>
  )
}

/** Monitor HMI sobre brazo negro articulado, a un costado de la estacion. */
export function HmiArm({
  position,
  mirrored = false,
  ok = false,
}: {
  position: Vec3
  mirrored?: boolean
  ok?: boolean
}) {
  const side = mirrored ? -1 : 1

  return (
    <group position={position}>
      <mesh castShadow position={[side * 0.14, 0, 0]}>
        <boxGeometry args={[0.28, 0.05, 0.05]} />
        <meshStandardMaterial color="#15171a" roughness={0.7} metalness={0.15} />
      </mesh>
      <mesh castShadow position={[side * 0.3, -0.02, 0.1]} rotation={[0, side * 0.5, 0]}>
        <boxGeometry args={[0.24, 0.05, 0.05]} />
        <meshStandardMaterial color="#15171a" roughness={0.7} metalness={0.15} />
      </mesh>
      <group position={[side * 0.42, 0.02, 0.2]} rotation={[0, side * 0.55, 0]}>
        <mesh castShadow>
          <boxGeometry args={[0.44, 0.34, 0.04]} />
          <meshStandardMaterial color="#16181c" roughness={0.45} metalness={0.2} />
        </mesh>
        <mesh position={[0, 0, 0.024]}>
          <planeGeometry args={[0.4, 0.29]} />
          <meshStandardMaterial
            color={ok ? '#eef6ff' : '#e8eef5'}
            emissive={ok ? '#bfe3c4' : '#9fc4e6'}
            emissiveIntensity={0.55}
          />
        </mesh>
        {ok ? (
          <mesh position={[0, -0.01, 0.028]} rotation={[0, 0, Math.PI / 4]}>
            <boxGeometry args={[0.06, 0.16, 0.005]} />
            <meshStandardMaterial color="#16a34a" emissive="#16a34a" emissiveIntensity={0.5} />
          </mesh>
        ) : null}
      </group>
    </group>
  )
}

/** Escuadras amarillas de posicion en el piso, para carros y contenedores. */
export function FloorCorners({ position, size }: { position: Vec3; size: [number, number] }) {
  const [width, depth] = size

  return (
    <group position={position}>
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => (
          <group key={`corner-${sx}-${sz}`} position={[(sx * width) / 2, 0, (sz * depth) / 2]}>
            <mesh receiveShadow position={[(-sx * 0.16), 0, 0]}>
              <boxGeometry args={[0.32, 0.016, 0.075]} />
              <meshStandardMaterial color="#f2c500" roughness={0.85} />
            </mesh>
            <mesh receiveShadow position={[0, 0, -sz * 0.16]}>
              <boxGeometry args={[0.075, 0.016, 0.32]} />
              <meshStandardMaterial color="#f2c500" roughness={0.85} />
            </mesh>
          </group>
        )),
      )}
    </group>
  )
}

/** Bandeja ESD rosa con tarjetas verdes sobre carro auxiliar. */
export function EsdTray({ position }: { position: Vec3 }) {
  return (
    <group position={position}>
      {[-0.3, 0.3].map((x) =>
        [-0.22, 0.22].map((z) => (
          <mesh key={`leg-${x}-${z}`} castShadow position={[x, 0.35, z]}>
            <boxGeometry args={[0.05, 0.7, 0.05]} />
            <meshStandardMaterial color="#b9c0c5" roughness={0.42} metalness={0.62} />
          </mesh>
        )),
      )}
      <mesh castShadow receiveShadow position={[0, 0.72, 0]}>
        <boxGeometry args={[0.72, 0.04, 0.54]} />
        <meshStandardMaterial color="#c3c9cd" roughness={0.5} metalness={0.45} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.84, 0]}>
        <boxGeometry args={[0.62, 0.2, 0.46]} />
        <meshStandardMaterial color="#15181c" roughness={0.86} metalness={0.04} />
      </mesh>
      <mesh position={[0, 0.95, 0]}>
        <boxGeometry args={[0.58, 0.06, 0.42]} />
        <meshStandardMaterial color="#e9a7c4" transparent opacity={0.7} roughness={0.6} />
      </mesh>
      {[-0.13, 0.13].map((x) => (
        <mesh key={`pcb-${x}`} castShadow position={[x, 0.95, 0]}>
          <boxGeometry args={[0.22, 0.02, 0.34]} />
          <meshStandardMaterial color="#1f6b44" roughness={0.58} metalness={0.08} />
        </mesh>
      ))}
    </group>
  )
}

/** Alimentador de tornillos tipo easyfeed / DEPRAG, al costado de la estacion. */
export function ScrewFeeder({ position }: { position: Vec3 }) {
  return (
    <group position={position}>
      {[-0.16, 0.16].map((x) => (
        <mesh key={`post-${x}`} castShadow position={[x, 0.45, 0]}>
          <boxGeometry args={[0.05, 0.9, 0.05]} />
          <meshStandardMaterial color="#2b3038" roughness={0.6} metalness={0.3} />
        </mesh>
      ))}
      <mesh castShadow receiveShadow position={[0, 1.02, 0]}>
        <boxGeometry args={[0.42, 0.34, 0.34]} />
        <meshStandardMaterial color="#f0f2f3" roughness={0.66} metalness={0.08} />
      </mesh>
      <mesh position={[0, 1.02, 0.172]}>
        <planeGeometry args={[0.3, 0.1]} />
        <meshStandardMaterial color="#1f8a4c" roughness={0.6} />
      </mesh>
      <mesh castShadow position={[0, 1.24, 0]}>
        <cylinderGeometry args={[0.15, 0.15, 0.1, 16]} />
        <meshPhysicalMaterial color="#dfe8ee" transparent opacity={0.4} roughness={0.15} />
      </mesh>
      <mesh receiveShadow position={[0, 0.03, 0]}>
        <boxGeometry args={[0.5, 0.05, 0.4]} />
        <meshStandardMaterial color="#15181c" roughness={0.8} metalness={0.1} />
      </mesh>
    </group>
  )
}

/** Tapete antifatiga negro frente a la estacion. */
export function AntiFatigueMat({ width, position }: { width: number; position: Vec3 }) {
  return (
    <mesh receiveShadow position={position}>
      <boxGeometry args={[width, 0.02, 0.85]} />
      <meshStandardMaterial color="#1a1c20" roughness={0.95} metalness={0.02} />
    </mesh>
  )
}

/** Servicios bajo la mesa: motor, caja roja y bolsa de recoleccion. */
function UnderTableUtilities({ width, depth }: { width: number; depth: number }) {
  return (
    <group>
      <mesh castShadow position={[-width * 0.3, 0.34, -depth * 0.12]}>
        <cylinderGeometry args={[0.09, 0.09, 0.24, 12]} />
        <meshStandardMaterial color="#7b8288" roughness={0.55} metalness={0.4} />
      </mesh>
      <mesh castShadow position={[width * 0.22, 0.32, -depth * 0.05]}>
        <boxGeometry args={[0.26, 0.2, 0.22]} />
        <meshStandardMaterial color="#b91c1c" roughness={0.55} metalness={0.15} />
      </mesh>
      <mesh castShadow position={[0, 0.42, depth * 0.16]}>
        <coneGeometry args={[0.09, 0.34, 10]} />
        <meshStandardMaterial color="#f1f3f4" roughness={0.9} />
      </mesh>
      <mesh castShadow position={[-width * 0.05, 0.2, depth * 0.1]}>
        <boxGeometry args={[0.3, 0.22, 0.26]} />
        <meshStandardMaterial color="#e6e8ea" roughness={0.75} metalness={0.08} />
      </mesh>
      {/* Contenedor de basura y manguera de servicio */}
      <mesh castShadow receiveShadow position={[width * 0.34, 0.22, depth * 0.12]}>
        <boxGeometry args={[0.26, 0.28, 0.24]} />
        <meshStandardMaterial color="#9aa2a8" roughness={0.72} metalness={0.12} />
      </mesh>
      <mesh castShadow position={[width * 0.4, 0.5, -depth * 0.1]} rotation={[0, 0, 0.4]}>
        <cylinderGeometry args={[0.035, 0.035, 0.6, 10]} />
        <meshStandardMaterial color="#15181c" roughness={0.85} metalness={0.05} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Cabina cerrada de policarbonato (ST 035, ST 040, ST 090)
 * ------------------------------------------------------------------ */

export function FassyGlassCell({ equipment }: { equipment: FassyEquipmentConfig }) {
  const [width, height, depth] = equipment.size
  const front = depth / 2
  const halfWidth = width / 2
  const profile = 0.06

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      {/* Bancada */}
      <mesh castShadow receiveShadow position={[0, 0.42, 0]}>
        <boxGeometry args={[width * 0.96, 0.84, depth * 0.92]} />
        <meshStandardMaterial color="#e8eaec" roughness={0.68} metalness={0.1} />
      </mesh>
      <mesh position={[0, 0.86, 0]}>
        <boxGeometry args={[width * 0.97, 0.05, depth * 0.93]} />
        <meshStandardMaterial color="#20242a" roughness={0.7} metalness={0.12} />
      </mesh>

      {/* Montantes de perfil de aluminio con ranura negra */}
      {[-halfWidth + profile, halfWidth - profile].map((x) =>
        [-depth / 2 + profile, depth / 2 - profile].map((z) => (
          <group key={`post-${x}-${z}`} position={[x, height / 2 + 0.45, z]}>
            <mesh castShadow receiveShadow>
              <boxGeometry args={[0.11, height, 0.11]} />
              <meshStandardMaterial color="#d5d9dc" roughness={0.4} metalness={0.6} />
            </mesh>
            <mesh position={[0.057, 0, 0]}>
              <boxGeometry args={[0.004, height, 0.035]} />
              <meshStandardMaterial color="#15181c" roughness={0.8} />
            </mesh>
          </group>
        )),
      )}

      {/* Paneles de policarbonato */}
      <mesh position={[0, height / 2 + 0.45, -depth / 2 + 0.03]}>
        <planeGeometry args={[width - 0.14, height - 0.1]} />
        <meshPhysicalMaterial color="#e8f0f5" transparent opacity={0.16} roughness={0.08} />
      </mesh>
      {[-halfWidth + 0.03, halfWidth - 0.03].map((x) => (
        <mesh key={`side-${x}`} position={[x, height / 2 + 0.45, 0]} rotation={[0, Math.PI / 2, 0]}>
          <planeGeometry args={[depth - 0.14, height - 0.1]} />
          <meshPhysicalMaterial color="#e8f0f5" transparent opacity={0.14} roughness={0.08} />
        </mesh>
      ))}

      {/* Puertas abatibles con manija negra y bisagras */}
      {[-width * 0.24, width * 0.24].map((x) => (
        <group key={`door-${x}`} position={[x, height / 2 + 0.45, front - 0.03]}>
          <mesh>
            <planeGeometry args={[width * 0.45, height - 0.14]} />
            <meshPhysicalMaterial color="#eaf2f7" transparent opacity={0.2} roughness={0.07} />
          </mesh>
          <mesh castShadow position={[x > 0 ? -width * 0.21 : width * 0.21, 0, 0.03]}>
            <boxGeometry args={[0.045, 0.32, 0.05]} />
            <meshStandardMaterial color="#15181c" roughness={0.6} metalness={0.2} />
          </mesh>
          {[-height * 0.32, height * 0.32].map((y) => (
            <mesh key={y} castShadow position={[x > 0 ? width * 0.22 : -width * 0.22, y, 0.02]}>
              <boxGeometry args={[0.1, 0.12, 0.03]} />
              <meshStandardMaterial color="#c9ced2" roughness={0.45} metalness={0.5} />
            </mesh>
          ))}
        </group>
      ))}

      {/* Travesano superior con la placa azul y los rotulos de variante */}
      <mesh castShadow receiveShadow position={[0, height + 0.42, 0]}>
        <boxGeometry args={[width, 0.12, depth]} />
        <meshStandardMaterial color="#d5d9dc" roughness={0.4} metalness={0.6} />
      </mesh>
      <mesh position={[0, height + 0.5, front - 0.02]}>
        <boxGeometry args={[0.44, 0.11, 0.02]} />
        <meshStandardMaterial color="#1e4c8a" roughness={0.5} />
      </mesh>
      <Text
        position={[0, height + 0.5, front - 0.006]}
        fontSize={0.07}
        color="#f8fafc"
        anchorX="center"
        anchorY="middle"
      >
        {equipment.tag}
      </Text>
      {equipment.variantSigns
        ? equipment.variantSigns.map((sign, index) => (
            <group
              key={sign}
              position={[index === 0 ? -width * 0.26 : width * 0.26, height + 0.52, front - 0.02]}
            >
              <mesh>
                <boxGeometry args={[0.4, 0.16, 0.02]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.8} />
              </mesh>
              <mesh position={[0, -0.03, 0.012]}>
                <boxGeometry args={[0.36, 0.07, 0.005]} />
                <meshStandardMaterial color="#1e4c8a" roughness={0.55} />
              </mesh>
              <Text position={[0, -0.03, 0.02]} fontSize={0.055} color="#f8fafc" anchorX="center" anchorY="middle">
                {sign}
              </Text>
            </group>
          ))
        : null}

      {/* Etiquetas amarillas de canal de dispensado */}
      {equipment.channelTags
        ? equipment.channelTags.map((channel, index) => {
            const step = width / (equipment.channelTags!.length + 1)
            return (
              <group key={channel} position={[-width / 2 + step * (index + 1), height + 0.02, depth * 0.1]}>
                <mesh>
                  <circleGeometry args={[0.09, 16]} />
                  <meshStandardMaterial color="#e8c400" roughness={0.6} />
                </mesh>
                <Text position={[0, 0, 0.006]} fontSize={0.055} color="#15181c" anchorX="center" anchorY="middle">
                  {channel}
                </Text>
                <mesh castShadow position={[0, -0.16, 0]} rotation={[0.5, 0, 0]}>
                  <cylinderGeometry args={[0.035, 0.035, 0.4, 10]} />
                  <meshStandardMaterial color="#c6ccd1" roughness={0.35} metalness={0.7} />
                </mesh>
              </group>
            )
          })
        : null}

      {/* Interior: nido, cadena portacables y cabezal */}
      <mesh castShadow receiveShadow position={[0, 1.02, 0]}>
        <boxGeometry args={[width * 0.5, 0.1, depth * 0.5]} />
        <meshStandardMaterial color="#8d9499" roughness={0.44} metalness={0.55} />
      </mesh>
      <mesh castShadow position={[0, 1.14, 0]}>
        <boxGeometry args={[width * 0.34, 0.14, depth * 0.34]} />
        <meshStandardMaterial color="#aab2b8" roughness={0.45} metalness={0.6} />
      </mesh>
      <mesh castShadow position={[0, height + 0.1, -depth * 0.14]}>
        <boxGeometry args={[width * 0.7, 0.09, 0.09]} />
        <meshStandardMaterial color="#9ca3a8" roughness={0.38} metalness={0.7} />
      </mesh>
      {Array.from({ length: 8 }).map((_, index) => (
        <mesh key={index} castShadow position={[-width * 0.28 + index * (width * 0.08), height + 0.2, -depth * 0.14]}>
          <boxGeometry args={[0.06, 0.07, 0.1]} />
          <meshStandardMaterial color="#15181c" roughness={0.8} metalness={0.05} />
        </mesh>
      ))}

      <ConveyorChannel width={width * 0.98} depth={depth * 0.8} />

      {equipment.showTowerLight ? (
        <TowerLight position={[-halfWidth + 0.1, height + 0.48, -depth * 0.3]} />
      ) : null}

      {equipment.showExtraction ? (
        <ExtractionDuct fromY={height + 0.5} position={[width * 0.28, 0, -depth * 0.24]} />
      ) : null}

      {/* HMI en brazo, en la esquina frontal izquierda */}
      <HmiArm position={[-halfWidth - 0.1, 1.62, front * 0.5]} mirrored />

      {/* Hoja de proceso en marco azul sobre el montante */}
      <group position={[-halfWidth - 0.16, 1.16, front * 0.2]} rotation={[0, Math.PI / 2, 0]}>
        <mesh>
          <planeGeometry args={[0.36, 0.46]} />
          <meshStandardMaterial color="#1e4c8a" roughness={0.7} />
        </mesh>
        <mesh position={[0, 0, 0.004]}>
          <planeGeometry args={[0.31, 0.41]} />
          <meshStandardMaterial color="#f8fafc" roughness={0.88} />
        </mesh>
      </group>

      <AntiFatigueMat width={Math.min(width * 0.85, 1.6)} position={[0, 0.01, front + 0.66]} />
      <FloorCorners position={[width * 0.62, 0.008, front + 0.5]} size={[0.9, 0.7]} />
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Estacion automatica: mesa de perfil con cuerpo blanco de lamina,
 * ventanas oscuras, portico con placa ST y dos HMI en brazo.
 * ------------------------------------------------------------------ */

export function FassyAutomatedCell({ equipment }: { equipment: FassyEquipmentConfig }) {
  const headRef = useRef<Group | null>(null)
  const [width, , depth] = equipment.size
  const accent = equipment.accentColor ?? '#0e7490'
  const front = depth / 2
  const tableHeight = 0.78

  useFrame((state) => {
    if (!headRef.current) {
      return
    }

    const t = state.clock.elapsedTime

    if (equipment.type === 'sealing-cell' || equipment.type === 'potting-cell') {
      headRef.current.position.x = Math.sin(t * 0.9) * (width * 0.18)
      return
    }

    if (equipment.type === 'press-cell' || equipment.type === 'screwdriving-cell') {
      headRef.current.position.y = Math.abs(Math.sin(t * 0.85)) * -0.2
      return
    }

    if (equipment.type === 'pick-place-cell') {
      headRef.current.position.x = Math.sin(t * 1.1) * (width * 0.22)
      headRef.current.position.y = Math.abs(Math.cos(t * 1.1)) * -0.16
      return
    }

    if (equipment.type === 'flipping-cell') {
      headRef.current.rotation.z = Math.sin(t * 0.7) * Math.PI * 0.5
      return
    }

    headRef.current.position.x = Math.sin(t * 0.6) * (width * 0.08)
  })

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      {/* Mesa de perfil de aluminio */}
      {[-(width / 2 - 0.12), width / 2 - 0.12].map((x) =>
        [-depth * 0.32, depth * 0.32].map((z) => (
          <mesh key={`leg-${x}-${z}`} castShadow receiveShadow position={[x, tableHeight / 2, z]}>
            <boxGeometry args={[0.09, tableHeight, 0.09]} />
            <meshStandardMaterial color="#b9c0c5" roughness={0.42} metalness={0.62} />
          </mesh>
        )),
      )}
      <mesh receiveShadow position={[0, 0.16, 0]}>
        <boxGeometry args={[width * 0.9, 0.04, depth * 0.72]} />
        <meshStandardMaterial color="#c3c9cd" roughness={0.5} metalness={0.5} />
      </mesh>

      {/* Cuerpo blanco de lamina */}
      <mesh castShadow receiveShadow position={[0, tableHeight + 0.36, 0]}>
        <boxGeometry args={[width * 0.98, 0.72, depth * 0.9]} />
        <meshStandardMaterial color="#edeff0" roughness={0.66} metalness={0.1} />
      </mesh>
      <mesh position={[0, tableHeight + 0.02, 0]}>
        <boxGeometry args={[width * 0.99, 0.05, depth * 0.91]} />
        <meshStandardMaterial color="#20242a" roughness={0.7} metalness={0.12} />
      </mesh>

      {/* Ventanas oscuras del tunel de transporte */}
      {[-width * 0.26, width * 0.26].map((x) => (
        <mesh key={`window-${x}`} position={[x, tableHeight + 0.725, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[width * 0.34, depth * 0.5]} />
          <meshPhysicalMaterial color="#0f172a" transparent opacity={0.72} roughness={0.12} />
        </mesh>
      ))}

      {/* Nido de trabajo al centro */}
      <mesh castShadow receiveShadow position={[0, tableHeight + 0.78, 0]}>
        <boxGeometry args={[width * 0.3, 0.12, depth * 0.5]} />
        <meshStandardMaterial color="#5c6268" roughness={0.44} metalness={0.5} />
      </mesh>

      <ConveyorChannel width={width * 0.96} depth={depth * 0.8} />

      {/* Ejes verticales verdes: el de proceso y el gemelo de la estacion contigua */}
      <group position={[0, tableHeight + 0.82, -depth * 0.06]}>
        <GreenAxis>
          <group ref={headRef} position={[0, 0.02, 0]}>
            <MechanismHead type={equipment.type} accent={accent} width={width} />
          </group>
        </GreenAxis>
      </group>
      <group position={[width * 0.34, tableHeight + 0.82, -depth * 0.22]}>
        <GreenAxis />
      </group>
      {/* Columnas verdes de los montantes del portico */}
      {[-(width / 2 - 0.08), width / 2 - 0.08].map((x) => (
        <mesh key={`green-${x}`} castShadow position={[x, 1.62, -depth * 0.32]}>
          <boxGeometry args={[0.14, 0.5, 0.14]} />
          <meshStandardMaterial color="#2f7d32" roughness={0.5} metalness={0.32} />
        </mesh>
      ))}

      <StationPortal
        width={width}
        depth={depth}
        tag={equipment.tag}
        showTowerLight={equipment.showTowerLight !== false}
      />

      <HmiArm position={[-width * 0.5, 1.56, front * 0.1]} mirrored />
      <HmiArm position={[width * 0.5, 1.56, front * 0.1]} ok />

      <InstructionSheet position={[-width * 0.3, 1.24, depth * 0.451]} width={0.26} height={0.34} />

      <UnderTableUtilities width={width} depth={depth} />

      {equipment.showExtraction ? (
        <ExtractionDuct fromY={2.24} position={[width * 0.28, 0, -depth * 0.2]} />
      ) : null}

      <AntiFatigueMat width={Math.min(width * 0.85, 1.6)} position={[0, 0.01, front + 0.62]} />
      <FloorCorners position={[width * 0.66, 0.008, front + 0.5]} size={[0.9, 0.7]} />

      {equipment.type === 'screwdriving-cell' ? (
        <ScrewFeeder position={[width * 0.62, 0, -depth * 0.28]} />
      ) : null}
      {equipment.type === 'pick-place-cell' || equipment.type === 'vision-cell' ? (
        <EsdTray position={[width * 0.72, 0, front * 0.5]} />
      ) : null}
    </group>
  )
}

function MechanismHead({
  type,
  accent,
  width,
}: {
  type: FassyEquipmentConfig['type']
  accent: string
  width: number
}) {
  if (type === 'flipping-cell') {
    return (
      <group>
        <mesh castShadow position={[0, 0.02, -0.05]}>
          <boxGeometry args={[0.5, 0.12, 0.36]} />
          <meshStandardMaterial color={accent} roughness={0.44} metalness={0.4} />
        </mesh>
        {[-0.3, 0.3].map((x) => (
          <mesh key={x} castShadow position={[x, 0.02, -0.05]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.075, 0.075, 0.1, 14]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.3} metalness={0.78} />
          </mesh>
        ))}
      </group>
    )
  }

  if (type === 'pick-place-cell') {
    return (
      <group>
        <mesh castShadow position={[0, 0.2, -0.05]}>
          <boxGeometry args={[0.34, 0.26, 0.26]} />
          <meshStandardMaterial color={accent} roughness={0.44} metalness={0.4} />
        </mesh>
        <mesh castShadow position={[0, -0.02, -0.05]}>
          <boxGeometry args={[0.1, 0.24, 0.1]} />
          <meshStandardMaterial color="#cbd5e1" roughness={0.28} metalness={0.8} />
        </mesh>
        <mesh castShadow position={[0, -0.18, -0.05]}>
          <boxGeometry args={[0.34, 0.08, 0.3]} />
          <meshStandardMaterial color="#475569" roughness={0.5} metalness={0.5} />
        </mesh>
      </group>
    )
  }

  if (type === 'potting-cell') {
    return (
      <group>
        <mesh castShadow position={[0, 0.26, -0.12]}>
          <cylinderGeometry args={[0.17, 0.17, 0.38, 16]} />
          <meshStandardMaterial color={accent} roughness={0.4} metalness={0.34} />
        </mesh>
        <mesh castShadow position={[0, -0.18, -0.12]}>
          <cylinderGeometry args={[0.028, 0.014, 0.24, 10]} />
          <meshStandardMaterial color="#e5e7eb" roughness={0.3} metalness={0.6} />
        </mesh>
        <mesh position={[0, -0.31, -0.12]}>
          <sphereGeometry args={[0.026, 10, 10]} />
          <meshStandardMaterial color="#c4b5fd" emissive="#a78bfa" emissiveIntensity={0.7} />
        </mesh>
      </group>
    )
  }

  if (type === 'sealing-cell') {
    return (
      <group>
        <mesh castShadow position={[0, 0.18, -0.1]}>
          <boxGeometry args={[0.3, 0.26, 0.24]} />
          <meshStandardMaterial color={accent} roughness={0.42} metalness={0.35} />
        </mesh>
        <mesh castShadow position={[0, -0.08, -0.1]}>
          <cylinderGeometry args={[0.03, 0.012, 0.34, 10]} />
          <meshStandardMaterial color="#e5e7eb" roughness={0.3} metalness={0.6} />
        </mesh>
      </group>
    )
  }

  if (type === 'press-cell') {
    return (
      <group>
        <mesh castShadow position={[0, 0.24, -0.05]}>
          <boxGeometry args={[0.42, 0.36, 0.32]} />
          <meshStandardMaterial color={accent} roughness={0.44} metalness={0.4} />
        </mesh>
        <mesh castShadow position={[0, -0.06, -0.05]}>
          <cylinderGeometry args={[0.05, 0.05, 0.36, 12]} />
          <meshStandardMaterial color="#cbd5e1" roughness={0.24} metalness={0.82} />
        </mesh>
        <mesh castShadow position={[0, -0.26, -0.05]}>
          <boxGeometry args={[0.36, 0.08, 0.28]} />
          <meshStandardMaterial color="#64748b" roughness={0.4} metalness={0.6} />
        </mesh>
      </group>
    )
  }

  if (type === 'screwdriving-cell') {
    return (
      <group>
        <mesh castShadow position={[0, 0.2, -0.05]}>
          <boxGeometry args={[0.26, 0.3, 0.24]} />
          <meshStandardMaterial color={accent} roughness={0.44} metalness={0.4} />
        </mesh>
        {[-0.13, 0.13].map((x) => (
          <group key={x} position={[x, -0.1, -0.05]}>
            <mesh castShadow>
              <cylinderGeometry args={[0.035, 0.035, 0.3, 12]} />
              <meshStandardMaterial color="#e2e8f0" roughness={0.3} metalness={0.7} />
            </mesh>
            <mesh castShadow position={[0, -0.2, 0]}>
              <cylinderGeometry args={[0.012, 0.012, 0.12, 8]} />
              <meshStandardMaterial color="#94a3b8" roughness={0.3} metalness={0.8} />
            </mesh>
          </group>
        ))}
      </group>
    )
  }

  if (type === 'vision-cell') {
    return (
      <group>
        <mesh castShadow position={[0, 0.2, -0.05]}>
          <boxGeometry args={[0.22, 0.3, 0.22]} />
          <meshStandardMaterial color="#111827" roughness={0.4} metalness={0.4} />
        </mesh>
        <mesh castShadow position={[0, -0.02, -0.05]}>
          <cylinderGeometry args={[0.055, 0.055, 0.16, 14]} />
          <meshStandardMaterial color="#374151" roughness={0.35} metalness={0.6} />
        </mesh>
        <mesh position={[0, -0.12, -0.05]}>
          <torusGeometry args={[0.11, 0.022, 8, 20]} />
          <meshStandardMaterial color="#60a5fa" emissive="#3b82f6" emissiveIntensity={1.2} />
        </mesh>
      </group>
    )
  }

  return (
    <group>
      <mesh castShadow position={[0, 0.2, -0.05]}>
        <boxGeometry args={[0.3, 0.28, 0.26]} />
        <meshStandardMaterial color={accent} roughness={0.44} metalness={0.4} />
      </mesh>
      <mesh castShadow position={[0, -0.06, -0.05]}>
        <boxGeometry args={[0.32, 0.14, width * 0.08 + 0.2]} />
        <meshStandardMaterial color="#cbd5e1" roughness={0.28} metalness={0.72} />
      </mesh>
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Estacion manual: misma mesa y portico, con cubierta ESD azul
 * ------------------------------------------------------------------ */

export function FassyWorkstation({ equipment }: { equipment: FassyEquipmentConfig }) {
  const [width, , depth] = equipment.size
  const front = depth / 2
  const tableHeight = 0.9

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      {[-(width / 2 - 0.12), width / 2 - 0.12].map((x) =>
        [-depth * 0.32, depth * 0.32].map((z) => (
          <mesh key={`leg-${x}-${z}`} castShadow receiveShadow position={[x, tableHeight / 2, z]}>
            <boxGeometry args={[0.09, tableHeight, 0.09]} />
            <meshStandardMaterial color="#b9c0c5" roughness={0.42} metalness={0.62} />
          </mesh>
        )),
      )}

      {/* Cubierta ESD azul */}
      <mesh castShadow receiveShadow position={[0, tableHeight, 0]}>
        <boxGeometry args={[width, 0.06, depth * 0.84]} />
        <meshStandardMaterial color="#2f5f8f" roughness={0.82} metalness={0.05} />
      </mesh>
      <mesh receiveShadow position={[0, tableHeight - 0.05, 0]}>
        <boxGeometry args={[width, 0.05, depth * 0.86]} />
        <meshStandardMaterial color="#c3c9cd" roughness={0.5} metalness={0.5} />
      </mesh>

      {/* Cuerpo blanco lateral con el nido de trabajo */}
      <mesh castShadow receiveShadow position={[width * 0.24, tableHeight + 0.22, -depth * 0.08]}>
        <boxGeometry args={[width * 0.44, 0.38, depth * 0.6]} />
        <meshStandardMaterial color="#edeff0" roughness={0.66} metalness={0.1} />
      </mesh>
      <mesh castShadow receiveShadow position={[-width * 0.16, tableHeight + 0.1, 0]}>
        <boxGeometry args={[width * 0.36, 0.14, depth * 0.46]} />
        <meshStandardMaterial color="#5c6268" roughness={0.44} metalness={0.5} />
      </mesh>

      {/* Repisa inferior con cajas KLT */}
      <mesh receiveShadow position={[0, 0.3, 0]}>
        <boxGeometry args={[width * 0.86, 0.04, depth * 0.6]} />
        <meshStandardMaterial color="#9ca3a8" roughness={0.5} metalness={0.5} />
      </mesh>
      {[-width * 0.22, width * 0.08].map((x) => (
        <mesh key={`klt-${x}`} castShadow receiveShadow position={[x, 0.43, 0]}>
          <boxGeometry args={[width * 0.26, 0.22, depth * 0.42]} />
          <meshStandardMaterial color="#15181c" roughness={0.86} metalness={0.04} />
        </mesh>
      ))}

      <ConveyorChannel width={width} depth={depth * 0.6} />

      <StationPortal width={width} depth={depth} tag={equipment.tag} showTowerLight />

      <HmiArm position={[-width * 0.5, 1.56, front * 0.1]} mirrored />
      <HmiArm position={[width * 0.5, 1.56, front * 0.1]} ok />

      <InstructionSheet position={[-width * 0.34, 1.24, depth * 0.42]} width={0.26} height={0.34} />

      <UnderTableUtilities width={width} depth={depth} />

      <AntiFatigueMat width={Math.min(width * 0.85, 1.6)} position={[0, 0.01, front + 0.62]} />
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Modulo de limpieza: tunel blanco con la caja CC Limpieza y su
 * manguera beige de extraccion, tal como se ve en piso.
 * ------------------------------------------------------------------ */

export function FassyCleaningStation({ equipment }: { equipment: FassyEquipmentConfig }) {
  const [width, , depth] = equipment.size
  const front = depth / 2
  const tableHeight = 0.78

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      {[-(width / 2 - 0.1), width / 2 - 0.1].map((x) =>
        [-depth * 0.3, depth * 0.3].map((z) => (
          <mesh key={`leg-${x}-${z}`} castShadow receiveShadow position={[x, tableHeight / 2, z]}>
            <boxGeometry args={[0.09, tableHeight, 0.09]} />
            <meshStandardMaterial color="#b9c0c5" roughness={0.42} metalness={0.62} />
          </mesh>
        )),
      )}

      {/* Cuerpo del tunel */}
      <mesh castShadow receiveShadow position={[0, tableHeight + 0.34, 0]}>
        <boxGeometry args={[width, 0.68, depth * 0.94]} />
        <meshStandardMaterial color="#eef0f1" roughness={0.68} metalness={0.08} />
      </mesh>
      <mesh position={[0, tableHeight + 0.01, 0]}>
        <boxGeometry args={[width * 1.01, 0.04, depth * 0.95]} />
        <meshStandardMaterial color="#20242a" roughness={0.7} metalness={0.12} />
      </mesh>

      {/* Mamparas verticales del tunel */}
      {[-width * 0.34, width * 0.34].map((x) => (
        <mesh key={`panel-${x}`} castShadow receiveShadow position={[x, tableHeight + 1.06, -depth * 0.02]}>
          <boxGeometry args={[width * 0.3, 0.76, depth * 0.66]} />
          <meshStandardMaterial color="#f3f4f5" roughness={0.7} metalness={0.06} />
        </mesh>
      ))}

      {/* Caja CC Limpieza con manguera beige */}
      <mesh castShadow receiveShadow position={[0, tableHeight + 0.82, -depth * 0.02]}>
        <boxGeometry args={[width * 0.42, 0.22, depth * 0.44]} />
        <meshStandardMaterial color="#f5f6f7" roughness={0.72} metalness={0.06} />
      </mesh>
      <mesh position={[0, tableHeight + 0.79, depth * 0.2]}>
        <planeGeometry args={[width * 0.22, 0.08]} />
        <meshStandardMaterial color="#1e4c8a" roughness={0.55} />
      </mesh>
      {Array.from({ length: 6 }).map((_, index) => {
        const angle = (index / 5) * Math.PI
        return (
          <mesh
            key={`hose-${index}`}
            castShadow
            position={[
              -Math.cos(angle) * width * 0.16,
              tableHeight + 0.96 + Math.sin(angle) * 0.16,
              -depth * 0.02,
            ]}
            rotation={[0, 0, angle]}
          >
            <cylinderGeometry args={[0.055, 0.055, width * 0.13, 10]} />
            <meshStandardMaterial color="#d8c49a" roughness={0.85} metalness={0.04} />
          </mesh>
        )
      })}

      <ConveyorChannel width={width * 0.98} depth={depth * 0.8} />

      <StationPortal width={width * 1.15} depth={depth} tag={equipment.tag} showTowerLight={false} />

      <AntiFatigueMat width={Math.min(width * 0.9, 1.3)} position={[0, 0.01, front + 0.6]} />
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * ST 150 Potting: maquina bdtronic con camara de vacio
 * ------------------------------------------------------------------ */

export function FassyPottingMachine({ equipment }: { equipment: FassyEquipmentConfig }) {
  const [width, , depth] = equipment.size
  const front = depth / 2

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      {/* Cuerpo blanco de lamina */}
      <mesh castShadow receiveShadow position={[0, 0.62, 0]}>
        <boxGeometry args={[width, 1.24, depth]} />
        <meshStandardMaterial color="#eceef0" roughness={0.68} metalness={0.08} />
      </mesh>

      {/* Camara de vacio con dos mirillas atornilladas */}
      <mesh position={[0, 0.94, front + 0.005]}>
        <planeGeometry args={[width * 0.62, 0.34]} />
        <meshStandardMaterial color="#b9c0c5" roughness={0.4} metalness={0.6} />
      </mesh>
      {[-width * 0.13, width * 0.13].map((x) => (
        <group key={`port-${x}`} position={[x, 0.94, front + 0.012]}>
          <mesh>
            <circleGeometry args={[0.12, 20]} />
            <meshStandardMaterial color="#c9ced2" roughness={0.35} metalness={0.7} />
          </mesh>
          <mesh position={[0, 0, 0.004]}>
            <circleGeometry args={[0.075, 20]} />
            <meshPhysicalMaterial color="#9fd8e6" transparent opacity={0.75} roughness={0.1} />
          </mesh>
          {Array.from({ length: 8 }).map((_, index) => {
            const angle = (index / 8) * Math.PI * 2
            return (
              <mesh key={index} position={[Math.cos(angle) * 0.1, Math.sin(angle) * 0.1, 0.006]}>
                <cylinderGeometry args={[0.012, 0.012, 0.01, 6]} />
                <meshStandardMaterial color="#8d9499" roughness={0.4} metalness={0.7} />
              </mesh>
            )
          })}
        </group>
      ))}

      {/* Capota superior con chaflan y ventana de proceso */}
      <mesh castShadow receiveShadow position={[0, 1.72, 0]}>
        <boxGeometry args={[width, 0.16, depth]} />
        <meshStandardMaterial color="#eceef0" roughness={0.68} metalness={0.08} />
      </mesh>
      {[-width / 2 + 0.09, width / 2 - 0.09].map((x) => (
        <mesh key={`col-${x}`} castShadow receiveShadow position={[x, 1.36, 0]}>
          <boxGeometry args={[0.18, 0.6, depth]} />
          <meshStandardMaterial color="#eceef0" roughness={0.68} metalness={0.08} />
        </mesh>
      ))}
      <mesh position={[0, 1.36, front - 0.02]}>
        <planeGeometry args={[width - 0.4, 0.58]} />
        <meshPhysicalMaterial color="#dfeaf2" transparent opacity={0.22} roughness={0.07} />
      </mesh>

      {/* Cabezal de dispensado y plato de trabajo */}
      <mesh castShadow position={[0, 1.3, -depth * 0.1]}>
        <cylinderGeometry args={[0.28, 0.28, 0.05, 20]} />
        <meshStandardMaterial color="#aab2b8" roughness={0.42} metalness={0.62} />
      </mesh>
      <mesh castShadow position={[0, 1.5, -depth * 0.1]}>
        <boxGeometry args={[0.22, 0.3, 0.22]} />
        <meshStandardMaterial color="#4a5058" roughness={0.45} metalness={0.4} />
      </mesh>

      {/* Placa azul de identificacion */}
      <mesh position={[0, 1.72, front + 0.008]}>
        <boxGeometry args={[0.44, 0.11, 0.02]} />
        <meshStandardMaterial color="#1e4c8a" roughness={0.5} />
      </mesh>
      <Text position={[0, 1.72, front + 0.02]} fontSize={0.07} color="#f8fafc" anchorX="center" anchorY="middle">
        {equipment.tag}
      </Text>

      {/* Columna lateral con HMI bdtronic */}
      <mesh castShadow receiveShadow position={[width / 2 + 0.34, 0.9, 0]}>
        <boxGeometry args={[0.62, 1.8, depth * 0.9]} />
        <meshStandardMaterial color="#e6e8ea" roughness={0.7} metalness={0.08} />
      </mesh>
      <HmiArm position={[width / 2 + 0.34, 1.52, front * 0.6]} />

      {/* Paro de emergencia y torreta en poste */}
      <mesh position={[-width / 2 + 0.14, 1.0, front + 0.01]}>
        <cylinderGeometry args={[0.05, 0.05, 0.03, 14]} />
        <meshStandardMaterial color="#dc2626" roughness={0.45} />
      </mesh>
      <mesh castShadow position={[width * 0.36, 2.2, -depth * 0.3]}>
        <cylinderGeometry args={[0.035, 0.035, 0.9, 10]} />
        <meshStandardMaterial color="#c9ced2" roughness={0.4} metalness={0.55} />
      </mesh>
      {equipment.showTowerLight ? (
        <TowerLight position={[width * 0.36, 2.62, -depth * 0.3]} />
      ) : null}

      {equipment.showExtraction ? (
        <ExtractionDuct fromY={1.9} position={[-width * 0.28, 0, -depth * 0.3]} />
      ) : null}

      <ConveyorChannel width={width * 0.99} depth={depth * 0.7} />
      <AntiFatigueMat width={Math.min(width * 0.7, 1.4)} position={[0, 0.01, front + 0.68]} />
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Horno HOLS de curado: seis camaras con puertas de palanca
 * ------------------------------------------------------------------ */

export function FassyHolsOven({ equipment }: { equipment: FassyEquipmentConfig }) {
  const [width, height, depth] = equipment.size
  const front = depth / 2
  const bodyWidth = width - 0.7

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      {/* Cuerpo del horno */}
      <mesh castShadow receiveShadow position={[bodyWidth * 0.12, height / 2, 0]}>
        <boxGeometry args={[bodyWidth, height, depth]} />
        <meshStandardMaterial color="#dcdfe1" roughness={0.66} metalness={0.12} />
      </mesh>

      {/* Seis puertas con bisagras y palanca negra */}
      {[0, 1, 2].map((row) =>
        [-1, 1].map((col) => (
          <group
            key={`door-${row}-${col}`}
            position={[bodyWidth * 0.12 + col * bodyWidth * 0.24, 0.55 + row * 0.66, front + 0.01]}
          >
            <mesh>
              <planeGeometry args={[bodyWidth * 0.42, 0.58]} />
              <meshStandardMaterial color="#d3d7da" roughness={0.68} metalness={0.12} />
            </mesh>
            <mesh castShadow position={[col > 0 ? -bodyWidth * 0.19 : bodyWidth * 0.19, 0, 0.03]}>
              <boxGeometry args={[0.05, 0.2, 0.05]} />
              <meshStandardMaterial color="#15181c" roughness={0.6} metalness={0.2} />
            </mesh>
            {[-0.22, 0.22].map((y) => (
              <mesh key={y} position={[col > 0 ? bodyWidth * 0.2 : -bodyWidth * 0.2, y, 0.012]}>
                <boxGeometry args={[0.1, 0.07, 0.02]} />
                <meshStandardMaterial color="#c9ced2" roughness={0.4} metalness={0.6} />
              </mesh>
            ))}
            <mesh position={[col > 0 ? -bodyWidth * 0.1 : bodyWidth * 0.1, 0.04, 0.012]}>
              <planeGeometry args={[0.07, 0.07]} />
              <meshStandardMaterial color="#e8c400" roughness={0.6} />
            </mesh>
          </group>
        )),
      )}

      {/* Logo rojo HOLS */}
      <mesh position={[bodyWidth * 0.12, height - 0.2, front + 0.012]}>
        <planeGeometry args={[0.46, 0.11]} />
        <meshStandardMaterial color="#c62828" roughness={0.6} />
      </mesh>

      {/* Columna de control con panel Beckhoff */}
      <mesh castShadow receiveShadow position={[-width / 2 + 0.32, height / 2, 0]}>
        <boxGeometry args={[0.64, height, depth * 0.95]} />
        <meshStandardMaterial color="#e4e6e8" roughness={0.68} metalness={0.1} />
      </mesh>
      {[0.62, 1.66].map((y) => (
        <mesh key={y} position={[-width / 2 + 0.32, y, front + 0.008]}>
          <planeGeometry args={[0.28, 0.5]} />
          <meshPhysicalMaterial color="#0f172a" transparent opacity={0.78} roughness={0.12} />
        </mesh>
      ))}
      <group position={[-width / 2 + 0.32, 1.18, front + 0.16]}>
        <mesh castShadow>
          <boxGeometry args={[0.46, 0.42, 0.12]} />
          <meshStandardMaterial color="#e9ebec" roughness={0.6} metalness={0.12} />
        </mesh>
        <mesh position={[0, 0.03, 0.062]}>
          <planeGeometry args={[0.36, 0.26]} />
          <meshStandardMaterial color="#e8eef5" emissive="#9fc4e6" emissiveIntensity={0.5} />
        </mesh>
        <mesh position={[0.15, -0.15, 0.062]}>
          <cylinderGeometry args={[0.032, 0.032, 0.02, 14]} />
          <meshStandardMaterial color="#dc2626" roughness={0.45} />
        </mesh>
      </group>

      {/* Ductos de extraccion en espiral sobre el horno */}
      <ExtractionDuct fromY={height} position={[bodyWidth * 0.02, 0, -depth * 0.2]} />
      <ExtractionDuct fromY={height} position={[bodyWidth * 0.34, 0, -depth * 0.2]} />

      {equipment.showTowerLight ? (
        <TowerLight position={[-width / 2 + 0.32, height + 0.04, -depth * 0.2]} />
      ) : null}

      <ConveyorChannel width={width * 0.99} depth={depth * 0.6} />
      <AntiFatigueMat width={Math.min(width * 0.5, 1.2)} position={[bodyWidth * 0.12, 0.01, front + 0.7]} />
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Hornos de precalentado y curado
 * ------------------------------------------------------------------ */

export function FassyOven({ equipment }: { equipment: FassyEquipmentConfig }) {
  const [width, height, depth] = equipment.size
  const front = depth / 2 + 0.02

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.16, 0]}>
        <boxGeometry args={[width, 0.32, depth]} />
        <meshStandardMaterial color="#71787f" roughness={0.62} metalness={0.28} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 1.05, 0]}>
        <boxGeometry args={[width, 1.42, depth]} />
        <meshStandardMaterial color="#e4e7e9" roughness={0.66} metalness={0.1} />
      </mesh>

      {[-width * 0.26, width * 0.06].map((x) => (
        <mesh key={`window-${x}`} position={[x, 1.3, front]}>
          <planeGeometry args={[width * 0.22, 0.36]} />
          <meshPhysicalMaterial color="#0f172a" transparent opacity={0.62} roughness={0.15} />
        </mesh>
      ))}

      {Array.from({ length: 3 }).map((_, index) => {
        const offsetX = -width * 0.3 + index * (width * 0.3)

        return (
          <mesh key={offsetX} castShadow receiveShadow position={[offsetX, 1.86, 0]}>
            <boxGeometry args={[width * 0.2, 0.24, depth * 0.7]} />
            <meshStandardMaterial color="#cfd4d7" roughness={0.64} metalness={0.12} />
          </mesh>
        )
      })}

      <mesh position={[0, 0.42, front]}>
        <planeGeometry args={[width * 0.9, 0.07]} />
        <meshStandardMaterial color="#f2c500" roughness={0.7} />
      </mesh>

      <ConveyorChannel width={width * 0.99} depth={depth} />

      {equipment.showExtraction ? (
        <>
          <ExtractionDuct fromY={1.98} position={[-width * 0.3, 0, -depth * 0.16]} />
          <ExtractionDuct fromY={1.98} position={[width * 0.3, 0, -depth * 0.16]} />
        </>
      ) : null}

      <HmiScreen position={[width * 0.34, 1.32, front + 0.03]} width={0.32} height={0.24} />

      {equipment.showTowerLight ? (
        <TowerLight position={[-width * 0.42, height - 0.02, depth * 0.26]} />
      ) : null}

      <MachineLabel label={equipment.shortName} width={width} position={[0, 1.72, front + 0.04]} />
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Transfer de retorno: corre sobre Z, no se rota.
 * ------------------------------------------------------------------ */

export function FassyTransfer({ equipment }: { equipment: FassyEquipmentConfig }) {
  const [width, height, depth] = equipment.size

  return (
    <group position={equipment.position} rotation={equipment.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.12, 0]}>
        <boxGeometry args={[width, 0.24, depth]} />
        <meshStandardMaterial color="#3f464e" roughness={0.72} metalness={0.22} />
      </mesh>

      {[-width * 0.24, width * 0.24].map((x) => (
        <mesh key={`rail-${x}`} castShadow receiveShadow position={[x, CONVEYOR_HEIGHT - 0.06, 0]}>
          <boxGeometry args={[0.09, 0.09, depth - 0.3]} />
          <meshStandardMaterial color="#cbd5e1" roughness={0.28} metalness={0.8} />
        </mesh>
      ))}

      {[-depth * 0.36, 0, depth * 0.36].map((z) =>
        [-width * 0.3, width * 0.3].map((x) => (
          <mesh key={`post-${x}-${z}`} castShadow receiveShadow position={[x, CONVEYOR_HEIGHT / 2, z]}>
            <boxGeometry args={[0.08, CONVEYOR_HEIGHT - 0.12, 0.08]} />
            <meshStandardMaterial color="#8d9499" roughness={0.5} metalness={0.5} />
          </mesh>
        )),
      )}

      <mesh castShadow receiveShadow position={[0, CONVEYOR_HEIGHT + 0.02, 0]}>
        <boxGeometry args={[width * 0.7, 0.06, 0.7]} />
        <meshStandardMaterial color="#64748b" roughness={0.44} metalness={0.55} />
      </mesh>

      {[-width / 2 + 0.06, width / 2 - 0.06].map((x) =>
        [-depth / 2 + 0.08, depth / 2 - 0.08].map((z) => (
          <mesh key={`frame-${x}-${z}`} castShadow position={[x, height * 0.6, z]}>
            <boxGeometry args={[0.07, height * 1.2, 0.07]} />
            <meshStandardMaterial color="#b9c0c5" roughness={0.4} metalness={0.66} />
          </mesh>
        )),
      )}

      {equipment.showTowerLight ? <TowerLight position={[0, height * 1.2, -depth * 0.3]} /> : null}

      <MachineLabel label={equipment.shortName} width={width * 1.4} position={[0, height * 1.05, depth / 2 - 0.02]} />
    </group>
  )
}

/** Punto unico de despacho tipo de equipo -> componente. */
export function FassyMachine({ equipment }: { equipment: FassyEquipmentConfig }) {
  switch (equipment.type) {
    case 'manual-workstation':
      return <FassyWorkstation equipment={equipment} />
    case 'cleaning-station':
      return <FassyCleaningStation equipment={equipment} />
    case 'preheating-oven':
    case 'curing-oven':
      return <FassyOven equipment={equipment} />
    case 'glass-cell':
      return <FassyGlassCell equipment={equipment} />
    case 'potting-machine':
      return <FassyPottingMachine equipment={equipment} />
    case 'hols-oven':
      return <FassyHolsOven equipment={equipment} />
    case 'conveyor':
      return <FassyTransfer equipment={equipment} />
    default:
      return <FassyAutomatedCell equipment={equipment} />
  }
}
