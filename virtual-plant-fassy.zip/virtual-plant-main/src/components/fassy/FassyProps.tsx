import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import { Group } from 'three'
import type { FassyPropConfig } from '../../types/fassy'

/* ------------------------------------------------------------------ *
 * Arco del elevador
 * ------------------------------------------------------------------ */

/**
 * Elevador de entrada y salida de FASSY.
 *
 * Es un portico de perfil de aluminio, de esquinas rectas, que cruza la celda de
 * lado a lado:
 * dos columnas en los extremos de Z y una viga superior. Es el unico acceso a
 * pie (se camina por debajo del vano) y a la vez el inicio y el final del flujo:
 * por la columna del lado del tramo A sube el producto hacia ST 010, y por la
 * columna del lado del tramo B baja el producto terminado que entrega ST 230.
 *
 * Se declara con `solid: false`: solo sus dos columnas generan colision.
 */
export function ElevatorArch({ prop }: { prop: FassyPropConfig }) {
  const inputRef = useRef<Group | null>(null)
  const outputRef = useRef<Group | null>(null)
  const [thickness, height, span] = prop.size ?? [0.52, 3.4, 7.6]
  const columnWidth = 0.38
  const beamHeight = 0.36
  const clearHeight = height - beamHeight
  const liftTop = 1.86
  const liftBottom = 0.34

  useFrame((state) => {
    const cycle = 7
    const phase = (state.clock.elapsedTime % cycle) / cycle
    const eased = phase < 0.5 ? phase * 2 : 2 - phase * 2

    if (inputRef.current) {
      inputRef.current.position.y = liftBottom + eased * (liftTop - liftBottom)
    }

    if (outputRef.current) {
      outputRef.current.position.y = liftTop - eased * (liftTop - liftBottom)
    }
  })

  return (
    <group position={prop.position} rotation={prop.rotation}>
      {/* Columnas del portico, en los extremos de la celda */}
      {[-span / 2, span / 2].map((z) => (
        <group key={`column-${z}`} position={[0, 0, z]}>
          <mesh castShadow receiveShadow position={[0, clearHeight / 2, 0]}>
            <boxGeometry args={[thickness + 0.3, clearHeight, columnWidth]} />
            <meshStandardMaterial color="#c9cdd1" roughness={0.4} metalness={0.55} />
          </mesh>
          <mesh receiveShadow position={[0, 0.07, 0]}>
            <boxGeometry args={[thickness + 0.6, 0.14, columnWidth + 0.34]} />
            <meshStandardMaterial color="#3f464e" roughness={0.8} metalness={0.14} />
          </mesh>
          {[0.55, 0.8].map((y) => (
            <mesh key={y} position={[(thickness + 0.3) / 2 + 0.002, y, 0]} rotation={[0, Math.PI / 2, 0]}>
              <planeGeometry args={[columnWidth * 0.9, 0.11]} />
              <meshStandardMaterial color="#16181c" roughness={0.7} />
            </mesh>
          ))}
        </group>
      ))}

      {/* Viga superior, esquinas rectas */}
      <mesh castShadow receiveShadow position={[0, clearHeight + beamHeight / 2, 0]}>
        <boxGeometry args={[thickness + 0.3, beamHeight, span + columnWidth]} />
        <meshStandardMaterial color="#c9cdd1" roughness={0.4} metalness={0.55} />
      </mesh>

      {/* Cartelas rectas de esquina */}
      {[-span / 2, span / 2].map((z) => (
        <mesh
          key={`gusset-${z}`}
          castShadow
          position={[0, clearHeight - 0.16, z + (z > 0 ? -0.34 : 0.34)]}
        >
          <boxGeometry args={[thickness + 0.3, 0.16, 0.62]} />
          <meshStandardMaterial color="#aeb4b9" roughness={0.42} metalness={0.58} />
        </mesh>
      ))}

      {/* Letrero del elevador */}
      <mesh position={[(thickness + 0.3) / 2 + 0.01, clearHeight + beamHeight / 2, 0]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[span * 0.34, 0.2]} />
        <meshStandardMaterial color="#1e3a8a" roughness={0.6} />
      </mesh>

      {/* Guias verticales de cada torre de elevacion */}
      {[-span / 2, span / 2].map((z) =>
        [-0.12, 0.12].map((offset) => (
          <mesh key={`guide-${z}-${offset}`} castShadow position={[offset, clearHeight / 2, z + (z > 0 ? -0.3 : 0.3)]}>
            <boxGeometry args={[0.05, clearHeight - 0.4, 0.05]} />
            <meshStandardMaterial color="#94a3b8" roughness={0.3} metalness={0.8} />
          </mesh>
        )),
      )}

      {/* Carro de entrada: sube el producto hacia ST 010 (tramo A) */}
      <group ref={inputRef} position={[0, liftBottom, -span / 2 + 0.3]}>
        <ElevatorCarriage withPart />
      </group>

      {/* Carro de salida: baja el producto terminado de ST 230 (tramo B) */}
      <group ref={outputRef} position={[0, liftTop, span / 2 - 0.3]}>
        <ElevatorCarriage withPart={false} />
      </group>

      {/* Conveyors de enlace con cada tramo, a la altura de transporte */}
      {[-span / 2 + 0.3, span / 2 - 0.3].map((z) => (
        <mesh key={`link-${z}`} castShadow receiveShadow position={[-0.62, liftTop - 0.06, z]}>
          <boxGeometry args={[1.2, 0.1, 0.46]} />
          <meshStandardMaterial color="#8d9499" roughness={0.46} metalness={0.5} />
        </mesh>
      ))}

      {/* Resguardo de malla metalica a los costados del vano */}
      {[-span / 2, span / 2].map((z) => (
        <group key={`mesh-${z}`} position={[0, 0, z + (z > 0 ? -0.9 : 0.9)]}>
          {[-(thickness + 0.3) / 2, (thickness + 0.3) / 2].map((x) => (
            <mesh key={`mesh-post-${x}`} castShadow position={[x, clearHeight / 2, 0]}>
              <boxGeometry args={[0.06, clearHeight, 0.06]} />
              <meshStandardMaterial color="#b9c0c5" roughness={0.4} metalness={0.66} />
            </mesh>
          ))}
          {Array.from({ length: 9 }).map((_, index) => (
            <mesh key={`mesh-h-${index}`} position={[0, 0.3 + index * 0.32, 0]}>
              <boxGeometry args={[0.02, 0.015, 1.5]} />
              <meshStandardMaterial color="#aeb5ba" roughness={0.42} metalness={0.7} />
            </mesh>
          ))}
          {Array.from({ length: 8 }).map((_, index) => (
            <mesh key={`mesh-v-${index}`} position={[0, clearHeight / 2 + 0.15, -0.68 + index * 0.19]}>
              <boxGeometry args={[0.02, clearHeight - 0.4, 0.015]} />
              <meshStandardMaterial color="#aeb5ba" roughness={0.42} metalness={0.7} />
            </mesh>
          ))}
        </group>
      ))}

      {/* Pantalla de reportes sobre el vano */}
      <group position={[(thickness + 0.3) / 2 + 0.06, clearHeight + beamHeight + 0.42, 0]} rotation={[0, Math.PI / 2, 0]}>
        <mesh castShadow>
          <boxGeometry args={[1.5, 0.88, 0.07]} />
          <meshStandardMaterial color="#16181c" roughness={0.45} metalness={0.2} />
        </mesh>
        <mesh position={[0, 0, 0.04]}>
          <planeGeometry args={[1.42, 0.8]} />
          <meshStandardMaterial color="#dceaf7" emissive="#7fb3e0" emissiveIntensity={0.6} />
        </mesh>
        <mesh position={[0, 0.33, 0.045]}>
          <planeGeometry args={[1.42, 0.12]} />
          <meshStandardMaterial color="#1d78c4" emissive="#1d78c4" emissiveIntensity={0.35} />
        </mesh>
        {[-0.5, -0.12, 0.26].map((x, index) => (
          <mesh key={x} position={[x, -0.06, 0.046]}>
            <planeGeometry args={[0.3, 0.34]} />
            <meshStandardMaterial
              color={index === 0 ? '#8fd6a0' : '#bcd9f2'}
              emissive={index === 0 ? '#4ea862' : '#79aad6'}
              emissiveIntensity={0.4}
            />
          </mesh>
        ))}
      </group>

      {/* Refuerzos diagonales bajo la pantalla, como en el acceso real */}
      {[-1, 1].map((side) => (
        <mesh
          key={`brace-${side}`}
          castShadow
          position={[0, clearHeight - 0.12, side * (span / 2 - 1.15)]}
          rotation={[side * Math.PI / 4, 0, 0]}
        >
          <boxGeometry args={[thickness + 0.24, 0.1, 0.62]} />
          <meshStandardMaterial color="#15181c" roughness={0.6} metalness={0.25} />
        </mesh>
      ))}

      {/* Puerta de malla con manijas negras, del lado de acceso */}
      {[-1, 1].map((side) => (
        <group key={`door-${side}`} position={[(thickness + 0.3) / 2 + 0.02, 0, side * (span / 2 - 2.1)]}>
          <mesh castShadow position={[0, clearHeight / 2, 0]}>
            <boxGeometry args={[0.05, clearHeight - 0.2, 0.05]} />
            <meshStandardMaterial color="#c9cdd1" roughness={0.4} metalness={0.55} />
          </mesh>
          <mesh castShadow position={[0.04, clearHeight * 0.45, side * 0.12]}>
            <boxGeometry args={[0.05, 0.34, 0.05]} />
            <meshStandardMaterial color="#15181c" roughness={0.62} metalness={0.2} />
          </mesh>
        </group>
      ))}

      {/* Torreta de estado */}
      <group position={[0, clearHeight + beamHeight, -span / 2]}>
        <mesh castShadow position={[0, 0.18, 0]}>
          <cylinderGeometry args={[0.035, 0.04, 0.36, 10]} />
          <meshStandardMaterial color="#50555d" roughness={0.5} metalness={0.42} />
        </mesh>
        <mesh castShadow position={[0, 0.44, 0]}>
          <cylinderGeometry args={[0.055, 0.055, 0.09, 14]} />
          <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.55} />
        </mesh>
      </group>
    </group>
  )
}

function ElevatorCarriage({ withPart }: { withPart: boolean }) {
  return (
    <group>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[0.66, 0.08, 0.54]} />
        <meshStandardMaterial color="#64748b" roughness={0.44} metalness={0.55} />
      </mesh>
      <mesh castShadow position={[0, -0.09, 0]}>
        <boxGeometry args={[0.54, 0.05, 0.42]} />
        <meshStandardMaterial color="#111827" roughness={0.85} metalness={0.05} />
      </mesh>
      {withPart ? (
        <mesh castShadow position={[0, 0.14, 0]}>
          <boxGeometry args={[0.44, 0.2, 0.32]} />
          <meshStandardMaterial color="#aab2b8" roughness={0.42} metalness={0.68} />
        </mesh>
      ) : (
        <mesh castShadow position={[0, 0.14, 0]}>
          <boxGeometry args={[0.46, 0.22, 0.34]} />
          <meshStandardMaterial color="#14171b" roughness={0.86} metalness={0.04} />
        </mesh>
      )}
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Grua de portico del retorno
 * ------------------------------------------------------------------ */

export function OverheadCrane({ prop }: { prop: FassyPropConfig }) {
  const [width, height, depth] = prop.size ?? [2.6, 3.9, 6.5]
  const columnHeight = height - 0.35

  return (
    <group position={prop.position} rotation={prop.rotation}>
      {[-width / 2, width / 2].map((x) =>
        [-depth / 2, depth / 2].map((z) => (
          <group key={`col-${x}-${z}`} position={[x, 0, z]}>
            <mesh castShadow receiveShadow position={[0, columnHeight / 2, 0]}>
              <boxGeometry args={[0.22, columnHeight, 0.22]} />
              <meshStandardMaterial color="#9ca3a8" roughness={0.46} metalness={0.55} />
            </mesh>
            <mesh receiveShadow position={[0, 0.06, 0]}>
              <boxGeometry args={[0.5, 0.12, 0.5]} />
              <meshStandardMaterial color="#4b5563" roughness={0.8} metalness={0.14} />
            </mesh>
          </group>
        )),
      )}

      {[-width / 2, width / 2].map((x) => (
        <mesh key={`beam-${x}`} castShadow position={[x, columnHeight, 0]}>
          <boxGeometry args={[0.24, 0.26, depth]} />
          <meshStandardMaterial color="#9ca3a8" roughness={0.6} metalness={0.3} />
        </mesh>
      ))}

      <group position={[0, columnHeight - 0.02, depth * 0.1]}>
        <mesh castShadow>
          <boxGeometry args={[width, 0.2, 0.28]} />
          <meshStandardMaterial color="#cbd5e1" roughness={0.42} metalness={0.6} />
        </mesh>
        <mesh castShadow position={[0, -0.24, 0]}>
          <boxGeometry args={[0.4, 0.3, 0.34]} />
          <meshStandardMaterial color="#334155" roughness={0.48} metalness={0.42} />
        </mesh>
        <mesh position={[0, -0.75, 0]}>
          <cylinderGeometry args={[0.012, 0.012, 0.72, 8]} />
          <meshStandardMaterial color="#94a3b8" roughness={0.35} metalness={0.8} />
        </mesh>
        <mesh castShadow position={[0, -1.16, 0]}>
          <boxGeometry args={[0.2, 0.12, 0.2]} />
          <meshStandardMaterial color="#ea580c" roughness={0.6} metalness={0.2} />
        </mesh>
      </group>
    </group>
  )
}

/* ------------------------------------------------------------------ *
 * Mobiliario y servicios
 * ------------------------------------------------------------------ */

export function ServiceCabinet({ prop }: { prop: FassyPropConfig }) {
  const [width, height, depth] = prop.size ?? [0.85, 1.35, 0.75]
  const accent = prop.accentColor ?? '#94a3b8'

  return (
    <group position={prop.position} rotation={prop.rotation}>
      <mesh castShadow receiveShadow position={[0, height / 2, 0]}>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial color="#dfe3e6" roughness={0.7} metalness={0.12} />
      </mesh>
      <mesh position={[0, height - 0.13, depth / 2 + 0.005]}>
        <planeGeometry args={[width * 0.94, 0.16]} />
        <meshStandardMaterial color={accent} roughness={0.6} metalness={0.15} />
      </mesh>
      <mesh position={[0, height * 0.44, depth / 2 + 0.004]}>
        <planeGeometry args={[width * 0.88, height * 0.62]} />
        <meshStandardMaterial color="#c9ced2" roughness={0.72} metalness={0.1} />
      </mesh>
      <mesh castShadow position={[width * 0.34, height * 0.44, depth / 2 + 0.03]}>
        <boxGeometry args={[0.04, 0.16, 0.04]} />
        <meshStandardMaterial color="#3f4650" roughness={0.5} metalness={0.42} />
      </mesh>
      <mesh receiveShadow position={[0, 0.05, 0]}>
        <boxGeometry args={[width * 1.02, 0.1, depth * 1.02]} />
        <meshStandardMaterial color="#4b5563" roughness={0.78} metalness={0.14} />
      </mesh>
    </group>
  )
}

export function MaterialTrolley({ prop }: { prop: FassyPropConfig }) {
  const width = 0.98
  const depth = 0.7
  const height = 1.0

  return (
    <group position={prop.position} rotation={prop.rotation}>
      {[-width / 2 + 0.05, width / 2 - 0.05].map((x) =>
        [-depth / 2 + 0.05, depth / 2 - 0.05].map((z) => (
          <mesh key={`post-${x}-${z}`} castShadow receiveShadow position={[x, height / 2 + 0.1, z]}>
            <boxGeometry args={[0.06, height, 0.06]} />
            <meshStandardMaterial color="#b9c0c5" roughness={0.4} metalness={0.66} />
          </mesh>
        )),
      )}
      {[0.24, 0.72].map((y) => (
        <mesh key={`shelf-${y}`} castShadow receiveShadow position={[0, y, 0]}>
          <boxGeometry args={[width, 0.035, depth]} />
          <meshStandardMaterial color="#9ca3a8" roughness={0.48} metalness={0.5} />
        </mesh>
      ))}
      {[0.38, 0.86].map((y) => (
        <group key={`klt-${y}`} position={[0, y, 0]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[width * 0.86, 0.24, depth * 0.82]} />
            <meshStandardMaterial color="#14171b" roughness={0.88} metalness={0.03} />
          </mesh>
          <mesh position={[0, 0.02, (depth * 0.82) / 2 + 0.002]}>
            <planeGeometry args={[0.26, 0.14]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.92} />
          </mesh>
        </group>
      ))}
      {[-width / 2 + 0.12, width / 2 - 0.12].map((x) =>
        [-depth / 2 + 0.12, depth / 2 - 0.12].map((z) => (
          <mesh key={`wheel-${x}-${z}`} castShadow position={[x, 0.06, z]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.06, 0.06, 0.04, 12]} />
            <meshStandardMaterial color="#1f2937" roughness={0.8} metalness={0.1} />
          </mesh>
        )),
      )}
    </group>
  )
}

export function PalletStack({ prop }: { prop: FassyPropConfig }) {
  return (
    <group position={prop.position} rotation={prop.rotation}>
      <mesh castShadow receiveShadow position={[0, 0.07, 0]}>
        <boxGeometry args={[1.25, 0.14, 1.02]} />
        <meshStandardMaterial color="#22262b" roughness={0.9} metalness={0.03} />
      </mesh>
      {[-0.3, 0.3].map((x) =>
        [-0.24, 0.24].map((z) =>
          [0.26, 0.5, 0.74].map((y) => (
            <group key={`box-${x}-${z}-${y}`} position={[x, y, z]}>
              <mesh castShadow receiveShadow>
                <boxGeometry args={[0.56, 0.22, 0.44]} />
                <meshStandardMaterial color="#14171b" roughness={0.88} metalness={0.03} />
              </mesh>
              <mesh position={[0, 0.02, 0.222]}>
                <planeGeometry args={[0.24, 0.13]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.92} />
              </mesh>
            </group>
          )),
        ),
      )}
    </group>
  )
}

export function EsdChair({ prop }: { prop: FassyPropConfig }) {
  const seatHeight = 0.68

  return (
    <group position={prop.position} rotation={prop.rotation}>
      <mesh castShadow receiveShadow position={[0, seatHeight, 0]}>
        <cylinderGeometry args={[0.21, 0.21, 0.07, 18]} />
        <meshStandardMaterial color="#2b3038" roughness={0.85} metalness={0.06} />
      </mesh>
      <mesh castShadow position={[0, seatHeight + 0.3, -0.19]} rotation={[0.16, 0, 0]}>
        <boxGeometry args={[0.34, 0.3, 0.06]} />
        <meshStandardMaterial color="#2b3038" roughness={0.85} metalness={0.06} />
      </mesh>
      <mesh castShadow position={[0, seatHeight / 2, 0]}>
        <cylinderGeometry args={[0.04, 0.045, seatHeight, 12]} />
        <meshStandardMaterial color="#9ca3a8" roughness={0.36} metalness={0.68} />
      </mesh>
      <mesh position={[0, 0.28, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.21, 0.014, 8, 20]} />
        <meshStandardMaterial color="#cbd5e1" roughness={0.3} metalness={0.75} />
      </mesh>
      {Array.from({ length: 5 }).map((_, index) => (
        <group key={index} rotation={[0, (index / 5) * Math.PI * 2, 0]}>
          <mesh castShadow position={[0, 0.06, 0.14]}>
            <boxGeometry args={[0.05, 0.04, 0.28]} />
            <meshStandardMaterial color="#1f2937" roughness={0.72} metalness={0.14} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

export function SafetyBoard({ prop }: { prop: FassyPropConfig }) {
  const width = 1.9
  const height = 1.25
  const baseY = 1.0

  return (
    <group position={prop.position} rotation={prop.rotation}>
      {[-width / 2 + 0.08, width / 2 - 0.08].map((x) => (
        <mesh key={`post-${x}`} castShadow receiveShadow position={[x, (baseY + height / 2) / 2, 0]}>
          <boxGeometry args={[0.07, baseY + height / 2, 0.07]} />
          <meshStandardMaterial color="#8d9499" roughness={0.44} metalness={0.6} />
        </mesh>
      ))}
      <mesh castShadow receiveShadow position={[0, baseY + height / 2, 0]}>
        <boxGeometry args={[width, height, 0.04]} />
        <meshStandardMaterial color="#f8fafc" roughness={0.86} metalness={0.04} />
      </mesh>
      <mesh position={[0, baseY + height - 0.14, 0.021]}>
        <planeGeometry args={[width - 0.06, 0.2]} />
        <meshStandardMaterial color="#1e3a8a" roughness={0.7} />
      </mesh>
      <mesh position={[-width / 2 + 0.22, baseY + height / 2 - 0.16, 0.021]}>
        <planeGeometry args={[0.34, height - 0.6]} />
        <meshStandardMaterial color="#e2e8f0" roughness={0.9} />
      </mesh>
      <mesh position={[0.05, baseY + height / 2 - 0.2, 0.022]}>
        <planeGeometry args={[width * 0.56, height * 0.5]} />
        <meshStandardMaterial color="#ffffff" roughness={0.92} />
      </mesh>
      {[0.1, -0.1].map((offsetY) =>
        Array.from({ length: 7 }).map((_, index) => (
          <mesh
            key={`plan-${offsetY}-${index}`}
            position={[-0.28 + index * 0.11, baseY + height / 2 - 0.2 + offsetY, 0.024]}
          >
            <planeGeometry args={[0.075, 0.09]} />
            <meshStandardMaterial color="#cbd5e1" roughness={0.9} />
          </mesh>
        )),
      )}
      {Array.from({ length: 6 }).map((_, index) => (
        <mesh key={`hazard-${index}`} position={[width / 2 - 0.2, baseY + height - 0.5 - index * 0.13, 0.023]}>
          <circleGeometry args={[0.045, 3]} />
          <meshStandardMaterial color={index % 3 === 2 ? '#f87171' : '#facc15'} roughness={0.7} />
        </mesh>
      ))}
    </group>
  )
}

export function RackWall({ prop }: { prop: FassyPropConfig }) {
  const [width, height, depth] = prop.size ?? [4.6, 2.3, 1.0]
  const levels = [0.35, 0.95, 1.55]
  const bays = Math.max(2, Math.round(width / 1.15))

  return (
    <group position={prop.position} rotation={prop.rotation}>
      {Array.from({ length: bays + 1 }).map((_, index) => {
        const x = -width / 2 + (width * index) / bays

        return [-depth / 2 + 0.06, depth / 2 - 0.06].map((z) => (
          <mesh key={`post-${index}-${z}`} castShadow receiveShadow position={[x, height / 2, z]}>
            <boxGeometry args={[0.07, height, 0.07]} />
            <meshStandardMaterial color="#1d4ed8" roughness={0.55} metalness={0.35} />
          </mesh>
        ))
      })}
      {levels.map((y) => (
        <mesh key={`shelf-${y}`} castShadow receiveShadow position={[0, y, 0]}>
          <boxGeometry args={[width, 0.05, depth * 0.9]} />
          <meshStandardMaterial color="#9ca3a8" roughness={0.5} metalness={0.45} />
        </mesh>
      ))}
      {levels.map((y) =>
        Array.from({ length: bays * 2 }).map((_, index) => {
          const x = -width / 2 + (width * (index + 0.5)) / (bays * 2)

          return (
            <group key={`box-${y}-${index}`} position={[x, y + 0.17, 0]}>
              <mesh castShadow receiveShadow>
                <boxGeometry args={[width / (bays * 2) - 0.08, 0.28, depth * 0.7]} />
                <meshStandardMaterial color="#14171b" roughness={0.88} metalness={0.03} />
              </mesh>
              <mesh position={[0, 0.02, (depth * 0.7) / 2 + 0.003]}>
                <planeGeometry args={[0.2, 0.11]} />
                <meshStandardMaterial color="#f8fafc" roughness={0.92} />
              </mesh>
            </group>
          )
        }),
      )}
      <mesh castShadow position={[0, height + 0.16, 0]}>
        <boxGeometry args={[width * 0.5, 0.26, 0.05]} />
        <meshStandardMaterial color="#1e3a8a" roughness={0.6} metalness={0.15} />
      </mesh>
    </group>
  )
}

/**
 * Pila de contenedores KLT negros KOSTAL sobre tarima, con etiqueta blanca al
 * frente y tapa en la caja superior. `size` = [ancho, numero de cajas, fondo].
 */
export function KltStack({ prop }: { prop: FassyPropConfig }) {
  const [width, levels, depth] = prop.size ?? [0.62, 4, 0.44]
  const boxHeight = 0.24
  const count = Math.max(1, Math.round(levels))

  return (
    <group position={prop.position} rotation={prop.rotation}>
      {/* Tarima */}
      <mesh castShadow receiveShadow position={[0, 0.06, 0]}>
        <boxGeometry args={[width + 0.14, 0.12, depth + 0.12]} />
        <meshStandardMaterial color="#22262b" roughness={0.9} metalness={0.03} />
      </mesh>

      {Array.from({ length: count }).map((_, index) => (
        <group key={index} position={[0, 0.12 + boxHeight / 2 + index * boxHeight, 0]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[width, boxHeight - 0.01, depth]} />
            <meshStandardMaterial color="#141719" roughness={0.88} metalness={0.04} />
          </mesh>
          {/* Nervadura del contenedor */}
          <mesh position={[0, boxHeight * 0.34, depth / 2 + 0.002]}>
            <planeGeometry args={[width * 0.96, 0.03]} />
            <meshStandardMaterial color="#0d0f11" roughness={0.9} />
          </mesh>
          {/* Etiqueta blanca */}
          <mesh position={[0, -0.02, depth / 2 + 0.003]}>
            <planeGeometry args={[width * 0.42, 0.11]} />
            <meshStandardMaterial color="#f8fafc" roughness={0.92} />
          </mesh>
          {/* Logo amarillo ESD */}
          <mesh position={[width * 0.34, 0.05, depth / 2 + 0.003]}>
            <circleGeometry args={[0.022, 12]} />
            <meshStandardMaterial color="#d8b400" roughness={0.7} />
          </mesh>
        </group>
      ))}

      {/* Tapa de la caja superior */}
      <mesh castShadow receiveShadow position={[0, 0.12 + count * boxHeight + 0.015, 0]}>
        <boxGeometry args={[width + 0.03, 0.03, depth + 0.03]} />
        <meshStandardMaterial color="#1b1e21" roughness={0.7} metalness={0.06} />
      </mesh>
    </group>
  )
}

/** Carro vacio de perfil de aluminio, con barandal y ruedas. */
export function EmptyTrolley({ prop }: { prop: FassyPropConfig }) {
  const width = 1.05
  const depth = 0.68
  const height = 0.86

  return (
    <group position={prop.position} rotation={prop.rotation}>
      {[-width / 2 + 0.05, width / 2 - 0.05].map((x) =>
        [-depth / 2 + 0.05, depth / 2 - 0.05].map((z) => (
          <mesh key={`post-${x}-${z}`} castShadow receiveShadow position={[x, height / 2 + 0.08, z]}>
            <boxGeometry args={[0.05, height, 0.05]} />
            <meshStandardMaterial color="#c3c9cd" roughness={0.4} metalness={0.66} />
          </mesh>
        )),
      )}
      {[0.22, 0.64].map((y) => (
        <mesh key={`shelf-${y}`} castShadow receiveShadow position={[0, y, 0]}>
          <boxGeometry args={[width, 0.03, depth]} />
          <meshStandardMaterial color="#aeb5ba" roughness={0.48} metalness={0.5} />
        </mesh>
      ))}
      {/* Barandal de empuje */}
      <mesh castShadow position={[0, height + 0.1, -depth / 2 + 0.05]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.022, 0.022, width, 10]} />
        <meshStandardMaterial color="#c3c9cd" roughness={0.35} metalness={0.7} />
      </mesh>
      {[-width / 2 + 0.12, width / 2 - 0.12].map((x) =>
        [-depth / 2 + 0.12, depth / 2 - 0.12].map((z) => (
          <mesh key={`wheel-${x}-${z}`} castShadow position={[x, 0.05, z]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 0.035, 12]} />
            <meshStandardMaterial color="#15181c" roughness={0.8} metalness={0.1} />
          </mesh>
        )),
      )}
    </group>
  )
}

/** Tambo rojo de residuos peligrosos con bolsa negra, sobre base con pedal. */
export function WasteDrum({ prop }: { prop: FassyPropConfig }) {
  return (
    <group position={prop.position} rotation={prop.rotation}>
      <mesh receiveShadow position={[0, 0.05, 0.05]}>
        <boxGeometry args={[0.5, 0.1, 0.6]} />
        <meshStandardMaterial color="#c0392b" roughness={0.72} metalness={0.05} />
      </mesh>
      <mesh castShadow receiveShadow position={[0, 0.4, 0]}>
        <cylinderGeometry args={[0.26, 0.23, 0.62, 18]} />
        <meshStandardMaterial color="#d63a2b" roughness={0.68} metalness={0.06} />
      </mesh>
      {/* Tapa abatible */}
      <mesh castShadow position={[0, 0.74, -0.03]} rotation={[0.22, 0, 0]}>
        <cylinderGeometry args={[0.27, 0.27, 0.06, 18]} />
        <meshStandardMaterial color="#c0392b" roughness={0.66} metalness={0.06} />
      </mesh>
      {/* Bolsa negra asomando */}
      <mesh position={[0, 0.7, 0.06]}>
        <cylinderGeometry args={[0.24, 0.2, 0.16, 16]} />
        <meshStandardMaterial color="#15181c" roughness={0.9} metalness={0.02} />
      </mesh>
      {/* Escuadras amarillas de posicion */}
      {[-1, 1].map((sx) => (
        <mesh key={sx} receiveShadow position={[sx * 0.42, 0.008, 0.42]}>
          <boxGeometry args={[0.3, 0.016, 0.075]} />
          <meshStandardMaterial color="#f2c500" roughness={0.85} />
        </mesh>
      ))}
    </group>
  )
}

/** Escalerilla de dos peldanos con pasamanos, la del horno. */
export function StepLadder({ prop }: { prop: FassyPropConfig }) {
  return (
    <group position={prop.position} rotation={prop.rotation}>
      {[0.18, 0.4].map((y, index) => (
        <mesh key={y} castShadow receiveShadow position={[0, y, -index * 0.24]}>
          <boxGeometry args={[0.62, 0.04, 0.28]} />
          <meshStandardMaterial color="#8d9499" roughness={0.6} metalness={0.35} />
        </mesh>
      ))}
      {[-0.28, 0.28].map((x) =>
        [0.12, -0.36].map((z) => (
          <mesh key={`leg-${x}-${z}`} castShadow position={[x, 0.22, z]}>
            <boxGeometry args={[0.04, 0.44, 0.04]} />
            <meshStandardMaterial color="#aeb5ba" roughness={0.45} metalness={0.55} />
          </mesh>
        )),
      )}
      {/* Pasamanos curvo */}
      {[-0.28, 0.28].map((x) => (
        <mesh key={`rail-${x}`} castShadow position={[x, 0.72, -0.36]}>
          <boxGeometry args={[0.04, 0.62, 0.04]} />
          <meshStandardMaterial color="#aeb5ba" roughness={0.45} metalness={0.55} />
        </mesh>
      ))}
      <mesh castShadow position={[0, 1.02, -0.36]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.022, 0.022, 0.56, 10]} />
        <meshStandardMaterial color="#aeb5ba" roughness={0.4} metalness={0.6} />
      </mesh>
      {[-0.28, 0.28].map((x) =>
        [0.12, -0.36].map((z) => (
          <mesh key={`wheel-${x}-${z}`} castShadow position={[x, 0.03, z]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.035, 0.035, 0.03, 10]} />
            <meshStandardMaterial color="#d0d4d7" roughness={0.5} metalness={0.3} />
          </mesh>
        )),
      )}
    </group>
  )
}

/** Punto unico de despacho tipo de prop -> componente. */
export function FassyProp({ prop }: { prop: FassyPropConfig }) {
  switch (prop.kind) {
    case 'elevator-arch':
      return <ElevatorArch prop={prop} />
    case 'overhead-crane':
      return <OverheadCrane prop={prop} />
    case 'service-cabinet':
      return <ServiceCabinet prop={prop} />
    case 'material-trolley':
      return <MaterialTrolley prop={prop} />
    case 'pallet-stack':
      return <PalletStack prop={prop} />
    case 'esd-chair':
      return <EsdChair prop={prop} />
    case 'safety-board':
      return <SafetyBoard prop={prop} />
    case 'rack-wall':
      return <RackWall prop={prop} />
    case 'klt-stack':
      return <KltStack prop={prop} />
    case 'empty-trolley':
      return <EmptyTrolley prop={prop} />
    case 'waste-drum':
      return <WasteDrum prop={prop} />
    case 'step-ladder':
      return <StepLadder prop={prop} />
    default:
      return null
  }
}
