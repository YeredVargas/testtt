interface CrosshairProps {
  visible: boolean
}

export function Crosshair({ visible }: CrosshairProps) {
  if (!visible) {
    return null
  }

  return <div className="crosshair" aria-hidden="true" />
}
