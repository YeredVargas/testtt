import { Text } from '@react-three/drei'
import { memo } from 'react'
import {
  INFORMATION_CENTER_HEIGHT,
  informationCenterDisplays,
  informationCenterPosition,
  INFORMATION_CENTER_ROTATION_Y,
  INFORMATION_CENTER_RADIUS,
  INFORMATION_CENTER_SCREEN_HEIGHT,
  INFORMATION_CENTER_SCREEN_WIDTH,
} from '../data/informationCenter'
import { IndustrialScreen } from './IndustrialScreen'
import type { MediaModalData } from '../types/factory'

function getMediaType(source: string): 'image' | 'gif' | 'video' {
  const extension = source.split('?')[0].toLowerCase().split('.').pop()

  if (extension === 'gif') {
    return 'gif'
  }

  if (extension === 'mp4' || extension === 'webm') {
    return 'video'
  }

  return 'image'
}

interface InformationCenterProps {
  onOpenMedia?: (media: MediaModalData) => void
}

export const InformationCenter = memo(function InformationCenter({ onOpenMedia }: InformationCenterProps) {
  const apothem = INFORMATION_CENTER_RADIUS * Math.cos(Math.PI / 6)
  const displayRingRadius = apothem + 0.02

  return (
    <group position={informationCenterPosition} rotation={[0, INFORMATION_CENTER_ROTATION_Y, 0]}>
      <mesh castShadow receiveShadow position={[0, 0.1, 0]}>
        <cylinderGeometry args={[INFORMATION_CENTER_RADIUS + 0.34, INFORMATION_CENTER_RADIUS + 0.4, 0.2, 6]} />
        <meshStandardMaterial color="#3a4148" roughness={0.84} metalness={0.18} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 1.18, 0]}>
        <cylinderGeometry args={[INFORMATION_CENTER_RADIUS, INFORMATION_CENTER_RADIUS, 2.16, 6]} />
        <meshStandardMaterial color="#d9dde0" roughness={0.66} metalness={0.08} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, INFORMATION_CENTER_HEIGHT - 0.1, 0]}>
        <cylinderGeometry args={[INFORMATION_CENTER_RADIUS + 0.26, INFORMATION_CENTER_RADIUS + 0.18, 0.2, 6]} />
        <meshStandardMaterial color="#66707a" roughness={0.58} metalness={0.2} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, INFORMATION_CENTER_HEIGHT + 0.18, 0]}>
        <cylinderGeometry args={[0.34, 0.42, 0.3, 6]} />
        <meshStandardMaterial color="#8f99a3" roughness={0.52} metalness={0.26} />
      </mesh>

      {Array.from({ length: 6 }).map((_, index) => {
        const display = informationCenterDisplays[index]
        const angle = (index * Math.PI) / 3
        const mediaSource = display.media.source
        const mediaType = getMediaType(mediaSource)

        return (
          <group
            key={display.id}
            position={[Math.cos(angle) * displayRingRadius, 1.44, Math.sin(angle) * displayRingRadius]}
            rotation={[0, Math.PI / 2 - angle, 0]}
          >
            <mesh castShadow receiveShadow position={[0, 0, -0.045]}>
              <boxGeometry args={[INFORMATION_CENTER_SCREEN_WIDTH + 0.16, INFORMATION_CENTER_SCREEN_HEIGHT + 0.14, 0.12]} />
              <meshStandardMaterial color="#111827" roughness={0.34} metalness={0.26} />
            </mesh>

            <mesh castShadow receiveShadow position={[0, -0.06, -0.11]}>
              <boxGeometry args={[INFORMATION_CENTER_SCREEN_WIDTH + 0.22, INFORMATION_CENTER_SCREEN_HEIGHT + 0.24, 0.04]} />
              <meshStandardMaterial color="#cfd6dc" roughness={0.8} metalness={0.04} />
            </mesh>

            <mesh position={[0, 0, 0.012]}>
              <boxGeometry args={[INFORMATION_CENTER_SCREEN_WIDTH + 0.08, INFORMATION_CENTER_SCREEN_HEIGHT + 0.08, 0.02]} />
              <meshStandardMaterial color="#050505" roughness={0.18} metalness={0.22} />
            </mesh>

            <group position={[0, 0, 0.022]}>
              <IndustrialScreen
                media={display.media}
                width={INFORMATION_CENTER_SCREEN_WIDTH}
                height={INFORMATION_CENTER_SCREEN_HEIGHT}
              />
            </group>

            <mesh position={[0, -0.46, 0.03]}>
              <boxGeometry args={[0.72, 0.14, 0.03]} />
              <meshStandardMaterial color="#234a78" roughness={0.52} metalness={0.16} />
            </mesh>

            <Text position={[0, -0.46, 0.05]} fontSize={0.075} color="#f8fafc" anchorX="center" anchorY="middle">
              INFO
            </Text>

            <mesh
              position={[0, 0, 0.04]}
              onClick={() => {
                onOpenMedia?.({
                  id: display.id,
                  title: display.title,
                  source: mediaSource,
                  mediaType,
                })
              }}
              userData={{
                interactive: true,
                interactionType: 'media-display',
                displayId: display.id,
                title: display.title,
                mediaSource,
                mediaType,
              }}
            >
              <planeGeometry args={[INFORMATION_CENTER_SCREEN_WIDTH, INFORMATION_CENTER_SCREEN_HEIGHT]} />
              <meshBasicMaterial transparent opacity={0} depthWrite={false} colorWrite={false} />
            </mesh>
          </group>
        )
      })}

      <Text position={[0, 2.64, 0]} fontSize={0.13} color="#f8fafc" anchorX="center" anchorY="middle" maxWidth={1.9}>
        CENTRO DE INFORMACION
      </Text>
    </group>
  )
})
