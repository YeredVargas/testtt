import { useCallback, useEffect, useRef, useState } from 'react'
import { CameraDebug } from './components/CameraDebug'
import { FactoryScene } from './components/FactoryScene'
import { Crosshair } from './components/Crosshair'
import { GraphicsQualityControl } from './components/GraphicsQualityControl'
import { Instructions } from './components/Instructions'
import { MediaModal } from './components/MediaModal'
import { PauseMenu } from './components/PauseMenu'
import { PerformanceDebugPanel } from './components/PerformanceDebugPanel'
import { GRAPHICS_QUALITY_SETTINGS, GraphicsQualityContext } from './graphicsQuality'
import { navigationSections } from './data/navigationMenu'
import { displayStations } from './data/smtLine'
import type {
  CameraDebugState,
  CameraSnapshot,
  GraphicsQuality,
  MediaModalData,
  SceneControllerApi,
} from './types/factory'

const DEBUG_CAMERA = false
const DEFAULT_GRAPHICS_QUALITY: GraphicsQuality = 'medium'
const GRAPHICS_QUALITY_STORAGE_KEY = 'smt-graphics-quality'

function App() {
  const debugLocked =
    typeof window !== 'undefined' &&
    import.meta.env.DEV &&
    new URLSearchParams(window.location.search).get('debugLock') === '1'

  const [isPointerLocked, setIsPointerLocked] = useState(false)
  const [hasStarted, setHasStarted] = useState(debugLocked)
  const [pauseMenuOpen, setPauseMenuOpen] = useState(false)
  const [activeMedia, setActiveMedia] = useState<MediaModalData | null>(null)
  const [interactionPrompt, setInteractionPrompt] = useState<string | null>(null)
  const [graphicsQuality, setGraphicsQuality] = useState<GraphicsQuality>(() => {
    if (typeof window === 'undefined') {
      return DEFAULT_GRAPHICS_QUALITY
    }

    const storedQuality = window.localStorage.getItem(GRAPHICS_QUALITY_STORAGE_KEY)

    return storedQuality === 'low' || storedQuality === 'medium' || storedQuality === 'high'
      ? storedQuality
      : DEFAULT_GRAPHICS_QUALITY
  })
  const [cameraDebug, setCameraDebug] = useState<CameraDebugState>({
    locked: false,
    position: [-25, 1.7, 8.6],
    rotation: [0, 0, 0],
  })
  const controllerRef = useRef<SceneControllerApi | null>(null)
  const savedCameraStateRef = useRef<CameraSnapshot | null>(null)
  const suppressPauseOnUnlockRef = useRef(false)

  useEffect(() => {
    window.localStorage.setItem(GRAPHICS_QUALITY_STORAGE_KEY, graphicsQuality)
  }, [graphicsQuality])

  const handlePointerLockChange = useCallback((isLocked: boolean) => {
    setIsPointerLocked(isLocked)

    if (isLocked) {
      setHasStarted(true)
      setPauseMenuOpen(false)
      suppressPauseOnUnlockRef.current = false
      return
    }

    if (suppressPauseOnUnlockRef.current) {
      suppressPauseOnUnlockRef.current = false
      return
    }

    if (hasStarted && !activeMedia && !debugLocked) {
      setInteractionPrompt(null)
      setPauseMenuOpen(true)
    }
  }, [activeMedia, debugLocked, hasStarted])

  const handleOpenMedia = useCallback((media: MediaModalData) => {
    if (activeMedia) {
      return
    }

    savedCameraStateRef.current = controllerRef.current?.saveCameraState() ?? null
    controllerRef.current?.clearMovement()
    suppressPauseOnUnlockRef.current = true
    setPauseMenuOpen(false)
    controllerRef.current?.unlock()
    setInteractionPrompt(null)
    setActiveMedia(media)
  }, [activeMedia])

  const resumeRoute = useCallback(() => {
    controllerRef.current?.restoreCameraState(savedCameraStateRef.current)
    controllerRef.current?.clearMovement()
    setActiveMedia(null)
    setPauseMenuOpen(false)

    if (!debugLocked) {
      controllerRef.current?.lock()
    }
  }, [debugLocked])

  const handleResumePausedTour = useCallback(() => {
    controllerRef.current?.clearMovement()
    setPauseMenuOpen(false)

    if (!debugLocked) {
      controllerRef.current?.lock()
    }
  }, [debugLocked])

  const handleNavigate = useCallback((destinationId: string) => {
    const destination = navigationSections
      .flatMap((section) => section.destinations)
      .find((entry) => entry.id === destinationId)

    if (!destination) {
      return
    }

    controllerRef.current?.clearMovement()
    controllerRef.current?.teleportTo(destination.position, destination.lookAt)
    setInteractionPrompt(null)
    setPauseMenuOpen(false)

    if (!debugLocked) {
      controllerRef.current?.lock()
    }
  }, [debugLocked])

  const handleCloseMedia = useCallback(() => {
    resumeRoute()
  }, [resumeRoute])

  const handleCloseAndContinue = useCallback(() => {
    resumeRoute()
  }, [resumeRoute])

  const handleControllerReady = useCallback((controller: SceneControllerApi) => {
    controllerRef.current = controller
  }, [])

  useEffect(() => {
    if (!import.meta.env.DEV) {
      return
    }

    const openDisplay = (id: string) => {
      const station = displayStations.find((entry) => entry.id === id)

      if (!station) {
        return false
      }

      const source = station.media.source
      const cleanSource = source.split('?')[0].toLowerCase()
      const mediaType = cleanSource.endsWith('.gif')
        ? 'gif'
        : cleanSource.endsWith('.mp4') || cleanSource.endsWith('.webm')
          ? 'video'
          : 'image'

      handleOpenMedia({
        id: station.id,
        title: station.title,
        source,
        mediaType,
      })

      return true
    }

    ;(window as Window & { __SMT_DEBUG_OPEN_DISPLAY?: typeof openDisplay }).__SMT_DEBUG_OPEN_DISPLAY = openDisplay

    return () => {
      delete (window as Window & { __SMT_DEBUG_OPEN_DISPLAY?: typeof openDisplay }).__SMT_DEBUG_OPEN_DISPLAY
    }
  }, [handleOpenMedia])

  useEffect(() => {
    if (!pauseMenuOpen || activeMedia) {
      return undefined
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') {
        return
      }

      event.preventDefault()
      handleResumePausedTour()
    }

    window.addEventListener('keydown', handleKeyDown)

    return () => {
      window.removeEventListener('keydown', handleKeyDown)
    }
  }, [activeMedia, handleResumePausedTour, pauseMenuOpen])

  const hudLocked = isPointerLocked || debugLocked
  const performanceDebugEnabled =
    typeof window !== 'undefined' &&
    (new URLSearchParams(window.location.search).get('perfDebug') === '1')
  const debugCameraEnabled = DEBUG_CAMERA
  const graphicsSettings = GRAPHICS_QUALITY_SETTINGS[graphicsQuality]

  return (
    <GraphicsQualityContext.Provider value={graphicsSettings}>
      <main id="scene-shell" className="app-shell">
        <FactoryScene
          modalOpen={activeMedia !== null}
          graphicsQuality={graphicsQuality}
          onPointerLockChange={handlePointerLockChange}
          onCameraDebugChange={debugCameraEnabled ? setCameraDebug : undefined}
          onControllerReady={handleControllerReady}
          onOpenMedia={handleOpenMedia}
          onPromptChange={setInteractionPrompt}
        />

        <section className="hud hud-top-left">
          <p className="eyebrow">SMT Virtual Line</p>
          <h1>Interactive Manufacturing Tour</h1>
        </section>

        <Instructions isPointerLocked={hudLocked} showStartOverlay={!hasStarted} />
        <GraphicsQualityControl
          quality={graphicsQuality}
          onChange={setGraphicsQuality}
          visible={!hudLocked && activeMedia === null}
        />
        <Crosshair visible={hudLocked} />
        {hudLocked && interactionPrompt && !activeMedia ? (
          <div className="interaction-prompt">{interactionPrompt}</div>
        ) : null}
        {pauseMenuOpen && !activeMedia ? (
          <PauseMenu sections={navigationSections} onResume={handleResumePausedTour} onNavigate={handleNavigate} />
        ) : null}
        {activeMedia ? (
          <MediaModal
            data={activeMedia}
            onClose={handleCloseMedia}
            onCloseAndContinue={handleCloseAndContinue}
          />
        ) : null}
        <PerformanceDebugPanel enabled={performanceDebugEnabled} />
        {DEBUG_CAMERA ? <CameraDebug debug={cameraDebug} /> : null}
      </main>
    </GraphicsQualityContext.Provider>
  )
}

export default App
