import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes('node_modules')) {
            return undefined
          }

          if (id.includes('@react-three/drei')) {
            return 'dreiVendor'
          }

          if (id.includes('@react-three/fiber')) {
            return 'fiberVendor'
          }

          if (id.includes('three-stdlib')) {
            return 'stdlibVendor'
          }

          if (id.includes('three')) {
            return 'threeVendor'
          }

          if (id.includes('react')) {
            return 'reactVendor'
          }

          return undefined
        },
      },
    },
  },
})
