# Agent Handoff

## Objetivo del proyecto

Prototipo web 3D navegable de una planta industrial con:

- React
- TypeScript
- Vite
- Three.js
- @react-three/fiber
- @react-three/drei

La prioridad es una representacion 3D clara y funcional, no fotorrealista.

## Reglas de trabajo que ya se respetaron

- No reconstruir el proyecto desde cero.
- No crear otro proyecto ni otra carpeta anidada.
- No romper:
  - Pointer Lock
  - movimiento WASD
  - Shift para avance rapido
  - Escape para liberar mouse
  - control con mouse
  - cruceta
  - modal de Liberaciones
  - conservacion de posicion y orientacion al cerrar el modal
  - IndustrialScreen
  - pantallas multimedia existentes
- No modificar destructivamente SMT.
- No instalar dependencias innecesarias.
- No usar GLB ni modelos externos por ahora.
- No usar fisica / Rapier por ahora.
- Usar geometria basica y componentes reutilizables.

## Estado actual general

La escena contiene dos areas principales:

1. SMT
2. BACKEND

Ambas existen simultaneamente en la misma escena.

En backend ahora hay 2 lineas paralelas con el mismo sentido de flujo y un pasillo central.

## Estructura principal actual

- `src/components/FactoryScene.tsx`
  - monta `SmtLine`
  - monta `InformationCenter`
  - monta `BackendArea`
  - monta `FirstPersonController`
  - maneja raycast de interaccion para pantallas con cruceta
- `src/App.tsx`
  - maneja el modal multimedia
  - maneja reanudacion del recorrido
  - maneja menu de pausa por `ESC`
  - resuelve teletransporte por destinos de navegacion
- `src/components/FactoryFloor.tsx`
  - piso
  - grid
  - delimitaciones amarillas
- `src/components/SmtLine.tsx`
  - linea SMT completa
  - estaciones multimedia SMT
  - racks SMT frente a Pick & Place
- `src/components/InformationCenter.tsx`
  - kiosco hexagonal separado enfrente de SMT
  - 6 pantallas interactivas
  - reutiliza el mismo contenido/modal de `Liberaciones`
- `src/components/backend/BackendArea.tsx`
  - monta 2 lineas backend paralelas
  - la linea original conserva el almacen trasero
  - la segunda linea no duplica el almacen trasero
  - monta una celda XRAY independiente despues de OIA en cada linea
  - monta un equipo standalone `LASER BACKEND` detras de Wave Solder junto al almacen de Backend Ops
  - monta un proceso standalone `SOCKET INSERTION` despues de `LASER BACKEND` y antes de la zona XRAY
  - monta una `CONFORMAL COATING LINE` detras de XRAY y enseguida de `LASER BACKEND`
  - monta una `GLUE PROCESS CELL` enfrente de XRAY y separada de esa celda
- `src/components/backend/ManualAssemblyLine.tsx`
  - linea MASSY con 6 estaciones
  - conveyor continuo
  - puede renderizarse con o sin zona trasera de materiales de Estacion 1
- `src/components/backend/BackendProcessSection.tsx`
  - secuencia despues de MASSY:
    - conveyor corto
    - Wave Solder
    - conveyor corto
    - AOI Backend
    - conveyor corto hacia OIA
    - OIA
  - puede renderizarse para multiples lineas backend
- `src/components/backend/xray/XrayInspectionCell.tsx`
  - celda independiente despues de OIA
  - mesa verde + monitor interactivo + escaner + XRAY + XIA
  - sin conveyor entre OIA y la celda
- `src/components/backend/conformal/ConformalLine.tsx`
  - linea backend conectada desde `LASER BACKEND`
  - 2 coating + UV oven + AOI + OIA
  - conveyor unificado y salida corta
- `src/components/backend/glue/GlueProcessCell.tsx`
  - celda independiente enfrente de XRAY
  - mesa verde + 2 Glue Machines + OIA Glue
  - monitor interactivo con modal reutilizado

## Estado actual de SMT

Frente a SMT ahora existe un `Centro de Informacion` separado de la linea:

- kiosco hexagonal tipo isla
- 6 pantallas, una por cara
- todas usan la misma funcionalidad de `Liberaciones`
- usa colision propia para no atravesarlo caminando
- el piso y el area caminable fueron ampliados para que quepa con holgura

La secuencia SMT actual es:

1. Laser
2. Solder Paste Printer
3. Conveyor
4. SPI
5. Pick & Place 1
6. Pick & Place 2
7. Pick & Place 3
8. Pick & Place 4
9. Conveyor
10. Reflow Oven
11. Conveyor
12. AOI
13. Conveyor
14. Flashing
15. Conveyor
16. ICT In-Line
17. Conveyor
18. Router

Notas importantes:

- Pick & Place ya fue corregido a 4 modulos.
- No volverlo a 6 salvo instruccion explicita del usuario.
- Hay 2 racks de materiales SMT frente a Pick & Place.
- No hay pantalla alta extra junto a esos racks.

## Estado actual de Backend

### MASSY

- 2 lineas MASSY paralelas.
- cada linea tiene 6 estaciones manuales.
- cada linea tiene 1 conveyor continuo compartido.
- cada linea tiene 6 monitores centrados.
- cada linea tiene 6 letreros `ESTACION 1` a `ESTACION 6`.
- cada linea tiene 6 tapetes antifatiga.
- bandejas y bins integrados en ambas.
- solo la linea original conserva la zona trasera de materiales.

### Zona trasera de Estacion 1

Actualmente existe una sola zona de almacen trasera ligada a `massy-station-1` de la linea original con:

- 3 racks grandes de materiales
- 1 tarima llena de cajas
- 1 pantalla `BACKEND OPS` con `kanban.png` e interaccion por `E`

Orden actual solicitado por el usuario en esa zona:

- almacenes
- pantalla
- estaciones MASSY

Es decir, desde mas atras hacia adelante:

1. racks / tarima
2. pantalla
3. Estacion 1 de MASSY

### Secuencia de Backend actual

Cada linea Backend actual es:

1. MASSY ESTACION 1
2. MASSY ESTACION 2
3. MASSY ESTACION 3
4. MASSY ESTACION 4
5. MASSY ESTACION 5
6. MASSY ESTACION 6
7. conveyor corto de transicion
8. Wave Solder
9. conveyor corto
10. AOI Backend
11. conveyor corto hacia OIA
12. OIA

En cada linea ademas existe una celda adicional separada:

13. espacio libre sin conveyor
14. XRAY Inspection Cell
15. XRAY
16. XIA

Ademas, detras de la celda XRAY principal existe una linea adicional:

17. CONFORMAL COATING 1
18. CONFORMAL COATING 2
19. UV OVEN CONFORMAL
20. AOI CONFORMAL
21. OIA CONFORMAL

Enfrente de XRAY principal ademas existe una celda adicional:

22. MESA VERDE GLUE
23. GLUE MACHINE 1
24. GLUE MACHINE 2
25. OIA GLUE

## Pantallas e interaccion

### Pantalla Liberaciones

- sigue existiendo
- sigue siendo interactiva
- se abre con raycast de cruceta + tecla `E` / click segun el flujo existente
- usa modal HTML
- conserva posicion y orientacion de camara al cerrar

### Menu de pausa

- aparece al liberar el recorrido con `ESC`
- actua como menu de navegacion rapida
- permite saltar a destinos por area
- no desmonta `FactoryScene`
- reutiliza el controlador actual de camara mediante teletransporte
- `ESC` nuevamente reanuda el recorrido

### Pantalla XRAY de mesa verde

- usa el mismo sistema funcional que `Liberaciones`
- muestra `E — Ver instrucciones XRAY`
- abre `MediaModal`
- conserva posicion y orientacion de camara al cerrar
- usa como fuente publica `/media/backend/xray/xray-instructions.jpg`
- usa fallback `/media/backend/xray/placeholder.svg`

### Pantalla GLUE de mesa verde

- usa el mismo sistema funcional que `Liberaciones` y XRAY
- muestra `E — Ver instrucciones Glue`
- abre `MediaModal`
- conserva posicion y orientacion de camara al cerrar
- usa como fuente publica `/media/backend/glue/glue-instructions.jpg`
- usa fallback `/media/backend/glue/placeholder.svg`

### Pantalla trasera de Backend

- usa el lenguaje visual de `FloorDisplayStation`
- no debe abrir modal
- no debe participar en la interaccion de cruceta
- se renderiza siempre

## Reglas importantes sobre interaccion

- No desmontar `FactoryScene` al abrir modales.
- No reiniciar camara al abrir o cerrar modal.
- No cambiar `key` del `Canvas`.
- `FirstPersonController` ya expone API para lock/unlock/save/restore camera state.
- No romper el flujo actual de `Liberaciones`.

## Archivos importantes

### SMT

- `src/data/smtLine.ts`
- `src/data/informationCenter.ts`
- `src/data/navigationMenu.ts`
- `src/data/smtMaterialAreas.ts`
- `src/components/SmtLine.tsx`
- `src/components/InformationCenter.tsx`
- `src/components/PauseMenu.tsx`
- `src/components/Conveyor.tsx`
- `src/components/IndustrialMachine.tsx`
- `src/components/FloorDisplayStation.tsx`

### Backend

- `src/data/backendLine.ts`
- `src/data/backendRearArea.ts`
- `src/data/backendProcesses.ts`
- `src/data/backendStandaloneEquipment.ts`
- `src/data/conformalLine.ts`
- `src/data/glueProcessCell.ts`
- `src/data/xrayInspectionCell.ts`
- `src/types/backend.ts`
- `src/types/conformal.ts`
- `src/types/glue.ts`
- `src/types/xray.ts`
- `src/components/backend/BackendArea.tsx`
- `src/components/backend/ManualAssemblyLine.tsx`
- `src/components/backend/ManualAssemblyStation.tsx`
- `src/components/backend/ManualAssemblyConveyor.tsx`
- `src/components/backend/BackendProcessSection.tsx`
- `src/components/backend/WaveSolderMachine.tsx`
- `src/components/backend/BackendAOIMachine.tsx`
- `src/components/backend/BackendLaserMachine.tsx`
- `src/components/backend/BackendSocketInsertionStation.tsx`
- `src/components/backend/OIAStation.tsx`
- `src/components/backend/conformal/ConformalLine.tsx`
- `src/components/backend/conformal/ConformalCoatingMachine.tsx`
- `src/components/backend/conformal/ConformalUvOven.tsx`
- `src/components/backend/conformal/ConformalAOIMachine.tsx`
- `src/components/backend/conformal/ConformalOIAMachine.tsx`
- `src/components/backend/conformal/ConformalConveyor.tsx`
- `src/components/backend/conformal/ConformalControlPanel.tsx`
- `src/components/backend/conformal/ConformalExhaust.tsx`
- `src/components/backend/glue/GlueProcessCell.tsx`
- `src/components/backend/glue/GlueInspectionTable.tsx`
- `src/components/backend/glue/GlueMachine.tsx`
- `src/components/backend/glue/GlueOIAMachine.tsx`
- `src/components/backend/glue/GlueConveyor.tsx`
- `src/components/backend/glue/GlueControlPanel.tsx`
- `src/components/backend/glue/GlueScanner.tsx`
- `src/components/backend/xray/XrayInspectionCell.tsx`
- `src/components/backend/xray/GreenInspectionTable.tsx`
- `src/components/backend/xray/TableScanner.tsx`
- `src/components/backend/xray/InteractiveWorkMonitor.tsx`
- `src/components/backend/xray/XrayMachine.tsx`
- `src/components/backend/xray/XiaMachine.tsx`
- `src/components/backend/MaterialRack.tsx`
- `src/components/backend/RearMaterialArea.tsx`

### Piso y zonas

- `src/components/FactoryFloor.tsx`
- `src/components/SafetyTape.tsx`
- `src/data/safetyZones.ts`

### Multimedia

- `src/components/IndustrialScreen.tsx`
- `src/components/MediaModal.tsx`
- `public/media/screens/`
- `public/media/backend/`

## Recursos multimedia actuales

### SMT

- `public/media/screens/liberaciones.jpg`
- `public/media/screens/liberaciones-cropped.jpg`
- `public/media/screens/placeholder.svg`

### Backend

- `public/media/backend/station-1.svg` ... `station-6.svg`
- `public/media/backend/rear-display/backend-station-1.svg`
- `public/media/backend/wave-solder-dashboard.svg`
- `public/media/backend/backend-aoi-dashboard.svg`
- `public/media/backend/xray/placeholder.svg`
- `public/media/backend/xray/xia-dashboard.svg`
- `public/media/backend/xray/xray-instructions.jpg` (pendiente de que el usuario lo coloque)
- `public/media/backend/conformal/coating-1-dashboard.svg`
- `public/media/backend/conformal/coating-2-dashboard.svg`
- `public/media/backend/conformal/uv-oven-dashboard.svg`
- `public/media/backend/conformal/aoi-conformal-dashboard.svg`
- `public/media/backend/conformal/oia-conformal-dashboard.svg`
- `public/media/backend/glue/placeholder.svg`
- `public/media/backend/glue/glue-machine-1-dashboard.svg`
- `public/media/backend/glue/glue-machine-2-dashboard.svg`
- `public/media/backend/glue/glue-oia-dashboard.svg`
- `public/media/backend/glue/glue-instructions.jpg` (pendiente de que el usuario lo coloque)

## Delimitaciones amarillas

Las cintas amarillas ya fueron refactorizadas para evitar pasillos falsos y usar zonas por datos.

Archivos clave:

- `src/data/safetyZones.ts`
- `src/components/SafetyTape.tsx`

Actualmente existen:

- perimetro general SMT
- delimitaciones por proceso SMT
- zona de materiales Pick & Place
- perimetro general Backend
- zonas de operador MASSY para ambas lineas
- divisiones entre estaciones MASSY para ambas lineas
- zona trasera de almacenamiento Backend
- zonas internas para Wave Solder, AOI Backend y OIA en ambas lineas
- zona independiente para la celda XRAY
- zona independiente para `LASER BACKEND`
- zona independiente para `SOCKET INSERTION`
- zona independiente para `CONFORMAL COATING LINE`
- zonas internas de `CONFORMAL COATING 1`, `CONFORMAL COATING 2`, `UV OVEN CONFORMAL`, `AOI CONFORMAL` y `OIA CONFORMAL`
- zona independiente para `GLUE PROCESS CELL`
- zonas internas de `MESA VERDE GLUE`, `GLUE MACHINE 1`, `GLUE MACHINE 2` y `OIA GLUE`

## Navegacion y validacion

### Servidor

Normalmente se esta usando:

```bash
npm run dev -- --host 0.0.0.0 --port 4173
```

URL local:

```text
http://localhost:4173/
```

### Build obligatorio

Siempre validar con:

```bash
npm run build
```

### Nota sobre Playwright y Pointer Lock

El entorno automatizado no siempre permite Pointer Lock real.

Para validaciones visuales se ha estado usando tambien:

```text
http://localhost:4173/?debugLock=1
```

Eso solo sirve para revisar el estado visual del HUD / cruceta durante pruebas automatizadas. No reemplaza la logica real de Pointer Lock.

## .gitignore

Ya se actualizo para ignorar:

- capturas de validacion en la raiz (`*.png`, `*.jpg`, etc.)
- medios raster / video del usuario en `public/media/**`

Si se agregan nuevos recursos temporales de prueba visual, deben seguir esa convencion.

## Estado funcional actual que no se debe romper

- La escena no debe quedar gris.
- `WASD` funciona.
- `Shift` funciona.
- `Escape` libera el mouse.
- El modal de `Liberaciones` abre y cierra.
- `Cerrar y continuar recorrido` conserva posicion/orientacion.
- No hay que reinicializar la camara.
- No desmontar `FactoryScene`.

## Ultimos cambios importantes

1. Pick & Place se redujo de 6 a 4 modulos.
2. Se corrigieron patas de algunos conveyors SMT.
3. Se separo el almacen SMT de la zona trasera Backend.
4. La zona trasera de MASSY ahora usa 3 racks grandes y una tarima.
5. Se agrego Wave Solder y AOI Backend al final de MASSY.
6. La continuidad visual entre MASSY, Wave Solder y AOI se ajusto para no dejar huecos grandes.
7. AOI Backend ahora continua por conveyor hacia una estacion OIA con escritorio en L y dos pantallas.
8. Backend ahora tiene una segunda linea paralela enfrente de la original, con pasillo central, mismo sentido de flujo y un solo almacen trasero.
9. Frente a SMT ahora existe un centro de informacion hexagonal con 6 pantallas que abren el mismo modal de Liberaciones.
10. Cada linea de Backend ahora tiene una celda XRAY independiente despues de OIA, con mesa verde, monitor interactivo, escaner, XRAY y XIA.
11. Ahora existe un menu de pausa con `ESC` para navegar rapidamente entre SMT, Backend y Rework.
12. Detras de Wave Solder, junto al almacen de Backend Ops, ahora existe una maquina standalone `LASER BACKEND` sin conexion a otras lineas.
13. Detras de AOI y antes de la zona XRAY ahora existe un proceso standalone `SOCKET INSERTION` sin conexion a otras lineas.
14. Detras de XRAY principal y comenzando en `LASER BACKEND` ahora existe una `CONFORMAL COATING LINE` con 5 equipos conectados.
15. Enfrente de XRAY principal ahora existe una `GLUE PROCESS CELL` con mesa verde, 2 Glue Machines, OIA Glue y monitor interactivo.

## Recomendaciones para el siguiente agente

- Antes de mover cualquier equipo, revisar primero los archivos de datos:
  - `smtLine.ts`
  - `backendLine.ts`
  - `backendRearArea.ts`
  - `backendProcesses.ts`
  - `safetyZones.ts`
- Si hay que recolocar procesos, hacerlo desde datos y no desde JSX suelto.
- Si se agregan nuevos equipos Backend, montarlos dentro de `BackendArea` y no dentro de `SmtLine`.
- Si se agregan nuevas pantallas Backend operativas, evitar que sean interactivas salvo que el usuario lo pida.
- Si se agregan nuevos modales, no reutilizar automaticamente la interaccion de `Liberaciones` sin revisar el flujo de cruceta.

## Regla de continuidad para futuras iteraciones

Este archivo debe actualizarse despues de cambios estructurales importantes para que otro agente pueda continuar sin rehacer el analisis.
