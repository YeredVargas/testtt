# Factory Column Display

Placeholder media for the architectural pillar-mounted television.

- `factory-dashboard.svg` is an original generic dashboard used as ambient content.
- It contains no commercial branding and is intended for permanent in-scene display.
- Future replacements can use `jpg`, `jpeg`, `png`, `webp`, `gif`, `mp4`, or `webm` through the same media pipeline.
