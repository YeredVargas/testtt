Place Glue cell media files here.

Expected user-provided asset:

- `glue-instructions.jpg`

This asset is loaded in-app from:

- `/media/backend/glue/glue-instructions.jpg`

Included assets:

- `placeholder.svg`
- `glue-machine-1-dashboard.svg`
- `glue-machine-2-dashboard.svg`
- `glue-oia-dashboard.svg`
