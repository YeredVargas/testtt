Monitor assets for Backend Manual Assembly stations.

These files live under `public`, so they are referenced without the `public` prefix.

Example:
- File: `public/media/backend/station-1.svg`
- URL in React: `/media/backend/station-1.svg`

You can later replace these SVGs with JPG, PNG, WebP, GIF, MP4 or WebM files.
