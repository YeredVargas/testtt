Assets for the rear material support area of Backend / MASSY.

Files under `public` are referenced without the `public` prefix.

Example:
- File: `public/media/backend/rear-display/backend-station-1.svg`
- URL: `/media/backend/rear-display/backend-station-1.svg`

These can later be replaced with JPG, PNG, WebP, GIF, MP4 or WebM files.
