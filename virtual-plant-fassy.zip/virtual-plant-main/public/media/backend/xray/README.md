Place XRAY media files for the backend inspection cell here.

Expected user-provided asset:

- `xray-instructions.jpg`

This asset is loaded in-app from:

- `/media/backend/xray/xray-instructions.jpg`

Included placeholders:

- `placeholder.svg`
- `xia-dashboard.svg`
