# Screen Media

Aqui se colocan imagenes y videos para las pantallas del recorrido.

Los archivos dentro de `public` se consultan sin escribir `public` en la URL.

Ejemplo:

Archivo:
`public/media/screens/liberaciones.jpg`

URL utilizada en React:
`/media/screens/liberaciones.jpg`

Formatos soportados:
- JPG
- JPEG
- PNG
- WebP
- GIF
- MP4
- WebM

Para animaciones largas se recomienda usar MP4 o WebM en lugar de GIF.

Los nombres de archivos deben respetar mayusculas y minusculas.
