# Performance Report

Measurements were captured on the production preview build (`npm run build` + `npm run preview -- --host`) with a scripted camera sweep and the temporary `perfDebug` panel enabled.

Important note: the automated browser environment used for measurement is heavily throttled compared with a normal desktop browser window, so the absolute FPS values are much lower than a real interactive session. The before/after comparison is still valid because both runs used the same environment, same camera paths, and same sampling method.

## Scene Inventory

| Metric | Before | After |
|------|--------|-------|
| Meshes | 3441 | 3070 |
| Groups | 726 | 635 |
| Materials | 3441 | 2507 |
| Geometries | 3441 | 2508 |
| Textures | 25 | 5 |
| Lights | 4 | 4 |
| Shadow-casting lights | 1 | 1 |
| Interactive objects | 16 | 16 |
| Meshes with castShadow | 1658 | 1248 |
| Meshes with receiveShadow | 1666 | 1359 |
| JS heap used | 115269893 | 59268629 |
| Load time ms | 2593.6 | 779.4 |

## Zone Comparison

| Zona | FPS antes | FPS después | Draw calls antes | Draw calls después | Triángulos antes | Triángulos después |
|------|-----------|-------------|-------------------|----------------------|------------------|--------------------|
| Inicio SMT | 0.214 | 1.049 | 3619 | 2915 | 81326 | 73451 |
| Pick & Place | 0.761 | 0.974 | 3976 | 3465 | 92096 | 88278 |
| MASSY | 1.204 | 1.179 | 2820 | 2377 | 63448 | 60441 |
| Wave Solder | 1.131 | 1.094 | 2290 | 1881 | 51870 | 49266 |
| XRAY | 1.108 | 1.135 | 1894 | 1509 | 41642 | 39326 |
| Conformal | 1.108 | 1.104 | 1408 | 1043 | 29774 | 27706 |
| Glue | 1.094 | 1.100 | 1609 | 1234 | 33859 | 31675 |
| Techo / Pilares / TV | 1.100 | 1.105 | 1209 | 852 | 26214 | 24238 |
| Vista Elevada | 1.083 | 1.118 | 1420 | 1041 | 31148 | 28916 |
| Shift Rápido | 1.087 | 1.010 | 3117 | 2659 | 71214 | 68022 |

## Aggregates

| Aggregate | Before | After |
|------|--------|-------|
| Average FPS across sampled zones | 0.989 | 1.087 |
| Lowest observed FPS | 0.214 | 0.751 |
| Average draw calls across sampled zones | 2336.2 | 1897.6 |
| Average triangles across sampled zones | 52259.1 | 49131.9 |

## Graphics Quality Sweep

Representative measurement taken on Pick & Place in production preview.

| Quality | FPS avg | FPS min | Draw calls avg | Triangles avg | Effective DPR | Shadows |
|------|---------|---------|----------------|---------------|---------------|---------|
| Low | 0.266 | 0.266 | 2654 | 69034 | 1.00 | Off |
| Medium | 0.336 | 0.336 | 3464 | 88270 | 1.00 | On |
| High | 0.323 | 0.323 | 3464 | 88270 | 1.00 | On |

The automated browser clamps DPR to `1`, so the visual differences between Medium and High in this environment are mainly shadow-map quality and antialiasing policy. In a normal desktop browser, the configured DPR caps are higher for Medium and High.
