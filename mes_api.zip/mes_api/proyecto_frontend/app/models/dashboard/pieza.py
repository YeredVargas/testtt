from sqlalchemy import Column, Integer, String, TIMESTAMP, func, UniqueConstraint
from app.config import Base

class Pieza(Base):
    __tablename__ = "piezas"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    nombre_pieza     = Column(String(255))
    numero_material  = Column(String(50), nullable=False)
    centro           = Column(String(4), nullable=False, server_default='0094')
    proyecto         = Column(String(50), server_default='SIN PROYECTO')
    creado_en        = Column(TIMESTAMP, server_default=func.now())

    __table_args__ = (
        UniqueConstraint('numero_material', 'centro', name='uq_piezas_mat_centro'),
    )