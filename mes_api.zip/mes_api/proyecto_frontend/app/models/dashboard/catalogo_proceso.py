# app/models/dashboard/catalogo_proceso.py
from sqlalchemy import Column, String, TIMESTAMP, func
from app.config import Base


class CatalogoProceso(Base):
    __tablename__ = "catalogo_procesos"

    codigo     = Column(String(50), primary_key=True)
    seccion    = Column(String(30), nullable=False)
    creado_en  = Column(TIMESTAMP, server_default=func.now())
