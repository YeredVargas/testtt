from datetime import datetime
from sqlalchemy import Column, Integer, String, Numeric, Date, ForeignKey, DateTime, UniqueConstraint
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.config import Base

class Trazabilidad(Base):
    __tablename__ = "trazabilidad"

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    pieza_id           = Column(Integer, ForeignKey("piezas.id", ondelete="CASCADE"), nullable=False)
    operacion_num      = Column(String(10), nullable=False)
    descripcion        = Column(String(255))
    clave_modelo       = Column(String(50))
    codigo_busqueda    = Column(String(50))
    proceso            = Column(String(50), nullable=True)
    steus              = Column(String(20))
    plnnr              = Column(String(40))
    plnal              = Column(String(10))
    aennr              = Column(String(40))
    equipos            = Column(Integer)
    cantidad_base      = Column(Numeric(10, 2))
    
    tiempo             = Column(Numeric(10, 4))
    tiempo_preparacion = Column(Numeric(10, 4), nullable=True)
    tiempo_mano_obra   = Column(Numeric(10, 4), nullable=True)
    
    unidad_t           = Column(String(5))
    fecha_inicio       = Column(Date)
    fecha_fin          = Column(Date)
    creado_el          = Column(Date)
    modificado_el      = Column(Date)


class CostosCK13NCabecera(Base):
    __tablename__ = 'costos_ck13n_cabecera'

    id = Column(Integer, primary_key=True, index=True)
    numero_material = Column(String(50), ForeignKey('piezas.numero_material', ondelete='CASCADE'), nullable=False)
    centro = Column(String(10), nullable=False, default='0094')
    variante = Column(String(20), default="Y001")
    
    estatus = Column(String(10), nullable=False)
    fecha_validez = Column(Date, nullable=False)
    numero_costeo = Column(String(50), nullable=False)
    
    total_global = Column(Numeric(15, 2), nullable=False, default=0)
    total_fijado = Column(Numeric(15, 2), nullable=False, default=0)
    total_variable = Column(Numeric(15, 2), nullable=False, default=0)
    
    creado_en = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # 🔴 AQUÍ ESTÁ LA SOLUCIÓN: Cambiamos 'numero_costeo' por 'fecha_validez'
    __table_args__ = (
        UniqueConstraint('numero_material', 'centro', 'variante', 'fecha_validez', name='uq_costos_cabecera'),
    )

    elementos = relationship("CostosCK13NElementos", back_populates="cabecera", cascade="all, delete-orphan")
    produccion = relationship("CostosCK13NProduccion", back_populates="cabecera", cascade="all, delete-orphan")

class CostosCK13NElementos(Base):
    __tablename__ = 'costos_ck13n_elementos'

    id = Column(Integer, primary_key=True, index=True)
    cabecera_id = Column(Integer, ForeignKey('costos_ck13n_cabecera.id', ondelete='CASCADE'), nullable=False)
    
    componente = Column(String(10), nullable=False)
    denominacion = Column(String(100))
    
    total = Column(Numeric(15, 2), nullable=False, default=0)
    fijado = Column(Numeric(15, 2), nullable=False, default=0)
    variable = Column(Numeric(15, 2), nullable=False, default=0)

    __table_args__ = (
        UniqueConstraint('cabecera_id', 'componente', name='uq_costos_elementos'),
    )

    cabecera = relationship("CostosCK13NCabecera", back_populates="elementos")


class CostosCK13NProduccion(Base):
    __tablename__ = 'costos_ck13n_produccion'

    id = Column(Integer, primary_key=True, index=True)
    cabecera_id = Column(Integer, ForeignKey('costos_ck13n_cabecera.id', ondelete='CASCADE'), nullable=False)
    posicion = Column(String(20))
    centro_coste = Column(String(50))
    texto_centro_coste = Column(String(200))
    clase_actividad = Column(String(50))
    texto_actividad = Column(String(200))
    elemento_coste = Column(String(50))
    texto_recurso = Column(String(255))
    cantidad = Column(Numeric(15, 3), default=0)
    unidad = Column(String(10))
    valor_total = Column(Numeric(15, 2), default=0)
    moneda = Column(String(10))

    cabecera = relationship("CostosCK13NCabecera", back_populates="produccion")