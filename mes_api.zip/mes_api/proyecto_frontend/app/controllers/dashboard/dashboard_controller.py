# app/controllers/dashboard/dashboard_controller.py
import math
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, desc, extract
from typing import List, Optional

from app.config import SessionLocal
from app.models.dashboard.pieza import Pieza
from app.models.dashboard.trazabilidad import Trazabilidad
from app.schemas.dashboard.dashboard_schema import (
    DashboardMaterialResponse,
    ProcesoAgrupado,
    RegistroHistorico,
    PaginatedDashboardResponse # <-- NUEVA IMPORTACIÓN
)

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/secciones")
def get_secciones(centro: str = Query("0094"), db: Session = Depends(get_db)):
    """Obtiene las secciones disponibles para un centro específico."""
    secciones = (
        db.query(Trazabilidad.proceso)
        .join(Pieza, Trazabilidad.pieza_id == Pieza.id)
        .filter(Pieza.centro == centro)
        .filter(Trazabilidad.proceso != None)
        .distinct()
        .all()
    )
    return [s[0] for s in secciones if s[0]]


@router.get("/{seccion}", response_model=PaginatedDashboardResponse)
def get_dashboard_por_seccion(
    seccion: str, 
    centro: str = Query("0094"),
    page: int = Query(1, ge=1),
    limit: int = Query(5, ge=1, le=10000),
    numero_material: Optional[str] = Query(None),
    proyecto: Optional[str] = Query(None),
    fecha_inicio: Optional[str] = Query(None),
    fecha_fin: Optional[str] = Query(None),
    mes_exacto: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Obtiene el historial de materiales aplicando Paginación Server-Side y filtros."""

    # =========================================================================
    # FASE 1: SUB-CONSULTA RÁPIDA (Paginamos los Números de Material)
    # =========================================================================
    q_ids = (
        db.query(Pieza.numero_material, func.max(Trazabilidad.fecha_inicio).label("max_fecha"))
        .join(Trazabilidad, Trazabilidad.pieza_id == Pieza.id)
        .filter(Pieza.centro == centro)
        .filter(Trazabilidad.tiempo.isnot(None))
        .filter(Trazabilidad.tiempo > 0)
    )

    # 1.1 Aplicar filtros a la búsqueda de IDs
    if seccion.upper() != "TODOS":
        q_ids = q_ids.filter(func.upper(Trazabilidad.proceso) == seccion.upper())

    if numero_material:
        q_ids = q_ids.filter(Pieza.numero_material == numero_material)
        
    if proyecto:
        q_ids = q_ids.filter(Pieza.proyecto == proyecto)

    if fecha_inicio:
        q_ids = q_ids.filter(Trazabilidad.fecha_inicio >= fecha_inicio)
        
    if fecha_fin:
        q_ids = q_ids.filter(Trazabilidad.fecha_inicio <= fecha_fin)
        
    if mes_exacto:
        try:
            year, month = mes_exacto.split('-')
            q_ids = q_ids.filter(
                extract('year', Trazabilidad.fecha_inicio) == int(year),
                extract('month', Trazabilidad.fecha_inicio) == int(month)
            )
        except ValueError:
            pass

    # 1.2 Ejecutar, agrupar y ordenar para paginar correctamente
    materiales_filtrados = q_ids.group_by(Pieza.numero_material).order_by(desc("max_fecha")).all()

    # 1.3 Matemática de paginación
    total_registros = len(materiales_filtrados)
    total_paginas = math.ceil(total_registros / limit) if limit > 0 else 1
    
    offset = (page - 1) * limit
    materiales_paginados = materiales_filtrados[offset : offset + limit]
    numeros_material_pagina = [p[0] for p in materiales_paginados]

    # Si no hubo resultados en esta página, abortar rápido
    if not numeros_material_pagina:
        return {
            "total_registros": total_registros,
            "total_paginas": total_paginas,
            "pagina_actual": page,
            "registros_por_pagina": limit,
            "datos": []
        }

    # =========================================================================
    # FASE 2: EXTRACCIÓN PESADA (Solo para los 5 materiales de esta página)
    # =========================================================================
    q_detalle = (
        db.query(
            Pieza.numero_material,
            Pieza.nombre_pieza,
            Pieza.proyecto,
            Trazabilidad.proceso,
            Trazabilidad.plnal,
            Trazabilidad.fecha_inicio,
            func.max(Trazabilidad.tiempo).label("tiempo"),
            func.max(Trazabilidad.tiempo_preparacion).label("tiempo_preparacion"),
            func.max(Trazabilidad.tiempo_mano_obra).label("tiempo_mano_obra"),
            func.max(Trazabilidad.equipos).label("equipos_sap"), 
            func.count(Trazabilidad.id).label("conteo_operaciones"), 
        )
        .join(Trazabilidad, Trazabilidad.pieza_id == Pieza.id)
        .filter(Pieza.centro == centro)
        .filter(Pieza.numero_material.in_(numeros_material_pagina)) # <- El filtro salvavidas de RAM
    )

    if seccion.upper() != "TODOS":
        q_detalle = q_detalle.filter(func.upper(Trazabilidad.proceso) == seccion.upper())

    rows = (
        q_detalle.filter(Trazabilidad.tiempo.isnot(None))
        .filter(Trazabilidad.tiempo > 0)
        .group_by(
            Pieza.numero_material,
            Pieza.nombre_pieza,
            Pieza.proyecto,
            Trazabilidad.proceso,
            Trazabilidad.plnal,
            Trazabilidad.fecha_inicio,
        )
        .order_by(Pieza.numero_material, Trazabilidad.proceso, Trazabilidad.plnal, Trazabilidad.fecha_inicio)
        .all()
    )

    # =========================================================================
    # FASE 3: AGRUPAMIENTO EN DICCIONARIO
    # =========================================================================
    materiales_dict: dict = {}
    for row in rows:
        mat_key = row.numero_material
        if mat_key not in materiales_dict:
            materiales_dict[mat_key] = {
                "numero_material": row.numero_material,
                "nombre_pieza":    row.nombre_pieza,
                "proyecto":        row.proyecto,
                "procesos":        {},
            }

        # 🔴 CORRECCIÓN: La BD ya tiene el texto perfecto (Ej. "SMT" o "SMT (Alt 02)")
        proc_key = row.proceso if row.proceso else "SIN CLASIFICAR"
        
        if proc_key not in materiales_dict[mat_key]["procesos"]:
            materiales_dict[mat_key]["procesos"][proc_key] = []

        tiempo_val  = float(row.tiempo) if row.tiempo else 0
        
        # Leemos los equipos de SAP directo, o fallbackeamos al conteo
        e_sap = getattr(row, "equipos_sap", None)
        if e_sap is not None and e_sap > 0:
            equipos_val = int(e_sap)
        else:
            # Se usa "in" para que detecte "SMT" incluso si es "SMT (Alt 02)"
            equipos_val = int(row.conteo_operaciones) if "SMT" in proc_key.upper() else 1
        
        tiempo_prep_val = float(row.tiempo_preparacion) if row.tiempo_preparacion is not None else None
        tiempo_mo_val   = float(row.tiempo_mano_obra) if row.tiempo_mano_obra is not None else None

        materiales_dict[mat_key]["procesos"][proc_key].append({
            "fecha_cambio": row.fecha_inicio.strftime("%d.%m.%Y") if row.fecha_inicio else "",
            "tiempo":       tiempo_val,
            "equipos":      equipos_val,
            "tiempo_preparacion": tiempo_prep_val,
            "tiempo_mano_obra":   tiempo_mo_val,
        })

    resultado_procesado = []
    for mat_data in materiales_dict.values():
        procesos_list = []
        for proc_name, historial in mat_data["procesos"].items():
            baseline_pzs_hr = None
            
            for idx, reg in enumerate(historial):
                tiempo = reg["tiempo"]
                equipos = reg["equipos"]
                
                pzs_hr = None
                seg_pz = None
                mejora = None
                mejora_global = None
                prev_tiempo = None
                prev_seg_pz = None
                prev_pzs_hr = None

                if tiempo and equipos and tiempo > 0 and equipos > 0:
                    pzs_hr = (1000 / tiempo) / equipos
                    seg_pz = 3600 / pzs_hr if pzs_hr > 0 else 0
                    
                    if baseline_pzs_hr is None:
                        baseline_pzs_hr = pzs_hr
                    else:
                        mejora_global = ((pzs_hr - baseline_pzs_hr) / baseline_pzs_hr) * 100
                        
                if idx > 0:
                    anterior = historial[idx - 1]
                    t_ant = anterior["tiempo"]
                    e_ant = anterior["equipos"]
                    prev_tiempo = t_ant
                    
                    if t_ant and e_ant and t_ant > 0 and e_ant > 0:
                        pzs_hr_ant = (1000 / t_ant) / e_ant
                        prev_seg_pz = 3600 / pzs_hr_ant
                        prev_pzs_hr = pzs_hr_ant
                        if pzs_hr is not None:
                            mejora = ((pzs_hr - pzs_hr_ant) / pzs_hr_ant) * 100
                            
                reg.update({
                    "pzs_hr": pzs_hr,
                    "seg_pz": seg_pz,
                    "mejora": mejora,
                    "mejora_global": mejora_global,
                    "prev_tiempo": prev_tiempo,
                    "prev_seg_pz": prev_seg_pz,
                    "prev_pzs_hr": prev_pzs_hr
                })
                
            procesos_list.append(
                ProcesoAgrupado(
                    nombre_proceso=proc_name,
                    historial=[RegistroHistorico(**reg) for reg in historial],
                )
            )
            
        resultado_procesado.append(
            DashboardMaterialResponse(
                numero_material=mat_data["numero_material"],
                nombre_pieza=mat_data["nombre_pieza"],
                proyecto=mat_data["proyecto"] if mat_data["proyecto"] else "SIN PROYECTO",
                procesos=procesos_list,
            )
        )

    # 4. Forzamos el orden final para que respete las fechas más recientes de la Fase 1
    resultado_ordenado = []
    diccionario_orden = { r.numero_material: r for r in resultado_procesado }
    for num in numeros_material_pagina:
        if num in diccionario_orden:
            resultado_ordenado.append(diccionario_orden[num])

    return {
        "total_registros": total_registros,
        "total_paginas": total_paginas,
        "pagina_actual": page,
        "registros_por_pagina": limit,
        "datos": resultado_ordenado
    }

from sqlalchemy import func, and_

@router.get("/{numero_material}/operaciones_crudas")
def get_operaciones_crudas(numero_material: str, centro: str = Query("0094"), db: Session = Depends(get_db)):
    """Obtiene todas las operaciones en su versión más reciente individual, previniendo que fechas desfasadas oculten pasos."""
    pieza = db.query(Pieza).filter_by(numero_material=numero_material, centro=centro).first()
    if not pieza:
        return {"operaciones": []}

    # 1. SUBCONSULTA: Encontrar la fecha más reciente INDIVIDUALMENTE para cada paso (operacion_num)
    subquery = db.query(
        Trazabilidad.operacion_num,
        func.max(Trazabilidad.fecha_inicio).label('max_fecha')
    ).filter(
        Trazabilidad.pieza_id == pieza.id
    ).group_by(
        Trazabilidad.operacion_num
    ).subquery()

    # 2. CONSULTA PRINCIPAL: Unir la tabla con la subconsulta para traer los datos completos
    ops = db.query(
        Trazabilidad.operacion_num,
        Trazabilidad.descripcion,
        Trazabilidad.tiempo,
        Trazabilidad.tiempo_preparacion,
        Trazabilidad.tiempo_mano_obra,
        Trazabilidad.equipos
    ).join(
        subquery,
        and_(
            Trazabilidad.operacion_num == subquery.c.operacion_num,
            Trazabilidad.fecha_inicio == subquery.c.max_fecha
        )
    ).filter(
        Trazabilidad.pieza_id == pieza.id
    ).order_by(Trazabilidad.operacion_num).all()

    return {"operaciones": [{
        "operacion_num": op.operacion_num,
        "descripcion": op.descripcion,
        "tiempo": float(op.tiempo) if op.tiempo else 0,
        "tiempo_preparacion": float(op.tiempo_preparacion) if op.tiempo_preparacion else 0,
        "tiempo_mano_obra": float(op.tiempo_mano_obra) if op.tiempo_mano_obra else 0,
        "equipos": op.equipos if op.equipos else 1
    } for op in ops]}