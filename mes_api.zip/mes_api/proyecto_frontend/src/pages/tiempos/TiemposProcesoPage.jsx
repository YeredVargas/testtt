// src/pages/tiempos/TiemposProcesoPage.jsx
import React, { useMemo, useState, useEffect, useRef } from 'react'
import { useParams, useNavigate, useOutletContext } from 'react-router-dom'
import { Maximize2, Download, X, Filter, MoveRight, RefreshCw, Calculator, BarChart2, Info, Plus, ChevronLeft, ChevronRight, Clock } from 'lucide-react'
import * as htmlToImage from 'html-to-image'
import { useQueryClient } from '@tanstack/react-query'
import { useSecciones, useDashboardSeccion } from '../../hooks/useDashboard'
import { useFiltrosGraficas } from '../../hooks/useGraficas'
import CustomSelect from '../../components/ui/CustomSelect'
import GraficaBarras from '../../components/graficas/GraficaBarras'
import { useToast } from '../../components/ui/ToastContext'
import { sincronizarDatosSAP } from '../../services/SapService'
import NuevoMaterialModal from '../../components/ui/NuevoMaterialModal'

const parseFechaSap = (str) => {
  if (!str) return null
  const partes = str.split('.')
  if (partes.length !== 3) return null
  const [d, m, y] = partes
  return new Date(parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10))
}

const MESES_NOMBRES = {
  0: "Enero", 1: "Febrero", 2: "Marzo", 3: "Abril", 4: "Mayo", 5: "Junio",
  6: "Julio", 7: "Agosto", 8: "Septiembre", 9: "Octubre", 10: "Noviembre", 11: "Diciembre"
}

function ProcesoHistorial({ proceso, material, fechaInicio, fechaFin, mesFiltro }) {
  const tableRef = useRef(null)
  const showToast = useToast() 
  const [metricaActiva, setMetricaActiva] = useState('tiempo')

  const registrosCalculados = proceso.historial;

  const registrosParaMostrar = useMemo(() => {
    return registrosCalculados.filter(r => {
      const dateObj = parseFechaSap(r.fecha_cambio)
      if (!dateObj) return true
      if (fechaInicio && dateObj < new Date(`${fechaInicio}T00:00:00`)) return false
      if (fechaFin && dateObj > new Date(`${fechaFin}T00:00:00`)) return false
      if (mesFiltro) {
        const m = String(dateObj.getMonth() + 1).padStart(2, '0')
        const y = dateObj.getFullYear()
        if (`${y}-${m}` !== mesFiltro) return false
      }
      return true
    })
  }, [registrosCalculados, fechaInicio, fechaFin, mesFiltro])

  const registrosCalculadosDinamicos = useMemo(() => {
    let baseline_pzs_hr = null;
    return registrosParaMostrar.map((reg, idx, arr) => {
      let valTiempo = 0;
      if (metricaActiva === 'tiempo_total') {
        valTiempo = (Number(reg.tiempo) || 0) + (Number(reg.tiempo_preparacion) || 0) + (Number(reg.tiempo_mano_obra) || 0);
      } else {
        valTiempo = Number(reg[metricaActiva]) || 0;
      }
      
      const equipos = Number(reg.equipos) || 1;
      let pzs_hr = null; let seg_pz = null; let mejora = null; let mejora_global = null;
      
      if (valTiempo > 0 && equipos > 0) {
        pzs_hr = (1000 / valTiempo) / equipos;
        seg_pz = pzs_hr > 0 ? 3600 / pzs_hr : 0;
        
        if (baseline_pzs_hr === null) baseline_pzs_hr = pzs_hr;
        else mejora_global = ((pzs_hr - baseline_pzs_hr) / baseline_pzs_hr) * 100;
      }
      
      if (idx > 0) {
        let valTiempoAnt = 0;
        const regAnt = arr[idx - 1];
        if (metricaActiva === 'tiempo_total') { 
          valTiempoAnt = (Number(regAnt.tiempo) || 0) + (Number(regAnt.tiempo_preparacion) || 0) + (Number(regAnt.tiempo_mano_obra) || 0);
        } else { valTiempoAnt = Number(regAnt[metricaActiva]) || 0; }
        const equiposAnt = Number(regAnt.equipos) || 1;
        
        if (valTiempoAnt > 0 && equiposAnt > 0) {
          const pzs_hr_ant = (1000 / valTiempoAnt) / equiposAnt;
          if (pzs_hr !== null) mejora = ((pzs_hr - pzs_hr_ant) / pzs_hr_ant) * 100;
        }
      }
      return { ...reg, _dinamico: { pzs_hr, seg_pz, mejora, mejora_global, valTiempo } };
    });
  }, [registrosParaMostrar, metricaActiva])

  const [fechaGrafica, setFechaGrafica] = useState('')
  useEffect(() => {
    if (registrosCalculadosDinamicos.length > 0) {
      if (!fechaGrafica || !registrosCalculadosDinamicos.find(r => r.fecha_cambio === fechaGrafica)) {
        setFechaGrafica(registrosCalculadosDinamicos[registrosCalculadosDinamicos.length - 1].fecha_cambio);
      }
    }
  }, [registrosCalculadosDinamicos, fechaGrafica]);

  const datosHistorialAgrupados = useMemo(() => {
    const arr = [];
    registrosCalculadosDinamicos.forEach(reg => {
      const fechaCorta = reg.fecha_cambio.substring(0, 5); 
      arr.push({ operacion_num: `${fechaCorta} (Op)`, valor: Number(reg.tiempo) || 0, color: '#3b82f6', fecha_cambio: reg.fecha_cambio, equipos: reg.equipos });
      arr.push({ operacion_num: `${fechaCorta} (Pr)`, valor: Number(reg.tiempo_preparacion) || 0, color: '#f59e0b', fecha_cambio: reg.fecha_cambio, equipos: reg.equipos });
      arr.push({ operacion_num: `${fechaCorta} (MO)`, valor: Number(reg.tiempo_mano_obra) || 0, color: '#10b981', fecha_cambio: reg.fecha_cambio, equipos: reg.equipos });
    });
    return arr;
  }, [registrosCalculadosDinamicos]);

  const handleDownloadTable = async () => {
    if (!tableRef.current) return
    try {
      const dataUrl = await htmlToImage.toPng(tableRef.current, { backgroundColor: '#ffffff', pixelRatio: 2, filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true') })
      const a = document.createElement('a'); a.download = `trazabilidad_${material.numero_material}_${proceso.nombre_proceso}.png`; a.href = dataUrl; a.click()
    } catch (error) { showToast("Error al generar la imagen de la tabla.", "error") }
  }

  if (registrosParaMostrar.length === 0) return null;

  const stickyColClass = "px-4 py-3 text-left w-[12rem] min-w-[12rem] border-r border-gray-200 sticky left-0 z-10 shadow-[2px_0_4px_-2px_rgba(0,0,0,0.1)] transition-colors"

  return (
    <div className="mb-6">
      <div className="overflow-x-auto pb-3 [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-gray-50 [&::-webkit-scrollbar-thumb]:bg-gray-300 hover:[&::-webkit-scrollbar-thumb]:bg-gray-400 [&::-webkit-scrollbar-thumb]:rounded-full">
        <div ref={tableRef} className="flex flex-col bg-white min-w-max pb-2">
          
          <div className="border border-gray-200 shadow-sm overflow-hidden rounded-t-sm">
            <table className="min-w-full text-sm whitespace-nowrap">
              <tbody className="divide-y divide-gray-100">
                <tr className="bg-blue-50">
                  <td className={`${stickyColClass} font-bold text-[#003588] bg-blue-50`}>
                    <div className="flex items-center justify-between gap-2"><span>Proceso</span></div>
                  </td>
                  <td colSpan={registrosParaMostrar.length || 1} className="px-5 py-3 font-bold text-[#003588] tracking-wide text-left">
                    <div className="flex items-center justify-between relative w-full">
                      <span>{proceso.nombre_proceso}</span>
                      <button data-html2canvas-ignore="true" onClick={handleDownloadTable} className="p-1.5 bg-white rounded shadow-sm border border-blue-100 text-[#003588] hover:bg-[#003588] hover:text-white transition-colors focus:outline-none flex-shrink-0"><Download className="w-3.5 h-3.5" /></button>
                    </div>
                  </td>
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Fecha cambio en SAP</td>
                  {registrosParaMostrar.map((r, i) => <td key={`fecha-${i}`} className="px-5 py-3 text-left font-bold text-gray-900 border-r border-gray-100">{r.fecha_cambio}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Tiempo Operación</td>
                  {registrosParaMostrar.map((r, i) => <td key={`tiempo-${i}`} className="px-5 py-3 text-left text-gray-900 border-r border-gray-100">{r.tiempo != null ? Number(r.tiempo).toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Tiempo Prep.</td>
                  {registrosParaMostrar.map((r, i) => <td key={`tprep-${i}`} className="px-5 py-3 text-left text-gray-900 border-r border-gray-100">{r.tiempo_preparacion != null ? Number(r.tiempo_preparacion).toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Tiempo M. Obra</td>
                  {registrosParaMostrar.map((r, i) => <td key={`tmo-${i}`} className="px-5 py-3 text-left text-gray-900 border-r border-gray-100">{r.tiempo_mano_obra != null ? Number(r.tiempo_mano_obra).toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Equipos</td>
                  {registrosParaMostrar.map((r, i) => <td key={`equipos-${i}`} className="px-5 py-3 text-left text-gray-900 border-r border-gray-100">{r.equipos}</td>)}
                </tr>
              </tbody>
            </table>
          </div>

          <div className="bg-gray-50 border-x border-gray-200 px-5 py-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-[inset_0px_2px_4px_rgba(0,0,0,0.02)]">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1.5"><Calculator className="w-4 h-4 text-[#003588]" />Base de cálculo para rendimiento:</span>
            <div className="flex bg-white border border-gray-300 rounded-none shadow-sm text-xs font-medium">
              {[ { id: 'tiempo', label: 'T. Operación' }, { id: 'tiempo_preparacion', label: 'T. Preparación' }, { id: 'tiempo_mano_obra', label: 'T. M. Obra' }, { id: 'tiempo_total', label: 'Suma Total' } ].map(opt => (
                <button key={opt.id} onClick={() => setMetricaActiva(opt.id)} className={`px-3 py-1.5 border-r last:border-r-0 border-gray-200 transition-colors focus:outline-none ${metricaActiva === opt.id ? 'bg-[#003588] text-white font-bold' : 'text-gray-600 hover:bg-gray-100'}`}>{opt.label}</button>
              ))}
            </div>
          </div>

          <div className="border border-gray-200 shadow-sm overflow-hidden rounded-b-sm">
            <table className="min-w-full text-sm whitespace-nowrap">
              <tbody className="divide-y divide-gray-100">
                <tr className="bg-blue-50/50">
                  <td className={`${stickyColClass} font-bold text-[#003588] bg-blue-50/50`}>Fecha cambio en SAP</td>
                  {registrosCalculadosDinamicos.map((r, i) => <td key={`h-fecha2-${i}`} className="px-5 py-3 text-left font-bold text-[#003588] border-r border-blue-100/50">{r.fecha_cambio}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>pzs/hr</td>
                  {registrosCalculadosDinamicos.map((r, i) => <td key={`pzs-${i}`} className="px-5 py-3 text-left text-gray-900 border-r border-gray-100">{r._dinamico.pzs_hr != null ? r._dinamico.pzs_hr.toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} font-bold text-[#003588] bg-white group-hover:bg-gray-50`}>seg/pz</td>
                  {registrosCalculadosDinamicos.map((r, i) => <td key={`seg-${i}`} className="px-5 py-3 text-left font-bold text-gray-900 border-r border-gray-100">{r._dinamico.seg_pz != null ? r._dinamico.seg_pz.toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>% vs Anterior</td>
                  {registrosCalculadosDinamicos.map((r, i) => {
                    const val = r._dinamico.mejora; const color = val === null ? 'text-gray-400' : val > 0 ? 'text-green-600 font-semibold' : val < 0 ? 'text-red-500 font-semibold' : 'text-gray-500'
                    return <td key={`mejora-${i}`} className={`px-5 py-3 text-left border-r border-gray-100 ${color}`}>{val !== null ? `${val > 0 ? '+' : ''}${val.toFixed(3)}%` : '—'}</td>
                  })}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-bold bg-white group-hover:bg-gray-50`}>% Acumulado</td>
                  {registrosCalculadosDinamicos.map((r, i) => {
                    const val = r._dinamico.mejora_global; const color = val === null ? 'text-gray-400' : val > 0 ? 'text-green-600 font-bold' : val < 0 ? 'text-red-500 font-bold' : 'text-gray-500'
                    return <td key={`mejora-global-${i}`} className={`px-5 py-3 text-left border-r border-gray-100 ${color}`}>{val !== null ? `${val > 0 ? '+' : ''}${val.toFixed(3)}%` : '—'}</td>
                  })}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {registrosCalculadosDinamicos.length > 0 && (
        <div className="mt-4 border border-gray-200 shadow-sm bg-white p-5 rounded-sm">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 border-b border-gray-100 pb-4">
            <div className="flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-[#003588]" />
              <h3 className="text-sm font-bold text-[#003588] uppercase tracking-wider">Histórico de Tiempos (Por Fecha)</h3>
            </div>
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-[#3b82f6]"></div><span className="text-xs font-bold text-gray-600">Operación</span></div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-[#f59e0b]"></div><span className="text-xs font-bold text-gray-600">Preparación</span></div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-[#10b981]"></div><span className="text-xs font-bold text-gray-600">Mano de Obra</span></div>
            </div>
          </div>
          <div className="w-full">
            <GraficaBarras 
              titulo="" 
              datos={datosHistorialAgrupados} 
              unidad="hr" 
              metricaActual="tiempo" 
              onChangeMetrica={() => {}} 
              opcionesMetricas={[]} 
             />
          </div>
        </div>
      )}
    </div>
  )
}

function ProcesoResumen({ material }) {
  const tableRef = useRef(null)
  const showToast = useToast() 
  const [metricaActiva, setMetricaActiva] = useState('tiempo')

  const registrosDinamicos = useMemo(() => {
    return material.procesos.map(proc => {
      let bestMatch = null;
      let bestDate = 0;
      
      proc.historial?.forEach(r => {
        const d = parseFechaSap(r.fecha_cambio)?.getTime() || 0;
        if (d >= bestDate) {
          bestDate = d;
          bestMatch = r;
        }
      });
      
      if (!bestMatch) {
        return {
          nombre_proceso: proc.nombre_proceso,
          fecha_cambio: '—',
          tiempo: null, tiempo_preparacion: null, tiempo_mano_obra: null, equipos: null,
          _dinamico: { pzs_hr: null, seg_pz: null, valTiempo: 0 }
        };
      }
      
      let valTiempo = 0;
      if (metricaActiva === 'tiempo_total') {
        valTiempo = (Number(bestMatch.tiempo) || 0) + (Number(bestMatch.tiempo_preparacion) || 0) + (Number(bestMatch.tiempo_mano_obra) || 0);
      } else { valTiempo = Number(bestMatch[metricaActiva]) || 0; }
      
      const equipos = Number(bestMatch.equipos) || 1;
      let pzs_hr = null; let seg_pz = null;
      
      if (valTiempo > 0 && equipos > 0) {
        pzs_hr = (1000 / valTiempo) / equipos;
        seg_pz = pzs_hr > 0 ? 3600 / pzs_hr : 0;
      }
      
      return { ...bestMatch, nombre_proceso: proc.nombre_proceso, _dinamico: { pzs_hr, seg_pz, valTiempo } };
    }).filter(Boolean);
  }, [material.procesos, metricaActiva])

  const datosAgrupadosResumen = useMemo(() => {
    const arr = [];
    registrosDinamicos.forEach(reg => {
      const nombreProceso = reg.nombre_proceso; 
      arr.push({ operacion_num: `${nombreProceso} (Op)`, valor: Number(reg.tiempo) || 0, color: '#3b82f6', fecha_cambio: reg.fecha_cambio, equipos: reg.equipos });
      arr.push({ operacion_num: `${nombreProceso} (Pr)`, valor: Number(reg.tiempo_preparacion) || 0, color: '#f59e0b', fecha_cambio: reg.fecha_cambio, equipos: reg.equipos });
      arr.push({ operacion_num: `${nombreProceso} (MO)`, valor: Number(reg.tiempo_mano_obra) || 0, color: '#10b981', fecha_cambio: reg.fecha_cambio, equipos: reg.equipos });
    });
    return arr;
  }, [registrosDinamicos]);

  const handleDownloadTable = async () => {
    if (!tableRef.current) return
    try {
      const dataUrl = await htmlToImage.toPng(tableRef.current, { backgroundColor: '#ffffff', pixelRatio: 2, filter: (n) => !(n?.getAttribute && n.getAttribute('data-html2canvas-ignore') === 'true') })
      const a = document.createElement('a'); a.download = `resumen_linea_${material.numero_material}.png`; a.href = dataUrl; a.click()
    } catch (error) { showToast("Error al generar imagen.", "error") }
  }

  if (material.procesos.length === 0) return null;

  const stickyColClass = "px-4 py-3 text-left w-[12rem] min-w-[12rem] border-r border-gray-200 sticky left-0 z-10 shadow-[2px_0_4px_-2px_rgba(0,0,0,0.1)] transition-colors"

  return (
    <div className="mb-6">
      <div className="flex items-center gap-3 px-4 py-3 mb-4">
        <Info className="w-5 h-5 text-gray-500 shrink-0" />
        <span className="text-sm text-gray-600">
          Las mediciones mostradas corresponden a la última fecha de actualización en SAP de cada proceso y están expresadas en horas.
        </span>
      </div>

      <div className="overflow-x-auto pb-3 [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-gray-50 [&::-webkit-scrollbar-thumb]:bg-gray-300 hover:[&::-webkit-scrollbar-thumb]:bg-gray-400 [&::-webkit-scrollbar-thumb]:rounded-full">
        <div ref={tableRef} className="flex flex-col bg-white min-w-max pb-2">
          
          <div className="border border-gray-200 shadow-sm overflow-hidden rounded-t-sm">
            <table className="min-w-full text-sm whitespace-nowrap">
              <tbody className="divide-y divide-gray-100">
                <tr className="bg-blue-50">
                  <td className={`${stickyColClass} font-bold text-[#003588] bg-blue-50`}>
                    <div className="flex items-center justify-between gap-2">
                      <span>Proceso</span>
                      <button data-html2canvas-ignore="true" onClick={handleDownloadTable} className="p-1.5 bg-white rounded shadow-sm border border-blue-100 text-[#003588] hover:bg-[#003588] hover:text-white transition-colors focus:outline-none flex-shrink-0"><Download className="w-3.5 h-3.5" /></button>
                    </div>
                  </td>
                  {registrosDinamicos.map((r, i) => (
                    <td key={`proc-${i}`} className="px-5 py-3 font-bold text-[#003588] text-center border-r border-blue-100 uppercase">
                      {r.nombre_proceso}
                    </td>
                  ))}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Fecha último cambio</td>
                  {registrosDinamicos.map((r, i) => <td key={`fecha-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.fecha_cambio}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Tiempo Operación</td>
                  {registrosDinamicos.map((r, i) => <td key={`tiempo-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.tiempo != null ? Number(r.tiempo).toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Tiempo Prep.</td>
                  {registrosDinamicos.map((r, i) => <td key={`tprep-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.tiempo_preparacion != null ? Number(r.tiempo_preparacion).toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Tiempo M. Obra</td>
                  {registrosDinamicos.map((r, i) => <td key={`tmo-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.tiempo_mano_obra != null ? Number(r.tiempo_mano_obra).toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>Equipos</td>
                  {registrosDinamicos.map((r, i) => <td key={`equipos-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.equipos}</td>)}
                </tr>
              </tbody>
            </table>
          </div>

          <div className="bg-gray-50 border-x border-gray-200 px-5 py-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-[inset_0px_2px_4px_rgba(0,0,0,0.02)]">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1.5"><Calculator className="w-4 h-4 text-[#003588]" />Base de cálculo para rendimiento:</span>
            <div className="flex bg-white border border-gray-300 rounded-none shadow-sm text-xs font-medium">
              {[ { id: 'tiempo', label: 'T. Operación' }, { id: 'tiempo_preparacion', label: 'T. Preparación' }, { id: 'tiempo_mano_obra', label: 'T. M. Obra' }, { id: 'tiempo_total', label: 'Suma Total' } ].map(opt => (
                <button key={opt.id} onClick={() => setMetricaActiva(opt.id)} className={`px-3 py-1.5 border-r last:border-r-0 border-gray-200 transition-colors focus:outline-none ${metricaActiva === opt.id ? 'bg-[#003588] text-white font-bold' : 'text-gray-600 hover:bg-gray-100'}`}>{opt.label}</button>
              ))}
            </div>
          </div>

          <div className="border border-gray-200 shadow-sm overflow-hidden rounded-b-sm">
            <table className="min-w-full text-sm whitespace-nowrap">
              <tbody className="divide-y divide-gray-100">
                <tr className="bg-blue-50/50">
                  <td className={`${stickyColClass} font-bold text-[#003588] bg-blue-50/50`}>Métrica de Rendimiento</td>
                  {registrosDinamicos.map((r, i) => <td key={`m-${i}`} className="px-5 py-3 text-center font-bold text-transparent border-r border-blue-100/50 select-none">.</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>pzs/hr</td>
                  {registrosDinamicos.map((r, i) => <td key={`pzs-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r._dinamico.pzs_hr != null ? r._dinamico.pzs_hr.toFixed(3) : '—'}</td>)}
                </tr>
                <tr className="group hover:bg-gray-50 bg-white transition-colors">
                  <td className={`${stickyColClass} font-bold text-[#003588] bg-white group-hover:bg-gray-50`}>seg/pz</td>
                  {registrosDinamicos.map((r, i) => <td key={`seg-${i}`} className="px-5 py-3 text-center font-bold text-gray-900 border-r border-gray-100">{r._dinamico.seg_pz != null ? r._dinamico.seg_pz.toFixed(3) : '—'}</td>)}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="mt-4 border border-gray-200 shadow-sm bg-white p-5 rounded-sm">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 border-b border-gray-100 pb-4">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-[#003588]" />
            <h3 className="text-sm font-bold text-[#003588] uppercase tracking-wider">Balanceo de Línea (Todos los Procesos)</h3>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-[#3b82f6]"></div><span className="text-xs font-bold text-gray-600">Operación</span></div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-[#f59e0b]"></div><span className="text-xs font-bold text-gray-600">Preparación</span></div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-[#10b981]"></div><span className="text-xs font-bold text-gray-600">Mano de Obra</span></div>
          </div>
        </div>
        <div className="w-full mb-4">
          <GraficaBarras 
            titulo="" 
            datos={datosAgrupadosResumen} 
            unidad="hr" 
            metricaActual="tiempo" 
            onChangeMetrica={() => {}} 
            opcionesMetricas={[]} 
            anguloRotacion={registrosDinamicos.length > 3 ? -25 : 0} 
            esResumen={true} 
          />
        </div>
      </div>
    </div>
  )
}

function MaterialCard({ material, fechaInicio, fechaFin, mesFiltro, seccionActiva }) {
  const [isExpanded, setIsExpanded] = useState(false)
  const cardRef = useRef(null)
  const modalCardRef = useRef(null)

  const handleDownloadGlobal = async (refTarget) => {
    if (!refTarget.current) return
    try {
      const dataUrl = await htmlToImage.toPng(refTarget.current, { backgroundColor: '#ffffff', pixelRatio: 2, filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true') })
      const a = document.createElement('a'); a.download = `trazabilidad_completa_${material.numero_material}.png`; a.href = dataUrl; a.click()
    } catch (error) { console.error(error) }
  }

  const CardContent = ({ refer, isModal }) => (
    <div ref={refer} className="w-full relative bg-white border border-gray-200 shadow-sm p-4">
      {!isModal && (
        <div data-html2canvas-ignore="true" className="absolute top-2 right-2 flex items-center gap-1 z-20 bg-gray-50 p-1 border border-gray-200 shadow-sm">
          <button onClick={() => handleDownloadGlobal(cardRef)} className="p-1.5 text-gray-500 hover:text-[#003588] transition-colors focus:outline-none" title="Descargar todas las tablas"><Download className="w-4 h-4" /></button>
          <button onClick={() => setIsExpanded(true)} className="p-1.5 text-gray-500 hover:text-[#003588] transition-colors focus:outline-none" title="Expandir vista"><Maximize2 className="w-4 h-4" /></button>
        </div>
      )}
      <div className="mb-4 mt-2 px-2">
        <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Núm. Parte</p>
        <p className="text-xl font-bold text-[#003588] leading-none">{material.numero_material} <span className="text-gray-400 text-sm ml-2 font-medium">{material.proyecto || '—'}</span></p>
      </div>
      <div className="mt-4">
        {seccionActiva === 'RESUMEN' ? (
          <ProcesoResumen material={material} />
        ) : (
          material.procesos.map((proc) => (
            <ProcesoHistorial key={proc.nombre_proceso} proceso={proc} material={material} fechaInicio={fechaInicio} fechaFin={fechaFin} mesFiltro={mesFiltro} />
          ))
        )}
      </div>
    </div>
  )

  return (
    <div className="mb-10 relative">
      <CardContent refer={cardRef} isModal={false} />
      {isExpanded && (
        <div onClick={(e) => e.target === e.currentTarget && setIsExpanded(false)} className="fixed inset-0 z-[9999] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8 cursor-pointer transition-opacity">
          <div className="bg-gray-50 border border-gray-200 shadow-2xl w-full max-w-7xl h-full max-h-[85vh] flex flex-col rounded-none cursor-default overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white shrink-0 shadow-sm z-10">
              <p className="text-sm font-bold text-[#003588] uppercase tracking-wider flex items-center gap-2"><Maximize2 className="w-4 h-4 text-[#003588]" /> Trazabilidad Histórica Ampliada</p>
              <div className="flex items-center gap-3">
                <button onClick={() => handleDownloadGlobal(modalCardRef)} className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 hover:text-[#003588] focus:outline-none"><Download className="w-4 h-4" /> <span className="hidden sm:inline">Descargar PNG Global</span></button>
                <div className="w-px h-6 bg-gray-300"></div>
                <button onClick={() => setIsExpanded(false)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 focus:outline-none border border-transparent"><X className="w-5 h-5" /></button>
              </div>
            </div>
            <div className="flex-1 p-6 md:p-10 overflow-y-auto bg-gray-50"><CardContent refer={modalCardRef} isModal={true} /></div>
          </div>
        </div>
      )}
    </div>
  )
}

const TiemposProcesoPage = () => {
  const { proceso: seccionParam } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const showToast = useToast()

  const { centroActual } = useOutletContext() || { centroActual: '0094' }

  // 1. ESTADOS DE FILTROS Y PAGINACIÓN
  const [filtroMaterial, setFiltroMaterial] = useState(null)
  const [fechaInicio, setFechaInicio] = useState('')
  const [fechaFin, setFechaFin] = useState('')
  const [mesFiltro, setMesFiltro] = useState(null)
  const [filtroProyecto, setFiltroProyecto] = useState(null)
  const [paginaActual, setPaginaActual] = useState(1)
  const limit = 5

  const [isSyncing, setIsSyncing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [isNuevoMaterialOpen, setIsNuevoMaterialOpen] = useState(false)

  // 2. LLAMADAS A LA API
  const { data: seccionesRaw = [], isLoading: cargandoSecciones } = useSecciones(filtroMaterial, centroActual)
  const { data: filtrosGlobales } = useFiltrosGraficas({ centro: centroActual })

  const seccionActiva = seccionParam ? decodeURIComponent(seccionParam) : null
  
  // 🐛 FIX: Si el usuario selecciona "RESUMEN", le pedimos a la API que devuelva "TODOS"
  const backendSeccion = (seccionActiva === 'RESUMEN' || !seccionActiva) ? 'TODOS' : seccionActiva;

  // --- MAGIA SERVER-SIDE ---
  const { data: apiResponse, isLoading, isError } = useDashboardSeccion({
    seccion: backendSeccion,
    centro: centroActual,
    page: paginaActual,
    limit: limit,
    numero_material: filtroMaterial,
    proyecto: filtroProyecto,
    fecha_inicio: fechaInicio || null,
    fecha_fin: fechaFin || null,
    mes_exacto: mesFiltro
  })

  // Extraemos los datos pre-digeridos por Python
  const materiales = apiResponse?.datos || []
  const totalPaginas = apiResponse?.total_paginas || 1
  const totalRegistros = apiResponse?.total_registros || 0

  const ejecutarSincronizacion = async () => {
    setIsSyncing(true)
    setProgress(5)

    const interval = setInterval(() => {
      setProgress((prev) => {
        const remaining = 95 - prev;
        return prev + (remaining * 0.15);
      })
    }, 800)

    try {
      const datos = await sincronizarDatosSAP(centroActual)
      clearInterval(interval)
      setProgress(100)
      await queryClient.invalidateQueries()
      showToast(`Sincronización completada. ${datos.total_materiales || 'Varios'} materiales procesados.`, 'success')
    } catch (error) {
      clearInterval(interval)
      setProgress(0)
      console.error('Falló la sincronización:', error)
      showToast('Ocurrió un error al intentar sincronizar con SAP.', 'error')
    } finally {
      setTimeout(() => {
        setIsSyncing(false)
        setProgress(0)
      }, 1000)
    }
  }

  const tabsVisibles = useMemo(() => {
    if (seccionesRaw.length === 0) return []
    return ['RESUMEN', 'TODOS', ...seccionesRaw]
  }, [seccionesRaw])

  useEffect(() => {
    if (!cargandoSecciones) {
      if (tabsVisibles.length > 0) {
        if (!seccionActiva || !tabsVisibles.includes(seccionActiva)) {
          navigate(`/app/tiempos/RESUMEN`, { replace: true })
        }
      } else if (tabsVisibles.length === 0 && seccionParam) {
        navigate(`/app/tiempos`, { replace: true })
      }
    }
  }, [seccionActiva, seccionParam, tabsVisibles, navigate, cargandoSecciones])

  useEffect(() => {
    setPaginaActual(1)
  }, [filtroMaterial, filtroProyecto, mesFiltro, fechaInicio, fechaFin, seccionActiva, centroActual])

  const opcionesMateriales = useMemo(() => {
    return (filtrosGlobales?.numeros_material || []).map((m) => ({ value: m, label: m }))
  }, [filtrosGlobales])

  const opcionesProyectos = useMemo(() => {
    return (filtrosGlobales?.proyectos || []).map((p) => ({ value: p, label: p }))
  }, [filtrosGlobales])

  const opcionesMeses = useMemo(() => {
    return (filtrosGlobales?.meses || []).map((m) => ({ value: m.value, label: m.label }))
  }, [filtrosGlobales])

  const valMaterial = filtroMaterial ? opcionesMateriales.find((opt) => opt.value === filtroMaterial) : null
  const valProyecto = filtroProyecto ? opcionesProyectos.find((opt) => opt.value === filtroProyecto) : null

  return (
    <div className="h-full flex flex-col bg-gray-50 overflow-hidden relative">
      
      {isSyncing && (
        <div className="absolute top-0 left-0 w-full h-1 bg-gray-200 z-[100] overflow-hidden">
          <div className="h-full bg-[#003588] transition-all duration-300 ease-out relative" style={{ width: `${progress}%` }}>
            <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
          </div>
        </div>
      )}

      <div className="bg-white border-b border-gray-200 px-6 py-4 shrink-0 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <Clock className="h-6 w-6 text-[#003588]" />
          <h2 className="text-xl md:text-2xl font-bold text-gray-900 m-0">Tiempos por Proceso</h2>

          <button
            onClick={ejecutarSincronizacion}
            disabled={isSyncing}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${
              isSyncing ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'
            }`}
            title="Sincronizar base de datos con SAP"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">
              {isSyncing ? `Sincronizando... ${Math.round(progress)}%` : 'Sincronizar SAP'}
            </span>
          </button>

          <button
            onClick={() => setIsNuevoMaterialOpen(true)}
            disabled={!centroActual || isSyncing}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${
              !centroActual || isSyncing ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'
            }`}
            title={centroActual ? 'Importar nuevo material desde SAP' : 'Selecciona un centro específico'}
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Importar Material</span>
          </button>
        </div>

        <div className="w-full md:w-80">
          <CustomSelect
            options={opcionesMateriales}
            value={valMaterial}
            onChange={(opt) => {
              setFiltroMaterial(opt?.value ?? null)
              setMesFiltro(null)
              setFiltroProyecto(null)
            }}
            placeholder="Buscar número de parte..."
            isClearable
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 scroll-smooth">
        
        {(seccionActiva || filtroMaterial) && (
          <div className="border border-gray-200 bg-white shadow-sm p-5 rounded-none mb-6">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-[#003588]" /> Parámetros de Filtrado Avanzado
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 items-end">
              
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Plataforma</label>
                <CustomSelect options={opcionesProyectos} value={valProyecto} onChange={(opt) => setFiltroProyecto(opt?.value ?? null)} placeholder="Todos..." isDisabled={opcionesProyectos.length === 0} isClearable />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Mes Exacto</label>
                <CustomSelect options={opcionesMeses} value={opcionesMeses.find((o) => o.value === mesFiltro) || null} onChange={(opt) => setMesFiltro(opt?.value ?? null)} placeholder="Todos..." isDisabled={opcionesMeses.length === 0} isClearable />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Inicio</label>
                <input type="date" value={fechaInicio} onChange={(e) => setFechaInicio(e.target.value)} className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors" />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Fin</label>
                <input type="date" value={fechaFin} onChange={(e) => setFechaFin(e.target.value)} className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors" />
              </div>

              {(fechaInicio || fechaFin || mesFiltro || filtroProyecto) && (
                <div>
                  <button onClick={() => { setFechaInicio(''); setFechaFin(''); setMesFiltro(null); setFiltroProyecto(null); }} className="w-full md:w-auto px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold uppercase rounded-none transition-colors border border-gray-300 h-[38px] focus:outline-none">
                    Limpiar Filtros
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {tabsVisibles.length > 0 && (
          <nav className="w-full bg-white shrink-0 border border-gray-200 shadow-sm overflow-x-auto mb-6 rounded-none [&::-webkit-scrollbar]:hidden" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
            <div className="flex w-max min-w-full">
              {cargandoSecciones ? (
                <div className="px-6 py-4 text-sm text-gray-400">Cargando procesos...</div>
              ) : (
                tabsVisibles.map((sec) => {
                  const isActive = sec === seccionActiva
                  return (
                    <button key={sec} onClick={() => navigate(`/app/tiempos/${encodeURIComponent(sec)}`)} className={`px-8 py-4 text-sm font-medium border-r border-gray-200 transition-colors rounded-none block focus:outline-none flex-shrink-0 ${isActive ? 'bg-[#003588] text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}>
                      {sec}
                    </button>
                  )
                })
              )}
            </div>
          </nav>
        )}

        {isLoading && (
          <div className="flex justify-center py-10">
            <div className="h-10 w-10 rounded-full border-4 border-gray-200 border-t-[#003588] animate-spin" />
          </div>
        )}

        {isError && (
          <div className="border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700 rounded-none mb-6">
            Error al cargar datos de SAP.
          </div>
        )}

        {!isLoading && !isError && totalRegistros === 0 && (
          <div className="border border-gray-200 bg-white shadow-sm p-10 text-center rounded-none mt-4">
            <p className="text-sm text-gray-400">
              No hay coincidencias para los filtros aplicados en la vista <strong>{seccionActiva}</strong>.
            </p>
          </div>
        )}

        {!isLoading && materiales.map((material) => (
          <MaterialCard
            key={material.numero_material}
            material={material}
            fechaInicio={fechaInicio}
            fechaFin={fechaFin}
            mesFiltro={mesFiltro}
            seccionActiva={seccionActiva}
          />
        ))}

        {totalPaginas > 1 && (
          <div className="flex items-center justify-between border border-gray-200 bg-white px-4 py-3 sm:px-6 shadow-sm mt-2 mb-8">
            <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Mostrando <span className="font-medium text-[#003588]">{(paginaActual - 1) * limit + 1}</span> a <span className="font-medium text-[#003588]">{Math.min(paginaActual * limit, totalRegistros)}</span> de <span className="font-medium text-[#003588]">{totalRegistros}</span> números de parte
                </p>
              </div>
              <div>
                <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
                  <button onClick={() => { setPaginaActual(p => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: 'smooth' }); }} disabled={paginaActual === 1} className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed">
                    <span className="sr-only">Anterior</span>
                    <ChevronLeft className="h-5 w-5" aria-hidden="true" />
                  </button>
                  
                  {[...Array(totalPaginas)].map((_, i) => {
                    const numPagina = i + 1;
                    const isCurrent = numPagina === paginaActual;
                    
                    if (numPagina === 1 || numPagina === totalPaginas || (numPagina >= paginaActual - 2 && numPagina <= paginaActual + 2)) {
                      return (
                        <button key={numPagina} onClick={() => { setPaginaActual(numPagina); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className={`relative inline-flex items-center px-4 py-2 text-sm font-semibold focus:z-20 focus:outline-offset-0 ${isCurrent ? 'bg-[#003588] text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#003588]' : 'text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50'}`}>
                          {numPagina}
                        </button>
                      );
                    } else if (numPagina === paginaActual - 3 || numPagina === paginaActual + 3) {
                      return <span key={numPagina} className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-700 ring-1 ring-inset ring-gray-300 focus:outline-offset-0">...</span>
                    }
                    return null;
                  })}

                  <button onClick={() => { setPaginaActual(p => Math.min(totalPaginas, p + 1)); window.scrollTo({ top: 0, behavior: 'smooth' }); }} disabled={paginaActual === totalPaginas} className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed">
                    <span className="sr-only">Siguiente</span>
                    <ChevronRight className="h-5 w-5" aria-hidden="true" />
                  </button>
                </nav>
              </div>
            </div>
          </div>
        )}

      </div>
      <NuevoMaterialModal isOpen={isNuevoMaterialOpen} onClose={() => setIsNuevoMaterialOpen(false)} centroActual={centroActual} />
    </div>
  )
}

export default TiemposProcesoPage