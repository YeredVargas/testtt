// src/pages/costos/CostosPage.jsx
import React, { useEffect, useMemo, useState, useRef } from 'react'
import { useOutletContext } from 'react-router-dom'
import { Maximize2, Minimize2, Download, X, Filter, RefreshCw, DollarSign, BarChart2, ChevronDown, Check, Calculator, WifiOff, Plus, Layers, Loader2 } from 'lucide-react'
import * as htmlToImage from 'html-to-image'
import { useQueryClient } from '@tanstack/react-query'
import { useCostos, useCostosDetalle, useSincronizarCostos, useSyncStatus, useCostosProduccion } from '../../hooks/useCostos'
import CustomSelect from '../../components/ui/CustomSelect'
import { useToast } from '../../components/ui/ToastContext'
import NuevoMaterialModal from '../../components/ui/NuevoMaterialModal'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, LabelList, Legend } from 'recharts'

const REGISTROS_POR_PAGINA = 5

// CATÁLOGO DE VARIANTES BASADO EN SAP
const OPCIONES_VARIANTES_SAP = [
  { value: 'PPC1', label: 'PPC1 - Cálculo costes plan' },
  { value: 'PPC2', label: 'PPC2 - Cálculo costes teor.' },
  { value: 'PPC3', label: 'PPC3 - Cálculo costes act.' },
  { value: 'PREM', label: 'PREM - Versiones fab. repetitiva' },
  { value: 'Y001', label: 'Y001 - Yearly standard calculat.' },
  { value: 'Y002', label: 'Y002 - monthly calculation' },
  { value: 'Y003', label: 'Y003 - monthly quotation calc.' },
  { value: 'Y004', label: 'Y004 - Single run quotat.calc.' },
  { value: 'Y008', label: 'Y008 - Variante 008' },
  { value: 'Y010', label: 'Y010 - Tax based calculation' },
  { value: 'Y011', label: 'Y011 - Yearly standard calculat.' },
  { value: 'Y020', label: 'Y020 - Variante 020' },
  { value: 'Y021', label: 'Y021 - multiple calc. 2nd run' },
  { value: 'Y023', label: 'Y023 - Variante 023' },
  { value: 'Y030', label: 'Y030 - Variante 030' },
  { value: 'Y040', label: 'Y040 - Variante 040' },
  { value: 'Y050', label: 'Y050 - Repetitive Mfg Plan' }
];

const formatearDinero = (monto) => {
  if (monto == null || monto === 0) return <span className="text-gray-300 font-normal">-</span>
  return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(monto)
}

const formatearFecha = (fecha) => {
  if (!fecha) return '-'
  const partes = fecha.split('-')
  if (partes.length === 3) {
    return `${partes[2]}.${partes[1]}.${partes[0]}`
  }
  return fecha
}

const toNumber = (value) => {
  const n = Number(value)
  return Number.isFinite(n) ? n : 0
}

const formatCompact = (val) => {
  if (val === 0 || val == null) return '0';
  return new Intl.NumberFormat('en-US', { notation: "compact", compactDisplay: "short" }).format(val);
}

// RENDERIZADOR PERSONALIZADO PARA ETIQUETAS BLANCAS DENTRO DE LAS BARRAS
const EtiquetaPorcentaje = (props) => {
  const { x, y, width, height, value } = props;
  
  if (!value || height < 15 || Number(value) === 0) return null; 

  return (
    <text 
      x={x + width / 2} 
      y={y + height / 2} 
      fill="#f2f2f5" 
      textAnchor="middle" 
      dominantBaseline="middle"
      className="font-bold text-[10px] sm:text-[11px] md:text-sm"
    >
      {value}%
    </text>
  );
};

// 🔴 CONTENEDOR CORREGIDO: SE AGREGÓ min-h-[320px] PARA FORZAR LA VISIBILIDAD DE RECHARTS
const ChartWrapper = ({ titulo, filename, children }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const chartRef = useRef(null);
  const modalRef = useRef(null);

  const handleDownload = () => {
    const ref = isExpanded ? modalRef : chartRef;
    if (!ref.current) return;
    const svgElement = ref.current.querySelector('svg');
    if (!svgElement) return;
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgElement);
    const blob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${filename}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderHeader = (isModal = false) => (
    <div className={`flex justify-between items-center pb-4 border-b border-gray-200 shrink-0 ${isModal ? 'px-6 py-4 bg-white' : 'mb-4'}`}>
      <div className="flex items-center gap-3">
        {isModal && <Maximize2 className="w-4 h-4 text-[#003588] font-bold" />}
        <h3 className={`text-xs font-bold uppercase tracking-wider ${isModal ? 'text-[#003588]' : 'text-gray-500'}`}>
          {titulo}
        </h3>
        {!isModal && (
          <span className="bg-blue-50 text-[#003588] text-[10px] font-bold px-2 py-0.5 border border-blue-100 rounded-sm">
            MXN
          </span>
        )}
      </div>
      <div className="flex items-center gap-3">
        {isModal ? (
          <>
            <button onClick={handleDownload} className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 hover:text-[#003588] transition-colors focus:outline-none">
              <Download className="w-4 h-4" /> DESCARGAR PNG
            </button>
            <div className="w-px h-6 bg-gray-300"></div>
            <button onClick={() => setIsExpanded(false)} className="text-gray-400 hover:text-red-500 transition-colors focus:outline-none" title="Cerrar">
              <X className="w-5 h-5" />
            </button>
          </>
        ) : (
          <>
            <button onClick={handleDownload} className="text-gray-400 hover:text-[#003588] transition-colors focus:outline-none" title="Descargar gráfica">
              <Download className="w-4 h-4" />
            </button>
            <button onClick={() => setIsExpanded(true)} className="text-gray-400 hover:text-[#003588] transition-colors focus:outline-none" title="Expandir gráfica">
              <Maximize2 className="w-4 h-4" />
            </button>
          </>
        )}
      </div>
    </div>
  );

  if (isExpanded) {
    return (
      <>
        {/* Vista Normal (mantenida debajo del modal para evitar que desaparezca) */}
        <div className="flex flex-col border border-gray-200 shadow-sm bg-white p-6 h-full relative" ref={chartRef}>
          {renderHeader(false)}
          <div className="w-full h-80 min-h-[320px]">{children}</div>
        </div>
        
        {/* Modal Expandido Clásico */}
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 sm:p-10" onClick={() => setIsExpanded(false)}>
          <div className="bg-gray-50 border border-gray-200 shadow-2xl w-full max-w-7xl h-[85vh] flex flex-col rounded-sm overflow-hidden" onClick={e => e.stopPropagation()}>
            {renderHeader(true)}
            <div className="flex-1 p-8 bg-white overflow-hidden flex flex-col" ref={modalRef}>
              <div className="flex-1 w-full h-full min-h-[500px]">
                {children}
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <div className="flex flex-col border border-gray-200 shadow-sm bg-white p-6 h-full relative" ref={chartRef}>
      {renderHeader(false)}
      <div className="w-full h-80 min-h-[320px]">{children}</div>
    </div>
  );
};


function CostosGraficas({ material, data, elementos, isLoading, isError }) {
  
  // 1. DATOS GRÁFICA 1: Resumen de Costos
  const datosResumen = useMemo(() => {
    const total = toNumber(data?.total_global);
    const fijo = toNumber(data?.total_fijado);
    const variable = toNumber(data?.total_variable);

    const pctFijo = total > 0 ? ((fijo / total) * 100).toFixed(1) : '0.0';
    const pctVariable = total > 0 ? ((variable / total) * 100).toFixed(1) : '0.0';

    return [
      { operacion_num: 'Total', valor: total, color: '#003588', porcentaje: total > 0 ? '100.0' : '0.0' },
      { operacion_num: 'Fijo', valor: fijo, color: '#003588', porcentaje: pctFijo },
      { operacion_num: 'Variable', valor: variable, color: '#003588', porcentaje: pctVariable }
    ]
  }, [data]);

  // 2. DATOS GRÁFICA 2: Total por Denominación Elemento
  const datosPorDenominacion = useMemo(() => {
    const totalGlobal = toNumber(data?.total_global);
    return (elementos || []).map((e) => {
        const val = toNumber(e.total);
        return {
          operacion_num: e.denominacion, 
          valor: val, 
          color: '#003588',
          porcentaje: totalGlobal > 0 ? ((val / totalGlobal) * 100).toFixed(1) : '0.0'
        };
      }).sort((a, b) => b.valor - a.valor)
  }, [elementos, data]);

  // 3. DATOS GRÁFICA 3: Desglose Agrupado (Total, Fijo, Variable)
  const datosAgrupadosElemento = useMemo(() => {
    const totalGlobal = toNumber(data?.total_global);
    return (elementos || []).map(e => {
      const t = toNumber(e.total);
      const f = toNumber(e.fijado);
      const v = toNumber(e.variable);
      return {
        denominacion: e.denominacion,
        Total: t,
        Fijo: f,
        Variable: v,
        pct_total: totalGlobal > 0 ? ((t / totalGlobal) * 100).toFixed(1) : '0.0',
        pct_fijo: totalGlobal > 0 ? ((f / totalGlobal) * 100).toFixed(1) : '0.0',
        pct_variable: totalGlobal > 0 ? ((v / totalGlobal) * 100).toFixed(1) : '0.0',
      };
    }).sort((a, b) => b.Total - a.Total);
  }, [elementos, data]);

  if (isLoading) return <div className="mt-6 border border-gray-200 shadow-sm bg-white p-6"><div className="py-10 text-center text-gray-400 italic">Cargando gráficas de costos...</div></div>
  if (isError) return <div className="mt-6 border border-gray-200 shadow-sm bg-white p-6"><div className="py-10 text-center text-red-500 italic">Error al cargar las gráficas.</div></div>
  if (!data) return null

  const ResumenTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const pData = payload[0].payload;
      return (
        <div className="bg-white border-t-4 border-[#003588] shadow-xl p-4 rounded-none min-w-[200px]">
          <p className="font-black text-[#003588] text-sm border-b border-gray-100 pb-2 mb-2">{label}</p>
          <div className="space-y-1 text-sm">
            <p className="flex justify-between gap-4 font-semibold">
              <span style={{ color: pData.color }}>Monto:</span> 
              <span>{new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(pData.valor)}</span>
            </p>
            {pData.porcentaje && (
              <p className="flex justify-between gap-4 font-semibold text-gray-500">
                <span>% del Costo Global:</span> 
                <span>{pData.porcentaje}%</span>
              </p>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  const AgrupadaTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border-t-4 border-[#003588] shadow-xl p-4 rounded-none min-w-[280px]">
          <p className="font-black text-[#003588] text-sm border-b border-gray-100 pb-2 mb-2">{label}</p>
          <div className="space-y-1 text-sm">
            {payload.map((entry, index) => (
              <p key={index} className="flex justify-between gap-4 font-semibold">
                <span style={{ color: entry.color }}>{entry.name}:</span> 
                <span className="text-right">
                   {new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(entry.value)}
                   <span className="text-gray-400 ml-1 text-xs">({entry.payload[`pct_${entry.name.toLowerCase()}`]}%)</span>
                </span>
              </p>
            ))}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="mt-6 border border-gray-200 shadow-sm bg-white p-6">
      <div className="border-b border-gray-100 pb-5 mb-5 flex items-center gap-3">
        <BarChart2 className="h-5 w-5 text-[#003588]" />
        <div>
          <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Visualización Dinámica</p>
          <p className="text-lg font-bold text-gray-900 leading-none">Gráficas de Product Cost</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-6">
        
        {/* GRÁFICA 1: RESUMEN DE COSTOS */}
        <ChartWrapper titulo={`Resumen de costos - ${material.numero_material}`} filename={`resumen_${material.numero_material}`}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={datosResumen} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis dataKey="operacion_num" axisLine={{ stroke: '#000000', strokeWidth: 2 }} tickLine={false} tick={{ fontSize: 13, fill: '#4B5563', fontWeight: 'bold' }} />
              <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} tickFormatter={formatCompact} />
              <Tooltip content={<ResumenTooltip />} cursor={{ fill: '#F3F4F6' }} />
              
              <Bar dataKey="valor" maxBarSize={80} minPointSize={5} radius={[0, 0, 0, 0]}>
                {datosResumen.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
                <LabelList dataKey="valor" position="top" fill="#003588" fontSize={13} fontWeight="bold" formatter={(v) => v.toFixed(3)} />
                <LabelList dataKey="porcentaje" content={<EtiquetaPorcentaje />} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartWrapper>

        {/* GRÁFICA 2: TOTAL POR DENOMINACIÓN ELEMENTO */}
        <ChartWrapper titulo={`Total por denominación elemento - ${material.numero_material}`} filename={`denominacion_${material.numero_material}`}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={datosPorDenominacion} margin={{ top: 20, right: 30, left: 0, bottom: 40 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis dataKey="operacion_num" axisLine={{ stroke: '#000000', strokeWidth: 2 }} tickLine={false} tick={{ fontSize: 11, fill: '#4B5563', fontWeight: 'bold' }} angle={-25} textAnchor="end" />
              <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} tickFormatter={formatCompact} />
              <Tooltip content={<ResumenTooltip />} cursor={{ fill: '#F3F4F6' }} />
              
              <Bar dataKey="valor" maxBarSize={80} minPointSize={5} radius={[0, 0, 0, 0]}>
                {datosPorDenominacion.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
                <LabelList dataKey="valor" position="top" fill="#003588" fontSize={12} fontWeight="bold" formatter={(v) => v.toFixed(3)} />
                <LabelList dataKey="porcentaje" content={<EtiquetaPorcentaje />} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartWrapper>
      </div>

      {/* GRÁFICA 3: AGRUPADA (TOTAL, FIJO, VARIABLE POR ELEMENTO) */}
      <div className="grid grid-cols-1 gap-6">
        <ChartWrapper titulo={`Desglose Total / Fijo / Variable por elemento - ${material.numero_material}`} filename={`desglose_agrupado_${material.numero_material}`}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={datosAgrupadosElemento} margin={{ top: 20, right: 10, left: 10, bottom: 40 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis dataKey="denominacion" axisLine={{ stroke: '#000000', strokeWidth: 2 }} tickLine={false} tick={{ fontSize: 11, fill: '#6B7280', fontWeight: 'bold' }} angle={-20} textAnchor="end" />
              <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} tickFormatter={formatCompact} />
              <Tooltip content={<AgrupadaTooltip />} cursor={{ fill: '#F3F4F6' }} />
              <Legend wrapperStyle={{ paddingTop: '20px', fontSize: '13px', fontWeight: 'bold' }} />
              
              <Bar dataKey="Total" fill="#003588" maxBarSize={45} minPointSize={5} radius={[0, 0, 0, 0]}>
                 <LabelList dataKey="Total" position="top" fill="#003588" fontSize={10} fontWeight="bold" formatter={(v) => formatCompact(v)} />
                 <LabelList dataKey="pct_total" content={<EtiquetaPorcentaje />} />
              </Bar>
              <Bar dataKey="Fijo" fill="#64748b" maxBarSize={45} minPointSize={5} radius={[0, 0, 0, 0]}>
                 <LabelList dataKey="Fijo" position="top" fill="#64748b" fontSize={10} fontWeight="bold" formatter={(v) => formatCompact(v)} />
                 <LabelList dataKey="pct_fijo" content={<EtiquetaPorcentaje />} />
              </Bar>
              <Bar dataKey="Variable" fill="#0f766e" maxBarSize={45} minPointSize={5} radius={[0, 0, 0, 0]}>
                 <LabelList dataKey="Variable" position="top" fill="#0f766e" fontSize={10} fontWeight="bold" formatter={(v) => formatCompact(v)} />
                 <LabelList dataKey="pct_variable" content={<EtiquetaPorcentaje />} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartWrapper>
      </div>

    </div>
  )
}

const ModalDetalleProduccion = ({ isOpen, onClose, materialId, centro, fechaValidez, variante }) => {
  const { data, isLoading, isError } = useCostosProduccion(materialId, centro, fechaValidez, variante, isOpen);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-white border-t-4 border-[#003588] shadow-2xl w-full max-w-5xl max-h-[85vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center px-6 py-4 border-b border-gray-200">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Desglose de Producción en SAP (Posiciones E)</h3>
            <p className="text-sm text-gray-500">
              Material: <span className="font-bold text-[#003588]">{materialId}</span> | Variante: <span className="font-bold text-[#003588]">{variante}</span>
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-red-500 transition-colors focus:outline-none"><X className="w-6 h-6" /></button>
        </div>
        <div className="flex-1 overflow-auto bg-gray-50 p-6">
          {isLoading ? (
             <div className="flex flex-col items-center justify-center py-10">
               <Loader2 className="w-8 h-8 animate-spin text-[#003588] mb-4" />
               <p className="text-gray-500 text-sm font-medium animate-pulse">Consultando posiciones CKIS en vivo...</p>
             </div>
          ) : isError ? (
             <p className="text-red-500 text-center font-bold py-10">Error de conexión al intentar leer la tabla CKIS en SAP.</p>
          ) : !data?.elementos?.length ? (
             <p className="text-gray-500 text-center italic py-10">No hay posiciones de tipo E (Producción) para este cálculo.</p>
          ) : (
            <div className="border border-gray-200 shadow-sm overflow-hidden bg-white">
              <table className="min-w-full text-sm whitespace-nowrap">
                <thead className="bg-blue-50 border-b border-gray-200">
                  <tr>
                    <th className="px-5 py-3.5 text-center font-bold text-[#003588]">Pos.</th>
                    <th className="px-5 py-3.5 text-left font-bold text-[#003588]">Centro de Costo</th>
                    <th className="px-5 py-3.5 text-left font-bold text-[#003588]">Actividad</th>
                    <th className="px-5 py-3.5 text-left font-bold text-[#003588]">Recurso SAP</th>
                    <th className="px-5 py-3.5 text-right font-bold text-[#003588]">Cantidad</th>
                    <th className="px-5 py-3.5 text-right font-bold text-[#003588]">Valor Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {data.elementos.map((e, idx) => (
                    <tr key={idx} className="hover:bg-gray-50 transition-colors">
                      <td className="px-5 py-3 text-center text-gray-500 font-medium">{e.posicion}</td>
                      <td className="px-5 py-3">
                        <div className="font-bold text-gray-900">{e.centro_coste}</div>
                        <div className="text-xs text-gray-500 max-w-[200px] truncate" title={e.texto_centro_coste}>{e.texto_centro_coste}</div>
                      </td>
                      <td className="px-5 py-3">
                        <div className="font-bold text-gray-900">{e.clase_actividad}</div>
                        <div className="text-xs text-gray-500 max-w-[150px] truncate" title={e.texto_actividad}>{e.texto_actividad}</div>
                      </td>
                      <td className="px-5 py-3 text-gray-700 font-medium max-w-[250px] truncate" title={e.texto_recurso}>
                        {e.texto_recurso}
                      </td>
                      <td className="px-5 py-3 text-right font-medium text-gray-600">
                        {e.cantidad.toLocaleString('es-MX', { minimumFractionDigits: 3 })} <span className="text-xs text-gray-400">{e.unidad}</span>
                      </td>
                      <td className="px-5 py-3 text-right font-bold text-[#003588]">
                        {e.valor_total.toLocaleString('es-MX', { style: 'currency', currency: e.moneda || 'MXN' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CostosHistorial({ material, data, elementos, isLoading, isError, fechaActiva, setFechaActiva }) {
  const tableRef = useRef(null)
  const showToast = useToast()
  const [modalProduccion, setModalProduccion] = useState(false);

  const tituloPrincipal = material.proyecto && material.proyecto !== 'SIN PROYECTO'
      ? `${material.numero_material} - ${material.proyecto}`
      : `${material.numero_material} - Pieza SIN PROYECTO`

  const handleDownloadTable = async () => {
    if (!tableRef.current) return
    try {
      const dataUrl = await htmlToImage.toPng(tableRef.current, {
        backgroundColor: '#ffffff', pixelRatio: 2,
        filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true')
      })
      const a = document.createElement('a')
      a.download = `costos_${material.numero_material}_${material.variante_activa}.png`
      a.href = dataUrl; a.click()
    } catch (error) {
      showToast('Error al generar la imagen de la tabla.', 'error')
    }
  }

  return (
    <div className="relative mb-6">
      <div ref={tableRef} className="bg-white border border-gray-200 shadow-sm">
        <div className="px-6 pt-5 pb-4">
          <div className="flex justify-between items-start">
            <div className="text-left">
              <div className="text-[12px] font-medium text-[#5B6B84] tracking-[0.28em] uppercase">Material y familia</div>
              <div className="mt-1 text-[18px] font-bold text-black">{tituloPrincipal}</div>
            </div>
            
            <div className="text-right bg-blue-50 border border-blue-100 px-4 py-2 rounded-sm flex flex-col gap-2 items-end shadow-sm">
               <div className="flex items-center gap-2">
                   <span className="text-[11px] font-bold text-[#003588] uppercase tracking-wider">Variante Actual:</span>
                   <span className="text-sm font-black text-gray-900">{material.variante_activa}</span>
               </div>
               {material.historial_activo.length > 0 && (
                   <div className="w-48">
                       <CustomSelect
                           options={material.historial_activo.map((h, i) => ({
                               value: h.fecha_validez,
                               label: `Cálculo: ${formatearFecha(h.fecha_validez)}`
                           }))}
                           value={{
                               value: fechaActiva,
                               label: `Cálculo: ${formatearFecha(fechaActiva)}`
                           }}
                           onChange={(opt) => { if (opt) setFechaActiva(opt.value); }}
                           isSearchable={false}
                           isClearable={false}
                       />
                   </div>
               )}
            </div>
          </div>
        </div>
        <div className="overflow-x-auto [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-gray-50 [&::-webkit-scrollbar-thumb]:bg-gray-300 hover:[&::-webkit-scrollbar-thumb]:bg-gray-400 [&::-webkit-scrollbar-thumb]:rounded-full">
          <table className="min-w-full text-sm whitespace-nowrap table-fixed select-none">
            <thead className="bg-blue-50 border-y border-gray-200">
              <tr>
                <th className="px-5 py-3.5 text-center font-bold text-[#003588] w-[15%]">Elemento</th>
                <th className="px-5 py-3.5 text-left font-bold text-[#003588] w-[35%]">Denominación elemento</th>
                <th className="px-5 py-3.5 text-right font-bold text-[#003588] w-[20%]">Total (MXP)</th>
                <th className="px-5 py-3.5 text-right font-bold text-[#003588] w-[15%]">Fijo</th>
                <th className="px-5 py-3.5 text-right font-bold text-[#003588] w-[15%]">Variable</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {isLoading ? (
                <tr><td colSpan={5} className="px-5 py-10 text-center text-gray-400 italic">Cargando desglose de Finanzas...</td></tr>
              ) : isError ? (
                <tr><td colSpan={5} className="px-5 py-10 text-center text-red-500 italic">Error al cargar desglose de SAP.</td></tr>
              ) : elementos.length > 0 ? (
                elementos.map((e) => (
                  <tr
                      key={e.componente}
                      className={`group transition-colors ${e.componente === '140' ? 'hover:bg-blue-100 cursor-pointer bg-blue-50/20' : 'hover:bg-gray-50'}`}
                     onDoubleClick={() => { if(e.componente === '140') setModalProduccion(true); }}
                     title={e.componente === '140' ? "Da doble clic para ver el desglose en SAP (CKIS)" : ""}
                  >
                    <td className="px-5 py-3.5 text-center font-medium text-gray-800">{e.componente}</td>
                    <td className="px-5 py-3.5 text-left font-bold text-gray-900 flex items-center gap-2">
                       {e.denominacion}
                       {e.componente === '140' && <span className="text-[10px] bg-[#003588] text-white px-2 py-0.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">Doble clic para ver</span>}
                    </td>
                    <td className="px-5 py-3.5 text-right font-bold text-[#003588] tabular-nums">{formatearDinero(e.total)}</td>
                    <td className="px-5 py-3.5 text-right font-medium text-gray-500 tabular-nums">{formatearDinero(e.fijado)}</td>
                    <td className="px-5 py-3.5 text-right font-medium text-gray-500 tabular-nums">{formatearDinero(e.variable)}</td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan={5} className="px-5 py-10 text-center text-gray-400 italic">No se encontraron elementos.</td></tr>
              )}
            </tbody>
            <tfoot className="bg-white">
              {!isLoading && !isError && data && (
                <tr className="border-t-[3px] border-[#003588]">
                  <td colSpan={2} className="px-5 py-4 text-center font-black text-gray-900 uppercase tracking-wider text-[15px]">Costo Total</td>
                  <td className="px-5 py-4 text-right font-black text-[#003588] text-[16px] tabular-nums">{formatearDinero(data.total_global)}</td>
                  <td className="px-5 py-4 text-right font-bold text-gray-900 text-[15px] tabular-nums">{formatearDinero(data.total_fijado)}</td>
                  <td className="px-5 py-4 text-right font-bold text-gray-900 text-[15px] tabular-nums">{formatearDinero(data.total_variable)}</td>
                </tr>
              )}
            </tfoot>
          </table>
        </div>
      </div>
             
      <ModalDetalleProduccion
          isOpen={modalProduccion}
          onClose={() => setModalProduccion(false)}
          materialId={material.numero_material}
          centro={material.centro}
          fechaValidez={fechaActiva}
          variante={material.variante_activa}
       />
    </div>
  )
}

function MaterialCard({ material, filtrosTabla, centroActual }) {
  const [isExpanded, setIsExpanded] = useState(false)
  const cardRef = useRef(null)
  const modalCardRef = useRef(null)

  const [fechaActiva, setFechaActiva] = useState(material.calculo_reciente?.fecha_validez)

  useEffect(() => {
      if (material.calculo_reciente?.fecha_validez) {
          setFechaActiva(material.calculo_reciente.fecha_validez);
      }
  }, [material.calculo_reciente?.fecha_validez]);

  const { data, isLoading, isError } = useCostosDetalle(material.numero_material, centroActual, fechaActiva, material.variante_activa);

  const elementosFiltrados = useMemo(() => {
    if (!data?.elementos) return []
    let filtrados = data.elementos.filter((e) => {
      if (filtrosTabla.filtroDenominaciones.length > 0 && !filtrosTabla.filtroDenominaciones.includes(e.denominacion)) return false;
      return true;
    });
    
    return filtrados.sort((a, b) => {
      const numA = parseInt(a.componente, 10) || 0;
      const numB = parseInt(b.componente, 10) || 0;
      return numA - numB;
    });
  }, [data?.elementos, filtrosTabla])

  const handleDownloadGlobal = async (refTarget) => {
    if (!refTarget.current) return
    try {
      const dataUrl = await htmlToImage.toPng(refTarget.current, { backgroundColor: '#ffffff', pixelRatio: 2, filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true') })
      const a = document.createElement('a'); a.download = `costos_completos_${material.numero_material}_${material.variante_activa}.png`; a.href = dataUrl; a.click()
    } catch (error) { console.error(error) }
  }

  const CardContent = ({ refer, isModal }) => (
    <div ref={refer} className="w-full relative bg-white border border-gray-200 shadow-sm p-4">
      {!isModal && (
        <div data-html2canvas-ignore="true" className="absolute top-2 right-2 flex items-center gap-1 z-20 bg-gray-50 p-1 border border-gray-200 shadow-sm">
          <button onClick={() => handleDownloadGlobal(cardRef)} className="p-1.5 text-gray-500 hover:text-[#003588] transition-colors focus:outline-none" title="Descargar PNG"><Download className="w-4 h-4" /></button>
          <button onClick={() => setIsExpanded(true)} className="p-1.5 text-gray-500 hover:text-[#003588] transition-colors focus:outline-none" title="Expandir vista"><Maximize2 className="w-4 h-4" /></button>
        </div>
      )}
      <div className={!isModal ? 'mt-10' : 'mt-2'}>
        <CostosHistorial material={material} data={data} elementos={elementosFiltrados} isLoading={isLoading} isError={isError} fechaActiva={fechaActiva} setFechaActiva={setFechaActiva} />
        <CostosGraficas material={material} data={data} elementos={elementosFiltrados} isLoading={isLoading} isError={isError} />
      </div>
    </div>
  )

  return (
    <div className="mb-10 relative">
      <CardContent refer={cardRef} isModal={false} />
      {isExpanded && (
        <div onClick={(e) => e.target === e.currentTarget && setIsExpanded(false)} className="fixed inset-0 z-[9999] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8 cursor-pointer transition-opacity">
          <div className="bg-gray-50 border border-gray-200 shadow-2xl w-full max-w-7xl h-full max-h-[85vh] flex flex-col rounded-none cursor-default overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white shrink-0 shadow-sm z-10">
              <p className="text-sm font-bold text-[#003588] uppercase tracking-wider flex items-center gap-2"><Maximize2 className="w-4 h-4 text-[#003588]" /> Costos Financieros Ampliados</p>
              <div className="flex items-center gap-3">
                <button onClick={() => handleDownloadGlobal(modalCardRef)} className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 hover:text-[#003588] focus:outline-none"><Download className="w-4 h-4" /> <span className="hidden sm:inline">Descargar PNG Global</span></button>
                <div className="w-px h-6 bg-gray-300"></div>
                <button onClick={() => setIsExpanded(false)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 focus:outline-none border border-transparent"><X className="w-5 h-5" /></button>
              </div>
            </div>
            <div className="flex-1 p-6 md:p-10 overflow-y-auto bg-gray-50"><CardContent refer={modalCardRef} isModal={true} /></div>
          </div>
        </div>
      )}
    </div>
  )
}

const CostosPage = () => {
  const queryClient = useQueryClient()
  const showToast = useToast()
  const { centroActual } = useOutletContext() || { centroActual: '0094' }
  const [filtroMaterial, setFiltroMaterial] = useState(null)
  const [filtroProyecto, setFiltroProyecto] = useState(null)
  const [costoMin, setCostoMin] = useState('')
  const [costoMax, setCostoMax] = useState('')
  const [tipoCosto, setTipoCosto] = useState('total') 
  const [filtroDenominaciones, setFiltroDenominaciones] = useState([])
  const [isDenomOpen, setIsDenomOpen] = useState(false)
  const [paginaActual, setPaginaActual] = useState(1)
  const [isNuevoMaterialOpen, setIsNuevoMaterialOpen] = useState(false)
  const [varianteFiltro, setVarianteFiltro] = useState(null)
  
  const [activeJobId, setActiveJobId] = useState(null)
  const syncMutation = useSincronizarCostos()
  const { data: syncData } = useSyncStatus(activeJobId)
  const [progress, setProgress] = useState(0)

  const { data: materialesRaw = [], isLoading, isError, error } = useCostos(centroActual)
  const isSyncing = activeJobId !== null || syncMutation.isPending;

  useEffect(() => {
    if (isSyncing) {
      const interval = setInterval(() => setProgress((prev) => (prev + 10 < 90 ? prev + 10 : 90)), 1000);
      return () => clearInterval(interval);
    } else setProgress(0);
  }, [isSyncing]);

  useEffect(() => {
    if (syncData?.status === 'completed') {
      showToast(`Sincronización completada con éxito en SAP`, 'success');
      setActiveJobId(null);
      queryClient.invalidateQueries({ queryKey: ['costos_ck13n'] });
    } else if (syncData?.status === 'failed') {
      showToast(`Error interno en SAP: ${syncData.error}`, 'error');
      setActiveJobId(null);
    }
  }, [syncData, showToast, queryClient]);

  const ejecutarSincronizacion = () => {
    syncMutation.mutate(centroActual, {
      onSuccess: (data) => { setActiveJobId(data.job_id); showToast(`Sincronizando...`, 'info'); },
      onError: () => showToast('No se pudo comunicar con SAP.', 'error')
    });
  }

  const opcionesDenominaciones = useMemo(() => [
    "Costes de material", "Costes recuperación", "Ctes.produc.fijos", "Ctes.produc.variables",
    "Ext. aquisition cost", "Gastos admin.fijos", "Gastos grales.fijos", "Gastos grales.mat.fijos",
    "Gastos grales.mat.vbles", "Gastos grales.variables", "IPC tool repaire", "Mat KostalGrp / Imp",
    "Materia prima", "Material", "Material overhead", "Otros", "Production costs", "Setup costs",
    "Subcontracting", "Trabajo ext."
  ].sort(), [])

  const opcionesMetricaCosto = useMemo(() => [
    { value: 'total', label: 'Total (MXP)' }, { value: 'fijo', label: 'Fijo' },
    { value: 'variable', label: 'Variable' }, { value: 'costo_total', label: 'Costo Total' }
  ], []);

  const opcionesMateriales = useMemo(() => {
    return materialesRaw.map((m) => ({ value: m.numero_material, label: m.numero_material }))
  }, [materialesRaw])

  const opcionesProyectos = useMemo(() => {
    const arr = Array.from(new Set(materialesRaw.map((m) => m.proyecto))).filter(Boolean)
    return arr.map((p) => ({ value: p, label: p }))
  }, [materialesRaw])

  const materialesFiltrados = useMemo(() => {
    if (!materialesRaw) return [];
    let flatResult = [];

    materialesRaw.forEach(m => {
      if (!m.variantes) return;

      m.variantes.forEach(varData => {
        if (varianteFiltro && varData.variante !== varianteFiltro) return;

        const latestCalc = varData.historial?.[0];
        if (!latestCalc) return;

        flatResult.push({
          ...m,
          variante_activa: varData.variante,
          historial_activo: varData.historial || [],
          calculo_reciente: latestCalc,
          unique_key: `${m.numero_material}-${varData.variante}`
        });
      });
    });

    if (filtroMaterial) flatResult = flatResult.filter((m) => m.numero_material === filtroMaterial)
    if (filtroProyecto) flatResult = flatResult.filter((m) => m.proyecto === filtroProyecto)

    if (costoMin !== '' || costoMax !== '') {
      flatResult = flatResult.filter(item => {
        let valorEvaluado = 0;
        if (tipoCosto === 'total' || tipoCosto === 'costo_total') valorEvaluado = Number(item.calculo_reciente.total_global) || 0;
        else if (tipoCosto === 'fijo') valorEvaluado = Number(item.calculo_reciente.total_fijado) || 0;
        else if (tipoCosto === 'variable') valorEvaluado = Number(item.calculo_reciente.total_variable) || 0;
        
        const min = costoMin === '' ? -Infinity : Number(costoMin);
        const max = costoMax === '' ? Infinity : Number(costoMax);
        return valorEvaluado >= min && valorEvaluado <= max;
      });
    }

    flatResult.sort((a, b) => {
      let valA = 0; let valB = 0;
      if (tipoCosto === 'fijo') { 
        valA = Number(a.calculo_reciente.total_fijado) || 0; 
        valB = Number(b.calculo_reciente.total_fijado) || 0; 
      } 
      else if (tipoCosto === 'variable') { 
        valA = Number(a.calculo_reciente.total_variable) || 0; 
        valB = Number(b.calculo_reciente.total_variable) || 0; 
      } 
      else { 
        valA = Number(a.calculo_reciente.total_global) || 0; 
        valB = Number(b.calculo_reciente.total_global) || 0; 
      }
      return valB - valA;
    });

    return flatResult
  }, [materialesRaw, filtroMaterial, filtroProyecto, costoMin, costoMax, tipoCosto, varianteFiltro])

  const totalPaginas = Math.ceil(materialesFiltrados.length / REGISTROS_POR_PAGINA)
  const materialesPaginados = useMemo(() => {
    const inicio = (paginaActual - 1) * REGISTROS_POR_PAGINA
    return materialesFiltrados.slice(inicio, inicio + REGISTROS_POR_PAGINA)
  }, [materialesFiltrados, paginaActual])

  const renderPageNumbers = () => {
    if (totalPaginas <= 1) return null
    const pages = []
    const goToPage = (page) => { setPaginaActual(page); window.scrollTo({ top: 0, behavior: 'smooth' }) }
    const addPageButton = (page) => { pages.push(<button key={page} onClick={() => goToPage(page)} className={`min-w-[36px] px-3 py-1.5 text-sm border focus:outline-none transition-colors ${paginaActual === page ? 'bg-[#003588] border-[#003588] text-white' : 'bg-white border-gray-300 text-gray-600 hover:bg-gray-50'}`}>{page}</button>) }
    const addDots = (key) => { pages.push(<span key={key} className="px-2 text-gray-400 select-none">...</span>) }
    
    if (totalPaginas <= 7) { for (let i = 1; i <= totalPaginas; i++) addPageButton(i); return pages; }
    if (paginaActual <= 4) { for (let i = 1; i <= 5; i++) addPageButton(i); addDots('end'); addPageButton(totalPaginas); return pages; }
    if (paginaActual >= totalPaginas - 3) { addPageButton(1); addDots('start'); for (let i = totalPaginas - 4; i <= totalPaginas; i++) addPageButton(i); return pages; }
    
    addPageButton(1); addDots('left'); addPageButton(paginaActual - 1); addPageButton(paginaActual); addPageButton(paginaActual + 1); addDots('right'); addPageButton(totalPaginas); return pages;
  }

  const valMaterial = filtroMaterial ? opcionesMateriales.find((opt) => opt.value === filtroMaterial) : null
  const valProyecto = filtroProyecto ? opcionesProyectos.find((opt) => opt.value === filtroProyecto) : null
  const valMetrica = opcionesMetricaCosto.find((opt) => opt.value === tipoCosto) || opcionesMetricaCosto[0];
  const valVariante = varianteFiltro ? OPCIONES_VARIANTES_SAP.find((opt) => opt.value === varianteFiltro) : null;

  return (
    <div className="h-full flex flex-col bg-gray-50 overflow-hidden relative">
      {isSyncing && (
        <div className="absolute top-0 left-0 w-full h-1 bg-gray-200 z-[100] overflow-hidden">
          <div className="h-full bg-[#003588] transition-all duration-300 ease-out relative" style={{ width: `${progress}%` }}>
            <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
          </div>
        </div>
      )}
      <div className="bg-white border-b border-gray-200 px-6 py-4 shrink-0 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="hidden sm:flex items-center gap-3 mr-2">
            <DollarSign className="h-6 w-6 text-[#003588]" />
            <div><h2 className="text-xl md:text-2xl font-bold text-gray-900 leading-none">Costos Financieros</h2></div>
          </div>
          <button onClick={ejecutarSincronizacion} disabled={isSyncing} className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${isSyncing ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'}`}>
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{isSyncing ? `Sincronizando... ${Math.round(progress)}%` : 'Sincronizar SAP'}</span>
          </button>
          <button onClick={() => setIsNuevoMaterialOpen(true)} disabled={!centroActual || isSyncing} className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${!centroActual || isSyncing ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'}`} title={centroActual ? 'Importar nuevo material desde SAP' : 'Selecciona un centro específico'}>
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Importar Material</span>
          </button>
        </div>
        <div className="w-full md:w-80">
          <CustomSelect options={opcionesMateriales} value={valMaterial} onChange={(opt) => { setFiltroMaterial(opt?.value ?? null); setFiltroProyecto(null); setPaginaActual(1) }} placeholder="Buscar número de parte..." isClearable />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-6 scroll-smooth">
        <div className="border border-gray-200 bg-white shadow-sm p-5 rounded-none mb-6 relative">
          <div className="flex items-center justify-between mb-4">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1.5"><Filter className="w-3.5 h-3.5 text-[#003588]" /> Parámetros de Filtrado Analítico</p>
            {(filtroMaterial || filtroProyecto || costoMin !== '' || costoMax !== '' || filtroDenominaciones.length > 0 || varianteFiltro) && (
              <button onClick={() => { setFiltroMaterial(null); setFiltroProyecto(null); setCostoMin(''); setCostoMax(''); setTipoCosto('total'); setFiltroDenominaciones([]); setVarianteFiltro(null); setPaginaActual(1); }} className="text-xs font-bold text-[#003588] hover:underline uppercase transition-colors focus:outline-none">Limpiar Filtros</button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4 items-end">
            <div>
              <label className="block text-xs font-bold text-[#003588] uppercase tracking-wider mb-1 flex items-center gap-1.5"><Layers className="w-3.5 h-3.5" /> Variante de Costeo</label>
              <CustomSelect options={OPCIONES_VARIANTES_SAP} value={valVariante} onChange={(opt) => { setVarianteFiltro(opt?.value ?? null); setPaginaActual(1); }} isClearable={true} isSearchable={true} placeholder="Todas..." />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Plataforma</label>
              <CustomSelect options={opcionesProyectos} value={valProyecto} onChange={(opt) => { setFiltroProyecto(opt?.value ?? null); setPaginaActual(1) }} placeholder="Todos..." isDisabled={opcionesProyectos.length === 0} isClearable />
            </div>
            <div className="relative">
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Elemento (Tablas)</label>
              <button onClick={() => setIsDenomOpen(!isDenomOpen)} className="w-full bg-white border border-gray-300 shadow-sm h-[38px] pl-3 pr-2 flex items-center justify-between text-[15px] focus:outline-none focus:border-[#003588] transition-colors hover:border-gray-400">
                <span className={`truncate ${filtroDenominaciones.length > 0 ? 'text-[#003588]' : 'text-[#808080]'}`}>{filtroDenominaciones.length === 0 ? 'Todas...' : `${filtroDenominaciones.length} selecc.`}</span>
                <div className="flex items-center"><span className="w-[1px] h-[20px] bg-gray-200 mx-2"></span><ChevronDown className="w-4 h-4 text-[#cccccc] shrink-0 mr-1" /></div>
              </button>
              {isDenomOpen && (
                <>
                  <div className="fixed inset-0 z-[90]" onClick={() => setIsDenomOpen(false)}></div>
                  <div className="absolute z-[100] top-[100%] left-0 mt-1 w-full min-w-[250px] bg-white border border-gray-200 shadow-lg max-h-64 overflow-y-auto rounded-none">
                    {opcionesDenominaciones.map(denom => {
                      const isChecked = filtroDenominaciones.includes(denom);
                      return (
                        <div key={denom} onClick={(e) => { e.preventDefault(); setFiltroDenominaciones(prev => prev.includes(denom) ? prev.filter(d => d !== denom) : [...prev, denom]); setPaginaActual(1); }} className={`flex items-center px-4 py-2 cursor-pointer border-b border-gray-100 last:border-0 text-sm transition-colors select-none ${isChecked ? 'bg-blue-50/50 text-[#003588] font-medium' : 'text-gray-700 hover:bg-gray-50'}`}>
                          <div className={`w-4 h-4 mr-3 flex items-center justify-center border rounded-sm transition-colors shrink-0 ${isChecked ? 'bg-[#003588] border-[#003588]' : 'bg-white border-gray-300'}`}>{isChecked && <Check className="w-3 h-3 text-white" strokeWidth={3} />}</div>
                          <span className="truncate">{denom}</span>
                        </div>
                      )
                    })}
                  </div>
                </>
              )}
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 flex items-center gap-1.5"><Calculator className="w-3.5 h-3.5 text-[#003588]" /> Métrica</label>
              <CustomSelect options={opcionesMetricaCosto} value={valMetrica} onChange={(opt) => { setTipoCosto(opt?.value ?? 'total'); setPaginaActual(1); }} isClearable={false} isSearchable={false} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Rango (Filtro)</label>
              <div className="flex bg-white border border-gray-300 h-[38px] shadow-sm">
                <div className="flex items-center justify-center bg-gray-50 border-r border-gray-200 px-3 text-gray-500"><DollarSign className="w-4 h-4" /></div>
                <input type="number" placeholder="Mín" value={costoMin} onChange={(e) => { setCostoMin(e.target.value); setPaginaActual(1) }} className="w-full min-w-[60px] px-3 text-sm outline-none focus:bg-blue-50/50 transition-colors border-r border-gray-100" />
                <input type="number" placeholder="Máx" value={costoMax} onChange={(e) => { setCostoMax(e.target.value); setPaginaActual(1) }} className="w-full min-w-[60px] px-3 text-sm outline-none focus:bg-blue-50/50 transition-colors" />
              </div>
            </div>
          </div>
        </div>

        {isLoading && <div className="flex justify-center py-10"><div className="h-10 w-10 rounded-full border-4 border-gray-200 border-t-[#003588] animate-spin" /></div>}
        {isError && (
          <div className="flex flex-col items-center justify-center p-10 bg-gray-50 border border-gray-200 mb-6">
            <WifiOff className="w-12 h-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-bold text-gray-700">Modo sin conexión</h3>
            <p className="text-sm text-gray-500">{error?.isNetworkError ? error.customMessage : "Ocurrió un error al cargar los datos."}</p>
          </div>
        )}
        {!isLoading && !isError && materialesFiltrados.length === 0 && (
          <div className="border border-gray-200 bg-white shadow-sm p-10 text-center rounded-none mt-4"><p className="text-sm text-gray-400">No hay costos para los filtros aplicados.</p></div>
        )}

        {!isLoading && !isError && materialesPaginados.map((material) => (
            <MaterialCard
              key={material.unique_key}
              material={material}
              centroActual={centroActual}
              filtrosTabla={{ tipoCosto, costoMin, costoMax, filtroDenominaciones }}
            />
          ))}

        {!isLoading && !isError && totalPaginas > 1 && (
          <div className="flex items-center justify-between border border-gray-200 bg-white px-4 py-3 shadow-sm mt-4 mb-8">
            <div><span className="text-sm text-gray-600">Mostrando {(paginaActual - 1) * REGISTROS_POR_PAGINA + 1}-{Math.min(paginaActual * REGISTROS_POR_PAGINA, materialesFiltrados.length)} de {materialesFiltrados.length} registros</span></div>
            <div className="flex items-center gap-1.5">
              <button onClick={() => { setPaginaActual((p) => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: 'smooth' }) }} disabled={paginaActual === 1} className="px-3 py-1.5 text-sm border border-gray-300 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none transition-colors">Anterior</button>
              <div className="flex items-center gap-1">{renderPageNumbers()}</div>
              <button onClick={() => { setPaginaActual((p) => Math.min(totalPaginas, p + 1)); window.scrollTo({ top: 0, behavior: 'smooth' }) }} disabled={paginaActual === totalPaginas} className="px-3 py-1.5 text-sm border border-gray-300 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none transition-colors">Siguiente</button>
            </div>
          </div>
        )}
      </div>
      <NuevoMaterialModal isOpen={isNuevoMaterialOpen} onClose={() => setIsNuevoMaterialOpen(false)} centroActual={centroActual} />
    </div>
  )
}

export default CostosPage