// src/pages/dashboard/Dashboard.jsx
import React, { useMemo, useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Maximize2, Download, X, Filter, MoveRight } from 'lucide-react'
import * as htmlToImage from 'html-to-image' 
import { useSecciones, useDashboardSeccion } from '../../hooks/useDashboard'
import { useFiltrosGraficas } from '../../hooks/useGraficas'
import CustomSelect from '../../components/ui/CustomSelect'

const parseFechaSap = (str) => {
  if (!str) return null
  const partes = str.split('.')
  if (partes.length !== 3) return null
  const [d, m, y] = partes
  return new Date(`${y}-${m}-${d}T00:00:00`)
}

const MESES_NOMBRES = {
  0: "Enero", 1: "Febrero", 2: "Marzo", 3: "Abril", 4: "Mayo", 5: "Junio",
  6: "Julio", 7: "Agosto", 8: "Septiembre", 9: "Octubre", 10: "Noviembre", 11: "Diciembre"
}

function calcularMetricas(historial, nombreProceso) {
  let baseline_pzs_hr = null; 

  return historial.map((reg, idx) => {
    const tiempo  = parseFloat(reg.tiempo)
    const equiposOriginales = parseInt(reg.equipos)
    const equipos = (nombreProceso && nombreProceso.toUpperCase() === 'SMT') ? equiposOriginales : 1
    
    let pzs_hr = null, seg_pz = null, mejora = null, mejora_global = null

    if (tiempo && equipos && tiempo > 0 && equipos > 0) {
      pzs_hr = (1000 / tiempo) / equipos
      seg_pz = 3600 / pzs_hr

      if (baseline_pzs_hr === null) {
        baseline_pzs_hr = pzs_hr; 
      } else {
        mejora_global = ((pzs_hr - baseline_pzs_hr) / baseline_pzs_hr) * 100;
      }
    }
    
    if (idx > 0) {
      const anterior = historial[idx - 1]
      const tAnt = parseFloat(anterior.tiempo)
      const eAnt = (nombreProceso && nombreProceso.toUpperCase() === 'SMT') ? parseInt(anterior.equipos) : 1
      
      if (tAnt && eAnt && tAnt > 0 && eAnt > 0) {
        const pzs_hr_ant = (1000 / tAnt) / eAnt
        if (pzs_hr) {
          mejora = ((pzs_hr - pzs_hr_ant) / pzs_hr_ant) * 100
        }
      }
    }
    return { ...reg, equipos, pzs_hr, seg_pz, mejora, mejora_global }
  })
}

function ProcesoHistorial({ proceso, material, fechaInicio, fechaFin, mesFiltro }) {
  const tableRef = useRef(null)

  const registrosCalculados = useMemo(() => calcularMetricas(proceso.historial, proceso.nombre_proceso), [proceso.historial, proceso.nombre_proceso])
  
  const registrosParaMostrar = useMemo(() => {
    return registrosCalculados.filter(r => {
      const dateObj = parseFechaSap(r.fecha_cambio)
      if (!dateObj) return true
      if (fechaInicio && dateObj < new Date(`${fechaInicio}T00:00:00`)) return false
      if (fechaFin && dateObj > new Date(`${fechaFin}T00:00:00`)) return false
      if (mesFiltro) {
        const m = String(dateObj.getMonth() + 1).padStart(2, '0')
        const y = dateObj.getFullYear()
        if (`${y}-${m}` !== mesFiltro) return false
      }
      return true
    })
  }, [registrosCalculados, fechaInicio, fechaFin, mesFiltro])

  const handleDownloadTable = async () => {
    if (!tableRef.current) return
    try {
      const dataUrl = await htmlToImage.toPng(tableRef.current, {
        backgroundColor: '#ffffff',
        pixelRatio: 2,
        filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true')
      })
      const a = document.createElement('a')
      a.download = `trazabilidad_${material.numero_material}_${proceso.nombre_proceso}.png`
      a.href = dataUrl
      a.click()
    } catch (error) {
      console.error(error)
      alert("Error al capturar la imagen. Asegúrate de tener instalada la librería html-to-image.")
    }
  }

  if (registrosParaMostrar.length === 0) {
    return (
      <div className="border border-gray-200 bg-gray-50 text-center py-4 text-xs text-gray-400 italic mb-6">
        No hay modificaciones de SAP para el proceso "{proceso.nombre_proceso}" con los filtros aplicados.
      </div>
    )
  }

  const stickyColClass = "px-4 py-3 text-right w-[10.5rem] min-w-[10.5rem] border-r border-gray-200 sticky left-0 z-10 shadow-[2px_0_4px_-2px_rgba(0,0,0,0.1)] transition-colors"

  return (
    <div className="mb-6 overflow-x-auto pb-3 [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-gray-50 [&::-webkit-scrollbar-thumb]:bg-gray-300 hover:[&::-webkit-scrollbar-thumb]:bg-gray-400 [&::-webkit-scrollbar-thumb]:rounded-full">
      <div ref={tableRef} className="border border-gray-200 shadow-sm bg-white min-w-max relative">
        <table className="min-w-full text-sm whitespace-nowrap">
          <tbody className="divide-y divide-gray-100">
            
            <tr className="bg-blue-50">
              <td className={`${stickyColClass} font-bold text-[#003588] bg-blue-50`}>
                <div className="flex items-center justify-end gap-2">
                  Proceso <MoveRight className="w-4 h-4 text-[#003588] opacity-70 animate-pulse" title="Desplazar hacia la derecha" />
                </div>
              </td>
              <td colSpan={registrosParaMostrar.length || 1} className="px-5 py-3 font-bold text-[#003588] tracking-wide">
                <div className="flex items-center justify-start relative w-full pr-8">
                  <span>{proceso.nombre_proceso}</span>
                  <button
                    data-html2canvas-ignore="true"
                    onClick={handleDownloadTable}
                    className="absolute right-0 p-1.5 bg-white rounded shadow-sm border border-blue-100 text-[#003588] hover:bg-[#003588] hover:text-white transition-colors focus:outline-none flex-shrink-0"
                    title={`Descargar tabla de ${proceso.nombre_proceso}`}
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </td>
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} font-bold text-gray-900 bg-white group-hover:bg-gray-50`}>
                Núm. Parte
              </td>
              <td colSpan={registrosParaMostrar.length || 1} className="px-5 py-3 text-left font-bold text-gray-900 uppercase tracking-wide">
                {material.numero_material}
                {material.nombre_pieza && <span className="ml-3 text-xs font-normal text-gray-400">{material.nombre_pieza}</span>}
              </td>
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} font-medium text-gray-500 bg-white group-hover:bg-gray-50`}>
                Plataforma
              </td>
              <td colSpan={registrosParaMostrar.length || 1} className="px-5 py-3 text-left text-gray-900 uppercase">
                {material.proyecto || '—'}
              </td>
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>
                Fecha cambio en SAP
              </td>
              {registrosParaMostrar.map((r, i) => <td key={`fecha-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.fecha_cambio}</td>)}
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} font-bold text-[#003588] bg-white group-hover:bg-gray-50`}>
                Tiempo
              </td>
              {registrosParaMostrar.map((r, i) => <td key={`tiempo-${i}`} className="px-5 py-3 text-center font-bold text-gray-900 border-r border-gray-100">{r.tiempo != null ? Number(r.tiempo).toFixed(3) : '—'}</td>)}
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>
                Equipos
              </td>
              {registrosParaMostrar.map((r, i) => <td key={`equipos-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.equipos}</td>)}
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>
                pzs/hr
              </td>
              {registrosParaMostrar.map((r, i) => <td key={`pzs-${i}`} className="px-5 py-3 text-center text-gray-900 border-r border-gray-100">{r.pzs_hr != null ? r.pzs_hr.toFixed(3) : '—'}</td>)}
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} font-bold text-[#003588] bg-white group-hover:bg-gray-50`}>
                seg/pz
              </td>
              {registrosParaMostrar.map((r, i) => <td key={`seg-${i}`} className="px-5 py-3 text-center font-bold text-gray-900 border-r border-gray-100">{r.seg_pz != null ? r.seg_pz.toFixed(3) : '—'}</td>)}
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} text-gray-500 font-medium bg-white group-hover:bg-gray-50`}>
                % vs Anterior
              </td>
              {registrosParaMostrar.map((r, i) => {
                const val = r.mejora
                const color = val === null ? 'text-gray-400' : val > 0 ? 'text-green-600 font-semibold' : val < 0 ? 'text-red-500 font-semibold' : 'text-gray-500'
                return <td key={`mejora-${i}`} className={`px-5 py-3 text-center border-r border-gray-100 ${color}`}>{val !== null ? `${val > 0 ? '+' : ''}${val.toFixed(3)}%` : '—'}</td>
              })}
            </tr>

            <tr className="group hover:bg-gray-50 bg-white transition-colors">
              <td className={`${stickyColClass} text-gray-500 font-bold bg-white group-hover:bg-gray-50`}>
                % Acumulado
              </td>
              {registrosParaMostrar.map((r, i) => {
                const val = r.mejora_global
                const color = val === null ? 'text-gray-400' : val > 0 ? 'text-green-600 font-bold' : val < 0 ? 'text-red-500 font-bold' : 'text-gray-500'
                return <td key={`mejora-global-${i}`} className={`px-5 py-3 text-center border-r border-gray-100 ${color}`}>{val !== null ? `${val > 0 ? '+' : ''}${val.toFixed(3)}%` : '—'}</td>
              })}
            </tr>

          </tbody>
        </table>
      </div>
    </div>
  )
}

function MaterialCard({ material, fechaInicio, fechaFin, mesFiltro }) {
  const [isExpanded, setIsExpanded] = useState(false)
  const cardRef = useRef(null)
  const modalCardRef = useRef(null)

  const handleDownloadGlobal = async (refTarget) => {
    if (!refTarget.current) return
    try {
      const dataUrl = await htmlToImage.toPng(refTarget.current, {
        backgroundColor: '#ffffff',
        pixelRatio: 2,
        filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true')
      })
      const a = document.createElement('a')
      a.download = `trazabilidad_completa_${material.numero_material}.png`
      a.href = dataUrl
      a.click()
    } catch (error) {
      console.error(error)
      alert("Error al capturar la imagen global.")
    }
  }

  const CardContent = ({ refer, isModal }) => (
    <div ref={refer} className="w-full relative bg-white border border-gray-200 shadow-sm p-4">
      
      {!isModal && (
        <div data-html2canvas-ignore="true" className="absolute top-2 right-2 flex items-center gap-1 z-20 bg-gray-50 p-1 border border-gray-200 shadow-sm">
          <button onClick={() => handleDownloadGlobal(cardRef)} className="p-1.5 text-gray-500 hover:text-[#003588] transition-colors focus:outline-none" title="Descargar todas las tablas">
            <Download className="w-4 h-4" />
          </button>
          <button onClick={() => setIsExpanded(true)} className="p-1.5 text-gray-500 hover:text-[#003588] transition-colors focus:outline-none" title="Expandir vista">
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className={!isModal ? "mt-10" : "mt-2"}>
        {material.procesos.map((proc) => (
          <ProcesoHistorial 
            key={proc.nombre_proceso} 
            proceso={proc} 
            material={material}
            fechaInicio={fechaInicio} 
            fechaFin={fechaFin} 
            mesFiltro={mesFiltro}
          />
        ))}
      </div>
    </div>
  )

  return (
    <div className="mb-10 relative">
      <CardContent refer={cardRef} isModal={false} />
      
      {isExpanded && (
        <div onClick={(e) => e.target === e.currentTarget && setIsExpanded(false)} className="fixed inset-0 z-[9999] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8 cursor-pointer transition-opacity">
          <div className="bg-gray-50 border border-gray-200 shadow-2xl w-full max-w-7xl h-full max-h-[85vh] flex flex-col rounded-none cursor-default overflow-hidden">
            
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white shrink-0 shadow-sm z-10">
              <p className="text-sm font-bold text-[#003588] uppercase tracking-wider flex items-center gap-2">
                <Maximize2 className="w-4 h-4 text-[#003588]" /> Trazabilidad Histórica Ampliada
              </p>
              <div className="flex items-center gap-3">
                <button onClick={() => handleDownloadGlobal(modalCardRef)} className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 hover:text-[#003588] focus:outline-none">
                  <Download className="w-4 h-4" /> <span className="hidden sm:inline">Descargar PNG Global</span>
                </button>
                <div className="w-px h-6 bg-gray-300"></div>
                <button onClick={() => setIsExpanded(false)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 focus:outline-none border border-transparent">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="flex-1 p-6 md:p-10 overflow-y-auto bg-gray-50">
              <CardContent refer={modalCardRef} isModal={true} />
            </div>

          </div>
        </div>
      )}
    </div>
  )
}

const Dashboard = () => {
  const { proceso: seccionParam } = useParams()
  const navigate = useNavigate()

  const [filtroMaterial, setFiltroMaterial] = useState(null)
  
  const { data: seccionesRaw = [], isLoading: cargandoSecciones } = useSecciones(filtroMaterial)
  const { data: filtrosGlobales } = useFiltrosGraficas()
  
  const seccionActiva = seccionParam ? decodeURIComponent(seccionParam) : null
  const { data: materiales = [], isLoading, isError } = useDashboardSeccion(seccionActiva)

  const [fechaInicio, setFechaInicio] = useState('')
  const [fechaFin, setFechaFin] = useState('')
  const [mesFiltro, setMesFiltro] = useState(null)
  const [filtroProyecto, setFiltroProyecto] = useState(null)

  const tabsVisibles = useMemo(() => {
    if (seccionesRaw.length === 0) return []
    return ['TODOS', ...seccionesRaw]
  }, [seccionesRaw])

  useEffect(() => {
    if (!cargandoSecciones) {
      if (tabsVisibles.length > 0) {
        if (!seccionActiva || !tabsVisibles.includes(seccionActiva)) {
          navigate(`/app/dashboard/TODOS`, { replace: true })
        }
      } else if (tabsVisibles.length === 0 && seccionParam) {
        navigate(`/app/dashboard`, { replace: true })
      }
    }
  }, [seccionActiva, seccionParam, tabsVisibles, navigate, cargandoSecciones])

  const opcionesMateriales = useMemo(() => {
    return (filtrosGlobales?.numeros_material || []).map(m => ({ value: m, label: m }))
  }, [filtrosGlobales])

  const opcionesProyectos = useMemo(() => {
    return (filtrosGlobales?.proyectos || []).map(p => ({ value: p, label: p }))
  }, [filtrosGlobales])

  const opcionesMeses = useMemo(() => {
    if (!materiales) return [];
    const mesesSet = new Set();
    
    let base = [...materiales]
    if (filtroMaterial) base = base.filter(m => m.numero_material === filtroMaterial)
    if (filtroProyecto) base = base.filter(m => m.proyecto === filtroProyecto)

    base.forEach(mat => {
      mat.procesos?.forEach(proc => {
        proc.historial?.forEach(reg => {
          const dateObj = parseFechaSap(reg.fecha_cambio);
          if (dateObj) {
            const y = dateObj.getFullYear();
            const m = dateObj.getMonth();
            const val = `${y}-${String(m + 1).padStart(2, '0')}`;
            const label = `${MESES_NOMBRES[m]} ${y}`;
            mesesSet.add(JSON.stringify({ value: val, label }));
          }
        });
      });
    });
    return Array.from(mesesSet).map(s => JSON.parse(s)).sort((a, b) => b.value.localeCompare(a.value));
  }, [materiales, filtroMaterial, filtroProyecto]);

  const getMaxDate = (m) => {
    let max = 0;
    m.procesos?.forEach(p => {
      p.historial?.forEach(h => {
        const d = parseFechaSap(h.fecha_cambio);
        if (d && d.getTime() > max) max = d.getTime();
      })
    });
    return max;
  };

  const materialesFiltrados = useMemo(() => {
    if (!materiales) return []
    let result = [...materiales]
    
    if (filtroMaterial) result = result.filter(m => m.numero_material === filtroMaterial)
    if (filtroProyecto) result = result.filter(m => m.proyecto === filtroProyecto)
    
    result.sort((a, b) => getMaxDate(b) - getMaxDate(a))
    
    return result
  }, [materiales, filtroMaterial, filtroProyecto])

  const valMaterial = filtroMaterial ? opcionesMateriales.find(opt => opt.value === filtroMaterial) : null
  const valProyecto = filtroProyecto ? opcionesProyectos.find(opt => opt.value === filtroProyecto) : null

  return (
    <div className="h-full flex flex-col bg-gray-50 overflow-hidden">
      
      <div className="bg-white border-b border-gray-200 px-6 py-4 shrink-0 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-xl md:text-2xl font-bold text-gray-900 m-0">Tiempos de Operación</h2>
        <div className="w-full md:w-80">
          <CustomSelect
            options={opcionesMateriales}
            value={valMaterial}
            onChange={(opt) => {
              setFiltroMaterial(opt?.value ?? null)
              setMesFiltro(null)
              setFiltroProyecto(null)
            }}
            placeholder="Buscar número de parte..."
            isClearable 
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        
        {(seccionActiva || filtroMaterial) && (
          <div className="border border-gray-200 bg-white shadow-sm p-5 rounded-none mb-6">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-[#003588]" /> Parámetros de Filtrado Avanzado
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 items-end">
              
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Plataforma</label>
                <CustomSelect
                  options={opcionesProyectos}
                  value={valProyecto}
                  onChange={(opt) => setFiltroProyecto(opt?.value ?? null)}
                  placeholder="Todos..."
                  isDisabled={opcionesProyectos.length === 0}
                  isClearable 
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Mes Exacto</label>
                <CustomSelect
                  options={opcionesMeses}
                  value={opcionesMeses.find(o => o.value === mesFiltro) || null}
                  onChange={(opt) => setMesFiltro(opt?.value ?? null)}
                  placeholder="Todos..."
                  isDisabled={opcionesMeses.length === 0}
                  isClearable 
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Inicio</label>
                <input type="date" value={fechaInicio} onChange={(e) => setFechaInicio(e.target.value)} className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors" />
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Fin</label>
                <input type="date" value={fechaFin} onChange={(e) => setFechaFin(e.target.value)} className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors" />
              </div>
              
              {(fechaInicio || fechaFin || mesFiltro || filtroProyecto) && (
                <div>
                  <button onClick={() => { setFechaInicio(''); setFechaFin(''); setMesFiltro(null); setFiltroProyecto(null); }} className="w-full md:w-auto px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold uppercase rounded-none transition-colors border border-gray-300 h-[38px] focus:outline-none">
                    Limpiar Filtros
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {tabsVisibles.length > 0 && (
          <nav className="w-full bg-white shrink-0 border border-gray-200 shadow-sm overflow-x-auto mb-6 rounded-none [&::-webkit-scrollbar]:hidden" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
            <div className="flex w-max min-w-full">
              {cargandoSecciones ? (
                <div className="px-6 py-4 text-sm text-gray-400">Cargando procesos...</div>
              ) : (
                tabsVisibles.map((sec) => {
                  const isActive = sec === seccionActiva
                  return (
                    <button
                      key={sec}
                      onClick={() => navigate(`/app/dashboard/${encodeURIComponent(sec)}`)}
                      className={`px-8 py-4 text-sm font-medium border-r border-gray-200 transition-colors rounded-none block focus:outline-none flex-shrink-0
                        ${isActive ? 'bg-[#003588] text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
                    >
                      {sec}
                    </button>
                  )
                })
              )}
            </div>
          </nav>
        )}

        {isLoading && <div className="flex justify-center py-10"><div className="h-10 w-10 rounded-full border-4 border-gray-200 border-t-[#003588] animate-spin" /></div>}
        {isError && <div className="border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700 rounded-none mb-6">Error al cargar datos de SAP.</div>}

        {!isLoading && !isError && materiales.length > 0 && materialesFiltrados.length === 0 && (
          <div className="border border-gray-200 bg-white shadow-sm p-10 text-center rounded-none mt-4">
            <p className="text-sm text-gray-400">No hay coincidencias para los filtros aplicados en la vista <strong>{seccionActiva}</strong>.</p>
          </div>
        )}

        {!isLoading && materialesFiltrados.map((material) => (
          <MaterialCard 
            key={material.numero_material} 
            material={material} 
            fechaInicio={fechaInicio} 
            fechaFin={fechaFin} 
            mesFiltro={mesFiltro}
          />
        ))}

      </div>
    </div>
  )
}

export default Dashboard