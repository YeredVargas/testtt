// src/pages/sapMes/SapMesPage.jsx
// Apartado SAP/MES: tiempo de operacion SAP (hoja de ruta) vs tiempo ciclo real MES.
import React, { useEffect, useMemo, useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import { AlertTriangle, Info, Loader2, Play, RefreshCw, SlidersHorizontal } from 'lucide-react'
import CustomSelect from '../../components/ui/CustomSelect'
import { useToast } from '../../components/ui/ToastContext'
import ResumenKpis from '../../components/sapMes/ResumenKpis'
import ComparativaGrafica from '../../components/sapMes/ComparativaGrafica'
import ComparativaTabla from '../../components/sapMes/ComparativaTabla'
import ReglaSlideOver from '../../components/sapMes/ReglaSlideOver'
import GruposProcesos from '../../components/sapMes/GruposProcesos'
import {
  useComparativaSapMes, useEstadoCatalogo, useEstadoMes, useMaterialesSapMes, useReglasSapMes,
  useSincronizarCatalogo, useVersionesSap,
} from '../../hooks/useSapMes'
import {
  aApi, CAMPOS_TIEMPO_SAP, COLOR_MES, COLOR_SAP, ESTADISTICOS, etiquetaCampoTiempo, fechaApiCorta, fechaCorta, isoHoyMenos,
} from '../../utils/sapMesFormato'

// Por ahora el apartado solo trabaja con KEMM.
const CENTRO_SAP_MES = '0094'

const inputCls = 'border border-gray-300 bg-white px-2 py-[7px] text-sm focus:outline-none focus:border-[#003588] rounded-none'

const Campo = ({ etiqueta, children, className = '' }) => (
  <div className={className}>
    <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1">{etiqueta}</p>
    {children}
  </div>
)

const EstadoMes = () => {
  const { data, isLoading } = useEstadoMes()
  if (isLoading) return null
  const ok = data?.disponible
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-1 text-xs font-semibold border ${ok ? 'text-green-700 border-green-200 bg-green-50' : 'text-red-700 border-red-200 bg-red-50'}`}
      title={data?.detalle || data?.url}
    >
      <span className={`w-2 h-2 rounded-full ${ok ? 'bg-green-600' : 'bg-red-600'}`} aria-hidden="true" />
      API MES {ok ? 'conectada' : 'sin conexión'}
    </span>
  )
}

// Catalogo T435T: texto de clave de modelo = operacion MES (mapeo automatico).
const EstadoCatalogo = ({ onMensaje }) => {
  const { data } = useEstadoCatalogo()
  const sincronizar = useSincronizarCatalogo()
  const ejecutar = async () => {
    try {
      const r = await sincronizar.mutateAsync()
      onMensaje(`T435T sincronizado: ${r.total_sap} claves (${r.nuevas} nuevas, ${r.actualizadas} actualizadas, ${r.desactivadas} desactivadas).`)
    } catch (e) {
      onMensaje(e?.response?.data?.detail || e?.customMessage || 'No se pudo sincronizar T435T con SAP.', 'error')
    }
  }
  const vacio = !data?.activos
  const fecha = data?.ultima_sincronizacion
    ? new Date(data.ultima_sincronizacion).toLocaleDateString('es-MX', { day: '2-digit', month: '2-digit', year: 'numeric' })
    : null
  return (
    <span className="inline-flex items-center gap-2">
      <span
        className={`inline-flex items-center gap-1.5 px-2 py-1 text-xs font-semibold border ${vacio ? 'text-amber-800 border-amber-200 bg-amber-50' : 'text-gray-700 border-gray-200 bg-white'}`}
        title="Claves de modelo SAP (T435T): su texto es el nombre de la operación en MES"
      >
        {vacio ? <AlertTriangle className="w-3.5 h-3.5" /> : null}
        T435T: {vacio ? 'sin sincronizar' : `${data.activos} claves · ${fecha}`}
      </span>
      <button
        onClick={ejecutar}
        disabled={sincronizar.isPending}
        className="inline-flex items-center gap-1.5 px-2 py-1 text-xs font-semibold border border-gray-300 text-gray-600 hover:text-[#003588] hover:border-[#003588] disabled:opacity-50"
        title="Leer T435T desde SAP (API de SAP)"
      >
        <RefreshCw className={`w-3.5 h-3.5 ${sincronizar.isPending ? 'animate-spin' : ''}`} /> Sincronizar
      </button>
    </span>
  )
}

const SapMesPage = () => {
  const { centroActual } = useOutletContext() || { centroActual: CENTRO_SAP_MES }
  const showToast = useToast()
  const centro = CENTRO_SAP_MES

  // ---- Filtros en borrador ----
  const [material, setMaterial] = useState(null)
  const [plnal, setPlnal] = useState('')
  const [fecha, setFecha] = useState('')
  const [desde, setDesde] = useState(isoHoyMenos(13))
  const [hasta, setHasta] = useState(isoHoyMenos(0))
  const [estadistico, setEstadistico] = useState('mediana')
  const [campoTiempo, setCampoTiempo] = useState('tiempo')
  const [divisorSalida, setDivisorSalida] = useState(1)
  const [materialMes, setMaterialMes] = useState('')
  const [tolerancia, setTolerancia] = useState(10)
  const [maxGap, setMaxGap] = useState(600)
  const [maxCt, setMaxCt] = useState(3600)
  const [avanzado, setAvanzado] = useState(false)

  // ---- Filtros aplicados (disparan la consulta) ----
  const [aplicados, setAplicados] = useState(null)
  const [metrica, setMetrica] = useState('proceso')
  const [opEditando, setOpEditando] = useState(null)
  const [grupoActivo, setGrupoActivo] = useState(null)

  const { data: materiales = [], isLoading: cargandoMateriales } = useMaterialesSapMes(centro)
  const { data: versiones } = useVersionesSap(material?.value, centro)
  const { data: comp, isFetching, isError, error } = useComparativaSapMes(aplicados)
  const { data: reglas } = useReglasSapMes(centro, aplicados?.material)

  const opcionesMaterial = useMemo(
    () => materiales.map((m) => ({
      value: m.numero_material,
      label: `${m.numero_material} · ${m.nombre_pieza || ''}${m.reglas ? `  (${m.reglas} mapeos)` : ''}`,
    })),
    [materiales]
  )

  // Al cambiar de material: alternativa y version por defecto (principal / vigente).
  useEffect(() => {
    if (versiones?.default) {
      setPlnal(versiones.default.plnal || '')
      setFecha(versiones.default.fecha || '')
    }
  }, [versiones])

  const altActual = versiones?.alternativas?.find((a) => a.plnal === plnal)

  const cambiarAlternativa = (nueva) => {
    setPlnal(nueva)
    const alt = versiones?.alternativas?.find((a) => a.plnal === nueva)
    setFecha(alt?.vigente || '')
  }

  const rangoInvalido = !desde || !hasta || desde > hasta
  const puedeComparar = !!material && !!plnal && !rangoInvalido

  const comparar = () => {
    if (!puedeComparar) return
    setAplicados({
      material: material.value,
      centro,
      plnal,
      fecha: fecha || undefined,
      start_date: aApi(desde),
      end_date: aApi(hasta),
      estadistico,
      campo_tiempo: campoTiempo,
      divisor_salida: Number(divisorSalida) > 0 ? Number(divisorSalida) : 1,
      material_mes: materialMes.trim() || undefined,
      tolerancia_pct: Number(tolerancia) || 0,
      max_gap_sec: Number(maxGap) || 600,
      max_ct_sec: Number(maxCt) || 3600,
    })
  }

  // Cuantas operaciones traen cada tiempo (de la ultima comparacion del mismo material).
  const disponibles = useMemo(() => {
    if (!comp || comp.numero_material !== material?.value) return {}
    return Object.fromEntries((comp.campos_tiempo || []).map((c) => [c.campo, c]))
  }, [comp, material])

  // Grupo de procesos elegido: filtra grafica, tabla y KPIs. Si el grupo ya no
  // existe en la comparativa (otro material, se borro), se vuelve a toda la ruta.
  const grupoSel = comp?.grupos?.find((g) => g.id === grupoActivo) || null
  useEffect(() => {
    if (comp && grupoActivo && !grupoSel) setGrupoActivo(null)
  }, [comp, grupoActivo, grupoSel])
  const operacionesVisibles = useMemo(() => {
    if (!comp) return []
    if (!grupoSel) return comp.operaciones
    const set = new Set(grupoSel.operaciones)
    return comp.operaciones.filter((o) => set.has(o.operacion_num))
  }, [comp, grupoSel])
  const resumenVisible = grupoSel ? grupoSel.resumen : comp?.resumen

  // Divisor que REALMENTE aplico el backend. Si el backend no lo devuelve
  // (version anterior a la v8), la salida MES viene sin dividir: se trata como 1
  // y se avisa, en lugar de mostrar "÷ undefined" con valores sin dividir.
  const divAplicado = Number(comp?.parametros?.divisor_salida) || 1
  const divPedido = Number(aplicados?.divisor_salida) || 1
  const divisorIgnorado = !!comp && divPedido !== 1 && comp?.parametros?.divisor_salida === undefined

  // Material con el que se consultaron los datos MES (si es distinto al material SAP).
  const materialMesUsado = comp?.parametros?.material_mes
  const mesDeOtroMaterial = !!materialMesUsado && String(materialMesUsado) !== String(comp?.numero_material)

  const errorApi = error?.response?.data?.detail || error?.customMessage || error?.message

  return (
    <div className="p-6 space-y-5">
      {/* Encabezado */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-gray-900">SAP / MES</h2>
          <p className="text-sm text-gray-500">
            Tiempo de operación de la hoja de ruta SAP contra el tiempo ciclo real registrado en MES, por operación.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <EstadoCatalogo onMensaje={(m, t = 'success') => showToast(m, t)} />
          <EstadoMes />
        </div>
      </div>

      {centroActual !== CENTRO_SAP_MES && (
        <div className="flex items-start gap-2 border border-blue-200 bg-blue-50 px-3 py-2 text-sm text-blue-900">
          <Info className="w-4 h-4 mt-0.5 shrink-0" />
          Este apartado trabaja por ahora solo con el centro 0094 (KEMM). Se ignora el centro seleccionado arriba.
        </div>
      )}

      {/* Filtros */}
      <div className="bg-white border border-gray-200 p-4">
        <div className="flex flex-wrap items-end gap-3">
          <Campo etiqueta="Material" className="w-full sm:w-80">
            <CustomSelect
              options={opcionesMaterial}
              value={material}
              onChange={(opt) => setMaterial(opt || null)}
              placeholder={cargandoMateriales ? 'Cargando…' : 'Buscar número de parte…'}
            />
          </Campo>
          <Campo etiqueta="Alternativa SAP">
            <select className={`${inputCls} w-28`} value={plnal} onChange={(e) => cambiarAlternativa(e.target.value)} disabled={!versiones}>
              {(versiones?.alternativas || []).map((a) => (
                <option key={a.plnal} value={a.plnal}>Alt {a.plnal}</option>
              ))}
            </select>
          </Campo>
          <Campo etiqueta="Versión SAP">
            <select className={`${inputCls} w-64`} value={fecha} onChange={(e) => setFecha(e.target.value)} disabled={!altActual}>
              {(altActual?.fechas || []).map((f) => (
                <option key={f} value={f}>
                  {f === altActual.vigente ? `Vigente · desde ${fechaCorta(f)}` : `Desde ${fechaCorta(f)}`}
                </option>
              ))}
            </select>
          </Campo>
          <Campo etiqueta="Tiempo SAP a comparar">
            <select
              className={`${inputCls} w-80`}
              value={campoTiempo}
              onChange={(e) => setCampoTiempo(e.target.value)}
              title="Columna de la hoja de ruta (trazabilidad) que se compara contra MES"
            >
              {CAMPOS_TIEMPO_SAP.map((c) => {
                const d = disponibles[c.value]
                const extra = d ? ` · ${d.operaciones_con_valor}/${d.operaciones} ops` : ''
                return <option key={c.value} value={c.value}>{`${c.label} (${c.vgw})${extra}`}</option>
              })}
            </select>
          </Campo>
          <Campo etiqueta="MES desde">
            <input type="date" className={inputCls} value={desde} max={hasta} onChange={(e) => setDesde(e.target.value)} />
          </Campo>
          <Campo etiqueta="MES hasta">
            <input type="date" className={inputCls} value={hasta} min={desde} onChange={(e) => setHasta(e.target.value)} />
          </Campo>
          <Campo etiqueta="Estadístico MES">
            <select className={`${inputCls} w-40`} value={estadistico} onChange={(e) => setEstadistico(e.target.value)}>
              {ESTADISTICOS.map((e) => <option key={e.value} value={e.value}>{e.label}</option>)}
            </select>
          </Campo>
          <Campo etiqueta="MES salida ÷">
            <input
              id="divisor-salida"
              type="number"
              min={1}
              step={1}
              className={`${inputCls} w-20`}
              value={divisorSalida}
              onChange={(e) => setDivisorSalida(e.target.value)}
              title="Si MES registra varias piezas juntas (p. ej. un panel de 4), divide la salida START→START entre ese número"
            />
          </Campo>
          <Campo etiqueta="Datos MES de">
            <input
              id="material-mes"
              type="text"
              inputMode="numeric"
              placeholder={material?.value || 'mismo'}
              className={`${inputCls} w-28`}
              value={materialMes}
              onChange={(e) => setMaterialMes(e.target.value.replace(/\s/g, ''))}
              title="Vacío = el mismo material. Escribe otro número de material con la misma ruta para usar sus eventos MES (p. ej. un material nuevo que aún no corre en MES)."
            />
          </Campo>
          <Campo etiqueta="Tolerancia ±%">
            <input type="number" min={0} max={100} className={`${inputCls} w-20`} value={tolerancia} onChange={(e) => setTolerancia(e.target.value)} />
          </Campo>
          <button
            onClick={() => setAvanzado((v) => !v)}
            className={`inline-flex items-center gap-1.5 px-3 py-[7px] text-sm border ${avanzado ? 'border-[#003588] text-[#003588]' : 'border-gray-300 text-gray-600'} hover:text-[#003588] hover:border-[#003588]`}
            title="Límites para excluir paros y piezas detenidas"
          >
            <SlidersHorizontal className="w-4 h-4" /> Límites
          </button>
          <button
            onClick={comparar}
            disabled={!puedeComparar || isFetching}
            className="inline-flex items-center gap-2 px-5 py-[7px] text-sm font-bold uppercase tracking-wide text-white bg-[#003588] hover:bg-[#002a6b] disabled:opacity-40 disabled:cursor-not-allowed ml-auto"
          >
            {isFetching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />} Comparar
          </button>
        </div>

        {avanzado && (
          <div className="flex flex-wrap items-end gap-4 mt-4 pt-4 border-t border-gray-100">
            <Campo etiqueta="Salida: excluir huecos mayores a (seg)">
              <input type="number" min={1} className={`${inputCls} w-28`} value={maxGap} onChange={(e) => setMaxGap(e.target.value)} />
            </Campo>
            <Campo etiqueta="Proceso: excluir ciclos mayores a (seg)">
              <input type="number" min={1} className={`${inputCls} w-28`} value={maxCt} onChange={(e) => setMaxCt(e.target.value)} />
            </Campo>
            <p className="text-xs text-gray-500 max-w-md">
              Los intervalos entre piezas más largos que el límite se consideran paros (comidas, cambios de turno o de modelo) y no entran al cálculo de salida. Los ciclos más largos que el límite de proceso se consideran piezas detenidas.
            </p>
          </div>
        )}
        {rangoInvalido && <p className="text-xs text-red-700 mt-2">El rango de fechas de MES no es válido.</p>}
      </div>

      {/* Contenido */}
      {!aplicados && (
        <div className="bg-white border border-dashed border-gray-300 px-6 py-14 text-center">
          <p className="text-sm font-semibold text-gray-700">Selecciona un material y presiona Comparar</p>
          <p className="text-xs text-gray-500 mt-1">
            La consulta lee los eventos de MES del rango elegido; rangos cortos (7–14 días) responden más rápido.
          </p>
        </div>
      )}

      {aplicados && isFetching && !comp && (
        <div className="bg-white border border-gray-200 px-6 py-14 flex items-center justify-center gap-3 text-sm text-gray-600">
          <Loader2 className="w-5 h-5 animate-spin text-[#003588]" /> Consultando SAP y MES…
        </div>
      )}

      {aplicados && isError && (
        <div className="flex items-start gap-2 border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" /> {errorApi || 'No se pudo obtener la comparativa.'}
        </div>
      )}

      {comp && (
        <div className={`space-y-5 ${isFetching ? 'opacity-60 pointer-events-none' : ''}`}>
          <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
            <p className="text-xl font-bold text-[#003588]">{comp.numero_material}</p>
            <p className="text-sm text-gray-600">{comp.nombre_pieza}</p>
            <p className="text-xs text-gray-500">
              Alt {comp.version.plnal} · versión SAP al {fechaCorta(comp.version.fecha)} · {etiquetaCampoTiempo(comp.parametros.campo_tiempo)}{divAplicado !== 1 ? ` · salida MES ÷ ${divAplicado}` : ''} · MES {fechaApiCorta(comp.parametros.start_date)} – {fechaApiCorta(comp.parametros.end_date)}
            </p>
          </div>

          {comp.mes.meta?.fuente === 'BD' && (() => {
            const h = comp.mes.meta.historico || {}
            const fmt = (t) => (t ? `${t.slice(6, 8)}.${t.slice(4, 6)}.${t.slice(0, 4)}` : '')
            const periodos = h.periodos || []
            return (
              <div className="flex items-start gap-2 border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>
                  SAP HANA (MES) no respondió. Se muestran <b>datos MES guardados</b> por la API de MES
                  {periodos.map((p, i) => (
                    <span key={i}>
                      {i === 0 ? ': ' : '; '}MES {fmt(p.start_date)} – {fmt(p.end_date)}, consultado {p.consultado_en}
                    </span>
                  ))}
                  .{h.exactas < h.filas && ' Algunos datos son de otro periodo o límites que los elegidos.'}
                </span>
              </div>
            )
          })()}

          {comp.mes.error && (
            <div className="flex items-start gap-2 border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>No se obtuvieron datos de MES: {comp.mes.error}. Se muestran solo los tiempos SAP.</span>
            </div>
          )}

          {(() => {
            const c = (comp.campos_tiempo || []).find((x) => x.campo === comp.parametros.campo_tiempo)
            if (!c || c.operaciones_con_valor > 0) return null
            return (
              <div className="flex items-start gap-2 border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>
                  Ninguna operación de esta versión tiene {etiquetaCampoTiempo(c.campo)} en SAP. Elige otro tiempo en "Tiempo SAP a comparar".
                </span>
              </div>
            )
          })()}

          {mesDeOtroMaterial && (
            <div className="flex items-start gap-2 border border-blue-200 bg-blue-50 px-3 py-2 text-sm text-blue-900">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>
                SAP de <b>{comp.numero_material}</b> contra los eventos MES de <b>{materialMesUsado}</b>.
              </span>
            </div>
          )}

          {divisorIgnorado && (
            <div className="flex items-start gap-2 border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>
                El servidor no aplicó <b>MES salida ÷ {divPedido}</b>: el backend de OpTimeSAP que está corriendo es anterior a la v8.
                Reinícialo (o vuelve a generar el .exe con <code>build.py</code>) después de copiar la v8. Mientras tanto, la salida MES se muestra sin dividir.
              </span>
            </div>
          )}

          <GruposProcesos
            comp={comp}
            centro={centro}
            grupoActivo={grupoSel?.id ?? null}
            onSeleccionar={setGrupoActivo}
            onMensaje={(m, t = 'success') => showToast(m, t)}
          />

          {grupoSel && (
            <p className="text-sm text-gray-700">
              Mostrando el grupo <b className="text-[#003588]">{grupoSel.nombre}</b> ({grupoSel.op_inicio}–{grupoSel.op_fin}, {grupoSel.operaciones.length} operaciones).{' '}
              <button className="text-[#003588] font-semibold hover:underline" onClick={() => setGrupoActivo(null)}>Ver toda la ruta</button>
            </p>
          )}

          <ResumenKpis resumen={resumenVisible} colorSap={COLOR_SAP} colorMes={COLOR_MES} />

          <div className="bg-white border border-gray-200">
            <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-b border-gray-200">
              <div>
                <p className="text-sm font-bold text-gray-900">SAP vs MES por operación (seg/pz)</p>
                <p className="text-xs text-gray-500">
                  {metrica === 'proceso'
                    ? 'Proceso: tiempo de una pieza en la estación (START→COMPLETE) contra el tiempo SAP por equipo.'
                    : `Salida: cada cuánto entra una pieza a la estación (START→START)${divAplicado !== 1 ? `, dividido entre ${divAplicado}` : ''} contra el tiempo SAP ÷ equipos.`}
                </p>
              </div>
              <div className="inline-flex border border-gray-300" role="group" aria-label="Métrica MES">
                {[['proceso', 'Proceso'], ['salida', 'Salida']].map(([v, l]) => (
                  <button
                    key={v}
                    onClick={() => setMetrica(v)}
                    aria-pressed={metrica === v}
                    className={`px-4 py-1.5 text-xs font-bold uppercase ${metrica === v ? 'bg-[#003588] text-white' : 'bg-white text-gray-600 hover:text-[#003588]'}`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div className="p-4">
              <ComparativaGrafica divisorSalida={divAplicado} operaciones={operacionesVisibles} metrica={metrica} colorSap={COLOR_SAP} colorMes={COLOR_MES} />
            </div>
          </div>

          <div className="bg-white border border-gray-200">
            <div className="px-4 py-3 border-b border-gray-200">
              <p className="text-sm font-bold text-gray-900">Detalle por operación</p>
              <p className="text-xs text-gray-500">
                Δ = (MES − SAP) / SAP. Positivo: MES tarda más que el estándar. Tolerancia ±{comp.parametros.tolerancia_pct}% · estadístico MES: {comp.parametros.estadistico}.
              </p>
            </div>
            <ComparativaTabla
              operaciones={operacionesVisibles}
              estadistico={comp.parametros.estadistico}
              campoTiempo={comp.parametros.campo_tiempo}
              divisorSalida={divAplicado}
              onEditarRegla={setOpEditando}
            />
          </div>
        </div>
      )}

      <ReglaSlideOver
        isOpen={!!opEditando}
        onClose={() => setOpEditando(null)}
        op={opEditando}
        material={comp?.numero_material}
        plnal={comp?.version?.plnal}
        centro={centro}
        reglas={reglas}
        onGuardado={(msg) => showToast(msg, 'success')}
      />
    </div>
  )
}

export default SapMesPage
