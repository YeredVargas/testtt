// src/pages/graficas/GraficasPage.jsx
import React, { useMemo, useState, useEffect } from 'react'
import { useSearchParams, useNavigate, useOutletContext } from 'react-router-dom'
import { BarChart2, Filter, Settings, ChevronLeft, ChevronRight, RefreshCw, Plus } from 'lucide-react'
import { useQueryClient } from '@tanstack/react-query'
import { useSecciones, useDashboardSeccion } from '../../hooks/useDashboard'
import { useFiltrosGraficas } from '../../hooks/useGraficas'
import CustomSelect from '../../components/ui/CustomSelect'
import GraficaBarras from '../../components/graficas/GraficaBarras'
import { useToast } from '../../components/ui/ToastContext'
import { sincronizarDatosSAP } from '../../services/SapService'
import NuevoMaterialModal from '../../components/ui/NuevoMaterialModal'

const parseFechaSap = (str) => {
  if (!str) return null
  const partes = str.split('.')
  if (partes.length !== 3) return null
  const [d, m, y] = partes
  return new Date(parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10))
}

const MESES_NOMBRES = {
  0: "Enero", 1: "Febrero", 2: "Marzo", 3: "Abril", 4: "Mayo", 5: "Junio",
  6: "Julio", 7: "Agosto", 8: "Septiembre", 9: "Octubre", 10: "Noviembre", 11: "Diciembre"
}

const OPCIONES_METRICAS = [
  { value: 'tiempo', label: 'Tiempo SAP (hr)' },
  { value: 'porcentaje', label: '% vs Anterior' },
  { value: 'porcentaje_global', label: '% Acumulado (Global)' }, 
  { value: 'equipos', label: 'Equipos' },
  { value: 'seg_pz', label: 'seg/pz' },
  { value: 'pzs_hr', label: 'pzs/hr' } 
]

function GraficasMaterial({ material, fechaInicio, fechaFin, mesFiltro, metricaGlobal }) {
  const [metricaLocal, setMetricaLocal] = useState(metricaGlobal)

  useEffect(() => {
    setMetricaLocal(metricaGlobal)
  }, [metricaGlobal])

  const procesosGraficables = useMemo(() => {
    if (!metricaLocal) return []

    return material.procesos.map(proc => {
      const registrosCalculados = proc.historial;
      
      const registrosParaMostrar = registrosCalculados.filter(r => {
        const dateObj = parseFechaSap(r.fecha_cambio)
        if (!dateObj) return true
        if (fechaInicio && dateObj < new Date(`${fechaInicio}T00:00:00`)) return false
        if (fechaFin && dateObj > new Date(`${fechaFin}T00:00:00`)) return false
        if (mesFiltro) {
          const m = String(dateObj.getMonth() + 1).padStart(2, '0')
          const y = dateObj.getFullYear()
          if (`${y}-${m}` !== mesFiltro) return false
        }
        return true
      })

      if (registrosParaMostrar.length === 0) return null

      const datosGrafica = registrosParaMostrar.map(r => {
        let valor = 0;
        let color = '#374151'; 

        if (metricaLocal === 'tiempo') {
          valor = r.tiempo;
          if (r.prev_tiempo != null) {
            if (valor > r.prev_tiempo) color = '#ef4444'; 
            else if (valor < r.prev_tiempo) color = '#16a34a'; 
          }
        } else if (metricaLocal === 'porcentaje') {
          valor = r.mejora || 0;
          if (valor > 0) color = '#16a34a'; 
          else if (valor < 0) color = '#ef4444'; 
          else color = '#9ca3af'; 
        } else if (metricaLocal === 'porcentaje_global') { 
          valor = r.mejora_global || 0;
          if (valor > 0) color = '#16a34a'; 
          else if (valor < 0) color = '#ef4444'; 
          else color = '#9ca3af'; 
        } else if (metricaLocal === 'seg_pz') {
          valor = r.seg_pz;
          if (r.prev_seg_pz != null) {
            if (valor > r.prev_seg_pz) color = '#ef4444'; 
            else if (valor < r.prev_seg_pz) color = '#16a34a'; 
          }
        } else if (metricaLocal === 'pzs_hr') {
          valor = r.pzs_hr != null ? r.pzs_hr : 0;
          if (r.prev_pzs_hr != null) {
            if (valor > r.prev_pzs_hr) color = '#16a34a'; 
            else if (valor < r.prev_pzs_hr) color = '#ef4444'; 
          }
        } else if (metricaLocal === 'equipos') {
          valor = r.equipos;
        }

        return {
          operacion_num: r.fecha_cambio,
          valor,
          color, 
          fecha_cambio: r.fecha_cambio,
          tiempo_sap: r.tiempo,
          equipos: r.equipos,
          pzs_hr: r.pzs_hr,
          seg_pz: r.seg_pz,
          mejora: r.mejora,
          mejora_global: r.mejora_global
        }
      })

      const titulos = {
        porcentaje: '% vs Anterior',
        porcentaje_global: '% Acumulado (Global)',
        tiempo: 'Tiempo SAP (hr)',
        equipos: 'Equipos',
        seg_pz: 'seg/pz',
        pzs_hr: 'pzs/hr'
      }

      return {
        nombre_proceso: proc.nombre_proceso,
        titulo: `${titulos[metricaLocal]} — ${proc.nombre_proceso}`,
        datosGrafica
      }
    }).filter(Boolean)
  }, [material, fechaInicio, fechaFin, mesFiltro, metricaLocal])

  const unidades = {
    porcentaje: '%',
    porcentaje_global: '%',
    tiempo: 'hr',
    equipos: 'eq',
    seg_pz: 'seg',
    pzs_hr: 'pzs'
  }

  return (
    <div className="mb-8 border border-gray-200 shadow-sm bg-white p-6">
      <div className="border-b border-gray-100 pb-5 mb-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex gap-10">
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Núm. Parte</p>
            <p className="text-xl font-bold text-[#003588] leading-none">
              {material.numero_material}
            </p>
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Plataforma</p>
            <p className="text-md font-bold text-gray-900 leading-none">{material.proyecto || '—'}</p>
          </div>
        </div>
        <div className="w-full md:w-80">
          <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">
             Graficando Localmente
          </label>
          <CustomSelect
            options={OPCIONES_METRICAS}
            value={OPCIONES_METRICAS.find(o => o.value === metricaLocal) || null}
            onChange={(opt) => setMetricaLocal(opt?.value ?? null)}
            placeholder="Seleccionar..."
            isClearable={true}
            isSearchable={false}
          />
        </div>
      </div>

      {!metricaLocal ? (
        <div className="py-12 text-center border border-dashed border-gray-200 bg-gray-50">
          <BarChart2 className="h-8 w-8 text-gray-300 mx-auto mb-2" />
          <p className="text-sm text-gray-400 font-medium">Selecciona una métrica en el menú superior para visualizar las gráficas.</p>
        </div>
      ) : (
        <>
          {procesosGraficables.length === 0 ? (
            <div className="py-12 text-center text-sm text-gray-400 italic">No hay datos en el rango seleccionado.</div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {procesosGraficables.map(proc => (
                <GraficaBarras
                  key={proc.nombre_proceso}
                  titulo={proc.titulo}
                  datos={proc.datosGrafica}
                  unidad={unidades[metricaLocal]}
                  metricaActual={metricaLocal}
                  onChangeMetrica={setMetricaLocal}
                  opcionesMetricas={OPCIONES_METRICAS}
                />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}

const GraficasPage = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const navigate = useNavigate()
  
  const queryClient = useQueryClient()
  const showToast = useToast() 

  const { centroActual } = useOutletContext() || { centroActual: '0094' }

  const [filtroMaterial, setFiltroMaterial] = useState(null)
  const [fechaInicio, setFechaInicio] = useState('')
  const [fechaFin, setFechaFin] = useState('')
  const [mesFiltro, setMesFiltro] = useState(null)
  const [filtroProyecto, setFiltroProyecto] = useState(null)
  const [metricaGlobal, setMetricaGlobal] = useState('tiempo')

  const [paginaActual, setPaginaActual] = useState(1)
  const itemsPorPagina = 5 

  const [isSyncing, setIsSyncing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [isNuevoMaterialOpen, setIsNuevoMaterialOpen] = useState(false) // <-- ESTADO DEL MODAL

  const { data: seccionesRaw = [], isLoading: cargandoSecciones } = useSecciones(filtroMaterial, centroActual)
  const { data: filtrosGlobales } = useFiltrosGraficas({ centro: centroActual })
  
  const seccionActiva = searchParams.get('seccion') || null
  
  const { data: apiResponse, isLoading, isError } = useDashboardSeccion({
    seccion: seccionActiva,
    centro: centroActual,
    page: paginaActual,
    limit: itemsPorPagina, 
    numero_material: filtroMaterial,
    proyecto: filtroProyecto,
    fecha_inicio: fechaInicio || null,
    fecha_fin: fechaFin || null,
    mes_exacto: mesFiltro
  })

  const materiales = apiResponse?.datos || []
  const totalPaginas = apiResponse?.total_paginas || 1
  const totalRegistros = apiResponse?.total_registros || 0

  const ejecutarSincronizacion = async () => {
    setIsSyncing(true);
    setProgress(5);

    const interval = setInterval(() => {
      setProgress((prev) => {
        const remaining = 95 - prev;
        return prev + (remaining * 0.15);
      });
    }, 800);

    try {
        const datos = await sincronizarDatosSAP(centroActual);
        
        clearInterval(interval);
        setProgress(100);

        await queryClient.invalidateQueries(); 
        showToast(`Sincronización completada. ${datos.total_materiales || 'Varios'} materiales procesados en el centro ${centroActual}.`, 'success');
        
    } catch (error) {
        clearInterval(interval);
        setProgress(0);
        console.error("Falló la sincronización:", error);
        showToast("Ocurrió un error al intentar sincronizar con SAP.", 'error');
    } finally {
        setTimeout(() => {
          setIsSyncing(false);
          setProgress(0);
        }, 1000);
    }
  };

  const tabsVisibles = useMemo(() => {
    if (seccionesRaw.length === 0) return []
    return ['TODOS', ...seccionesRaw]
  }, [seccionesRaw])

  useEffect(() => {
    if (!cargandoSecciones) {
      if (tabsVisibles.length > 0) {
        if (!seccionActiva || !tabsVisibles.includes(seccionActiva)) {
          setSearchParams({ seccion: 'TODOS' }, { replace: true })
        }
      } else if (tabsVisibles.length === 0 && seccionActiva) {
        searchParams.delete('seccion')
        setSearchParams(searchParams, { replace: true })
      }
    }
  }, [seccionActiva, tabsVisibles, cargandoSecciones, setSearchParams, searchParams])

  useEffect(() => {
    setPaginaActual(1)
  }, [filtroMaterial, filtroProyecto, mesFiltro, fechaInicio, fechaFin, seccionActiva, metricaGlobal, centroActual])

  const opcionesMateriales = useMemo(() => {
    return (filtrosGlobales?.numeros_material || []).map(m => ({ value: m, label: m }))
  }, [filtrosGlobales])

  const opcionesProyectos = useMemo(() => {
    return (filtrosGlobales?.proyectos || []).map(p => ({ value: p, label: p }))
  }, [filtrosGlobales])

  const opcionesMeses = useMemo(() => {
    return (filtrosGlobales?.meses || []).map(m => ({ value: m.value, label: m.label }))
  }, [filtrosGlobales])

  const valMaterial = filtroMaterial ? opcionesMateriales.find(opt => opt.value === filtroMaterial) : null
  const valProyecto = filtroProyecto ? opcionesProyectos.find(opt => opt.value === filtroProyecto) : null

  return (
    <div className="h-full flex flex-col bg-gray-50 overflow-hidden relative">
      
      {isSyncing && (
        <div className="absolute top-0 left-0 w-full h-1 bg-gray-200 z-[100] overflow-hidden">
          <div 
            className="h-full bg-[#003588] transition-all duration-300 ease-out relative"
            style={{ width: `${progress}%` }}
          >
            <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
          </div>
        </div>
      )}

      <div className="bg-white border-b border-gray-200 px-6 py-4 shrink-0 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="hidden sm:flex items-center gap-3 mr-2">
             <BarChart2 className="h-6 w-6 text-[#003588]" />
             <div>
               <h2 className="text-xl md:text-2xl font-bold text-gray-900 leading-none">Análisis Gráfico</h2>
             </div>
          </div>

          <button 
            onClick={ejecutarSincronizacion} 
            disabled={isSyncing}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${
              isSyncing 
                ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' 
                : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'
            }`}
            title="Sincronizar base de datos con SAP"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{isSyncing ? `Sincronizando... ${Math.round(progress)}%` : 'Sincronizar SAP'}</span>
          </button>

          {/* BOTÓN IMPORTAR MATERIAL */}
          <button
            onClick={() => setIsNuevoMaterialOpen(true)}
            disabled={!centroActual || isSyncing}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${
              !centroActual || isSyncing
                ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'
            }`}
            title={centroActual ? 'Importar nuevo material desde SAP' : 'Selecciona un centro específico'}
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Importar Material</span>
          </button>
        </div>

        <div className="w-full md:w-80">
          <CustomSelect
            options={opcionesMateriales}
            value={valMaterial}
            onChange={(opt) => {
              setFiltroMaterial(opt?.value ?? null)
              setMesFiltro(null)
              setFiltroProyecto(null)
            }}
            placeholder="Buscar número de parte..."
            isClearable
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 scroll-smooth">
        
        <div className="border border-gray-200 bg-white shadow-sm p-5 rounded-none mb-6">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-[#003588]" /> Parámetros de Filtrado Global
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-4 items-end">
            
            <div>
              <label className="block text-xs font-bold text-[#003588] uppercase tracking-wider mb-1 flex items-center gap-1">
                <Settings className="w-3 h-3" /> Métrica Global
              </label>
              <CustomSelect
                options={OPCIONES_METRICAS}
                value={OPCIONES_METRICAS.find(o => o.value === metricaGlobal) || null}
                onChange={(opt) => setMetricaGlobal(opt?.value ?? null)}
                placeholder="Seleccionar..."
                isClearable={true} 
                isSearchable={false} 
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Plataforma</label>
              <CustomSelect
                options={opcionesProyectos}
                value={valProyecto}
                onChange={(opt) => setFiltroProyecto(opt?.value ?? null)}
                placeholder="Todos..."
                isDisabled={opcionesProyectos.length === 0}
                isClearable
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Mes Exacto</label>
              <CustomSelect
                options={opcionesMeses}
                value={opcionesMeses.find(o => o.value === mesFiltro) || null}
                onChange={(opt) => setMesFiltro(opt?.value ?? null)}
                placeholder="Todos..."
                isDisabled={opcionesMeses.length === 0}
                isClearable
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Inicio</label>
              <input type="date" value={fechaInicio} onChange={(e) => setFechaInicio(e.target.value)} className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors" />
            </div>
            
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Fin</label>
              <input type="date" value={fechaFin} onChange={(e) => setFechaFin(e.target.value)} className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors" />
            </div>
            
            {(fechaInicio || fechaFin || mesFiltro || filtroProyecto || !metricaGlobal) && (
              <div>
                <button onClick={() => { setFechaInicio(''); setFechaFin(''); setMesFiltro(null); setFiltroProyecto(null); setMetricaGlobal('tiempo'); }} className="w-full md:w-auto px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold uppercase rounded-none transition-colors border border-gray-300 h-[38px] focus:outline-none">
                  Limpiar Filtros
                </button>
              </div>
            )}
          </div>
        </div>

        {tabsVisibles.length > 0 && (
          <nav className="w-full bg-white shrink-0 border border-gray-200 shadow-sm overflow-x-auto mb-6 rounded-none [&::-webkit-scrollbar]:hidden" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
            <div className="flex w-max min-w-full">
              {cargandoSecciones ? (
                <div className="px-6 py-4 text-sm text-gray-400">Cargando procesos...</div>
              ) : (
                tabsVisibles.map((sec) => {
                  const isActive = sec === seccionActiva
                  return (
                    <button
                      key={sec}
                      onClick={() => setSearchParams({ seccion: sec })}
                      className={`px-8 py-4 text-sm font-medium border-r border-gray-200 transition-colors rounded-none block focus:outline-none flex-shrink-0
                        ${isActive ? 'bg-[#003588] text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
                    >
                      {sec}
                    </button>
                  )
                })
              )}
            </div>
          </nav>
        )}

        {isLoading && <div className="flex justify-center py-10"><div className="h-10 w-10 rounded-full border-4 border-gray-200 border-t-[#003588] animate-spin" /></div>}
        {isError && <div className="border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700 rounded-none mb-6">Error al cargar datos de SAP.</div>}

        {!isLoading && !isError && totalRegistros === 0 && (
          <div className="border border-gray-200 bg-white shadow-sm p-10 text-center rounded-none mt-4">
            <p className="text-sm text-gray-400">No hay coincidencias gráficas para los filtros aplicados en la vista <strong>{seccionActiva}</strong>.</p>
          </div>
        )}

        {!isLoading && materiales.map((material) => (
          <GraficasMaterial 
            key={material.numero_material} 
            material={material} 
            fechaInicio={fechaInicio} 
            fechaFin={fechaFin} 
            mesFiltro={mesFiltro}
            metricaGlobal={metricaGlobal}
          />
        ))}

        {totalPaginas > 1 && (
          <div className="flex items-center justify-between border border-gray-200 bg-white px-4 py-3 sm:px-6 shadow-sm mt-2 mb-8">
            <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Mostrando <span className="font-medium text-[#003588]">{(paginaActual - 1) * itemsPorPagina + 1}</span> a <span className="font-medium text-[#003588]">{Math.min(paginaActual * itemsPorPagina, totalRegistros)}</span> de <span className="font-medium text-[#003588]">{totalRegistros}</span> números de parte
                </p>
              </div>
              <div>
                <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
                  <button
                    onClick={() => {
                      setPaginaActual(p => Math.max(1, p - 1));
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    disabled={paginaActual === 1}
                    className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <span className="sr-only">Anterior</span>
                    <ChevronLeft className="h-5 w-5" aria-hidden="true" />
                  </button>
                  
                  {[...Array(totalPaginas)].map((_, i) => {
                    const numPagina = i + 1;
                    const isCurrent = numPagina === paginaActual;
                    
                    if (
                      numPagina === 1 || 
                      numPagina === totalPaginas || 
                      (numPagina >= paginaActual - 2 && numPagina <= paginaActual + 2)
                    ) {
                      return (
                        <button
                          key={numPagina}
                          onClick={() => {
                            setPaginaActual(numPagina);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className={`relative inline-flex items-center px-4 py-2 text-sm font-semibold focus:z-20 focus:outline-offset-0 ${
                            isCurrent 
                              ? 'bg-[#003588] text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#003588]' 
                              : 'text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          {numPagina}
                        </button>
                      );
                    } else if (
                      numPagina === paginaActual - 3 || 
                      numPagina === paginaActual + 3
                    ) {
                      return <span key={numPagina} className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-700 ring-1 ring-inset ring-gray-300 focus:outline-offset-0">...</span>
                    }
                    return null;
                  })}

                  <button
                    onClick={() => {
                      setPaginaActual(p => Math.min(totalPaginas, p + 1));
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    disabled={paginaActual === totalPaginas}
                    className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <span className="sr-only">Siguiente</span>
                    <ChevronRight className="h-5 w-5" aria-hidden="true" />
                  </button>
                </nav>
              </div>
            </div>
          </div>
        )}

      </div>

      <NuevoMaterialModal 
        isOpen={isNuevoMaterialOpen} 
        onClose={() => setIsNuevoMaterialOpen(false)} 
        centroActual={centroActual} 
      />
    </div>
  )
}

export default GraficasPage