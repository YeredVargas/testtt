// src/pages/graficas/ComparativaPage.jsx
import React, { useState, useMemo, useRef } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  GitCompare,
  Filter,
  Loader2,
  Users,
  AlertTriangle,
  X,
  RefreshCw,
  Plus,
  Download,
  Maximize2,
  Timer,
  AlertOctagon,
  Activity,
  Zap
} from 'lucide-react';
import { useQueries, useQueryClient } from '@tanstack/react-query';
import * as htmlToImage from 'html-to-image';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
  ComposedChart,
  Line,
  LineChart
} from 'recharts';

import CustomSelect from '../../components/ui/CustomSelect';
import { DashboardService } from '../../services/dashboard/DashboardService';
import { useFiltrosGraficas } from '../../hooks/useGraficas';
import { useCostos } from '../../hooks/useCostos';
import { useToast } from '../../components/ui/ToastContext';
import { sincronizarDatosSAP } from '../../services/SapService';
import NuevoMaterialModal from '../../components/ui/NuevoMaterialModal';
import { calcularManoObra, tiempoReal } from '../../utils/manoObra';

const COLORS = {
  automatico: '#003588',
  manual: '#9ca3af',
  operadores: '#10b981',
  fijo: '#64748b',
  variable: '#0f766e',
};

const LINE_COLORS = ['#003588', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#ec4899'];

const formatMoney = (monto) =>
  new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 2
  }).format(Number.isFinite(Number(monto)) ? Number(monto) : 0);

// Renderizador Multilínea para el Eje Y (Gráfica Horizontal)
const CustomYAxisTick = ({ x, y, payload, data }) => {
  if (!payload || !payload.value) return null;
  const val = payload.value.toString();
  const idx = val.indexOf(' - ');
  const num = idx !== -1 ? val.substring(0, idx) : val;
  const desc = idx !== -1 ? val.substring(idx + 3) : '';

  // Identificador "No MES Ready"
  const itemData = data?.find((d) => d.display_name === val);
  const isLegacy = itemData?.isLegacy;

  let numY = 4;
  let descY = 10;
  let warnY = 16;

  if (desc && isLegacy) {
    numY = -12;
    descY = 2;
    warnY = 16;
  } else if (desc && !isLegacy) {
    numY = -6;
    descY = 10;
  } else if (!desc && isLegacy) {
    numY = -6;
    warnY = 10;
  }

  return (
    <g transform={`translate(${x},${y})`}>
      <text x={-10} y={numY} textAnchor="end" fill="#003588" fontSize={12} fontWeight="900">
        {num}
      </text>
      {desc && (
        <text x={-10} y={descY} textAnchor="end" fill="#6B7280" fontSize={10} fontWeight="normal">
          {desc.length > 35 ? `${desc.substring(0, 35)}...` : desc}
        </text>
      )}
      {isLegacy && (
        <text x={-10} y={warnY} textAnchor="end" fill="#f59e0b" fontSize={10} fontWeight="bold">
          ⚠️ No MES Ready
        </text>
      )}
    </g>
  );
};

// Renderizador Multilínea para Eje X con Inclinación de -35 grados
const CustomXAxisTick = ({ x, y, payload }) => {
  if (!payload || !payload.value) return null;
  const val = payload.value.toString();
  const idx = val.indexOf(' - ');
  const num = idx !== -1 ? val.substring(0, idx) : val;
  const desc = idx !== -1 ? val.substring(idx + 3) : '';

  return (
    <g transform={`translate(${x},${y})`}>
      <g transform="rotate(-35)">
        <text x={-5} y={10} textAnchor="end" fill="#003588" fontSize={11} fontWeight="900">
          {num}
        </text>
        {desc && (
          <text x={-5} y={22} textAnchor="end" fill="#6B7280" fontSize={9} fontWeight="normal">
            {desc.length > 25 ? `${desc.substring(0, 25)}...` : desc}
          </text>
        )}
      </g>
    </g>
  );
};

const GraficaCard = ({ titulo, badge, children }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const chartRef = useRef(null);
  const modalRef = useRef(null);

  const handleDownload = async () => {
    const ref = isExpanded ? modalRef : chartRef;
    if (!ref.current) return;

    try {
      const dataUrl = await htmlToImage.toPng(ref.current, {
        backgroundColor: '#ffffff',
        pixelRatio: 2,
        filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true')
      });
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `${titulo.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error descargando gráfica:', error);
    }
  };

  const renderHeader = (isModal = false) => (
    <div className={`flex justify-between items-center pb-4 border-b border-gray-200 shrink-0 ${isModal ? 'px-6 py-4 bg-white' : 'mb-4'}`}>
      <div className="flex items-center gap-3">
        {isModal && <Maximize2 className="w-4 h-4 text-[#003588] font-bold" />}
        <h3 className={`text-xs font-bold uppercase tracking-wider ${isModal ? 'text-[#003588]' : 'text-gray-500'}`}>
          {titulo}
        </h3>
        {!isModal && badge && (
          <span className="bg-blue-50 text-[#003588] text-[10px] font-bold px-2 py-0.5 border border-blue-100 rounded-sm">
            {badge}
          </span>
        )}
      </div>
      <div className="flex items-center gap-3" data-html2canvas-ignore="true">
        {isModal ? (
          <>
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 hover:text-[#003588] transition-colors focus:outline-none"
            >
              <Download className="w-4 h-4" /> DESCARGAR PNG
            </button>
            <div className="w-px h-6 bg-gray-300"></div>
            <button
              onClick={() => setIsExpanded(false)}
              className="text-gray-400 hover:text-red-500 transition-colors focus:outline-none"
              title="Cerrar"
            >
              <X className="w-5 h-5" />
            </button>
          </>
        ) : (
          <>
            <button
              onClick={handleDownload}
              className="text-gray-400 hover:text-[#003588] transition-colors focus:outline-none"
              title="Descargar gráfica"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsExpanded(true)}
              className="text-gray-400 hover:text-[#003588] transition-colors focus:outline-none"
              title="Expandir gráfica"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </>
        )}
      </div>
    </div>
  );

  if (isExpanded) {
    return (
      <>
        <div className="flex flex-col border border-gray-200 shadow-sm bg-white p-6 h-full relative" ref={chartRef}>
          {renderHeader(false)}
          <div className="w-full h-80 min-h-[320px]">{children}</div>
        </div>

        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 sm:p-10"
          onClick={() => setIsExpanded(false)}
        >
          <div
            className="bg-gray-50 border border-gray-200 shadow-2xl w-full max-w-7xl h-[85vh] flex flex-col rounded-sm overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {renderHeader(true)}
            <div className="flex-1 p-8 bg-white overflow-hidden flex flex-col" ref={modalRef}>
              <div className="flex-1 w-full h-full min-h-[500px]">
                {children}
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <div className="flex flex-col border border-gray-200 shadow-sm bg-white p-6 h-full relative" ref={chartRef}>
      {renderHeader(false)}
      <div className="w-full h-80 min-h-[320px]">{children}</div>
    </div>
  );
};

export default function ComparativaPage() {
  const { centroActual } = useOutletContext() || { centroActual: '0094' };
  const queryClient = useQueryClient();
  const showToast = useToast();

  const [isSyncing, setIsSyncing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isNuevoMaterialOpen, setIsNuevoMaterialOpen] = useState(false);

  const [materialesSeleccionados, setMaterialesSeleccionados] = useState([]);

  const [mesExacto, setMesExacto] = useState(null);
  const [fechaInicio, setFechaInicio] = useState('');
  const [fechaFin, setFechaFin] = useState('');

  const [filtroOpInicio, setFiltroOpInicio] = useState(null);
  const [filtroOpFin, setFiltroOpFin] = useState(null);

  const { data: filtrosGlobales } = useFiltrosGraficas({ centro: centroActual });
  const { data: costosRaw, isLoading: loadingCostos } = useCostos(centroActual);

  const opcionesMeses = useMemo(() => {
    return (filtrosGlobales?.meses || []).map((m) => ({ value: m.value, label: m.label }));
  }, [filtrosGlobales]);

  const opcionesMateriales = useMemo(() => {
    return (filtrosGlobales?.numeros_material || []).map((m) => ({ value: m, label: m }));
  }, [filtrosGlobales]);

  const handlePaste = (e) => {
    const pasteText = e.clipboardData.getData('text');
    if (pasteText) {
      const parts = pasteText.split(/[\s,]+/).filter(Boolean);
      if (parts.length > 0) {
        e.preventDefault();
        setMaterialesSeleccionados((prev) => {
          const prevValues = prev.map((m) => m.value);
          const toAdd = parts
            .filter((p) => !prevValues.includes(p))
            .map((p) => {
              const existing = opcionesMateriales.find((o) => o.value === p);
              return existing ? existing : { value: p, label: p };
            });
          return [...prev, ...toAdd];
        });
      }
    }
  };

  const queriesOperaciones = useQueries({
    queries: materialesSeleccionados.map((mat) => ({
      queryKey: ['operaciones_crudas', centroActual, mat.value],
      queryFn: () => DashboardService.getOperacionesCrudas(mat.value, centroActual),
      staleTime: 5 * 60 * 1000,
    }))
  });

  const isLoading = queriesOperaciones.some((q) => q.isLoading) || loadingCostos;

  const ejecutarSincronizacion = async () => {
    setIsSyncing(true);
    setProgress(5);

    const interval = setInterval(() => {
      setProgress((prev) => prev + ((95 - prev) * 0.15));
    }, 800);

    try {
      const datos = await sincronizarDatosSAP(centroActual);
      clearInterval(interval);
      setProgress(100);
      await queryClient.invalidateQueries();
      showToast(`Sincronización completada. ${datos.total_materiales || 'Varios'} materiales procesados.`, 'success');
    } catch (error) {
      clearInterval(interval);
      setProgress(0);
      showToast('Ocurrió un error al intentar sincronizar con SAP.', 'error');
    } finally {
      setTimeout(() => {
        setIsSyncing(false);
        setProgress(0);
      }, 1000);
    }
  };

  const handleRemoveMaterial = (materialValue) => {
    setMaterialesSeleccionados((prev) => prev.filter((m) => m.value !== materialValue));
  };

  const procesadasOperaciones = useMemo(() => {
    const resultado = [];

    materialesSeleccionados.forEach((mat, index) => {
      const opsRaw = queriesOperaciones[index]?.data?.operaciones || [];
      if (opsRaw.length === 0) return;

      const opsUnicasMap = new Map();
      opsRaw.forEach((op) => {
        if (op.operacion_num) {
          if (!opsUnicasMap.has(op.operacion_num)) {
            opsUnicasMap.set(op.operacion_num, op);
          }
        } else {
          opsUnicasMap.set(Math.random(), op);
        }
      });

      const ops = Array.from(opsUnicasMap.values());

      let versiones = [];
      let versionActual = [];
      let lastOpNum = -1;

      ops.forEach(op => {
        const currentOpNum = Number(op.operacion_num) || 0;
        if (currentOpNum <= lastOpNum && versionActual.length > 0) {
          versiones.push(versionActual);
          versionActual = [];
        }
        versionActual.push(op);
        lastOpNum = currentOpNum;
      });
      if (versionActual.length > 0) {
        versiones.push(versionActual);
      }

      // Todas las operaciones cuentan como proceso; los tiempos simbolicos
      // (<= 0.01) se toman como 0 en los calculos (tiempoReal).
      const opsActivas = versiones.length > 0 ? versiones[0] : [];

      resultado.push({
        id_unico: mat.value,
        material: mat.value,
        label: mat.label,
        ops: opsActivas,
        subName: ''
      });
    });

    return resultado;
  }, [materialesSeleccionados, queriesOperaciones]);

  const datosComparativa = useMemo(() => {
    if (procesadasOperaciones.length === 0) return [];
    const dataGrafica = [];

    const startIdx = filtroOpInicio !== null ? filtroOpInicio : 0;

    procesadasOperaciones.forEach((matObj) => {
      const opsData = matObj.ops;
      if (!opsData || opsData.length === 0) return;

      const currentEndIdx = filtroOpFin !== null ? filtroOpFin : (opsData.length - 1);
      const filteredOps = opsData.filter((_, idx) => idx >= startIdx && idx <= currentEndIdx);

      if (filteredOps.length === 0) return;

      let total_maquina = 0;
      let total_mano_obra = 0;
      let tiempo_maximo_maquina_base = 0;
      let tiene_tiempos_separados = false;

      let max_op_tiempo_crudo = 0;
      let nombre_cuello_botella = 'N/A';
      let total_tiempo_crudo_sum = 0;

      filteredOps.forEach((op) => {
        const t_maq_crudo = tiempoReal(op.tiempo);
        const t_prepa_crudo = tiempoReal(op.tiempo_preparacion);
        const t_mano_crudo = tiempoReal(op.tiempo_mano_obra);

        if (t_prepa_crudo > 0 || t_mano_crudo > 0) tiene_tiempos_separados = true;

        total_tiempo_crudo_sum += (t_maq_crudo + t_prepa_crudo + t_mano_crudo);

        if (t_maq_crudo > tiempo_maximo_maquina_base) {
          tiempo_maximo_maquina_base = t_maq_crudo;
        }

        if (t_maq_crudo > max_op_tiempo_crudo) {
          max_op_tiempo_crudo = t_maq_crudo;
          nombre_cuello_botella = op.descripcion || `Op ${op.operacion_num}`;
        }

        total_maquina += t_maq_crudo;
        total_mano_obra += t_mano_crudo;
      });

      let total_tiempo_crudo_original = 0;
      opsData.forEach((op) => {
        total_tiempo_crudo_original += tiempoReal(op.tiempo) + tiempoReal(op.tiempo_preparacion) + tiempoReal(op.tiempo_mano_obra);
      });

      let fraction = 1;
      if (total_tiempo_crudo_original > 0 && total_tiempo_crudo_sum > 0) {
        fraction = total_tiempo_crudo_sum / total_tiempo_crudo_original;
      } else if (total_tiempo_crudo_sum === 0) {
        fraction = 0;
      }

      const isLegacy = !tiene_tiempos_separados;
      // Personas equivalentes y % mano de obra / automatizacion con la regla de
      // planta (utils/manoObra.js): el VGW03 que mas se repite = 1 persona; las
      // demas operaciones cuentan como fraccion de esa persona.
      // % mano de obra = personas / operaciones del rango.
      const mo = calcularManoObra(filteredOps);

      let c_fijo = 0;
      let c_variable = 0;
      let c_total = 0;

      const costoMat = costosRaw?.find((c) => c.numero_material === matObj.material);
      const nombrePieza = costoMat?.nombre_pieza || matObj.label || '';

      if (costoMat && costoMat.variantes?.length > 0) {
        const variant = costoMat.variantes.find((v) => v.variante === 'Y001') || costoMat.variantes[0];
        if (variant && variant.historial?.length > 0) {
          c_total = Number(variant.historial[0].total_global) || 0;
          c_fijo = Number(variant.historial[0].total_fijado) || 0;
          c_variable = Number(variant.historial[0].total_variable) || 0;
        }
      }

      const c_fijo_scaled = c_fijo * fraction;
      const c_variable_scaled = c_variable * fraction;
      const c_total_scaled = c_total * fraction;

      const bottleneck_hr_pz = max_op_tiempo_crudo / 1000;
      const max_shift_output = bottleneck_hr_pz > 0 ? Math.floor(7.5 / bottleneck_hr_pz) : 0;
      const valor_por_hora = total_tiempo_crudo_sum > 0 ? (c_total_scaled / total_tiempo_crudo_sum) : 0;

      const display_name = matObj.subName 
        ? `${matObj.material} [${matObj.subName}] - ${nombrePieza}`
        : (nombrePieza && nombrePieza !== matObj.material ? `${matObj.material} - ${nombrePieza}` : matObj.material);

      dataGrafica.push({
        material: matObj.material,
        display_name,
        nombre_pieza: nombrePieza,
        pct_automatico: mo.pctAutomatizacion,
        pct_manual: mo.pctManoObra,
        operadores: mo.personas,
        procesos: mo.procesos,
        procesos_con_mano: mo.procesosConMano,
        procesos_automaticos: mo.procesosAutomaticos,
        referencia_mano_obra: mo.referencia,
        veces_referencia: mo.vecesReferencia,
        sin_mano_obra: mo.sinDatos,
        c_fijo_unit: parseFloat(c_fijo_scaled.toFixed(4)),
        c_variable_unit: parseFloat(c_variable_scaled.toFixed(4)),
        c_total_unit: parseFloat(c_total_scaled.toFixed(4)),
        isLegacy,
        nombre_cuello_botella,
        bottleneck_hr_pz,
        max_shift_output,
        valor_por_hora
      });
    });

    return dataGrafica;
  }, [procesadasOperaciones, costosRaw, filtroOpInicio, filtroOpFin]);

  const datosBalanceo = useMemo(() => {
    if (procesadasOperaciones.length === 0) return [];

    let maxOperaciones = 0;
    procesadasOperaciones.forEach((item) => {
      if (item.ops.length > maxOperaciones) maxOperaciones = item.ops.length;
    });

    const balanceoData = [];

    for (let i = 0; i < maxOperaciones; i++) {
      let refOp = null;
      for (const item of procesadasOperaciones) {
        if (item.ops[i]) {
          refOp = item.ops[i];
          break;
        }
      }

      const stepName = refOp ? `${refOp.operacion_num} - ${refOp.descripcion || `Paso ${i + 1}`}` : `Paso ${i + 1}`;
      const stepData = { step: stepName };

      procesadasOperaciones.forEach((item) => {
        if (item.ops[i]) {
          const t_convertido = tiempoReal(item.ops[i].tiempo);
          stepData[item.id_unico] = parseFloat(t_convertido.toFixed(3));
        }
      });

      balanceoData.push(stepData);
    }

    return balanceoData;
  }, [procesadasOperaciones]);

  const opcionesOperaciones = useMemo(() => {
    return datosBalanceo.map((d, index) => ({ value: index, label: d.step }));
  }, [datosBalanceo]);

  const datosBalanceoFiltrado = useMemo(() => {
    const startIdx = filtroOpInicio !== null ? filtroOpInicio : 0;
    const endIdx = filtroOpFin !== null ? filtroOpFin : (datosBalanceo.length > 0 ? datosBalanceo.length - 1 : 0);
    return datosBalanceo.filter((_, idx) => idx >= startIdx && idx <= endIdx);
  }, [datosBalanceo, filtroOpInicio, filtroOpFin]);

  const lblUnidad = 'h';
  const lblBase = '1,000 pzas';

  const fmt = (v, d = 2) => new Intl.NumberFormat('es-MX', { maximumFractionDigits: d }).format(v ?? 0);

  // Detalle del calculo de personas / % mano de obra (mismo para ambas graficas).
  const DetalleManoObra = ({ data }) => (
    <div className="space-y-1.5 text-sm">
      {data.sin_mano_obra ? (
        <p className="text-amber-700 font-semibold">Sin tiempo de mano de obra (VGW03) en SAP para estas operaciones.</p>
      ) : (
        <>
          <p className="flex justify-between gap-6 text-gray-600">
            <span>1 persona =</span>
            <span className="font-semibold text-gray-900">{fmt(data.referencia_mano_obra, 4)} {lblUnidad} MO <span className="text-gray-400 font-normal">(se repite {data.veces_referencia}×)</span></span>
          </p>
          <p className="flex justify-between gap-6 text-gray-600">
            <span>Operaciones con mano de obra:</span>
            <span className="font-semibold text-gray-900">{data.procesos_con_mano}</span>
          </p>
          <p className="flex justify-between gap-6 text-gray-600">
            <span>Operaciones automáticas (MO ≤ 0.01):</span>
            <span className="font-semibold text-gray-900">{data.procesos_automaticos}</span>
          </p>

        </>
      )}
      <p className="flex justify-between gap-6 border-t border-gray-100 pt-1.5 font-bold" style={{ color: COLORS.operadores }}>
        <span>Personas / operaciones:</span>
        <span>{fmt(data.operadores)} / {data.procesos}</span>
      </p>
      <p className="flex justify-between gap-6 font-semibold text-gray-600">
        <span>% Mano de obra:</span><span>{fmt(data.pct_manual, 1)}%</span>
      </p>
      <p className="flex justify-between gap-6 font-semibold" style={{ color: COLORS.automatico }}>
        <span>% Automatización:</span><span>{fmt(data.pct_automatico, 1)}%</span>
      </p>
    </div>
  );

  const PorcentajeTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    return (
      <div className="bg-white border-t-4 border-[#003588] shadow-xl p-4 rounded-none min-w-[320px]">
        <p className="font-black text-[#003588] text-sm border-b border-gray-100 pb-2 mb-3">{label}</p>
        <DetalleManoObra data={payload[0].payload} />
      </div>
    );
  };

  const PersonasTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    return (
      <div className="bg-white border-t-4 border-[#10b981] shadow-xl p-4 rounded-none min-w-[320px]">
        <p className="font-black text-[#003588] text-sm border-b border-gray-100 pb-2 mb-3">{label}</p>
        <DetalleManoObra data={payload[0].payload} />
      </div>
    );
  };

  const BalanceoTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border-t-4 border-[#003588] shadow-xl p-4 rounded-none min-w-[250px]">
          <p className="font-black text-[#003588] text-sm border-b border-gray-100 pb-2 mb-2">{label}</p>
          <div className="space-y-1 text-sm">
            {payload.map((entry, index) => (
              <p key={index} className="flex justify-between gap-4 font-semibold" style={{ color: entry.color }}>
                <span className="truncate pr-4">{entry.name}:</span>
                <span>{entry.value} {lblUnidad}</span>
              </p>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-2 italic">El pico más alto representa el cuello de botella.</p>
        </div>
      );
    }
    return null;
  };

  const CostoTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white border-t-4 border-[#003588] shadow-xl p-4 rounded-none min-w-[200px]">
          <p className="font-black text-[#003588] text-sm border-b border-gray-100 pb-2 mb-2">{label}</p>
          <div className="space-y-1 text-sm mb-1">
            <p className="flex justify-between gap-4 text-gray-600">
              <strong className="text-gray-900">Costo Fijo:</strong>
              <span>{formatMoney(data.c_fijo_unit)}</span>
            </p>
            <p className="flex justify-between gap-4 text-gray-600">
              <strong className="text-gray-900">Costo Variable:</strong>
              <span>{formatMoney(data.c_variable_unit)}</span>
            </p>
            <p className="flex justify-between gap-4 font-bold text-[#003588] pt-1 border-t border-gray-100">
              <strong className="text-gray-900">Total PCB Completa (Y001):</strong>
              <span>{formatMoney(data.c_total_unit)}</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-full flex flex-col bg-gray-50 overflow-hidden relative">
      {isSyncing && (
        <div className="absolute top-0 left-0 w-full h-1 bg-gray-200 z-[100] overflow-hidden">
          <div className="h-full bg-[#003588] transition-all duration-300 ease-out relative" style={{ width: `${progress}%` }}>
            <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
          </div>
        </div>
      )}

      <div className="bg-white border-b border-gray-200 px-6 py-4 shrink-0 flex flex-col md:flex-row md:items-center justify-between shadow-sm z-30 gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="hidden sm:flex items-center gap-3 mr-2">
            <GitCompare className="h-6 w-6 text-[#003588]" />
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 leading-none">Comparativa de Líneas</h2>
          </div>

          <button
            onClick={ejecutarSincronizacion}
            disabled={isSyncing}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${
              isSyncing ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{isSyncing ? `Sincronizando... ${Math.round(progress)}%` : 'Sincronizar SAP'}</span>
          </button>

          <button
            onClick={() => setIsNuevoMaterialOpen(true)}
            disabled={!centroActual || isSyncing}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide border rounded-none transition-colors shadow-sm focus:outline-none ${
              !centroActual || isSyncing ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-[#003588] border-[#003588] hover:bg-blue-50'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Importar Material</span>
          </button>
        </div>

        <div className="w-full md:w-[450px]" onPaste={handlePaste}>
          <CustomSelect
            options={opcionesMateriales}
            value={materialesSeleccionados}
            onChange={(opts) => setMaterialesSeleccionados(opts || [])}
            placeholder="Buscar o pegar múltiples (espacios)..."
            isMulti={true}
            isClearable={true}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-6 scroll-smooth">
        <div className="bg-white border-b border-gray-200 p-6 shadow-sm mb-6 relative z-20">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-[#003588]" /> Parámetros de Filtrado Avanzado
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 items-end">
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Mes Exacto</label>
              <CustomSelect
                options={opcionesMeses}
                value={opcionesMeses.find((o) => o.value === mesExacto) || null}
                onChange={(opt) => setMesExacto(opt?.value ?? null)}
                placeholder="Todos..."
                isDisabled={opcionesMeses.length === 0}
                isClearable
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Inicio</label>
              <input
                type="date"
                value={fechaInicio}
                onChange={(e) => setFechaInicio(e.target.value)}
                className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Fecha Fin</label>
              <input
                type="date"
                value={fechaFin}
                onChange={(e) => setFechaFin(e.target.value)}
                className="w-full rounded-none border border-gray-300 bg-white min-h-[38px] px-3 py-1 text-sm outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors"
              />
            </div>
          </div>
        </div>

        <div className="px-6 mb-6">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-[#003588]" /> Líneas en Análisis y Diagnóstico
          </p>

          {materialesSeleccionados.length === 0 ? (
            <div className="text-sm text-gray-400 italic py-10 text-center border border-dashed border-gray-300 rounded-none bg-white">
              Aún no hay líneas en análisis. Usa el buscador superior para agregar números de parte.
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {materialesSeleccionados.map((mat, index) => {
                const dataMat = datosComparativa.find((d) => d.material === mat.value);
                const isLegacy = dataMat ? dataMat.isLegacy : false;
                const costoMat = costosRaw?.find((c) => c.numero_material === mat.value);
                const nombreRealPieza = dataMat?.nombre_pieza || costoMat?.nombre_pieza || 'LÍNEA DE PRODUCCIÓN';
                
                // Determinamos el estado individual del card
                const queryInfo = queriesOperaciones[index];
                const isCardLoading = queryInfo?.isLoading || loadingCostos;
                const hasError = queryInfo?.isError;

                return (
                  <div key={mat.value} className="bg-white border border-gray-200 shadow-sm relative overflow-hidden group hover:border-[#003588] transition-colors rounded-none flex flex-col">
                    <div className="flex items-start justify-between border-b border-gray-100 p-4 pl-5 bg-gray-100">
                      <div className="flex-1 min-w-0 pr-4">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="text-xl font-black text-[#003588] leading-none truncate" title={mat.value}>
                            {mat.value}
                          </h4>
                          {isLegacy && (
                            <AlertTriangle className="w-4 h-4 text-orange-500 shrink-0" title="Línea Caja Negra (No MES Ready)" />
                          )}
                        </div>
                        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider truncate" title={nombreRealPieza}>
                          {nombreRealPieza}
                        </p>
                      </div>

                      <button
                        onClick={() => handleRemoveMaterial(mat.value)}
                        className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 border border-transparent hover:border-red-100 transition-all rounded-sm focus:outline-none shrink-0"
                        title="Eliminar de la comparativa"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="p-5 pl-5 bg-white flex-1 space-y-5">
                      {isCardLoading ? (
                        <div className="flex flex-col items-center justify-center h-full text-[#003588] space-y-2 py-4">
                          <Loader2 className="w-6 h-6 animate-spin opacity-80" />
                          <span className="text-xs font-bold uppercase tracking-wider opacity-80">Analizando SAP...</span>
                        </div>
                      ) : hasError ? (
                        <div className="flex flex-col items-center justify-center h-full text-red-500 space-y-2 py-4 text-center">
                          <AlertOctagon className="w-6 h-6 opacity-80" />
                          <span className="text-xs font-bold uppercase tracking-wider opacity-80">Error de conexión</span>
                        </div>
                      ) : dataMat ? (
                        <>
                          <div className="flex items-start gap-3">
                            <div className="p-2 bg-blue-50 text-[#003588] border border-blue-100 rounded-sm shrink-0">
                              <Timer className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Capacidad Teórica (Turno 8h)</p>
                              <p className="text-xl font-black text-gray-900 leading-tight">
                                {new Intl.NumberFormat('es-MX').format(dataMat.max_shift_output)} <span className="text-sm font-bold text-gray-400">pzas</span>
                              </p>
                            </div>
                          </div>

                          <div className="w-full h-px bg-gray-100"></div>

                          <div className="flex items-start gap-3">
                            <div className="p-2 bg-red-50 text-red-600 border border-red-100 rounded-sm shrink-0">
                              <AlertOctagon className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Valor de Producción detenida</p>
                              <p className="text-xl font-black text-gray-900 leading-tight">
                                {formatMoney(dataMat.valor_por_hora)} <span className="text-sm font-bold text-gray-500">/ hora</span>
                              </p>
                            </div>
                          </div>
                        </>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full text-gray-400 space-y-2 py-4 text-center">
                          <Activity className="w-6 h-6 opacity-50" />
                          <span className="text-xs font-bold uppercase tracking-wider opacity-80">Sin Operaciones</span>
                          <span className="text-[10px] px-2 leading-tight">No se encontró una hoja de ruta válida.</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* El loader general de la parte inferior se mantiene sutilmente para tablas de abajo */}
        {isLoading && (
          <div className="flex justify-center py-10">
            <Loader2 className="h-6 w-6 text-gray-300 animate-spin" />
          </div>
        )}

        {!isLoading && datosComparativa.length > 0 && (
          <div className="px-6 space-y-6">
            <GraficaCard titulo="Balanceo de Línea (Tiempo de Máquina por Operación)" badge="HRS">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={datosBalanceoFiltrado} margin={{ top: 20, right: 30, left: 20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis
                    dataKey="step"
                    tick={{ fontSize: 11, fill: '#6B7280' }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(val) => {
                      if (!val) return '';
                      const parts = val.split(' - ');
                      const desc = parts.length > 1 ? parts[1] : val;
                      return desc.length > 25 ? `${desc.substring(0, 25)}...` : desc;
                    }}
                    angle={-25}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                  <Tooltip content={<BalanceoTooltip />} cursor={{ stroke: '#E5E7EB', strokeWidth: 2 }} />
                  <Legend wrapperStyle={{ paddingTop: '20px', fontSize: '12px', fontWeight: 'bold' }} />

                  {materialesSeleccionados.map((mat, idx) => {
                    const dataMat = datosComparativa.find((d) => d.material === mat.value);
                    const displayName = dataMat ? dataMat.display_name : mat.value;
                    return (
                      <Line
                        key={mat.value}
                        type="monotone"
                        dataKey={mat.value}
                        name={displayName}
                        stroke={LINE_COLORS[idx % LINE_COLORS.length]}
                        strokeWidth={3}
                        dot={{ r: 4, strokeWidth: 2 }}
                        activeDot={{ r: 6 }}
                      />
                    );
                  })}
                </LineChart>
              </ResponsiveContainer>
            </GraficaCard>

            <div className="bg-white border border-gray-200 p-4 shadow-sm relative z-10 flex flex-col md:flex-row md:items-center gap-4">
               <div className="flex items-center gap-2 text-[#003588] shrink-0">
                 <Filter className="w-5 h-5" />
                 <span className="font-bold text-sm uppercase tracking-wider">Filtrar por Estaciones:</span>
               </div>
               <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                   <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Estación Inicial</label>
                   <CustomSelect
                     options={opcionesOperaciones}
                     value={opcionesOperaciones.find(o => o.value === filtroOpInicio) || null}
                     onChange={(opt) => {
                       setFiltroOpInicio(opt ? opt.value : null);
                       if (opt && filtroOpFin !== null && opt.value > filtroOpFin) {
                         setFiltroOpFin(opt.value);
                       }
                     }}
                     placeholder="Desde el inicio..."
                     isClearable
                   />
                 </div>
                 <div>
                   <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">Estación Final</label>
                   <CustomSelect
                     options={opcionesOperaciones}
                     value={opcionesOperaciones.find(o => o.value === filtroOpFin) || null}
                     onChange={(opt) => {
                       setFiltroOpFin(opt ? opt.value : null);
                       if (opt && filtroOpInicio !== null && opt.value < filtroOpInicio) {
                         setFiltroOpInicio(opt.value);
                       }
                     }}
                     placeholder="Hasta el final..."
                     isClearable
                   />
                 </div>
               </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <GraficaCard titulo="Automatización vs Mano de Obra (%)" badge="%">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={datosComparativa} layout="vertical" margin={{ top: 10, right: 30, left: -10, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E5E7EB" />
                    <XAxis type="number" domain={[0, 100]} hide />
                    <YAxis
                      dataKey="display_name"
                      type="category"
                      axisLine={false}
                      tickLine={false}
                      width={120}
                      tick={(props) => <CustomYAxisTick {...props} data={datosComparativa} />}
                    />
                    <Tooltip content={<PorcentajeTooltip />} cursor={{ fill: '#F3F4F6' }} />
                    <Legend wrapperStyle={{ paddingTop: '10px', fontSize: '12px', fontWeight: 'bold' }} />
                    <Bar dataKey="pct_automatico" name="% Automatización" stackId="a" fill={COLORS.automatico} barSize={28}>
                      <LabelList
                        dataKey="pct_automatico"
                        position="inside"
                        formatter={(val) => (val >= 1 ? `${val}%` : '')}
                        fill="#ffffff"
                        fontSize={12}
                        fontWeight="bold"
                      />
                    </Bar>
                    <Bar dataKey="pct_manual" name="% Mano de Obra" stackId="a" fill={COLORS.manual} radius={[0, 4, 4, 0]}>
                      <LabelList
                        dataKey="pct_manual"
                        position="inside"
                        formatter={(val) => (val >= 1 ? `${val}%` : '')}
                        fill="#ffffff"
                        fontSize={12}
                        fontWeight="bold"
                      />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </GraficaCard>

              <GraficaCard titulo="Personas Equivalentes (1 persona = VGW03 más repetido)" badge="FTE">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={datosComparativa} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                    <XAxis
                      dataKey="display_name"
                      axisLine={false}
                      tickLine={false}
                      height={90}
                      interval={0}
                      tick={<CustomXAxisTick />}
                    />
                    <YAxis tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<PersonasTooltip />} cursor={{ fill: '#F3F4F6' }} />
                    <Bar dataKey="operadores" name="Personas Equivalentes" fill={COLORS.operadores} barSize={45} radius={[4, 4, 0, 0]}>
                      <LabelList dataKey="operadores" position="top" fill="#4B5563" fontSize={12} fontWeight="bold" />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </GraficaCard>

              <div className="xl:col-span-2">
                <GraficaCard titulo="Costo Fijo (Depreciación) vs Costo Variable" badge="MXN">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={datosComparativa} margin={{ top: 10, right: 30, left: 20, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                      <XAxis
                        dataKey="display_name"
                        axisLine={false}
                        tickLine={false}
                        height={90}
                        interval={0}
                        tick={<CustomXAxisTick />}
                      />
                      <YAxis
                        tick={{ fontSize: 12, fill: '#6B7280' }}
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(val) => formatMoney(val)}
                      />
                      <Tooltip content={<CostoTooltip />} cursor={{ fill: '#F3F4F6' }} />
                      <Legend wrapperStyle={{ paddingTop: '20px', fontSize: '12px', fontWeight: 'bold' }} />
                      <Bar dataKey="c_fijo_unit" name="Costo Fijo" stackId="a" fill={COLORS.fijo} barSize={60} />
                      <Bar dataKey="c_variable_unit" name="Costo Variable" stackId="a" fill={COLORS.variable} radius={[4, 4, 0, 0]} />
                      <Line type="monotone" dataKey="c_total_unit" name="Costo Total" stroke={COLORS.automatico} strokeWidth={3} dot={{ r: 5 }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </GraficaCard>
              </div>
            </div>
          </div>
        )}
      </div>

      <NuevoMaterialModal
        isOpen={isNuevoMaterialOpen}
        onClose={() => setIsNuevoMaterialOpen(false)}
        centroActual={centroActual}
      />
    </div>
  );
}