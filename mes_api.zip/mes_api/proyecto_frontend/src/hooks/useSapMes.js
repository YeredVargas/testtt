// src/hooks/useSapMes.js
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { SapMesService } from '../services/sapMes/SapMesService'

export const useEstadoMes = () =>
  useQuery({
    queryKey: ['sap-mes-estado'],
    queryFn: SapMesService.estadoMes,
    staleTime: 60 * 1000,
  })

export const useEstadoCatalogo = () =>
  useQuery({
    queryKey: ['sap-mes-catalogo'],
    queryFn: SapMesService.estadoCatalogo,
    staleTime: 60 * 1000,
  })

export const useSincronizarCatalogo = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: SapMesService.sincronizarCatalogo,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sap-mes-catalogo'] })
      qc.invalidateQueries({ queryKey: ['sap-mes-comparativa'] })
    },
  })
}

export const useMaterialesSapMes = (centro) =>
  useQuery({
    queryKey: ['sap-mes-materiales', centro],
    queryFn: () => SapMesService.getMateriales(centro),
    staleTime: 5 * 60 * 1000,
  })

export const useVersionesSap = (material, centro) =>
  useQuery({
    queryKey: ['sap-mes-versiones', material, centro],
    queryFn: () => SapMesService.getVersiones(material, centro),
    enabled: !!material,
    staleTime: 5 * 60 * 1000,
  })

// `params` son los filtros YA APLICADOS (boton "Comparar"), no el borrador:
// cada consulta va a HANA, asi que no se dispara con cada cambio de filtro.
export const useComparativaSapMes = (params) =>
  useQuery({
    queryKey: ['sap-mes-comparativa', params],
    queryFn: () => SapMesService.getComparativa(params),
    enabled: !!params?.material,
    // Al cambiar un filtro (p. ej. el tiempo SAP) se conserva la tabla anterior
    // atenuada mientras llega la nueva, en lugar de vaciar la pantalla.
    placeholderData: (anterior) => anterior,
    staleTime: 5 * 60 * 1000,
    retry: false,
  })

export const useOperacionesMes = (material, habilitado) =>
  useQuery({
    queryKey: ['sap-mes-operaciones-mes', material],
    queryFn: () => SapMesService.getOperacionesMes(material),
    enabled: !!material && !!habilitado,
    staleTime: 10 * 60 * 1000,
    retry: false,
  })

export const useReglasSapMes = (centro, material) =>
  useQuery({
    queryKey: ['sap-mes-reglas', centro, material],
    queryFn: () => SapMesService.getReglas(centro, material),
    enabled: !!material,
    staleTime: 60 * 1000,
  })

export const useGuardarRegla = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, regla }) => (id ? SapMesService.actualizarRegla(id, regla) : SapMesService.crearRegla(regla)),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sap-mes-reglas'] })
      qc.invalidateQueries({ queryKey: ['sap-mes-comparativa'] })
      qc.invalidateQueries({ queryKey: ['sap-mes-materiales'] })
    },
  })
}

export const useEliminarRegla = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id) => SapMesService.eliminarRegla(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sap-mes-reglas'] })
      qc.invalidateQueries({ queryKey: ['sap-mes-comparativa'] })
      qc.invalidateQueries({ queryKey: ['sap-mes-materiales'] })
    },
  })
}

// ---- Grupos de procesos ----
// Al guardar o borrar un grupo se rearma la comparativa: el backend recalcula
// el resumen por grupo. La consulta a MES sale de su cache (5 min), no de HANA.
export const useGuardarGrupo = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, grupo }) => (id ? SapMesService.actualizarGrupo(id, grupo) : SapMesService.crearGrupo(grupo)),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sap-mes-grupos'] })
      qc.invalidateQueries({ queryKey: ['sap-mes-comparativa'] })
    },
  })
}

export const useEliminarGrupo = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id) => SapMesService.eliminarGrupo(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sap-mes-grupos'] })
      qc.invalidateQueries({ queryKey: ['sap-mes-comparativa'] })
    },
  })
}
