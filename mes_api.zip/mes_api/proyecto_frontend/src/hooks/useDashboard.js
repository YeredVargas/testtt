// src/hooks/useDashboard.js
import { useQuery } from '@tanstack/react-query'
import { DashboardService } from '../services/dashboard/DashboardService'

export const useSecciones = (numero_material = null, centro = "0094") =>
  useQuery({
    queryKey: ['dashboard-secciones', numero_material, centro], 
    queryFn:  () => DashboardService.getSecciones(numero_material, centro),
    staleTime: 5 * 60 * 1000,
  })

// --- ACTUALIZADO PARA RECIBIR EL OBJETO DE PARÁMETROS ---
export const useDashboardSeccion = (params) =>
  useQuery({
    queryKey: ['dashboard', params], // Si cambia la página o un filtro, se recarga
    queryFn:  () => DashboardService.getBySeccion(params),
    enabled:  !!params.seccion && !!params.centro,
    staleTime: 2 * 60 * 1000,
  })