import { useQuery, useMutation } from '@tanstack/react-query';
import { CostosService } from '../services/costos/CostosService';

export const useCostos = (centro) => {
  return useQuery({
    queryKey: ['costos_ck13n', centro],
    queryFn: () => CostosService.getAll(centro),
    staleTime: 5 * 60 * 1000,
    retry: (failureCount, error) => {
      if (error.isNetworkError) return false;
      return failureCount < 2;
    }
  });
};

export const useCostosDetalle = (material, centro, fecha_validez, variante) => {
  return useQuery({
    queryKey: ['costos_detalle', material, centro, fecha_validez, variante],
    queryFn: () => CostosService.getDetalle(material, fecha_validez, centro, variante),
    enabled: !!material && !!centro && !!fecha_validez && !!variante,
    staleTime: 10 * 60 * 1000
  });
};

export const useCostosProduccion = (material, centro, fecha_validez, variante, enabled) => {
  return useQuery({
    queryKey: ['costos_produccion', material, centro, fecha_validez, variante],
    queryFn: () => CostosService.getDetalleProduccion(material, fecha_validez, centro, variante),
    enabled: enabled && !!material && !!centro && !!fecha_validez && !!variante,
    staleTime: 10 * 60 * 1000
  });
};

export const useSincronizarCostos = () => {
  return useMutation({
    mutationFn: (centro) => CostosService.sincronizarTodos(centro),
  });
};

export const useSyncStatus = (jobId) => {
  return useQuery({
    queryKey: ['sync_status', jobId],
    queryFn: () => CostosService.getSyncStatus(jobId),
    enabled: !!jobId,
    refetchInterval: (query) => {
      const status = query.state?.data?.status;
      if (status === 'completed' || status === 'failed') return false;
      return 2000;
    },
  });
};