// src/hooks/useGraficas.js
import { useQuery } from '@tanstack/react-query'
import { GraficasService } from '../services/graficas/GraficasService'

export const useFiltrosGraficas = ({ proceso, numero_material, mes, centro } = {}) =>
  useQuery({
    queryKey: ['graficas-filtros', proceso, numero_material, mes, centro], // <-- Añadido
    queryFn:  () => GraficasService.getFiltros({ proceso, numero_material, mes, centro }),
    staleTime: 3 * 60 * 1000,
  })

export const useDatosGraficas = ({ numero_material, proceso, mes, centro }) =>
  useQuery({
    queryKey: ['graficas-datos', numero_material, proceso, mes, centro], // <-- Añadido
    queryFn:  () => GraficasService.getDatos({ numero_material, proceso, mes, centro }),
    enabled:  !!numero_material,
    staleTime: 2 * 60 * 1000,
  })