// src/services/sapMes/SapMesService.js
// Apartado SAP/MES. Todo pasa por el backend principal (/api/sap-mes); el
// backend es quien consulta la API de MES, el navegador nunca la llama directo.
import client from '../../api/client'
import sapClient from '../../api/sapClient'

const basePath = '/sap-mes'
// La comparativa consulta HANA (eventos MES): puede tardar mas que el timeout
// general de 10 s del cliente.
const TIMEOUT_MES_MS = 180000

const limpiar = (params) =>
  Object.fromEntries(Object.entries(params).filter(([, v]) => v !== null && v !== undefined && v !== ''))

export const SapMesService = {
  estadoMes: async () => (await client.get(`${basePath}/mes/estado`)).data,

  // Catalogo T435T: el estado se lee del backend principal; la sincronizacion la
  // hace la API de SAP (es la unica con conexion RFC).
  estadoCatalogo: async () => (await client.get(`${basePath}/claves-modelo/estado`)).data,

  sincronizarCatalogo: async () =>
    (await sapClient.post('/claves-modelo/sincronizar', {}, { timeout: 120000 })).data,

  getMateriales: async (centro) =>
    (await client.get(`${basePath}/materiales`, { params: { centro } })).data,

  getVersiones: async (material, centro) =>
    (await client.get(`${basePath}/${encodeURIComponent(material)}/versiones`, { params: { centro } })).data,

  getComparativa: async ({ material, ...params }) =>
    (await client.get(`${basePath}/${encodeURIComponent(material)}/comparativa`, {
      params: limpiar(params),
      timeout: TIMEOUT_MES_MS,
    })).data,

  getOperacionesMes: async (material, dias_atras = 60) =>
    (await client.get(`${basePath}/${encodeURIComponent(material)}/mes-operaciones`, {
      params: { dias_atras },
      timeout: TIMEOUT_MES_MS,
    })).data,

  getReglas: async (centro, numero_material) =>
    (await client.get(`${basePath}/reglas`, { params: limpiar({ centro, numero_material }) })).data,

  crearRegla: async (regla) => (await client.post(`${basePath}/reglas`, regla)).data,

  actualizarRegla: async (id, regla) => (await client.put(`${basePath}/reglas/${id}`, regla)).data,

  // Grupos de procesos (rangos de operaciones con nombre, por material)
  getGrupos: async (centro, numero_material) =>
    (await client.get(`${basePath}/grupos`, { params: { centro, numero_material } })).data,

  crearGrupo: async (grupo) => (await client.post(`${basePath}/grupos`, grupo)).data,

  actualizarGrupo: async (id, grupo) => (await client.put(`${basePath}/grupos/${id}`, grupo)).data,

  eliminarGrupo: async (id) => {
    await client.delete(`${basePath}/grupos/${id}`)
  },

  eliminarRegla: async (id) => {
    await client.delete(`${basePath}/reglas/${id}`)
  },
}
