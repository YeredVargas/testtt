import client from '../../api/client'
const basePath = '/graficas'

export const GraficasService = {
  getFiltros: async ({ proceso = null, numero_material = null, mes = null, centro = "0094" } = {}) => {
    const params = new URLSearchParams()
    if (proceso) params.append('proceso', proceso)
    if (numero_material) params.append('numero_material', numero_material)
    if (mes) params.append('mes', mes)
    params.append('centro', centro) // <-- Añadido
    
    const res = await client.get(`${basePath}/filtros?${params.toString()}`)
    return res.data
  },
  
  getDatos: async ({ numero_material, proceso = null, mes = null, centro = "0094" }) => {
    const params = new URLSearchParams()
    params.append('numero_material', numero_material)
    if (proceso) params.append('proceso', proceso)
    if (mes) params.append('mes', mes)
    params.append('centro', centro) // <-- Añadido
    
    const res = await client.get(`${basePath}/datos?${params.toString()}`)
    return res.data
  },
}