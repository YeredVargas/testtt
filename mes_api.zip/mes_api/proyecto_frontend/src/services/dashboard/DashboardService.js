// src/services/dashboard/DashboardService.js
import client from '../../api/client'

const basePath = '/dashboard'

export const DashboardService = {
  getSecciones: async (numero_material = null, centro = "0094") => {
    const params = new URLSearchParams()
    if (numero_material) params.append('numero_material', numero_material)
    params.append('centro', centro)
    const res = await client.get(`${basePath}/secciones?${params.toString()}`)
    return res.data
  },
  
  // --- ACTUALIZADO PARA SERVER-SIDE PAGINATION ---
  getBySeccion: async ({ 
    seccion, centro = "0094", page = 1, limit = 5, 
    numero_material, proyecto, fecha_inicio, fecha_fin, mes_exacto 
  }) => {
    const params = new URLSearchParams()
    params.append('centro', centro)
    params.append('page', page)
    params.append('limit', limit)
    
    if (numero_material) params.append('numero_material', numero_material)
    if (proyecto) params.append('proyecto', proyecto)
    if (fecha_inicio) params.append('fecha_inicio', fecha_inicio)
    if (fecha_fin) params.append('fecha_fin', fecha_fin)
    if (mes_exacto) params.append('mes_exacto', mes_exacto)

    const res = await client.get(`${basePath}/${encodeURIComponent(seccion)}?${params.toString()}`)
    return res.data
  },

  // --- NUEVO ENDPOINT PARA AUDITORÍA CRUDAS ---
  getOperacionesCrudas: async (numero_material, centro = '0094') => {
    const res = await client.get(`${basePath}/${numero_material}/operaciones_crudas?centro=${centro}`);
    return res.data;
  }
}