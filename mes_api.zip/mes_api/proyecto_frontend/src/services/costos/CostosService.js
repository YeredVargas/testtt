import client from '../../api/client';
import sapClient from '../../api/sapClient';

export const CostosService = {
  getAll: async (centro = "0094") => {
    const response = await client.get(`/costos?centro=${centro}`);
    return response.data;
  },
  
  getDetalle: async (material, fecha_validez, centro = "0094", variante = "Y001") => {
    const response = await client.get(`/costos/${material}/elementos/${fecha_validez}?centro=${centro}&variante=${variante}`);
    return response.data;
  },

  getDetalleProduccion: async (material, fecha_validez, centro = "0094", variante = "Y001") => {
    const response = await client.get(`/costos/${material}/produccion/${fecha_validez}?centro=${centro}&variante=${variante}`);
    return response.data;
  },

  sincronizarTodos: async (centro = "0094") => {
    const response = await sapClient.post(`/costos/sincronizar-todos?centro=${centro}`);
    return response.data;
  },

  sincronizarMaterial: async (material, centro = "0094") => {
    const response = await sapClient.post(`/costos/sincronizar-material/${material}?centro=${centro}`, {}, { timeout: 180000 });
    return response.data;
  },
  
  getSyncStatus: async (jobId) => {
    const response = await sapClient.get(`/sincronizar-bg/status/${jobId}`);
    return response.data;
  }
};