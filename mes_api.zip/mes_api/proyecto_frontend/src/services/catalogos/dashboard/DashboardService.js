// src/services/catalogos/dashboard/DashboardService.js
//
// ARCHIVO OBSOLETO. Era una copia vieja de src/services/dashboard/DashboardService.js
// con basePath = '/api/dashboard'. Como el cliente axios ya tiene baseURL '/api',
// cualquier llamada desde aqui pegaba a '/api/api/dashboard' y devolvia 404.
//
// Ningun componente lo importa. Se deja re-exportando el servicio correcto para
// que, si alguien lo importa por error, funcione en lugar de romperse.
// Puedes borrarlo cuando confirmes que nadie lo usa.
export { DashboardService } from '../../dashboard/DashboardService'
export { DashboardService as default } from '../../dashboard/DashboardService'
