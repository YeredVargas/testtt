// src/services/SapService.js

// URL resuelta en src/api/sapConfig.js (VITE_SAP_API_URL o mismo host:5158).
import { SAP_API_URL } from '../api/sapConfig';

// 1. Sincronización general por centro
export const sincronizarDatosSAP = async (centro = "0094") => {
    const response = await fetch(`${SAP_API_URL}/tiempo_operacion/sincronizar/todo_dinamico?centro=${centro}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    
    if (!response.ok) {
        throw new Error(`Error en el servidor: ${response.status}`);
    }
    
    return await response.json();
};

// 2. NUEVO: Agregar un material individual por centro
export const agregarNuevoMaterial = async (material, centro = "0094") => {
    const response = await fetch(`${SAP_API_URL}/tiempo_operacion/nuevo_material/${material}?centro=${centro}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    });
    
    if (!response.ok) {
        throw new Error(`Error al agregar material: ${response.status}`);
    }
    
    return await response.json();
};