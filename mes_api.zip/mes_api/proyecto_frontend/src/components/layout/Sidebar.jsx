﻿// src/components/layout/Sidebar.jsx
import React, { useState } from 'react'
import {
  LayoutDashboard, BarChart2, Folder,
  ChevronDown, ChevronRight, FileText, LogOut, DollarSign, Clock, GitCompare, Scale
} from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const Sidebar = () => {
  const [isCatalogOpen, setIsCatalogOpen] = useState(false)
  const { user, logout } = useAuth()
  const location = useLocation()

  const isActive = (path) => location.pathname.startsWith(path)
  const linkCls = (path) =>
    `flex items-center px-3 py-2 text-sm font-medium rounded-none transition-colors ${
      isActive(path)
        ? 'bg-gray-100 text-[#003588]'
        : 'text-gray-700 hover:bg-gray-100'
    }`

  return (
    <aside className="w-64 h-full flex flex-col bg-white border-r border-gray-200 shrink-0">
      <div className="h-16 flex items-center justify-center px-6 border-b border-gray-200 shrink-0">
        <img src="/KOSTAL_LOGO.png" alt="Kostal Logo" className="h-8 object-contain" />
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        <Link to="/app/dashboard" className={linkCls('/app/dashboard')}>
          <LayoutDashboard className="mr-3 h-5 w-5 text-gray-500" />
          Dashboard
        </Link>
        <Link to="/app/graficas" className={linkCls('/app/graficas')}>
          <BarChart2 className="mr-3 h-5 w-5 text-gray-500" />
          Gráficas
        </Link>
        <Link to="/app/costos" className={linkCls('/app/costos')}>
          <DollarSign className="mr-3 h-5 w-5 text-gray-500" />
          Costos SAP
        </Link>
        {/* APARTADO: TIEMPOS POR PROCESO */}
        <Link to="/app/tiempos" className={linkCls('/app/tiempos')}>
          <Clock className="mr-3 h-5 w-5 text-gray-500" />
          Tiempos por Proceso
        </Link>
        {/* NUEVO APARTADO: COMPARATIVA */}
        <Link to="/app/comparativa" className={linkCls('/app/comparativa')}>
          <GitCompare className="mr-3 h-5 w-5 text-gray-500" />
          Comparativa
        </Link>
        {/* APARTADO: SAP vs MES (tiempo de operacion vs tiempo ciclo real) */}
        <Link to="/app/sap-mes" className={linkCls('/app/sap-mes')}>
          <Scale className="mr-3 h-5 w-5 text-gray-500" />
          SAP / MES
        </Link>
      </nav>

      <div className="border-t border-gray-200 p-4 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center min-w-0">
            {user ? (
              <>
                <div className="h-8 w-8 rounded-none bg-[#003588] text-white flex items-center justify-center text-xs font-bold shrink-0">
                  {`${(user.nombre || '').charAt(0)}${(user.apellido_paterno || '').charAt(0)}`.toUpperCase() || 'UD'}
                </div>
                <div className="ml-3 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {`${user.nombre || ''} ${user.apellido_paterno || ''}`.trim() || 'Usuario Demo'}
                  </p>
                  <p className="text-xs font-medium text-gray-500 truncate">{user.rol || ''}</p>
                </div>
              </>
            ) : (
              <>
                <div className="h-8 w-8 rounded-none bg-[#003588] text-white flex items-center justify-center text-xs font-bold shrink-0">UD</div>
                <div className="ml-3 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">Usuario</p>
                  <p className="text-xs font-medium text-gray-500 truncate">Invitado</p>
                </div>
              </>
            )}
          </div>
          <button
            onClick={logout}
            title="Cerrar sesión"
            className="p-1.5 text-gray-400 hover:text-[#003588] hover:bg-blue-50 transition-colors rounded-none focus:outline-none shrink-0"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </aside>
  )
}

export default Sidebar