// src/components/layout/AppLayout.jsx
import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';


const AppLayout = () => {
  // Aquí declaramos el estado que dominará a toda la aplicación
  const [centroActual, setCentroActual] = useState('0094');

  return (
    <div className="h-screen overflow-hidden bg-gray-50 flex text-gray-900 antialiased">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Pasamos el estado y la función al Header */}
        <Header 
          title="Dashboard" 
          centroActual={centroActual} 
          setCentroActual={setCentroActual} 
        />
        <main className="flex-1 overflow-y-auto">
          {/* Pasamos el estado al resto de las pantallas */}
          <Outlet context={{ centroActual }} />
        </main>
      </div>
    </div>
  );
};

export default AppLayout;