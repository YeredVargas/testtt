// src/components/layout/Header.jsx
import React from 'react';
import { Building2 } from 'lucide-react';
import CustomSelect from '../ui/CustomSelect'; // Ajusta la ruta si es necesario

const opcionesCentros = [
  { value: '0094', label: '0094 (KEMM)' },
  { value: '0008', label: '0008 (KOMEX 1 )' }
];

const Header = ({ title, centroActual, setCentroActual }) => {
  // Busca el objeto completo para pasarlo al CustomSelect
  const valorSeleccionado = opcionesCentros.find(opt => opt.value === centroActual) || opcionesCentros[0];

  return (
    <header className="h-16 bg-white border-b border-gray-200 px-6 shrink-0 flex items-center justify-between">
      <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
      
      {/* Selector de Centro Global */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5">
            <Building2 className="w-5 h-5 text-[#003588]" />
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Centro:</span>
        </div>
        <div className="w-56">
          <CustomSelect 
            options={opcionesCentros} 
            value={valorSeleccionado} 
            onChange={(opt) => {
                if (opt) setCentroActual(opt.value);
            }} 
            isClearable={false}
            isSearchable={false} /* Se desactiva la búsqueda para que actúe como un menú desplegable clásico */
            placeholder="Seleccionar..." 
          />
        </div>
      </div>
    </header>
  );
};

export default Header;