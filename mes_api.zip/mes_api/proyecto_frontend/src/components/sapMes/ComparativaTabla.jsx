// src/components/sapMes/ComparativaTabla.jsx
// Tabla principal: una fila por operacion SAP; al expandir se ven las
// estaciones MES individuales con su distribucion.
import React, { Fragment, useState } from 'react'
import { AlertTriangle, ChevronDown, ChevronRight, Pencil, Plus } from 'lucide-react'
import EstadoChip from './EstadoChip'
import { etiquetaCampoTiempo, num, ORIGEN_EQUIPOS, ORIGEN_REGLA } from '../../utils/sapMesFormato'

const Th = ({ children, className = '', ...rest }) => (
  <th className={`px-3 py-2 text-[11px] font-bold text-gray-500 uppercase tracking-wider whitespace-nowrap ${className}`} {...rest}>
    {children}
  </th>
)

const Td = ({ children, className = "" }) => <td className={`px-2.5 py-2.5 align-top ${className}`}>{children}</td>

const ValorMes = ({ valor, n }) =>
  valor === null || valor === undefined ? (
    <span className="text-gray-400">—</span>
  ) : (
    <span>
      <span className="font-semibold text-gray-900">{num(valor, 1)}</span>
      <span className="block text-[11px] text-gray-500">n = {n?.toLocaleString('es-MX')}</span>
    </span>
  )

const FilaEstaciones = ({ op, estadistico, divisorSalida = 1 }) => (
  <tr className="bg-gray-50/70">
    <td />
    <td colSpan={10} className="px-3 pb-3 pt-1">
      <div className="border border-gray-200 bg-white">
        <table className="w-full text-xs">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <Th className="text-left">Estación MES</Th>
              <Th className="text-right">Proceso {estadistico}</Th>
              <Th className="text-right">P25 – P75</Th>
              <Th className="text-right">n</Th>
              <Th className="text-right">Excl.</Th>
              <Th className="text-right">Recursos</Th>
              <Th className="text-right">Salida {estadistico}{divisorSalida !== 1 ? ` ÷ ${divisorSalida}` : ''}</Th>
              <Th className="text-right">P25 – P75</Th>
              <Th className="text-right">n</Th>
              <Th className="text-right">Excl.</Th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {op.mes.estaciones.map((e) => (
              <tr key={e.operation}>
                <td className="px-3 py-1.5 font-mono text-gray-800">{e.operation}</td>
                <td className="px-3 py-1.5 text-right font-semibold">{num(e.proceso?.[estadistico], 1)}</td>
                <td className="px-3 py-1.5 text-right text-gray-600">{num(e.proceso?.p25, 1)} – {num(e.proceso?.p75, 1)}</td>
                <td className="px-3 py-1.5 text-right text-gray-600">{e.proceso?.n ?? 0}</td>
                <td className="px-3 py-1.5 text-right text-gray-500">{e.proceso?.excluidos ?? 0}</td>
                <td className="px-3 py-1.5 text-right text-gray-600" title={(e.lista_recursos || []).join(', ')}>{e.recursos ?? 0}</td>
                <td className="px-3 py-1.5 text-right font-semibold">{num(e.salida?.[estadistico], 1)}</td>
                <td className="px-3 py-1.5 text-right text-gray-600">{num(e.salida?.p25, 1)} – {num(e.salida?.p75, 1)}</td>
                <td className="px-3 py-1.5 text-right text-gray-600">{e.salida?.n ?? 0}</td>
                <td className="px-3 py-1.5 text-right text-gray-500">{e.salida?.excluidos ?? 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="px-3 py-1.5 text-[11px] text-gray-500 border-t border-gray-100">
          Agregación <b>{op.mapeo.agregacion === 'PARALELO' ? 'en paralelo' : 'en serie'}</b>:{' '}
          {op.mapeo.agregacion === 'PARALELO'
            ? 'proceso = promedio ponderado por piezas; salida = capacidad combinada (1 / Σ 1/x).'
            : 'proceso = suma de estaciones; salida = la estación más lenta.'}
          {' '}Excl. = ciclos fuera de los límites (piezas detenidas o paros).
        </p>
      </div>
    </td>
  </tr>
)

const ComparativaTabla = ({ operaciones, estadistico, campoTiempo, divisorSalida = 1, onEditarRegla }) => {
  const div = Number(divisorSalida) || 1
  const [abiertas, setAbiertas] = useState({})
  const alternar = (k) => setAbiertas((p) => ({ ...p, [k]: !p[k] }))

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 border-y border-gray-200">
          <tr>
            <Th className="w-8" />
            <Th className="text-left">Operación</Th>
            <Th className="text-right" title="Maquinas en paralelo (se captura en el mapeo)">Equipos</Th>
            <Th className="text-right" title={`${etiquetaCampoTiempo(campoTiempo)} tal como está en SAP`}>Tiempo SAP</Th>
            <Th className="text-right border-l border-gray-200">SAP seg/pz</Th>
            <Th className="text-right">MES proceso</Th>
            <Th className="text-left">Δ proceso</Th>
            <Th className="text-right border-l border-gray-200">SAP ÷ equipos</Th>
            <Th className="text-right" title={div !== 1 ? `Salida MES (START→START) dividida entre ${div}` : undefined}>{div !== 1 ? `MES salida ÷ ${div}` : 'MES salida'}</Th>
            <Th className="text-left">Δ salida</Th>
            <Th className="text-left border-l border-gray-200">Mapeo MES</Th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {operaciones.map((op) => {
            const k = `${op.plnnr}-${op.operacion_num}`
            const abierta = !!abiertas[k]
            const tieneEstaciones = op.mes.estaciones.length > 0
            return (
              <Fragment key={k}>
                <tr className={`hover:bg-gray-50 ${abierta ? 'bg-gray-50' : ''}`}>
                  <Td>
                    {tieneEstaciones && (
                      <button
                        onClick={() => alternar(k)}
                        className="p-0.5 text-gray-400 hover:text-[#003588] focus:outline-none"
                        title={abierta ? 'Ocultar estaciones' : 'Ver estaciones MES'}
                        aria-expanded={abierta}
                      >
                        {abierta ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                    )}
                  </Td>
                  <Td>
                    <p className="font-bold text-[#003588]">{op.operacion_num}</p>
                    <p className="text-xs text-gray-700 max-w-[220px] truncate" title={op.descripcion}>{op.descripcion || '—'}</p>
                    <p className="text-[11px] text-gray-400 font-mono">{op.clave_modelo || 'sin clave'}</p>
                  </Td>
                  <Td className="text-right text-gray-800">
                    <span title={ORIGEN_EQUIPOS[op.equipos.origen]?.largo}>
                      {op.equipos.valor}
                      <span className="block text-[11px] text-gray-500">{ORIGEN_EQUIPOS[op.equipos.origen]?.corto}</span>
                    </span>
                  </Td>
                  <Td className="text-right text-gray-700 whitespace-nowrap">
                    {op.sap.tiempo !== null ? (
                      <>
                        {num(op.sap.tiempo, 4)} <span className="text-gray-500">{op.sap.unidad_t}</span>
                        <span className="block text-[11px] text-gray-500">por {num(op.sap.cantidad_base, 0)} pz</span>
                      </>
                    ) : '—'}
                  </Td>
                  <Td className="text-right border-l border-gray-100">
                    {op.sap.seg_pz !== null ? (
                      <span className="inline-flex items-center gap-1 font-semibold text-gray-900">
                        {op.sap.aviso && <AlertTriangle className="w-3.5 h-3.5 text-amber-600" title={op.sap.aviso} aria-label={op.sap.aviso} />}
                        {num(op.sap.seg_pz, 1)}
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs text-amber-700" title={op.sap.aviso}>
                        <AlertTriangle className="w-3.5 h-3.5" /> —
                      </span>
                    )}
                  </Td>
                  <Td className="text-right"><ValorMes valor={op.mes.proceso} n={op.mes.n_proceso} /></Td>
                  <Td><EstadoChip dif={op.dif_proceso} /></Td>
                  <Td className="text-right border-l border-gray-100">
                    {op.sap.seg_pz_linea !== null ? <span className="font-semibold text-gray-900">{num(op.sap.seg_pz_linea, 1)}</span> : <span className="text-gray-400">—</span>}
                  </Td>
                  <Td className="text-right"><ValorMes valor={op.mes.salida} n={op.mes.n_salida} /></Td>
                  <Td><EstadoChip dif={op.dif_salida} /></Td>
                  <Td className="border-l border-gray-100">
                    {op.mapeo.mes_operations.length > 0 ? (
                      <div className="max-w-[170px]">
                        <p className="text-xs font-mono text-gray-800 truncate" title={op.mapeo.mes_operations.join(', ')}>
                          {op.mapeo.mes_operations.join(', ')}
                        </p>
                        <p className={`text-[11px] ${op.mapeo.origen === 'AUTO_T435T' ? 'text-[#003588]' : 'text-gray-500'}`}>
                          {ORIGEN_REGLA[op.mapeo.origen]}
                          {op.mapeo.mes_operations.length > 1 && ` · ${op.mapeo.agregacion === 'PARALELO' ? 'paralelo' : 'serie'}`}
                          {op.mes.incompleto && <span className="text-amber-700"> · estación sin datos</span>}
                        </p>
                      </div>
                    ) : (
                      <div className="max-w-[170px]">
                        <span className="block text-xs text-gray-400">Sin mapeo</span>
                        {op.mapeo.texto_t435t && (
                          <span className="block text-[11px] text-gray-400 truncate" title={`Texto T435T: ${op.mapeo.texto_t435t} (no es un nombre de operación MES)`}>
                            T435T: {op.mapeo.texto_t435t}
                          </span>
                        )}
                      </div>
                    )}
                    <button
                      onClick={() => onEditarRegla(op)}
                      className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold border border-gray-300 text-gray-600 hover:text-[#003588] hover:border-[#003588] focus:outline-none whitespace-nowrap"
                    >
                      {op.mapeo.mes_operations.length > 0 ? <Pencil className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                      {op.regla ? 'Editar' : op.mapeo.origen === 'AUTO_T435T' ? 'Ajustar' : 'Mapear'}
                    </button>
                  </Td>
                </tr>
                {abierta && tieneEstaciones && <FilaEstaciones op={op} estadistico={estadistico} divisorSalida={div} />}
              </Fragment>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export default ComparativaTabla
