// src/components/sapMes/EstadoChip.jsx
import React from 'react'
import { ArrowDown, ArrowUp, CheckCircle2, Link2Off, Minus } from 'lucide-react'
import { ESTADOS, pct } from '../../utils/sapMesFormato'

const ICONOS = { ok: CheckCircle2, lento: ArrowUp, rapido: ArrowDown, vacio: Minus, mapeo: Link2Off }

const EstadoChip = ({ dif }) => {
  const meta = ESTADOS[dif?.estado] || ESTADOS.SIN_DATOS_MES
  const Icono = ICONOS[meta.icono] || Minus
  const tieneValor = dif?.pct !== null && dif?.pct !== undefined
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 border text-xs font-semibold whitespace-nowrap ${meta.clase}`}
      title={meta.label}
    >
      <Icono className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      {tieneValor ? pct(dif.pct) : meta.label}
    </span>
  )
}

export default EstadoChip
