// src/components/sapMes/ComparativaGrafica.jsx
// Barras agrupadas SAP vs MES por operacion, en seg/pz. Un solo eje.
import React, { useMemo } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { num, pct } from '../../utils/sapMesFormato'

const TooltipOp = ({ active, payload, metrica, etiquetaSalida }) => {
  if (!active || !payload?.length) return null
  const d = payload[0].payload
  return (
    <div className="bg-white border border-gray-200 shadow-lg px-3 py-2 text-xs min-w-[220px]">
      <p className="font-bold text-[#003588] mb-1">Op {d.op} · {d.descripcion}</p>
      <div className="grid grid-cols-[1fr_auto] gap-x-4 gap-y-0.5 text-gray-700">
        <span>{metrica === 'proceso' ? 'SAP (por equipo)' : 'SAP ÷ equipos'}</span>
        <span className="text-right font-semibold text-gray-900">{num(d.sap, 2)} s</span>
        <span>{metrica === 'proceso' ? 'MES proceso' : etiquetaSalida}</span>
        <span className="text-right font-semibold text-gray-900">{num(d.mes, 2)} s</span>
        <span>Diferencia</span>
        <span className="text-right font-semibold text-gray-900">{pct(d.difPct)}</span>
        <span>Piezas MES</span>
        <span className="text-right font-semibold text-gray-900">{d.n?.toLocaleString('es-MX') ?? '—'}</span>
      </div>
    </div>
  )
}

// Leyenda propia: orden fijo SAP -> MES y texto en color de texto (no del color de la serie).
const Leyenda = ({ items }) => (
  <div className="flex flex-wrap justify-center gap-x-5 gap-y-1 pt-2 text-xs text-gray-700">
    {items.map((it) => (
      <span key={it.label} className="inline-flex items-center gap-1.5">
        <span className="inline-block w-3 h-3" style={{ backgroundColor: it.color }} aria-hidden="true" />
        {it.label}
      </span>
    ))}
  </div>
)

const ComparativaGrafica = ({ operaciones, metrica, colorSap, colorMes, divisorSalida = 1 }) => {
  const div = Number(divisorSalida) || 1
  const etiquetaSalida = div !== 1 ? `MES salida ÷ ${div}` : 'MES salida'
  const nombreMes = metrica === 'proceso' ? 'MES proceso (START→COMPLETE)' : `MES salida (START→START${div !== 1 ? ` ÷ ${div}` : ''})`
  const datos = useMemo(
    () =>
      (operaciones || [])
        .filter((o) => o.sap.seg_pz !== null)
        .map((o) => ({
          op: o.operacion_num,
          descripcion: o.descripcion,
          sap: metrica === 'proceso' ? o.sap.seg_pz : o.sap.seg_pz_linea,
          mes: metrica === 'proceso' ? o.mes.proceso : o.mes.salida,
          difPct: (metrica === 'proceso' ? o.dif_proceso : o.dif_salida)?.pct,
          n: metrica === 'proceso' ? o.mes.n_proceso : o.mes.n_salida,
        })),
    [operaciones, metrica]
  )

  if (datos.length === 0) {
    return <p className="text-sm text-gray-500 py-10 text-center">No hay operaciones con tiempo SAP para graficar.</p>
  }

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={datos} margin={{ top: 8, right: 16, left: 0, bottom: 4 }} barGap={2} barCategoryGap="28%">
          <CartesianGrid vertical={false} stroke="#eef0f3" />
          <XAxis dataKey="op" tick={{ fontSize: 12, fill: '#4b5563' }} tickLine={false} axisLine={{ stroke: '#d1d5db' }} />
          <YAxis
            tick={{ fontSize: 11, fill: '#6b7280' }}
            tickLine={false}
            axisLine={false}
            width={48}
            label={{ value: 'seg/pz', angle: -90, position: 'insideLeft', fontSize: 11, fill: '#6b7280' }}
          />
          <Tooltip content={<TooltipOp metrica={metrica} etiquetaSalida={etiquetaSalida} />} cursor={{ fill: '#f3f4f6' }} />
          <Legend
            content={() => (
              <Leyenda
                items={[
                  { label: metrica === 'proceso' ? 'SAP (seg/pz por equipo)' : 'SAP (seg/pz ÷ equipos)', color: colorSap },
                  { label: nombreMes, color: colorMes },
                ]}
              />
            )}
          />
          <Bar
            dataKey="sap"
            name={metrica === 'proceso' ? 'SAP (seg/pz por equipo)' : 'SAP (seg/pz ÷ equipos)'}
            fill={colorSap}
            radius={[4, 4, 0, 0]}
            maxBarSize={36}
          />
          <Bar
            dataKey="mes"
            name={nombreMes}
            fill={colorMes}
            radius={[4, 4, 0, 0]}
            maxBarSize={36}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

export default ComparativaGrafica
