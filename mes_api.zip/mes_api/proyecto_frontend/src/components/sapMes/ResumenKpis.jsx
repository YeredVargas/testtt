// src/components/sapMes/ResumenKpis.jsx
import React from 'react'
import { num } from '../../utils/sapMesFormato'

const Tile = ({ titulo, valor, detalle, acento }) => (
  <div className="bg-white border border-gray-200 px-4 py-3 min-w-0">
    <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider truncate">{titulo}</p>
    <p className={`text-2xl font-bold leading-tight mt-1 ${acento || 'text-gray-900'}`}>{valor}</p>
    {detalle && <p className="text-xs text-gray-500 mt-0.5 truncate" title={detalle}>{detalle}</p>}
  </div>
)

const Cuello = ({ titulo, dato, colorBarra }) => (
  <div className="bg-white border border-gray-200 px-4 py-3 min-w-0">
    <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
      <span className="inline-block w-2.5 h-2.5 shrink-0" style={{ backgroundColor: colorBarra }} aria-hidden="true" />
      {titulo}
    </p>
    {dato ? (
      <>
        <p className="text-2xl font-bold leading-tight mt-1 text-gray-900">
          {num(dato.seg_pz, 1)} <span className="text-sm font-semibold text-gray-500">seg/pz</span>
        </p>
        <p className="text-xs text-gray-500 mt-0.5 truncate" title={`${dato.operacion_num} · ${dato.descripcion || ''}`}>
          Op {dato.operacion_num} · {num(dato.pzs_hr, 1)} pzs/hr
        </p>
      </>
    ) : (
      <p className="text-2xl font-bold leading-tight mt-1 text-gray-400">—</p>
    )}
  </div>
)

const ResumenKpis = ({ resumen, colorSap, colorMes }) => {
  if (!resumen) return null
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
      <Tile titulo="Operaciones SAP" valor={resumen.operaciones_sap} detalle={`${resumen.operaciones_con_tiempo} con tiempo`} />
      <Tile
        titulo="Mapeadas a MES"
        valor={`${resumen.operaciones_mapeadas}/${resumen.operaciones_sap}`}
        detalle={`${resumen.operaciones_auto ?? 0} automáticas · ${resumen.operaciones_manual ?? 0} manuales`}
        acento={resumen.operaciones_mapeadas < resumen.operaciones_con_tiempo ? 'text-amber-700' : 'text-gray-900'}
      />
      <Tile titulo="Con datos MES" valor={resumen.operaciones_con_datos_mes} />
      <Tile
        titulo="Fuera de tolerancia"
        valor={resumen.fuera_de_tolerancia}
        acento={resumen.fuera_de_tolerancia > 0 ? 'text-red-700' : 'text-green-700'}
      />
      <Cuello titulo="Cuello de botella SAP" dato={resumen.cuello_sap} colorBarra={colorSap} />
      <Cuello titulo="Cuello de botella MES" dato={resumen.cuello_mes} colorBarra={colorMes} />
    </div>
  )
}

export default ResumenKpis
