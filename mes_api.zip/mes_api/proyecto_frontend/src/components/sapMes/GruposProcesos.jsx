// src/components/sapMes/GruposProcesos.jsx
// Grupos de procesos: rangos de operaciones con nombre que arma el usuario por
// material (p. ej. "SMT Top" = 0100–0160). Elegir un grupo filtra la
// comparativa; la tabla muestra el resumen SAP vs MES de cada grupo.
import React, { useMemo, useState } from 'react'
import { Layers, Loader2, Pencil, Plus, Trash2 } from 'lucide-react'
import EstadoChip from './EstadoChip'
import { useEliminarGrupo, useGuardarGrupo } from '../../hooks/useSapMes'
import { num } from '../../utils/sapMesFormato'

const inputCls = 'border border-gray-300 bg-white px-2 py-[7px] text-sm focus:outline-none focus:border-[#003588] rounded-none'

const estadoDe = (dif, tol) => {
  if (dif === null || dif === undefined) return { pct: null, estado: 'SIN_DATOS_MES' }
  if (Math.abs(dif) <= tol) return { pct: dif, estado: 'OK' }
  return { pct: dif, estado: dif > 0 ? 'MES_MAS_LENTO' : 'MES_MAS_RAPIDO' }
}

const Seg = ({ v, pzs }) =>
  v === null || v === undefined ? <span className="text-gray-400">—</span> : (
    <span>
      <span className="font-semibold text-gray-900">{num(v, 1)}</span>
      {pzs != null && <span className="block text-[11px] text-gray-500">{num(pzs, 1)} pzs/hr</span>}
    </span>
  )

const Th = ({ children, className = '' }) => (
  <th className={`px-3 py-2 text-[11px] font-bold text-gray-500 uppercase tracking-wider whitespace-nowrap ${className}`}>{children}</th>
)

const vacio = { id: null, nombre: '', op_inicio: '', op_fin: '', soloAlt: true }

const FormGrupo = ({ inicial, operaciones, plnal, onCancel, onGuardar, guardando, error }) => {
  const [f, setF] = useState(inicial)
  const set = (k) => (e) => setF((p) => ({ ...p, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))
  const idxIni = operaciones.findIndex((o) => o.operacion_num === f.op_inicio)
  const valido = f.nombre.trim() && f.op_inicio && f.op_fin &&
    idxIni <= operaciones.findIndex((o) => o.operacion_num === f.op_fin)
  return (
    <form
      className="flex flex-wrap items-end gap-3 border border-[#003588]/30 bg-blue-50/40 px-3 py-3"
      onSubmit={(e) => { e.preventDefault(); if (valido) onGuardar(f) }}
    >
      <label className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
        Nombre
        <input id="grupo-nombre" className={`${inputCls} block w-48 mt-1 normal-case tracking-normal font-normal`} maxLength={60}
          value={f.nombre} onChange={set('nombre')} placeholder="Ej. SMT Top" autoFocus />
      </label>
      <label className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
        Operación inicial
        <select id="grupo-op-inicio" className={`${inputCls} block w-60 mt-1 normal-case tracking-normal font-normal`} value={f.op_inicio} onChange={set('op_inicio')}>
          <option value="">Elegir…</option>
          {operaciones.map((o) => <option key={o.operacion_num} value={o.operacion_num}>{o.operacion_num} · {o.descripcion || ''}</option>)}
        </select>
      </label>
      <label className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
        Operación final
        <select id="grupo-op-fin" className={`${inputCls} block w-60 mt-1 normal-case tracking-normal font-normal`} value={f.op_fin} onChange={set('op_fin')}>
          <option value="">Elegir…</option>
          {operaciones.filter((_, i) => idxIni < 0 || i >= idxIni).map((o) => (
            <option key={o.operacion_num} value={o.operacion_num}>{o.operacion_num} · {o.descripcion || ''}</option>
          ))}
        </select>
      </label>
      <label className="inline-flex items-center gap-2 text-sm text-gray-700 py-2">
        <input id="grupo-solo-alt" type="checkbox" checked={f.soloAlt} onChange={set('soloAlt')} />
        Solo Alt {plnal}
      </label>
      <div className="flex gap-2 ml-auto">
        <button type="button" onClick={onCancel} className="px-3 py-[7px] text-xs font-bold uppercase text-gray-600 border border-gray-300 bg-white hover:bg-gray-50">
          Cancelar
        </button>
        <button type="submit" disabled={!valido || guardando}
          className="inline-flex items-center gap-1.5 px-4 py-[7px] text-xs font-bold uppercase text-white bg-[#003588] hover:bg-[#002a6b] disabled:opacity-40">
          {guardando && <Loader2 className="w-4 h-4 animate-spin" />} Guardar grupo
        </button>
      </div>
      {error && <p className="w-full text-xs text-red-700">{error}</p>}
    </form>
  )
}

const GruposProcesos = ({ comp, centro, grupoActivo, onSeleccionar, onMensaje }) => {
  const [editando, setEditando] = useState(null)      // objeto del form o null
  const [borrando, setBorrando] = useState(null)      // id con confirmacion abierta
  const [error, setError] = useState(null)
  const guardar = useGuardarGrupo()
  const eliminar = useEliminarGrupo()
  const grupos = comp.grupos || []
  const tol = Number(comp.parametros.tolerancia_pct) || 0
  const plnal = comp.version.plnal

  const totalOps = comp.operaciones.length
  const ops = useMemo(() => comp.operaciones.map((o) => ({ operacion_num: o.operacion_num, descripcion: o.descripcion })), [comp])

  const onGuardar = async (f) => {
    setError(null)
    try {
      await guardar.mutateAsync({
        id: f.id,
        grupo: {
          centro, numero_material: comp.numero_material, plnal: f.soloAlt ? plnal : null,
          nombre: f.nombre.trim(), op_inicio: f.op_inicio, op_fin: f.op_fin, orden: f.orden ?? grupos.length,
        },
      })
      onMensaje(f.id ? 'Grupo actualizado.' : 'Grupo creado.')
      setEditando(null)
    } catch (e) {
      const d = e?.response?.data?.detail
      setError(Array.isArray(d) ? d.map((x) => x.msg).join(' ') : d || 'No se pudo guardar el grupo.')
    }
  }

  const onEliminar = async (id) => {
    try {
      await eliminar.mutateAsync(id)
      if (grupoActivo === id) onSeleccionar(null)
      setBorrando(null)
      onMensaje('Grupo eliminado.')
    } catch {
      onMensaje('No se pudo eliminar el grupo.', 'error')
    }
  }

  const chip = (activo) =>
    `inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold border ${activo ? 'bg-[#003588] border-[#003588] text-white' : 'bg-white border-gray-300 text-gray-700 hover:border-[#003588] hover:text-[#003588]'}`

  return (
    <div className="bg-white border border-gray-200">
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-b border-gray-200">
        <div>
          <p className="text-sm font-bold text-gray-900 flex items-center gap-2"><Layers className="w-4 h-4 text-[#003588]" /> Grupos de procesos</p>
          <p className="text-xs text-gray-500">Rangos de operaciones con nombre, guardados por material. Elige uno para ver solo esas operaciones.</p>
        </div>
        <button
          onClick={() => { setError(null); setEditando({ ...vacio }) }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold uppercase border border-[#003588] text-[#003588] hover:bg-blue-50"
        >
          <Plus className="w-4 h-4" /> Nuevo grupo
        </button>
      </div>

      <div className="px-4 py-3 space-y-3">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filtrar por grupo">
          <button className={chip(!grupoActivo)} aria-pressed={!grupoActivo} onClick={() => onSeleccionar(null)}>
            Toda la ruta <span className="opacity-70">· {totalOps} ops</span>
          </button>
          {grupos.map((g) => (
            <button key={g.id} className={chip(grupoActivo === g.id)} aria-pressed={grupoActivo === g.id} onClick={() => onSeleccionar(g.id)}>
              {g.nombre} <span className="opacity-70">· {g.op_inicio}–{g.op_fin}</span>
            </button>
          ))}
        </div>

        {editando && (
          <FormGrupo
            key={editando.id ?? 'nuevo'}
            inicial={editando}
            operaciones={ops}
            plnal={plnal}
            onCancel={() => setEditando(null)}
            onGuardar={onGuardar}
            guardando={guardar.isPending}
            error={error}
          />
        )}

        {grupos.length === 0 && !editando && (
          <p className="text-xs text-gray-500">
            Este material no tiene grupos. Crea uno con <b>Nuevo grupo</b>: por ejemplo, de la impresión de pasta al ICT para ver la línea SMT completa.
          </p>
        )}
      </div>

      {grupos.length > 0 && (
        <div className="overflow-x-auto border-t border-gray-200">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <Th className="text-left">Grupo</Th>
                <Th className="text-right border-l border-gray-200">SAP Σ proceso</Th>
                <Th className="text-right">MES Σ proceso</Th>
                <Th className="text-left">Δ proceso</Th>
                <Th className="text-right border-l border-gray-200">Cuello SAP ÷ equipos</Th>
                <Th className="text-right">Cuello MES salida{(Number(comp.parametros.divisor_salida) || 1) !== 1 ? ` ÷ ${comp.parametros.divisor_salida}` : ''}</Th>
                <Th className="text-left">Δ salida</Th>
                <Th className="border-l border-gray-200" />
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {grupos.map((g) => (
                <tr key={g.id} className={grupoActivo === g.id ? 'bg-blue-50/50' : 'hover:bg-gray-50'}>
                  <td className="px-3 py-2.5 align-top">
                    <button className="text-left font-bold text-[#003588] hover:underline" onClick={() => onSeleccionar(g.id)}>{g.nombre}</button>
                    <p className="text-[11px] text-gray-500">
                      {g.op_inicio}–{g.op_fin} · {g.operaciones.length} ops{g.plnal ? ` · Alt ${g.plnal}` : ' · todas las alt.'}
                    </p>
                  </td>
                  <td className="px-3 py-2.5 text-right align-top border-l border-gray-100"><Seg v={g.proceso.sap_seg_pz} /></td>
                  <td className="px-3 py-2.5 text-right align-top"><Seg v={g.proceso.mes_seg_pz} /></td>
                  <td className="px-3 py-2.5 align-top">
                    <EstadoChip dif={estadoDe(g.proceso.dif_pct, tol)} />
                    <p className="text-[11px] text-gray-500 mt-0.5">{g.proceso.comparables}/{g.operaciones.length} comparables</p>
                  </td>
                  <td className="px-3 py-2.5 text-right align-top border-l border-gray-100"><Seg v={g.salida.sap_seg_pz} pzs={g.salida.sap_pzs_hr} /></td>
                  <td className="px-3 py-2.5 text-right align-top"><Seg v={g.salida.mes_seg_pz} pzs={g.salida.mes_pzs_hr} /></td>
                  <td className="px-3 py-2.5 align-top"><EstadoChip dif={estadoDe(g.salida.dif_pct, tol)} /></td>
                  <td className="px-3 py-2.5 align-top border-l border-gray-100 whitespace-nowrap text-right">
                    {borrando === g.id ? (
                      <span className="inline-flex items-center gap-2 text-xs">
                        ¿Eliminar?
                        <button onClick={() => onEliminar(g.id)} disabled={eliminar.isPending} className="font-bold text-red-600 hover:underline">Sí</button>
                        <button onClick={() => setBorrando(null)} className="font-bold text-gray-600 hover:underline">No</button>
                      </span>
                    ) : (
                      <span className="inline-flex gap-1">
                        <button
                          title="Editar grupo" aria-label={`Editar ${g.nombre}`}
                          onClick={() => { setError(null); setEditando({ id: g.id, nombre: g.nombre, op_inicio: g.op_inicio, op_fin: g.op_fin, soloAlt: !!g.plnal, orden: grupos.indexOf(g) }) }}
                          className="p-1 text-gray-400 hover:text-[#003588]"
                        ><Pencil className="w-4 h-4" /></button>
                        <button
                          title="Eliminar grupo" aria-label={`Eliminar ${g.nombre}`}
                          onClick={() => setBorrando(g.id)}
                          className="p-1 text-gray-400 hover:text-red-600"
                        ><Trash2 className="w-4 h-4" /></button>
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="px-4 py-2 text-[11px] text-gray-500 border-t border-gray-100">
            Σ proceso: suma del tiempo por pieza de las operaciones que tienen SAP y MES (comparables). Cuello: la operación más lenta del grupo marca su ritmo de salida.
          </p>
        </div>
      )}
    </div>
  )
}

export default GruposProcesos
