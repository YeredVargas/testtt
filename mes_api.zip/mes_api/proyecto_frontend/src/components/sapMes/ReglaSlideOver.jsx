// src/components/sapMes/ReglaSlideOver.jsx
// Captura del mapeo: operacion SAP -> estacion(es) MES.
import React, { useEffect, useMemo, useState } from 'react'
import { Loader2, Plus, Trash2, X } from 'lucide-react'
import SlideOver from '../ui/SlideOver'
import { useEliminarRegla, useGuardarRegla, useOperacionesMes } from '../../hooks/useSapMes'

const ALCANCES = {
  ALT: 'Solo esta alternativa',
  MAT: 'Todas las alternativas de este material',
  CLAVE: 'Todos los materiales con esta clave',
}

const origenAAlcance = { MATERIAL_ALTERNATIVA: 'ALT', MATERIAL: 'MAT', CLAVE: 'CLAVE' }

const buscarRegla = (reglas, alcance, material, op, plnal) =>
  (reglas || []).find((r) => {
    if (alcance === 'CLAVE') return r.alcance === 'CLAVE' && r.clave_modelo === (op?.clave_modelo || '').toUpperCase()
    if (r.alcance !== 'MATERIAL' || r.numero_material !== material || r.operacion_num !== op?.operacion_num) return false
    return alcance === 'ALT' ? r.plnal === plnal : !r.plnal
  })

const extraerError = (err) => {
  const d = err?.response?.data?.detail
  if (Array.isArray(d)) return d.map((x) => x.msg).join(' ')
  return d || err?.customMessage || err?.message || 'No se pudo guardar.'
}

const Etiqueta = ({ children }) => (
  <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">{children}</p>
)

const ReglaSlideOver = ({ isOpen, onClose, op, material, plnal, centro, reglas, onGuardado }) => {
  const [alcance, setAlcance] = useState('MAT')
  const [estaciones, setEstaciones] = useState([])
  const [manual, setManual] = useState('')
  const [equipos, setEquipos] = useState(1)
  const [agregacion, setAgregacion] = useState('SERIE')
  const [notas, setNotas] = useState('')
  const [error, setError] = useState('')

  const guardar = useGuardarRegla()
  const eliminar = useEliminarRegla()
  const { data: opsMes, isLoading: cargandoOps, isError: errorOps, error: errOps } = useOperacionesMes(material, isOpen)

  const existente = useMemo(() => buscarRegla(reglas, alcance, material, op, plnal), [reglas, alcance, material, op, plnal])

  // Al abrir: arrancar con el alcance de la regla que hoy aplica.
  useEffect(() => {
    if (!isOpen || !op) return
    const inicial = op.regla ? origenAAlcance[op.regla.origen] || 'MAT' : 'MAT'
    setAlcance(inicial)
    // Sin regla manual: se parte de lo que propone T435T y de los recursos que vio MES.
    setEstaciones(op.regla?.mes_operations || op.mapeo?.mes_operations || [])
    setEquipos(op.regla?.equipos || op.equipos?.valor || 1)
    setAgregacion(op.regla?.agregacion || op.mapeo?.agregacion || 'SERIE')
    setNotas(op.regla?.notas || '')
    setManual('')
    setError('')
  }, [isOpen, op])

  // Al cambiar de alcance: si ya hay regla con esa llave, cargarla; si no, conservar lo capturado.
  const cambiarAlcance = (nuevo) => {
    setAlcance(nuevo)
    const r = buscarRegla(reglas, nuevo, material, op, plnal)
    if (r) {
      setEstaciones(r.mes_operations)
      setEquipos(r.equipos)
      setAgregacion(r.agregacion)
      setNotas(r.notas || '')
    }
  }

  const alternarEstacion = (nombre) =>
    setEstaciones((prev) => (prev.includes(nombre) ? prev.filter((x) => x !== nombre) : [...prev, nombre]))

  const agregarManual = () => {
    const v = manual.trim()
    if (v && !estaciones.includes(v)) setEstaciones((p) => [...p, v])
    setManual('')
  }

  const onGuardar = async () => {
    setError('')
    if (estaciones.length === 0) {
      setError('Selecciona al menos una estación MES.')
      return
    }
    const regla = {
      centro,
      alcance: alcance === 'CLAVE' ? 'CLAVE' : 'MATERIAL',
      numero_material: alcance === 'CLAVE' ? null : material,
      plnal: alcance === 'ALT' ? plnal : null,
      operacion_num: alcance === 'CLAVE' ? null : op.operacion_num,
      clave_modelo: alcance === 'CLAVE' ? op.clave_modelo : null,
      equipos: Number(equipos) || 1,
      agregacion,
      notas: notas || null,
      activo: true,
      mes_operations: estaciones,
    }
    try {
      await guardar.mutateAsync({ id: existente?.id, regla })
      onGuardado?.(existente ? 'Mapeo actualizado.' : 'Mapeo guardado.')
      onClose()
    } catch (e) {
      setError(extraerError(e))
    }
  }

  const onEliminar = async () => {
    if (!existente) return
    try {
      await eliminar.mutateAsync(existente.id)
      onGuardado?.('Mapeo eliminado.')
      onClose()
    } catch (e) {
      setError(extraerError(e))
    }
  }

  const listaMes = opsMes?.operations || []
  const fueraDeLista = estaciones.filter((e) => !listaMes.some((o) => o.OPERATION === e))

  return (
    <SlideOver isOpen={isOpen} onClose={onClose} title="Mapeo SAP → MES">
      {op && (
        <div className="space-y-5 text-sm">
          <div className="border border-gray-200 bg-gray-50 px-3 py-2">
            <p className="font-bold text-[#003588]">Op {op.operacion_num} · {op.descripcion || '—'}</p>
            <p className="text-xs text-gray-600">
              Material {material} · Alt {plnal} · Clave <span className="font-mono">{op.clave_modelo || '—'}</span>
            </p>
            {op.mapeo?.texto_t435t && (
              <p className="text-xs text-gray-600 mt-0.5">
                Texto T435T: <span className="font-mono">{op.mapeo.texto_t435t}</span>
                {op.mapeo.t435t_valido
                  ? (op.regla ? ' · la regla manual lo reemplaza' : ' · mapeo automático')
                  : ' · no es un nombre de operación MES'}
              </p>
            )}
          </div>

          <div>
            <Etiqueta>Aplica a</Etiqueta>
            <div className="space-y-1.5">
              {Object.entries(ALCANCES).map(([valor, texto]) => {
                const deshabilitado = valor === 'CLAVE' && !op.clave_modelo
                return (
                  <label key={valor} className={`flex items-start gap-2 ${deshabilitado ? 'opacity-40' : 'cursor-pointer'}`}>
                    <input
                      type="radio"
                      name="alcance"
                      className="mt-0.5 accent-[#003588]"
                      checked={alcance === valor}
                      disabled={deshabilitado}
                      onChange={() => cambiarAlcance(valor)}
                    />
                    <span>
                      {texto}
                      {valor === 'ALT' && <span className="text-gray-500"> (Alt {plnal})</span>}
                      {valor === 'CLAVE' && op.clave_modelo && <span className="text-gray-500 font-mono"> ({op.clave_modelo})</span>}
                    </span>
                  </label>
                )
              })}
            </div>
            <p className="text-[11px] text-gray-500 mt-1.5">
              Prioridad: esta alternativa &gt; este material &gt; clave general.
              {existente ? ' Ya existe una regla con este alcance; se va a actualizar.' : ' Se creará una regla nueva.'}
            </p>
          </div>

          <div>
            <Etiqueta>Estaciones MES</Etiqueta>
            {cargandoOps && (
              <p className="flex items-center gap-2 text-gray-500 text-xs"><Loader2 className="w-4 h-4 animate-spin" /> Consultando estaciones del material en MES (últimos 60 días)…</p>
            )}
            {errorOps && (
              <p className="text-xs text-amber-700 border border-amber-200 bg-amber-50 px-2 py-1.5">
                No se pudo obtener la lista de MES ({extraerError(errOps)}). Puedes escribir la estación a mano.
              </p>
            )}
            {!cargandoOps && !errorOps && listaMes.length === 0 && (
              <p className="text-xs text-gray-500">MES no tiene registros de este material en los últimos 60 días.</p>
            )}
            {listaMes.length > 0 && (
              <div className="border border-gray-200 max-h-56 overflow-y-auto divide-y divide-gray-100">
                {listaMes.map((o) => (
                  <label key={o.OPERATION} className="flex items-center gap-2 px-2.5 py-1.5 cursor-pointer hover:bg-gray-50">
                    <input
                      type="checkbox"
                      className="accent-[#003588]"
                      checked={estaciones.includes(o.OPERATION)}
                      onChange={() => alternarEstacion(o.OPERATION)}
                    />
                    <span className="font-mono text-xs text-gray-800 flex-1 truncate">{o.OPERATION}</span>
                    <span className="text-[11px] text-gray-500 whitespace-nowrap">
                      {o.TOTAL_COMPLETES.toLocaleString('es-MX')} pzs{o.RECURSOS ? ` · ${o.RECURSOS} rec.` : ''}
                    </span>
                  </label>
                ))}
              </div>
            )}
            {fueraDeLista.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {fueraDeLista.map((e) => (
                  <span key={e} className="inline-flex items-center gap-1 px-2 py-0.5 border border-gray-300 text-xs font-mono">
                    {e}
                    <button onClick={() => alternarEstacion(e)} className="text-gray-400 hover:text-red-600" title="Quitar"><X className="w-3 h-3" /></button>
                  </span>
                ))}
              </div>
            )}
            <div className="flex gap-2 mt-2">
              <input
                value={manual}
                onChange={(e) => setManual(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && agregarManual()}
                placeholder="Agregar estación a mano (Ej. OBC_FASSY_ST030)"
                className="flex-1 border border-gray-300 px-2 py-1.5 text-xs font-mono focus:outline-none focus:border-[#003588]"
              />
              <button onClick={agregarManual} className="px-2 border border-gray-300 text-gray-600 hover:text-[#003588] hover:border-[#003588]" title="Agregar">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {estaciones.length > 1 && (
            <div>
              <Etiqueta>Cómo se combinan las estaciones</Etiqueta>
              <div className="space-y-1.5">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input type="radio" name="agregacion" className="mt-0.5 accent-[#003588]" checked={agregacion === 'SERIE'} onChange={() => setAgregacion('SERIE')} />
                  <span><b>En serie</b> — una después de otra. Proceso = suma; salida = la más lenta.</span>
                </label>
                <label className="flex items-start gap-2 cursor-pointer">
                  <input type="radio" name="agregacion" className="mt-0.5 accent-[#003588]" checked={agregacion === 'PARALELO'} onChange={() => setAgregacion('PARALELO')} />
                  <span><b>En paralelo</b> — hacen lo mismo. Proceso = promedio; salida = capacidad combinada.</span>
                </label>
              </div>
            </div>
          )}

          <div className="grid grid-cols-[120px_1fr] gap-3 items-start">
            <div>
              <Etiqueta>Equipos</Etiqueta>
              <input
                type="number"
                min={1}
                max={99}
                value={equipos}
                onChange={(e) => setEquipos(e.target.value)}
                className="w-full border border-gray-300 px-2 py-1.5 focus:outline-none focus:border-[#003588]"
              />
            </div>
            <p className="text-[11px] text-gray-500 pt-5">
              Máquinas en paralelo de esta operación. El tiempo SAP se divide entre este número para compararlo con la <b>salida</b> de MES.
              {op.equipos?.recursos_mes > 0 && <> MES vio <b>{op.equipos.recursos_mes}</b> recurso(s) en el rango consultado.</>}
              {' '}Sin regla, se usa lo que ve MES.
            </p>
          </div>

          <div>
            <Etiqueta>Notas</Etiqueta>
            <input
              value={notas}
              maxLength={255}
              onChange={(e) => setNotas(e.target.value)}
              className="w-full border border-gray-300 px-2 py-1.5 focus:outline-none focus:border-[#003588]"
              placeholder="Opcional"
            />
          </div>

          {error && <p className="text-xs text-red-700 border border-red-200 bg-red-50 px-2 py-1.5">{error}</p>}

          <div className="flex items-center justify-between pt-2 border-t border-gray-200">
            {existente ? (
              <button
                onClick={onEliminar}
                disabled={eliminar.isPending}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold uppercase text-red-600 border border-red-200 hover:bg-red-50 disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" /> Eliminar regla
              </button>
            ) : <span />}
            <div className="flex gap-2">
              <button onClick={onClose} className="px-4 py-2 text-xs font-bold uppercase text-gray-600 border border-gray-300 hover:bg-gray-50">
                Cancelar
              </button>
              <button
                onClick={onGuardar}
                disabled={guardar.isPending}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase text-white bg-[#003588] hover:bg-[#002a6b] disabled:opacity-50"
              >
                {guardar.isPending && <Loader2 className="w-4 h-4 animate-spin" />} Guardar
              </button>
            </div>
          </div>
        </div>
      )}
    </SlideOver>
  )
}

export default ReglaSlideOver
