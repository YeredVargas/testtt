// src/components/ui/NuevoMaterialModal.jsx
import React, { useState, useEffect } from 'react';
import { Plus, X, Loader2, Building2 } from 'lucide-react';
import { agregarNuevoMaterial } from '../../services/SapService';
import { CostosService } from '../../services/costos/CostosService'; // 🔴 IMPORTANTE: Se añade este servicio
import { useToast } from './ToastContext';
import { useQueryClient } from '@tanstack/react-query';
import CustomSelect from './CustomSelect';

const opcionesCentros = [
  { value: '0094', label: '0094 (KEMM)' },
  { value: '0008', label: '0008 (KOMEX)' }
];

const NuevoMaterialModal = ({ isOpen, onClose, centroActual }) => {
  const [materialesInput, setMaterialesInput] = useState('');
  const [centroSeleccionado, setCentroSeleccionado] = useState(centroActual || '0094');
  
  const [isLoading, setIsLoading] = useState(false);
  const [statusTexto, setStatusTexto] = useState('');

  const showToast = useToast();
  const queryClient = useQueryClient();

  // Sincronizamos el modal con el centro en el que el usuario esté navegando
  useEffect(() => {
    if (isOpen) {
      setCentroSeleccionado(centroActual || '0094');
      setMaterialesInput('');
      setStatusTexto('');
    }
  }, [isOpen, centroActual]);

  if (!isOpen) return null;

  const handleAgregar = async () => {
    // 1. Convertimos el texto ingresado en un Array. 
    // Esto separa por comas, espacios, tabuladores o saltos de línea (ideal para Excel)
    const listaCruda = materialesInput.split(/[\n\t, ]+/);
    
    // 2. Limpiamos espacios vacíos y eliminamos números de parte duplicados
    const lista = [...new Set(listaCruda.map(m => m.trim()).filter(m => m !== ''))];

    if (lista.length === 0) {
      return showToast("Ingresa al menos un número de parte", "error");
    }

    setIsLoading(true);
    let exitos = 0;
    let errores = 0;

    // 3. Procesamos UNO POR UNO de forma secuencial.
    for (let i = 0; i < lista.length; i++) {
      const mat = lista[i];
      let exitoCostos = false;
      
      // 🔴 FASE 1: Descargar Tiempos / Hojas de Ruta
      try {
        setStatusTexto(`Paso 1/2: Descargando Rutas de ${mat}...`);
        await agregarNuevoMaterial(mat, centroSeleccionado);
      } catch (error) {
        // Si falla la ruta, solo avisa pero NO detiene el proceso de costos
        console.warn(`No se pudieron extraer rutas de ${mat}, pero se buscarán costos.`);
      }

      // 🔴 FASE 2: Descargar Costos Financieros (Independiente)
      try {
        setStatusTexto(`Paso 2/2: Extrayendo Costos Financieros de ${mat}...`);
        await CostosService.sincronizarMaterial(mat, centroSeleccionado);
        exitoCostos = true;
      } catch (error) {
        console.error(`Error importando costos de ${mat}:`, error);
      }

      // Evaluamos el éxito global basado en si al menos trajo los costos
      if (exitoCostos) { 
        exitos++; 
      } else { 
        errores++; 
      }
    }

    setStatusTexto('');
    setIsLoading(false);

    // 4. Mostrar resumen de la operación
    if (errores === 0) {
      showToast(`Se importaron ${exitos} material(es) exitosamente.`, "success");
    } else if (exitos > 0) {
      showToast(`Finalizado. ${exitos} exitosos, ${errores} con error.`, "warning");
    } else {
      showToast(`No se pudo importar ningún material. Verifica la conexión a SAP.`, "error");
    }

    // Invalida las consultas para que las tablas de fondo se recarguen
    await queryClient.invalidateQueries();
    
    // Si todo salió perfecto, cerramos el modal
    if (errores === 0) onClose();
  };

  const valCentro = opcionesCentros.find(opt => opt.value === centroSeleccionado) || opcionesCentros[0];

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white p-6 border-t-4 border-[#003588] shadow-2xl w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-gray-900">Importar Materiales</h3>
          <button onClick={onClose} disabled={isLoading} className="text-gray-400 hover:text-red-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-sm text-gray-600 mb-4">
          Se buscará la familia, tiempos y costos en SAP para los materiales indicados.
        </p>

        <div className="mb-4">
          <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 flex items-center gap-1">
            <Building2 className="w-3.5 h-3.5" /> Centro Destino
          </label>
          <CustomSelect
            options={opcionesCentros}
            value={valCentro}
            onChange={(opt) => setCentroSeleccionado(opt?.value ?? '0094')}
            isDisabled={isLoading}
            isClearable={false}
            isSearchable={false}
          />
        </div>

        <div className="mb-6">
           <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1">
            Números de Parte
          </label>
          <textarea
            value={materialesInput}
            onChange={(e) => setMaterialesInput(e.target.value)}
            placeholder="Ej. 12171980&#10;12171981, 12171982"
            disabled={isLoading}
            rows={4}
            className="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-[#003588] resize-none transition-colors"
          />
          <p className="text-[11px] text-gray-400 mt-1.5 leading-tight">
            Puedes separar múltiples números por comas, espacios o saltos de línea (puedes pegar directo desde Excel).
          </p>
        </div>

        <div className="flex justify-between items-center">
          <div className="text-xs font-bold text-[#003588] truncate pr-4">
            {isLoading && statusTexto}
          </div>
          <div className="flex gap-3 shrink-0">
            <button onClick={onClose} disabled={isLoading} className="px-4 py-2 text-sm border border-gray-300 text-gray-700 hover:bg-gray-50 focus:outline-none transition-colors">
              Cancelar
            </button>
            <button
              onClick={handleAgregar}
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2 text-sm bg-white border border-[#003588] text-[#003588] hover:bg-[#003588] hover:text-white transition-colors focus:outline-none"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              {isLoading ? 'Importando...' : 'Importar'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NuevoMaterialModal;