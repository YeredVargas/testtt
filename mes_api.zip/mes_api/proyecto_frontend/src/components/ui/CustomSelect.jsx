// src/components/ui/CustomSelect.jsx
import React, { useMemo, useRef, useState } from 'react';
import Select from 'react-select';

const CustomSelect = ({
  options = [],
  value,
  onChange,
  placeholder = 'Selecciona...',
  isDisabled = false,
  isClearable = true,
  isMulti = false, // <-- AÑADIR ESTO
  className = '',
  isSearchable = true, // Añadido para controlar si queremos ocultar el teclado en algunos
}) => {
  const selectRef = useRef(null);
  const [isFocused, setIsFocused] = useState(false);
  const [inputValue, setInputValue] = useState('');

  const selectedLabel = useMemo(
    () => (value ? String(value.label ?? '') : ''),
    [value]
  );

  const handleFocus = () => {
    setIsFocused(true);
    // MAGIA: Al hacer clic, vaciamos el texto de búsqueda.
    // Así el usuario puede escribir un nuevo número de parte inmediatamente.
    setInputValue(''); 
  };

  const handleBlur = () => {
    setIsFocused(false);
    // Al salir sin seleccionar nada, limpiamos el input de búsqueda.
    // React-select volverá a mostrar el valor seleccionado automáticamente.
    setInputValue('');
  };

  const handleChange = (newValue, actionMeta) => {
    onChange?.(newValue, actionMeta);
    // Al seleccionar una opción, cerramos y limpiamos el texto de búsqueda.
    setInputValue('');
    setIsFocused(false);
    selectRef.current?.blur(); // Quitamos el foco para que cierre el teclado/menú
  };

  const handleInputChange = (newValue, meta) => {
    if (meta.action === 'input-change') {
      setInputValue(newValue);
    }
    return newValue;
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      setInputValue('');
      setIsFocused(false);
      selectRef.current?.blur();
    }
  };

  return (
    <Select
      ref={selectRef}
      options={options}
      value={value}
      onChange={handleChange}
      inputValue={isFocused ? inputValue : ''}
      onInputChange={handleInputChange}
      onFocus={handleFocus}
      onBlur={handleBlur}
      onKeyDown={handleKeyDown}
      placeholder={placeholder}
      isDisabled={isDisabled}
      isClearable={isClearable}
      isSearchable={isSearchable}
      openMenuOnFocus
      openMenuOnClick
      isMulti={isMulti} // <-- Y PASARLO AQUÍ
      
      // Ajustes para que se sienta más natural:
      closeMenuOnSelect={true} 
      blurInputOnSelect={true} 
      backspaceRemovesValue={true} 
      
      menuIsOpen={isFocused}
      
      // Esto oculta el valor seleccionado original mientras el input de búsqueda está activo
      controlShouldRenderValue={!isFocused} 
      
      getOptionLabel={(option) => String(option.label ?? '')}
      getOptionValue={(option) => String(option.value ?? '')}
      unstyled
      menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
      styles={{
        menuPortal: (base) => ({ ...base, zIndex: 9999 }),
      }}
      className={className}
      classNames={{
        control: ({ isFocused }) =>
          `flex w-full items-center justify-between rounded-none border border-gray-300 bg-white min-h-[38px] text-sm transition-colors ${
            isFocused
              ? 'border-[#003588] ring-1 ring-[#003588] outline-none'
              : 'hover:border-gray-400'
          }`,
        menu: () =>
          'rounded-none shadow-lg border border-gray-200 mt-1 bg-white z-[100] absolute w-full',
        option: ({ isFocused, isSelected }) =>
          `cursor-pointer px-3 py-2 text-sm transition-colors ${
            isSelected
              ? 'bg-[#003588] text-white'
              : isFocused
                ? 'bg-blue-50 text-gray-900'
                : 'text-gray-700'
          }`,
        valueContainer: () =>
          'px-3 py-1 flex flex-wrap flex-1 items-center overflow-hidden',
        placeholder: () => 'text-gray-500 truncate',
        singleValue: () => 'text-gray-900 truncate',
        input: () => 'text-gray-900 m-0 p-0',
        menuList: () => 'py-1 max-h-60 overflow-y-auto',
        dropdownIndicator: () =>
          'text-gray-400 p-2 hover:text-gray-600 cursor-pointer',
        indicatorSeparator: () => 'bg-gray-200 my-2 mx-1 w-px',
        clearIndicator: () =>
          'text-gray-400 p-1 mx-1 hover:text-red-500 hover:bg-red-50 transition-colors cursor-pointer rounded-none',
      }}
    />
  );
};

export default CustomSelect;