// src/components/graficas/GraficaBarras.jsx
import React, { useState, useRef } from 'react'
import { Maximize2, Download, X } from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell, LabelList, ReferenceLine
} from 'recharts'

// ==========================================
// TOOLTIP INTELIGENTE (Cambia según la vista)
// ==========================================
const KostalTooltip = ({ active, payload, label, unidad, esResumen }) => {
  if (!active || !payload?.length) return null

  const p = payload[0]
  const data = p.payload
  
  let val = Number(p.value)
  let textVal = val % 1 !== 0 ? val.toFixed(3) : val

  if (unidad === '%') {
    if (val > 0) textVal = `+${textVal}`
  }

  const formatVal = (v, isPct = false) => {
    if (v == null) return '—'
    const formatted = Number(v).toFixed(3)
    if (isPct) return v > 0 ? `+${formatted}%` : `${formatted}%`
    return formatted
  }

  // 1. TOOLTIP SIMPLIFICADO (Solo para el Resumen)
  if (esResumen) {
    return (
      <div className="bg-white border border-gray-200 shadow-xl rounded-sm z-[9999] relative min-w-[200px]">
        <div className="px-4 py-3 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          {/* Aplicamos el color dinámico al título para saber qué estamos viendo */}
          <p className="text-sm font-bold" style={{ color: data.color || '#003588' }}>{label}</p>
          <p className="text-[10px] text-gray-400 font-medium tracking-widest uppercase">Reg. SAP</p>
        </div>
        <div className="p-4 bg-white flex justify-between items-center gap-4">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Graficando</span>
          {/* Aplicamos el color dinámico al valor */}
          <span className="text-base font-bold" style={{ color: data.color || '#003588' }}>
            {textVal} {unidad}
          </span>
        </div>
      </div>
    )
  }

  // 2. TOOLTIP DETALLADO (Para el historial normal)
  return (
    <div className="bg-white border border-gray-200 shadow-xl p-4 rounded-none z-[9999] relative min-w-[220px]">
      <div className="flex justify-between items-center border-b border-gray-100 pb-2 mb-3">
        <p className="font-bold text-[#003588] text-sm">{label}</p>
        <p className="text-[10px] text-gray-400 font-medium tracking-widest uppercase">Reg. SAP</p>
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs mb-4">
        <span className="text-gray-500 font-medium">Tiempo SAP:</span>
        <span className="text-gray-900 text-right font-semibold">{formatVal(data.tiempo_sap)} hr</span>

        <span className="text-gray-500 font-medium">Equipos:</span>
        <span className="text-gray-900 text-right font-semibold">{data.equipos || '—'}</span>

        <span className="text-gray-500 font-medium">pzs/hr:</span>
        <span className="text-gray-900 text-right font-semibold">{formatVal(data.pzs_hr)}</span>

        <span className="text-gray-500 font-medium">seg/pz:</span>
        <span className="text-gray-900 text-right font-semibold">{formatVal(data.seg_pz)}</span>

        <span className="text-gray-500 font-medium">% vs Anterior:</span>
        <span className={`text-right font-semibold ${data.mejora > 0 ? 'text-green-600' : data.mejora < 0 ? 'text-red-500' : 'text-gray-900'}`}>
          {formatVal(data.mejora, true)}
        </span>

        <span className="text-gray-500 font-bold">% Acumulado:</span>
        <span className={`text-right font-bold ${data.mejora_global > 0 ? 'text-green-600' : data.mejora_global < 0 ? 'text-red-500' : 'text-gray-900'}`}>
          {formatVal(data.mejora_global, true)}
        </span>
      </div>

      <div className="bg-gray-50 px-3 py-2 border border-gray-200 flex justify-between items-center">
        <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Graficando</span>
        {/* Aquí también respetamos el color dinámico */}
        <span className="font-bold text-[15px]" style={{ color: data.color || '#374151' }}>
          {textVal} {unidad}
        </span>
      </div>
    </div>
  )
}

const CustomLabel = (props) => {
  const { x, y, width, value, unidad, index, data } = props
  if (value === undefined || value === null) return null

  const entry = data[index] || {}
  const numValue = Number(value)
  
  // Mantiene los colores dinámicos (azul/naranja/verde) para los números flotantes
  let textColor = entry.color || '#374151' 
  let textVal = numValue % 1 !== 0 ? numValue.toFixed(3) : `${numValue}`

  if (unidad === '%') {
    if (numValue > 0) textVal = `+${textVal}%`
    else textVal = `${textVal}%`
  }

  // Si el número es negativo, lo empujamos un poco hacia abajo para que no choque con la línea base
  const isNegative = numValue < 0
  const yPos = isNegative ? y + 16 : y - 10

  return (
    <text
      x={x + width / 2}
      y={yPos}
      fill={textColor}
      fontSize={13} 
      fontWeight="bold"
      textAnchor="middle"
    >
      {textVal}
    </text>
  )
}

const GraficaBarras = ({ 
  titulo, 
  datos = [], 
  unidad = '', 
  colorBarras = '#003588', // <-- POR DEFECTO AZUL KOSTAL
  altura = 300,
  metricaActual,
  onChangeMetrica,
  opcionesMetricas,
  anguloRotacion = 0, 
  esResumen = false   
}) => {
  const [isExpanded, setIsExpanded] = useState(false)
  const chartRef = useRef(null)
  const modalChartRef = useRef(null)

  if (!datos.length) {
    return (
      <div className="border border-gray-200 bg-white shadow-sm rounded-none p-5">
        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">{titulo}</p>
        <div className="flex items-center justify-center h-40 text-sm text-gray-400 italic">
          Sin datos en este rango
        </div>
      </div>
    )
  }

  const dataConLabel = datos.map(d => ({
    ...d,
    _label: d.operacion_num,
  }))

  const handleDownload = async (refTarget) => {
    try {
      const htmlToImage = await import('html-to-image')
      const dataUrl = await htmlToImage.toPng(refTarget.current, {
        backgroundColor: '#ffffff',
        pixelRatio: 2,
        filter: (node) => !(node?.getAttribute && node.getAttribute('data-html2canvas-ignore') === 'true')
      })
      const a = document.createElement('a')
      a.download = `${titulo.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.png`
      a.href = dataUrl
      a.click()
    } catch (error) {
      console.error(error)
      alert("Error al descargar la gráfica.")
    }
  }

  const RenderChartCore = ({ refer, currentHeight }) => (
    <div ref={refer} className="w-full h-full bg-white relative pt-4 pb-2">
      <ResponsiveContainer width="100%" height={currentHeight}>
        <BarChart
          data={dataConLabel}
          margin={{ top: 30, right: 8, left: -10, bottom: anguloRotacion !== 0 ? 30 : 20 }}
          barCategoryGap="25%"
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
          
          <XAxis 
            dataKey="_label" 
            tick={{ fontSize: 11, fill: '#4b5563', fontWeight: 600 }} 
            tickMargin={12} 
            axisLine={false} 
            tickLine={false} 
            angle={anguloRotacion} 
            textAnchor={anguloRotacion !== 0 ? "end" : "middle"}
            height={anguloRotacion !== 0 ? 60 : 30} 
          />
          
          <YAxis 
            domain={[
              (dataMin) => {
                if (unidad === 'eq') return 0;
                if (dataMin < 0) return Math.floor(dataMin * 1.15);
                return 0;
              },
              (dataMax) => {
                if (unidad === 'eq') return Math.ceil(dataMax) + 1;
                if (dataMax > 0) return dataMax * 1.15;
                return 0; 
              }
            ]}
            tick={{ fontSize: 11, fill: '#4b5563', fontWeight: 600 }} 
            axisLine={false} 
            tickLine={false} 
          />
          <ReferenceLine y={0} stroke="#000000" strokeWidth={2} />
          
          <Tooltip content={<KostalTooltip unidad={unidad} esResumen={esResumen} />} cursor={{ fill: '#f3f4f6' }} />
          
          <Bar dataKey="valor" radius={[0, 0, 0, 0]} maxBarSize={60} minPointSize={4}>
            {dataConLabel.map((entry, i) => (
              // AQUÍ ESTÁ EL CAMBIO CLAVE:
              // Ignoramos el color de los datos y forzamos el azul (colorBarras) para rellenar la barra
              <Cell key={i} fill={colorBarras} /> 
            ))}
            <LabelList dataKey="valor" content={(props) => <CustomLabel {...props} unidad={unidad} data={dataConLabel} />} />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )

  return (
    <>
      <div className="border border-gray-200 bg-white shadow-sm rounded-none p-5 flex flex-col">
        <div className="flex items-center justify-between mb-6 shrink-0">
          <div className="flex items-center gap-3">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">{titulo}</p>
            {unidad && <span className="text-xs font-bold text-[#003588] bg-blue-50 border border-blue-100 px-2 py-0.5 rounded-none">{unidad}</span>}
          </div>
          
          <div data-html2canvas-ignore="true" className="flex items-center gap-1">
            <button onClick={() => handleDownload(chartRef)} className="p-1.5 text-gray-400 hover:text-[#003588] hover:bg-blue-50 transition-colors border border-transparent hover:border-blue-100 rounded-none focus:outline-none" title="Descargar gráfica">
              <Download className="w-4 h-4" />
            </button>
            <button onClick={() => setIsExpanded(true)} className="p-1.5 text-gray-400 hover:text-[#003588] hover:bg-blue-50 transition-colors border border-transparent hover:border-blue-100 rounded-none focus:outline-none" title="Expandir gráfica">
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="flex-1">
          <RenderChartCore refer={chartRef} currentHeight={altura} />
        </div>
      </div>

      {isExpanded && (
        <div onClick={(e) => e.target === e.currentTarget && setIsExpanded(false)} className="fixed inset-0 z-[9999] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8 cursor-pointer transition-opacity">
          <div className="bg-white border border-gray-200 shadow-2xl w-full max-w-7xl h-full max-h-[85vh] flex flex-col rounded-none cursor-default animate-in fade-in zoom-in duration-200">
            <div className="flex flex-wrap items-center justify-between px-6 py-4 border-b border-gray-200 bg-gray-50 shrink-0 gap-4">
              
              <div className="flex items-center gap-4">
                <p className="text-sm font-bold text-[#003588] uppercase tracking-wider flex items-center gap-2">
                  <Maximize2 className="w-4 h-4 text-[#003588]" /> {titulo}
                </p>
                
                {opcionesMetricas && onChangeMetrica && (
                  <div className="hidden sm:flex relative w-48">
                    <select
                      value={metricaActual}
                      onChange={(e) => onChangeMetrica(e.target.value)}
                      className="w-full rounded-none border border-gray-300 bg-white h-[30px] px-2 text-xs font-semibold text-gray-700 outline-none focus:border-[#003588] focus:ring-1 focus:ring-[#003588] transition-colors cursor-pointer appearance-none"
                    >
                      {opcionesMetricas.map(o => (
                        <option key={o.value} value={o.value}>{o.label}</option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
                      <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3">
                <button onClick={() => handleDownload(modalChartRef)} className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 hover:text-[#003588] transition-colors rounded-none shadow-sm focus:outline-none">
                  <Download className="w-4 h-4" /> <span className="hidden sm:inline">Descargar PNG</span>
                </button>
                <div className="w-px h-6 bg-gray-300"></div>
                <button onClick={() => setIsExpanded(false)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors border border-transparent hover:border-red-100 rounded-none focus:outline-none">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex-1 p-6 md:p-10 overflow-hidden bg-white">
              <RenderChartCore refer={modalChartRef} currentHeight="100%" />
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default GraficaBarras