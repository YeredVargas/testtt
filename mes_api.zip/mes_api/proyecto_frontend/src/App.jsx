// src/App.jsx
import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { AuthProvider }    from './context/AuthContext'
import { ToastProvider }   from './components/ui/ToastContext' 
import ProtectedRoute      from './components/auth/ProtectedRoute'
import Landing             from './pages/Landing'
import AppLayout           from './components/layout/AppLayout'
import Dashboard           from './pages/dashboard/Dashboard'
import CatalogoTurnos      from './pages/catalogos/CatalogoTurnos'
import GraficasPage        from './pages/graficas/GraficasPage'
import CostosPage          from './pages/costos/CostosPage'
import TiemposProcesoPage  from './pages/tiempos/TiemposProcesoPage'
import ComparativaPage from './pages/graficas/ComparativaPage'
import SapMesPage          from './pages/sapMes/SapMesPage'

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider> 
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route element={<ProtectedRoute allowedRoles={['ADMIN']} />}>
              <Route path="/app" element={<AppLayout />}>
                <Route index                        element={<Dashboard />} />
                <Route path="dashboard"             element={<Dashboard />} />
                <Route path="dashboard/:proceso"    element={<Dashboard />} />
                <Route path="graficas"              element={<GraficasPage />} />
                <Route path="costos"                element={<CostosPage />} /> 
                <Route path="catalogos/turnos"      element={<CatalogoTurnos />} />
                <Route path="tiempos"               element={<TiemposProcesoPage />} />
                <Route path="tiempos/:proceso"      element={<TiemposProcesoPage />} />
                <Route path="comparativa"           element={<ComparativaPage />} />
                <Route path="sap-mes"               element={<SapMesPage />} />
              </Route>
            </Route>
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}

export default App