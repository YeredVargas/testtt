// src/api/sapConfig.js
// URL de la API de SAP (servicio aparte, puerto 5158).
//
// CORREGIDO (Fase 0): sapClient.js y SapService.js tenian fijo
// "http://localhost:5158". "localhost" se resuelve en la PC de quien abre la
// pagina, no en el servidor, asi que solo funcionaba abriendo el sistema desde
// el propio servidor. Ahora:
//   1) VITE_SAP_API_URL del .env si existe (ya estaba en .env.example), o
//   2) el mismo host desde el que se sirve la pagina, puerto 5158.
const fromEnv = (import.meta.env.VITE_SAP_API_URL || '').trim()

export const SAP_API_URL = (fromEnv ||
  `${window.location.protocol}//${window.location.hostname}:5158/api/v1`
).replace(/\/+$/, '')

const timeoutEnv = Number(import.meta.env.VITE_SAP_TIMEOUT_MS)
export const SAP_TIMEOUT_MS = Number.isFinite(timeoutEnv) && timeoutEnv > 0 ? timeoutEnv : 15000
