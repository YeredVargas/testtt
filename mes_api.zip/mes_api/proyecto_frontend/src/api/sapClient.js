import axios from 'axios';
import { SAP_API_URL, SAP_TIMEOUT_MS } from './sapConfig';

// Cliente exclusivo para el microservicio de SAP (FastAPI en puerto 5158)
const sapClient = axios.create({
  baseURL: SAP_API_URL,
  timeout: SAP_TIMEOUT_MS,
});

sapClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Si la API de SAP está apagada
    if (!error.response) {
      error.isNetworkError = true;
      error.customMessage = "El servicio de conexión a SAP está apagado o inaccesible.";
    }
    return Promise.reject(error);
  }
);

export default sapClient;