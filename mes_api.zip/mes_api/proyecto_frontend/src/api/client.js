import axios from 'axios';

// Cliente para el backend principal (Dashboard, Gráficas, Turnos)
// Aprovecha el proxy de Vite para redirigir a http://localhost:5159
const client = axios.create({
  baseURL: '/api',
  timeout: 10000,
});

client.interceptors.response.use(
  (response) => response,
  (error) => {
    // Si no hay respuesta, el servidor está apagado o hay un problema de red
    if (!error.response) {
      error.isNetworkError = true;
      error.customMessage = "No se pudo conectar con el servidor principal de la interfaz.";
    }
    return Promise.reject(error);
  }
);

export default client;