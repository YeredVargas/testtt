// src/utils/manoObra.js
// Personas equivalentes y % mano de obra / % automatizacion de un conjunto de
// operaciones (todas las de la ruta o las del rango de estaciones elegido).
//
// Regla de planta:
//   0. Tiempos simbolicos: cualquier tiempo <= 0.01 (0.001, 0.01) se toma como 0
//      en las sumas. La operacion SI cuenta como proceso (es automatica).
//   1. Se toma el tiempo de mano de obra (VGW03) de cada operacion.
//   2. Referencia "1 persona" = el valor que MAS VECES se repite; si dos valores
//      empatan, el MAYOR de ellos.
//      Ej. real (OBC FASSY, 0005-0240): 16.667 x18 -> referencia 16.667.
//      Ruta completa: 16.667 x24, 30.303 x3, 50 x2 -> referencia 16.667, y las
//      estaciones de 50 cuentan como 3 personas.
//   3. Cada operacion cuenta como  VGW03 / referencia  personas:
//        5   -> 1 persona
//        2.5 -> 0.5 (una persona puede atender dos de esas operaciones)
//        10  -> 2 personas
//        0   -> 0 (operacion automatica)
//   4. Personas = suma de lo anterior.
//   5. % mano de obra = personas / numero de procesos (TODAS las operaciones
//      seleccionadas) * 100;  % automatizacion = 100 - % mano de obra.
//      Ej. real: 18 personas / 45 procesos = 40 % mano de obra, 60 % automatizacion.
//
// Supone que VGW03 viene en la misma unidad y base en todas las operaciones de
// la ruta (asi lo guarda SAP en una misma hoja de ruta).

export const TIEMPO_MINIMO = 0.01 // <= este valor se considera 0 (tiempo simbolico)
const DECIMALES_IGUALDAD = 4 // 2.5 y 2.50001 cuentan como el mismo valor

const redondear = (v, d) => Math.round(v * 10 ** d) / 10 ** d

/** Tiempo SAP limpio: numero, y 0 si es simbolico (<= 0.01) o invalido. */
export const tiempoReal = (v) => {
  const n = Number(v)
  return Number.isFinite(n) && n > TIEMPO_MINIMO ? n : 0
}

export function calcularManoObra(operaciones) {
  const procesos = operaciones
  const total = procesos.length
  const tiempos = procesos.map((op) => tiempoReal(op.tiempo_mano_obra))
  const conMano = tiempos.filter((t) => t > 0)

  if (total === 0 || conMano.length === 0) {
    return {
      procesos: total,
      procesosConMano: 0,
      procesosAutomaticos: total,
      referencia: null,
      vecesReferencia: 0,
      personas: 0,
      pctManoObra: 0,
      pctAutomatizacion: total ? 100 : 0,
      sinDatos: true,
      detalle: [],
    }
  }

  // Frecuencia de cada valor de mano de obra.
  const frecuencia = new Map()
  conMano.forEach((t) => {
    const llave = redondear(t, DECIMALES_IGUALDAD)
    frecuencia.set(llave, (frecuencia.get(llave) || 0) + 1)
  })
  // Referencia: el valor que mas veces se repite; en empate, el mayor.
  const [referencia, veces] = [...frecuencia.entries()].reduce((mejor, actual) =>
    actual[1] > mejor[1] || (actual[1] === mejor[1] && actual[0] > mejor[0]) ? actual : mejor
  )

  const detalle = procesos.map((op, i) => ({
    operacion_num: op.operacion_num,
    descripcion: op.descripcion,
    tiempo_mano_obra: tiempos[i],
    personas: tiempos[i] > 0 ? tiempos[i] / referencia : 0,
  }))
  const personas = detalle.reduce((s, d) => s + d.personas, 0)
  // Si alguna operacion pide mas de una persona, el % podria pasar de 100:
  // se topa en 100 % para la grafica (las personas se reportan completas).
  const pctManoObra = Math.min(100, (personas / total) * 100)

  return {
    procesos: total,
    procesosConMano: conMano.length,
    procesosAutomaticos: total - conMano.length,
    referencia,
    vecesReferencia: veces,
    personas: redondear(personas, 2),
    pctManoObra: redondear(pctManoObra, 1),
    pctAutomatizacion: redondear(100 - pctManoObra, 1),
    sinDatos: false,
    detalle,
  }
}
