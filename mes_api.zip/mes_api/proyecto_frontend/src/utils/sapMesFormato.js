// src/utils/sapMesFormato.js
// Helpers de formato y metadatos del apartado SAP/MES (sin JSX).

// Validados con el validador de paleta (CVD y contraste sobre blanco: PASS).
export const COLOR_SAP = '#2a78d6'
export const COLOR_MES = '#eb6834'

// Estados de la comparacion. El color nunca va solo: siempre icono + texto.
export const ESTADOS = {
  OK:             { label: 'En tolerancia',   clase: 'text-green-700 bg-green-50 border-green-200',  icono: 'ok' },
  MES_MAS_LENTO:  { label: 'MES más lento',   clase: 'text-red-700 bg-red-50 border-red-200',        icono: 'lento' },
  MES_MAS_RAPIDO: { label: 'MES más rápido',  clase: 'text-amber-800 bg-amber-50 border-amber-200',  icono: 'rapido' },
  SIN_DATOS_MES:  { label: 'Sin datos MES',   clase: 'text-gray-600 bg-gray-50 border-gray-200',     icono: 'vacio' },
  SIN_MAPEO:      { label: 'Sin mapeo',       clase: 'text-gray-500 bg-white border-dashed border-gray-300', icono: 'mapeo' },
  SIN_TIEMPO_SAP: { label: 'Sin tiempo SAP',  clase: 'text-gray-500 bg-gray-50 border-gray-200',     icono: 'vacio' },
}

export const ESTADISTICOS = [
  { value: 'mediana', label: 'Mediana' },
  { value: 'promedio', label: 'Promedio' },
  { value: 'p75', label: 'Percentil 75' },
  { value: 'p90', label: 'Percentil 90' },
]

// Tiempos de la hoja de ruta SAP que se pueden comparar contra MES (columnas de trazabilidad).
export const CAMPOS_TIEMPO_SAP = [
  { value: 'tiempo', vgw: 'VGW01', label: 'Tiempo de operación' },
  { value: 'tiempo_preparacion', vgw: 'VGW02', label: 'Tiempo de preparación' },
  { value: 'tiempo_mano_obra', vgw: 'VGW03', label: 'Mano de obra' },
]

export const etiquetaCampoTiempo = (campo) => {
  const c = CAMPOS_TIEMPO_SAP.find((x) => x.value === campo) || CAMPOS_TIEMPO_SAP[0]
  return `${c.label} (${c.vgw})`
}

export const num = (v, dec = 1) =>
  v === null || v === undefined || Number.isNaN(Number(v))
    ? '—'
    : Number(v).toLocaleString('es-MX', { minimumFractionDigits: dec, maximumFractionDigits: dec })

export const pct = (v) => (v === null || v === undefined ? '—' : `${v > 0 ? '+' : ''}${num(v, 1)}%`)

export const fechaCorta = (iso) => {
  if (!iso) return '—'
  const [y, m, d] = iso.split('-')
  return `${d}.${m}.${y}`
}

// 'YYYY-MM-DD' (input date) <-> 'YYYYMMDD' (API)
export const aApi = (isoDate) => (isoDate ? isoDate.replaceAll('-', '') : '')

export const isoHoyMenos = (dias) => {
  const d = new Date()
  d.setDate(d.getDate() - dias)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

export const ORIGEN_REGLA = {
  MATERIAL_ALTERNATIVA: 'Manual · esta alternativa',
  MATERIAL: 'Manual · este material',
  CLAVE: 'Manual · general por clave',
  AUTO_T435T: 'Automático (T435T)',
}

// De donde sale el numero de equipos de la operacion.
export const ORIGEN_EQUIPOS = {
  REGLA: { corto: 'regla', largo: 'Capturado en el mapeo' },
  MES: { corto: 'MES', largo: 'Recursos (RESRCE) distintos que MES vio trabajar en el rango' },
  DEFAULT: { corto: '—', largo: 'Sin dato: se asume 1' },
}

// 'YYYYMMDD' -> 'dd.mm.yyyy'
export const fechaApiCorta = (s) => (s && s.length === 8 ? `${s.slice(6)}.${s.slice(4, 6)}.${s.slice(0, 4)}` : '—')
