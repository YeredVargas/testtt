// src/context/AuthContext.jsx
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query'; 

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate();
  // 🐛 FIX: Instanciamos el QueryClient para poder vaciar la memoria
  const queryClient = useQueryClient(); 
  
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('user');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setUser(parsed);
        setIsAuthenticated(true);
      } catch {
        localStorage.removeItem('user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = useCallback(async (no_nomina, _password) => {
    const fakeUser = { no_nomina, rol: 'ADMIN', nombre: 'Usuario Kostal' };
    localStorage.setItem('user', JSON.stringify(fakeUser));
    setUser(fakeUser);
    setIsAuthenticated(true);
    return fakeUser;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('user');
    setUser(null);
    setIsAuthenticated(false);
    setIsLoading(false);

    // 🐛 FIX: Fuga de Datos en Caché
    // Destruye toda la memoria de React Query. Ningún usuario
    // posterior podrá acceder a información residual protegida.
    queryClient.clear();

    navigate('/');
  }, [navigate, queryClient]);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}; 