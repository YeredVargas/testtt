import React from 'react'
import ReactDOM from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ToastProvider } from './components/ui/ToastContext'
import App from './App'
import './styles/global.css'

// Configuración Global para Graceful Degradation
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: (failureCount, error) => {
        // Si el interceptor de Axios detectó que la API está apagada, no reintentamos
        if (error.isNetworkError) {
          return false;
        }
        // Para errores normales (ej. un 500 del servidor), reintenta máximo 2 veces
        return failureCount < 2;
      },
      // Evita que intente reconectar al cambiar de pestaña si la API está apagada
      refetchOnWindowFocus: false, 
    },
  },
})

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <App />
      </ToastProvider>
    </QueryClientProvider>
  </React.StrictMode>,
)