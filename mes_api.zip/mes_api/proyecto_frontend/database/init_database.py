# database/init_database.py  
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

from app.config import Base, engine

from database.migrations.dashboard.migration_dashboard        import up as migrate_dashboard
from database.seeders.dashboard.catalogo_procesos_seeder      import run as seed_catalogo_procesos


def main():
    Base.metadata.drop_all(bind=engine)
    print("Todas las tablas fueron eliminadas")

    migrate_dashboard();         print("Migración de dashboard ejecutada (piezas, catalogo_procesos, trazabilidad)")
    seed_catalogo_procesos();    print("Seeder de catálogo de procesos ejecutado")


if __name__ == "__main__":
    main()
