import os
import sys
import logging
import mimetypes


mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("image/svg+xml", ".svg")

def get_base_path():
    """Resuelve la ruta base dependiendo de si se ejecuta desde IDE o compilado (.exe)"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

base_path = get_base_path()

if getattr(sys, 'frozen', False):
    try:
        _log_path = os.path.join(base_path, "OpTimeSAP.log")
        _log_file = open(_log_path, "a", buffering=1, encoding="utf-8")
        sys.stdout = _log_file
        sys.stderr = _log_file
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
            stream=_log_file,
            force=True,
        )
    except Exception:
        pass 

from dotenv import load_dotenv
load_dotenv(os.path.join(base_path, ".env"))

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from app.config import setup_cors
from app.routes import router

app = FastAPI(title="OpTimeSAP")


@app.on_event("startup")
def _crear_tablas_sap_mes():
    # Tablas nuevas del apartado SAP/MES (idempotente; nunca borra nada).
    from app.services.sap_mes.schema import asegurar_tablas_sap_mes
    asegurar_tablas_sap_mes()


setup_cors(app)

app.include_router(router)

dist_path = os.path.join(base_path, "dist")

if os.path.exists(dist_path):
    print("-> EXITOSO: Carpeta dist ENCONTRADA. Montando React SPA...")
    
    assets_path = os.path.join(dist_path, "assets")
    if os.path.exists(assets_path):
        app.mount("/assets", StaticFiles(directory=assets_path), name="assets")

    @app.get("/")
    def serve_root():
        return FileResponse(os.path.join(dist_path, "index.html"))

    @app.get("/{catchall:path}")
    def serve_spa(request: Request, catchall: str):
        if request.url.path.startswith("/api"):
            return JSONResponse({"detail": "Not Found in API"}, status_code=404)
            
        file_path = os.path.join(dist_path, catchall)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return FileResponse(file_path)
            
        return FileResponse(os.path.join(dist_path, "index.html"))
else:
    print("-> ERROR FATAL: Carpeta dist NO ENCONTRADA.")
    print("FastAPI iniciará solo como API en modo 'Headless'. El frontend no funcionará.")


if __name__ == "__main__":
    import uvicorn
    host = os.getenv("APP_HOST", "0.0.0.0")
    port = int(os.getenv("APP_PORT", 8000))
    uvicorn.run(app, host=host, port=port, log_level="info", access_log=True)