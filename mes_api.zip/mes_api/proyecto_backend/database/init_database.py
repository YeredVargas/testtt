# database/init_database.py
"""
Inicializacion MANUAL de tablas del backend.

CORREGIDO (Fase 0): antes ejecutaba Base.metadata.drop_all() SIEMPRE, sin
preguntar. Correrlo por error contra produccion borraba piezas, trazabilidad
y costos. Ahora:
  - Por defecto SOLO crea lo que falte (no borra nada).
  - Borrar todo exige  --reset  y escribir el nombre de la base de datos.

Nota: las tablas piezas/trazabilidad/catalogo_procesos/costos las crea la API
de SAP al arrancar. Las tablas del modulo SAP/MES las crea este backend al
arrancar (app/services/sap_mes/schema.py). Este script queda para desarrollo.
"""
import argparse
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

from app.config import Base, engine, DB_NAME  # noqa: E402

from database.migrations.dashboard.migration_dashboard   import up as migrate_dashboard  # noqa: E402
from database.seeders.dashboard.catalogo_procesos_seeder import run as seed_catalogo_procesos  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="Inicializa tablas del backend OpTimeSAP.")
    parser.add_argument("--reset", action="store_true", help="BORRA todas las tablas antes de crearlas.")
    args = parser.parse_args()

    if args.reset:
        print(f"PRECAUCION: se van a BORRAR TODAS las tablas de la base '{DB_NAME}'.")
        confirmacion = input("Escribe el nombre de la base de datos para confirmar: ").strip()
        if confirmacion != DB_NAME:
            print("Confirmacion incorrecta. No se borro nada.")
            return
        Base.metadata.drop_all(bind=engine)
        print("Todas las tablas fueron eliminadas")

    migrate_dashboard();         print("Migracion de dashboard ejecutada (piezas, catalogo_procesos, trazabilidad)")
    seed_catalogo_procesos();    print("Seeder de catalogo de procesos ejecutado")


if __name__ == "__main__":
    main()
