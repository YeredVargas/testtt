# database/seeders/dashboard/catalogo_procesos_seeder.py
from app.config import SessionLocal
from app.models.dashboard.catalogo_proceso import CatalogoProceso

CENTRO = "0094"

PROCESOS = [
    # SMT
    ("RPBLM",    "SMT"), ("RPBSPPB", "SMT"), ("RPBSPIB", "SMT"), ("RPBSMDB",  "SMT"),
    ("RPBRFLB",  "SMT"), ("RPBAOIB", "SMT"), ("RPBOIAB", "SMT"), ("RPBFSH",   "SMT"),
    ("RLASER",   "SMT"), ("RSPP_B",  "SMT"), ("RSPI_B",  "SMT"), ("RSMT_B",   "SMT"),
    ("ROVEN_B",  "SMT"), ("RAOI_B",  "SMT"), ("ROIA_B",  "SMT"), ("RFLASH",   "SMT"),
    ("RPBSPPT",  "SMT"), ("RPBSPIT", "SMT"), ("RPBSMDT", "SMT"), ("RPBRFLT",  "SMT"),
    ("RPBAOIT",  "SMT"), ("RPBOIAT", "SMT"), ("RSPP_T",  "SMT"), ("RSPI_T",   "SMT"),
    ("RSMT_T",   "SMT"), ("ROVEN_T", "SMT"), ("RAOI_T",  "SMT"), ("ROIA_T",   "SMT"),
    # CONFORMAL
    ("RPBCCO",   "CONFORMAL"), ("RPBCOC", "CONFORMAL"), ("RPBCOA", "CONFORMAL"),
    ("RPBCOO",   "CONFORMAL"), ("RCOAT",  "CONFORMAL"),
    # PINNING
    ("RPBPIN",   "PINNING"), ("RPING", "PINNING"), ("RPING1", "PINNING"),
    # LASER
    ("RPBLMMY",  "LASER"),
    # SOCKET
    ("RPBSKT",   "SOCKET"),
    # ENSAMBLE MANUAL
    ("RPBMASY",  "ENSAMBLE MANUAL"), ("RMASSY",  "ENSAMBLE MANUAL"), ("RMASSY2", "ENSAMBLE MANUAL"),
    ("RPBWAV",   "ENSAMBLE MANUAL"), ("RWAVE",   "ENSAMBLE MANUAL"), ("RPBAOI",  "ENSAMBLE MANUAL"),
    ("RPBOIA",   "ENSAMBLE MANUAL"),
    # ICT OFFLINE
    ("RPBICT",   "ICT OFFLINE"), ("RICT", "ICT OFFLINE"),
    # ROUTER OFFLINE
    ("RPBMIL",   "ROUTER OFFLINE"), ("RMILL", "ROUTER OFFLINE"),
    # SILICON
    ("RGLUE",    "SILICON"), ("RPBGLU", "SILICON"),
    # AXI
    ("RPBAXI",   "AXI"),
    # WATER SPIDER
    ('WS_KEMM', 'WATER SPIDER'),
]


def run():
    session = SessionLocal()
    try:
        for codigo, seccion in PROCESOS:
            # La llave primaria real es (codigo, centro); antes se buscaba solo por codigo.
            existing = session.get(CatalogoProceso, (codigo, CENTRO))
            if existing:
                if not existing.bloqueado:
                    existing.seccion = seccion
            else:
                session.add(CatalogoProceso(codigo=codigo, centro=CENTRO, seccion=seccion))
        session.commit()
        print(f"  → {len(PROCESOS)} procesos insertados/actualizados en catálogo.")
    finally:
        session.close()
