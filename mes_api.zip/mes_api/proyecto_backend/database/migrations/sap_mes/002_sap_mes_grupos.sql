-- =====================================================================
--  002 - Modulo SAP/MES: grupos de procesos (rangos de operaciones con nombre)
--  El backend OpTimeSAP la crea solo al arrancar (IF NOT EXISTS).
--  Este archivo es para revisarlo o correrlo a mano en DBeaver.
--  No modifica ninguna tabla existente.
-- =====================================================================
BEGIN;

CREATE TABLE IF NOT EXISTS sap_mes_grupo (
    id              SERIAL PRIMARY KEY,
    centro          VARCHAR(4)  NOT NULL DEFAULT '0094',
    numero_material VARCHAR(50) NOT NULL,
    plnal           VARCHAR(10),            -- NULL = todas las alternativas
    nombre          VARCHAR(60) NOT NULL,
    op_inicio       VARCHAR(20) NOT NULL,   -- operacion SAP inicial (inclusive)
    op_fin          VARCHAR(20) NOT NULL,   -- operacion SAP final (inclusive)
    orden           INTEGER     NOT NULL DEFAULT 0,
    activo          BOOLEAN     NOT NULL DEFAULT TRUE,
    creado_en       TIMESTAMP   DEFAULT now(),
    modificado_en   TIMESTAMP   DEFAULT now(),
    CONSTRAINT ck_sap_mes_grupo_nombre CHECK (length(trim(nombre)) > 0)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sap_mes_grupo_nombre
    ON sap_mes_grupo (centro, numero_material, COALESCE(plnal, ''), lower(nombre));
CREATE INDEX IF NOT EXISTS ix_sap_mes_grupo_material ON sap_mes_grupo (centro, numero_material);

COMMIT;

-- Verificacion:
-- SELECT * FROM sap_mes_grupo ORDER BY numero_material, orden, id;
