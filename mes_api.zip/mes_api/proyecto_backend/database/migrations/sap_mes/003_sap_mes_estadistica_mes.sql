-- =====================================================================
--  003 - Modulo SAP/MES: historico de estadisticas MES (Fase 16)
--  El backend OpTimeSAP la crea solo al arrancar (IF NOT EXISTS).
--  Este archivo es para revisarlo o correrlo a mano en DBeaver.
--  No modifica ninguna tabla existente.
-- =====================================================================
BEGIN;

CREATE TABLE IF NOT EXISTS sap_mes_estadistica_mes (
    id             SERIAL PRIMARY KEY,
    material       VARCHAR(50)  NOT NULL,   -- sin ceros a la izquierda
    operation      VARCHAR(100) NOT NULL,   -- estacion MES
    start_date     VARCHAR(8)   NOT NULL,   -- YYYYMMDD
    end_date       VARCHAR(8)   NOT NULL,   -- YYYYMMDD inclusive
    max_gap_sec    DOUBLE PRECISION NOT NULL,
    max_ct_sec     DOUBLE PRECISION NOT NULL,
    proceso        JSONB,                   -- {n, excluidos, promedio, mediana, p25, p75, p90, minimo, maximo}
    salida         JSONB,                   -- igual; SIN dividir (el ÷ se aplica al comparar)
    recursos       INTEGER      NOT NULL DEFAULT 0,
    lista_recursos JSONB,
    gmasite        VARCHAR(20),
    consultado_en  TIMESTAMP    NOT NULL DEFAULT now(),
    CONSTRAINT uq_sap_mes_estadistica_mes
        UNIQUE (material, operation, start_date, end_date, max_gap_sec, max_ct_sec)
);

CREATE INDEX IF NOT EXISTS ix_sap_mes_estadistica_mes_buscar
    ON sap_mes_estadistica_mes (material, operation, consultado_en);

COMMIT;

-- Ver lo guardado de un material:
-- SELECT operation, start_date, end_date, proceso->>'mediana' AS proceso_mediana,
--        salida->>'mediana' AS salida_mediana, consultado_en
-- FROM sap_mes_estadistica_mes WHERE material = '12171980'
-- ORDER BY consultado_en DESC, operation;
