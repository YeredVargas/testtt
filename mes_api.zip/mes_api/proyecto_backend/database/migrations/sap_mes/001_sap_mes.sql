-- =====================================================================
--  001 - Modulo SAP/MES: reglas de mapeo operacion SAP -> operacion(es) MES
--  El backend OpTimeSAP las crea solo al arrancar (IF NOT EXISTS).
--  Este archivo es para revisarlo o correrlo a mano en DBeaver.
--  No modifica ninguna tabla existente.
-- =====================================================================
BEGIN;

CREATE TABLE IF NOT EXISTS sap_mes_regla (
    id              SERIAL PRIMARY KEY,
    centro          VARCHAR(4)   NOT NULL DEFAULT '0094',
    alcance         VARCHAR(10)  NOT NULL,
    numero_material VARCHAR(50),
    plnal           VARCHAR(10),
    operacion_num   VARCHAR(20),
    clave_modelo    VARCHAR(50),
    equipos         INTEGER      NOT NULL DEFAULT 1,
    agregacion      VARCHAR(10)  NOT NULL DEFAULT 'SERIE',
    notas           VARCHAR(255),
    activo          BOOLEAN      NOT NULL DEFAULT TRUE,
    creado_en       TIMESTAMP    DEFAULT now(),
    modificado_en   TIMESTAMP    DEFAULT now(),
    CONSTRAINT ck_sap_mes_regla_alcance    CHECK (alcance IN ('MATERIAL','CLAVE')),
    CONSTRAINT ck_sap_mes_regla_agregacion CHECK (agregacion IN ('SERIE','PARALELO')),
    CONSTRAINT ck_sap_mes_regla_equipos    CHECK (equipos >= 1),
    CONSTRAINT ck_sap_mes_regla_llave CHECK (
        (alcance = 'MATERIAL' AND numero_material IS NOT NULL AND operacion_num IS NOT NULL)
        OR (alcance = 'CLAVE' AND clave_modelo IS NOT NULL)
    )
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_sap_mes_regla_llave ON sap_mes_regla (
    centro, alcance,
    COALESCE(numero_material, ''), COALESCE(plnal, ''),
    COALESCE(operacion_num, ''),   COALESCE(clave_modelo, '')
);
CREATE INDEX IF NOT EXISTS ix_sap_mes_regla_material ON sap_mes_regla (centro, numero_material);

CREATE TABLE IF NOT EXISTS sap_mes_regla_operacion (
    id            SERIAL PRIMARY KEY,
    regla_id      INTEGER      NOT NULL REFERENCES sap_mes_regla(id) ON DELETE CASCADE,
    mes_operation VARCHAR(100) NOT NULL,
    orden         INTEGER      NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sap_mes_regla_operacion ON sap_mes_regla_operacion (regla_id, mes_operation);

COMMIT;

-- Verificacion:
-- SELECT r.*, o.mes_operation FROM sap_mes_regla r LEFT JOIN sap_mes_regla_operacion o ON o.regla_id = r.id ORDER BY r.id;
