-- =====================================================================
--  003 - Modulo SAP/MES: relacion SAP vs MES operacion por operacion (Fase 17)
--  El backend OpTimeSAP la crea solo al arrancar (IF NOT EXISTS) y la llena
--  cada vez que se compara un material. Este archivo es para revisarla o
--  crearla a mano en DBeaver. No modifica ninguna tabla existente.
-- =====================================================================
BEGIN;

CREATE TABLE IF NOT EXISTS sap_mes_relacion (
    id                 SERIAL PRIMARY KEY,
    centro             VARCHAR(4)   NOT NULL,
    numero_material    VARCHAR(50)  NOT NULL,
    nombre_pieza       VARCHAR(255),
    plnal              VARCHAR(10)  NOT NULL,   -- alternativa SAP
    version_sap        DATE,                    -- version SAP comparada
    operacion_num      VARCHAR(20)  NOT NULL,   -- VORNR
    descripcion        VARCHAR(255),
    clave_modelo       VARCHAR(50),
    -- relacion con MES
    mes_operations     VARCHAR(500),            -- estaciones MES, separadas por coma
    mapeo_origen       VARCHAR(30),             -- MATERIAL_ALTERNATIVA | MATERIAL | CLAVE | AUTO_T435T
    agregacion         VARCHAR(10),             -- SERIE | PARALELO
    equipos            INTEGER,
    equipos_origen     VARCHAR(10),             -- REGLA | MES | DEFAULT
    -- cantidad SAP
    campo_tiempo       VARCHAR(30),             -- tiempo | tiempo_preparacion | tiempo_mano_obra
    sap_tiempo         DOUBLE PRECISION,        -- valor tal cual en SAP
    sap_unidad         VARCHAR(10),
    sap_cantidad_base  DOUBLE PRECISION,
    sap_seg_pz         DOUBLE PRECISION,
    sap_seg_pz_equipos DOUBLE PRECISION,
    -- cantidad MES (ultimo dato obtenido)
    material_mes       VARCHAR(50),
    mes_proceso_seg_pz DOUBLE PRECISION,
    mes_proceso_piezas INTEGER,
    mes_salida_seg_pz  DOUBLE PRECISION,        -- ya con "MES salida ÷"
    mes_salida_piezas  INTEGER,
    divisor_salida     DOUBLE PRECISION,
    estadistico        VARCHAR(10),
    mes_desde          VARCHAR(8),
    mes_hasta          VARCHAR(8),
    mes_fuente         VARCHAR(10),             -- HANA | BD
    mes_actualizado_en TIMESTAMP,
    -- diferencia (MES - SAP)
    dif_proceso_pct    DOUBLE PRECISION,
    estado_proceso     VARCHAR(20),
    dif_salida_pct     DOUBLE PRECISION,
    estado_salida      VARCHAR(20),
    actualizado_en     TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT uq_sap_mes_relacion UNIQUE (centro, numero_material, plnal, operacion_num)
);

CREATE INDEX IF NOT EXISTS ix_sap_mes_relacion_material ON sap_mes_relacion (centro, numero_material);

COMMIT;

-- Relacion de un material, operacion por operacion:
-- SELECT operacion_num, descripcion, mes_operations,
--        sap_seg_pz, mes_proceso_seg_pz, mes_proceso_piezas,
--        sap_seg_pz_equipos, mes_salida_seg_pz, mes_salida_piezas,
--        dif_proceso_pct, estado_proceso, mes_fuente, actualizado_en
-- FROM sap_mes_relacion
-- WHERE centro = '0094' AND numero_material = '12171980'
-- ORDER BY plnal, operacion_num;
