-- =====================================================================
--  API de MES v3: historico de estadisticas de ciclo
--  La API la crea sola al arrancar (si puede conectarse a PostgreSQL).
--  Este archivo es para revisarlo o correrlo a mano en DBeaver.
--  No modifica ninguna tabla existente.
-- =====================================================================
BEGIN;

CREATE TABLE IF NOT EXISTS mes_ciclo_estadistica (
    id             SERIAL PRIMARY KEY,
    gmasite        VARCHAR(10)  NOT NULL,
    material       VARCHAR(50)  NOT NULL,   -- sin ceros a la izquierda
    operation      VARCHAR(100) NOT NULL,   -- estacion MES
    start_date     VARCHAR(8)   NOT NULL,   -- YYYYMMDD
    end_date       VARCHAR(8)   NOT NULL,   -- YYYYMMDD inclusive
    max_gap_sec    DOUBLE PRECISION NOT NULL,
    max_ct_sec     DOUBLE PRECISION NOT NULL,
    proceso        JSONB NOT NULL,          -- {n, excluidos, promedio, mediana, p25, p75, p90, minimo, maximo}
    salida         JSONB NOT NULL,
    recursos       INTEGER NOT NULL DEFAULT 0,
    lista_recursos JSONB,
    consultado_en  TIMESTAMP NOT NULL DEFAULT now(),
    CONSTRAINT uq_mes_ciclo_estadistica
        UNIQUE (gmasite, material, operation, start_date, end_date, max_gap_sec, max_ct_sec)
);

CREATE INDEX IF NOT EXISTS ix_mes_ciclo_estadistica_buscar
    ON mes_ciclo_estadistica (gmasite, material, operation, consultado_en);

COMMIT;

-- Ver lo guardado:
-- SELECT material, operation, start_date, end_date,
--        proceso->>'mediana' AS proceso_mediana, salida->>'mediana' AS salida_mediana, consultado_en
-- FROM mes_ciclo_estadistica WHERE material = '12171980'
-- ORDER BY consultado_en DESC, operation;
