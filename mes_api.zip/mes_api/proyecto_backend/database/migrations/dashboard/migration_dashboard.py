# database/migrations/dashboard/migration_dashboard.py
from app.config import Base, engine
from app.models.dashboard.pieza import Pieza
from app.models.dashboard.catalogo_proceso import CatalogoProceso
from app.models.dashboard.trazabilidad import Trazabilidad


def up():
    Base.metadata.create_all(
        bind=engine,
        tables=[
            Pieza.__table__,
            CatalogoProceso.__table__,
            Trazabilidad.__table__,
        ],
    )
