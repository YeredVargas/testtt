from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


APP_NAME = "api_saphana"
BUILD_DIR = Path(__file__).resolve().parent  # C:\...\proyecto_backend\script
PROJECT_ROOT = BUILD_DIR.parent  # C:\...\proyecto_backend (Raíz correcta)
ENTRYPOINT = PROJECT_ROOT / "main.py"
SPEC_PATH = BUILD_DIR / f"{APP_NAME}.spec"
RELEASE_DIR = BUILD_DIR / "release"
WORK_DIR = BUILD_DIR / "work"
OUTPUT_DIR = RELEASE_DIR / APP_NAME
ENV_FILE = PROJECT_ROOT / ".env"
ENV_EXAMPLE_FILE = PROJECT_ROOT / ".env.example"
LOGS_DIR = OUTPUT_DIR / "logs"
# Modificado para requerir los conectores de SAP HANA y PostgreSQL
REQUIRED_MODULES = ("PyInstaller", "fastapi", "uvicorn", "sqlalchemy", "hdbcli", "psycopg")


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def validate_build_paths() -> None:
    generated_paths = (SPEC_PATH, RELEASE_DIR, WORK_DIR, OUTPUT_DIR, LOGS_DIR)

    for path in generated_paths:
        if not is_relative_to(path, BUILD_DIR):
            raise RuntimeError(
                "Todos los artefactos del build deben generarse dentro de "
                f"{BUILD_DIR}. Ruta invalida: {path}"
            )


def has_module(python_executable: Path, module_name: str) -> bool:
    result = subprocess.run(
        [str(python_executable), "-c", f"import {module_name}"],
        capture_output=True,
        check=False,
    )
    return result.returncode == 0


def get_missing_modules(python_executable: Path, module_names: tuple[str, ...]) -> list[str]:
    return [module_name for module_name in module_names if not has_module(python_executable, module_name)]


def resolve_python_executable() -> Path:
    venv_python = PROJECT_ROOT / "venv" / "Scripts" / "python.exe"
    if venv_python.exists():
        missing_modules = get_missing_modules(venv_python, REQUIRED_MODULES)
        if missing_modules:
            missing = ", ".join(missing_modules)
            raise RuntimeError(
                "El build debe ejecutarse con el venv del proyecto para empaquetar las dependencias correctas. "
                f"Faltan modulos en {venv_python}: {missing}."
            )

        return venv_python

    current_python = Path(sys.executable).resolve()
    missing_modules = get_missing_modules(current_python, REQUIRED_MODULES)
    if missing_modules:
        missing = ", ".join(missing_modules)
        raise RuntimeError(
            "No existe un venv del proyecto y el interprete actual no tiene todas las dependencias para empaquetar. "
            f"Faltan modulos en {current_python}: {missing}."
        )

    return current_python


def remove_path(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def clean() -> None:
    print("[1/3] Limpiando artefactos anteriores...")
    remove_path(RELEASE_DIR)
    remove_path(WORK_DIR)
    remove_path(SPEC_PATH)


def compile_app() -> None:
    print("[2/3] Empaquetando backend con PyInstaller...")
    python_executable = resolve_python_executable()
    print(f"  - Python seleccionado: {python_executable}")

    command = [
        str(python_executable),
        "-m",
        "PyInstaller",
        str(ENTRYPOINT),
        "--name",
        APP_NAME,
        "--onedir",
        "--noconfirm",
        "--noconsole",
        "--specpath",
        str(BUILD_DIR),
        "--distpath",
        str(RELEASE_DIR),
        "--workpath",
        str(WORK_DIR),
        "--hidden-import",
        "uvicorn.logging",
        "--hidden-import",
        "uvicorn.loops.auto",
        "--hidden-import",
        "uvicorn.protocols.http.auto",
        "--hidden-import",
        "uvicorn.protocols.websockets.auto",
        "--hidden-import",
        "uvicorn.lifespan.on",
        # Dependencias de BD añadidas como hidden imports
        "--hidden-import",
        "hdbcli",
        "--hidden-import",
        "psycopg",
        # v3: historico MES en PostgreSQL (driver que usa SQLAlchemy)
        "--hidden-import",
        "sqlalchemy.dialects.postgresql.psycopg",
    ]

    subprocess.run(command, cwd=PROJECT_ROOT, check=True)


def copy_environment_file() -> None:
    if ENV_FILE.exists():
        shutil.copy2(ENV_FILE, OUTPUT_DIR / ".env")
        print("  - Archivo .env copiado al release.")
        return

    if ENV_EXAMPLE_FILE.exists():
        shutil.copy2(ENV_EXAMPLE_FILE, OUTPUT_DIR / ".env.example")
        print("  - No existe .env; se copio .env.example como referencia.")
        return

    print("  - No se encontro .env ni .env.example para copiar.")


def post_build() -> None:
    print("[3/3] Preparando carpeta final de distribucion...")

    if not OUTPUT_DIR.exists():
        raise FileNotFoundError(f"No se encontro la salida esperada: {OUTPUT_DIR}")

    copy_environment_file()
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    print("  - Carpeta logs creada en el release.")

    print(f"Release generado en: {OUTPUT_DIR}")


def main() -> None:
    if not ENTRYPOINT.exists():
        raise FileNotFoundError(f"No se encontro el entrypoint: {ENTRYPOINT}")

    validate_build_paths()
    clean()
    compile_app()
    post_build()


if __name__ == "__main__":
    main()