@echo off
echo ===================================================
echo   Iniciando API de Tiepos de Operacion (Puerto 5159)
echo ===================================================

cd /d "%~dp0proyecto_backend" || (
    echo Error: no se pudo entrar a la carpeta proyecto_backend
    pause
    exit /b 1
)

call "venv\Scripts\activate.bat"

uvicorn main:app --host 0.0.0.0 --port 5159

pause