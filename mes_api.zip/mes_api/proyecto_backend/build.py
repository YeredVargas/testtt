import os
import sys
import shutil
import subprocess
from pathlib import Path
from datetime import datetime


PROJECT_ROOT = Path(__file__).resolve().parent
FRONTEND_ROOT = PROJECT_ROOT.parent / "proyecto_frontend"

BUILD_DIR = PROJECT_ROOT / "build_output"
DIST_PATH = BUILD_DIR / "release"
WORK_PATH = BUILD_DIR / "work"
OUTPUT_DIR = DIST_PATH / "OpTimeSAP"

VENV_PYTHON = PROJECT_ROOT / "venv" / "Scripts" / "python.exe"
PYTHON = str(VENV_PYTHON) if VENV_PYTHON.exists() else sys.executable


class Logger:
    """Clase para duplicar la salida estándar a la consola y a un archivo de texto."""
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log_file = open(filename, "w", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log_file.write(message)

    def flush(self):
        self.terminal.flush()
        self.log_file.flush()

log_filename = PROJECT_ROOT / f"build_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
sys.stdout = Logger(log_filename)
sys.stderr = sys.stdout  

def ejecutar_comando(cmd, cwd, shell=False):
    """Ejecuta un comando y captura su salida en el log en tiempo real."""
    print(f"\n[Ejecutando]: {cmd if isinstance(cmd, str) else ' '.join(cmd)}")
    
    process = subprocess.Popen(
        cmd, cwd=str(cwd), shell=shell,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding='utf-8', errors='replace'
    )
    
    for line in process.stdout:
        sys.stdout.write(line)
        sys.stdout.flush()
        
    process.wait()
    
    if process.returncode != 0:
        print(f"\n-> ERROR FATAL: El comando falló con código {process.returncode}")
        sys.exit(process.returncode)


def clean():
    """Limpia archivos temporales y carpetas de builds previos."""
    print("-> Limpiando entorno...")
    files_dir = PROJECT_ROOT / "files"
    if files_dir.exists():
        for lock_file in files_dir.rglob("~$*"):
            try:
                lock_file.unlink()
                print(f"-> Eliminado archivo temporal: {lock_file.name}")
            except PermissionError:
                print(f"-> ADVERTENCIA: No se pudo eliminar {lock_file} (archivo en uso).")

    for folder in (DIST_PATH, WORK_PATH):
        if folder.exists():
            shutil.rmtree(folder, ignore_errors=True)
            print(f"-> Carpeta limpiada: {folder.name}")

def build_frontend():
    """Compila el frontend de React para producción."""
    print("\n===================================================")
    print("PASO 1: Compilando frontend React...")
    print("===================================================")
    
    if not FRONTEND_ROOT.exists():
        print(f"-> ERROR FATAL: No se encontró el proyecto frontend en {FRONTEND_ROOT}")
        sys.exit(1)

    ejecutar_comando("npm run build", cwd=FRONTEND_ROOT, shell=True)
    print("-> Frontend compilado exitosamente.")

def compile_app():
    """Empaqueta el backend usando PyInstaller."""
    print("\n===================================================")
    print("PASO 2: Empaquetando Backend con PyInstaller...")
    print("===================================================")
    
    hidden_imports = [
        "uvicorn.logging", "uvicorn.loops", "uvicorn.loops.auto",
        "uvicorn.protocols", "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
        "uvicorn.protocols.websockets.auto", "uvicorn.lifespan.on",
        "sqlalchemy.dialects.postgresql", "sqlalchemy.dialects.postgresql.psycopg",
        "psycopg", "psycopg.pq", "psycopg._psycopg", "psycopg_binary",
        "passlib", "passlib.handlers", "passlib.handlers.bcrypt", "passlib.handlers.pbkdf2", 
        "passlib.utils", "passlib.utils.binary", "passlib.utils.decor", 
        "passlib.crypto", "passlib.crypto.digest", "passlib.crypto.scrypt",
        "jose", "multipart"
    ]
    
    collect_all = ["hdbcli", "psycopg", "passlib"]
    path_sep = os.pathsep

    cmd = [
        PYTHON, "-m", "PyInstaller",
        str(PROJECT_ROOT / "main.py"),
        "--name", "OpTimeSAP",  
        "--onedir",
        "--noconfirm",
        "--noconsole",
        "--specpath", str(BUILD_DIR),
        "--distpath", str(DIST_PATH),
        "--workpath", str(WORK_PATH)
    ]
    
    if (PROJECT_ROOT / 'files').exists():
        cmd.extend(["--add-data", f"{str(PROJECT_ROOT / 'files')}{path_sep}files"])
    
    for imp in hidden_imports:
        cmd.extend(["--hidden-import", imp])
    for pkg in collect_all:
        cmd.extend(["--collect-all", pkg])

    ejecutar_comando(cmd, cwd=PROJECT_ROOT, shell=False)

def post_build():
    """Mueve los recursos finales a la carpeta del ejecutable compilado."""
    print("\n===================================================")
    print("PASO 3: Ensamblado Final...")
    print("===================================================")
    
    frontend_dist = FRONTEND_ROOT / "dist"
    env_file = PROJECT_ROOT / ".env"

    if frontend_dist.exists():
        shutil.copytree(frontend_dist, OUTPUT_DIR / "dist", dirs_exist_ok=True)
        print("-> Carpeta 'dist' (React) copiada al compilado.")
    else:
        print(f"-> ADVERTENCIA: No se encontró la carpeta 'dist' en {FRONTEND_ROOT}")

    if env_file.exists():
        shutil.copy2(env_file, OUTPUT_DIR / ".env")
        print("-> Archivo '.env' copiado exitosamente.")

    bat_path = OUTPUT_DIR / "run.bat"
    bat_path.write_text(
        "@echo off\r\n"
        "echo Iniciando OpTimeSAP API...\r\n"
        "OpTimeSAP.exe\r\n"
        "pause\r\n",
        encoding="utf-8",
    )
    
    print(f"\n===================================================")
    print(f" COMPILACIÓN TERMINADA CON ÉXITO.")
    print(f" Los logs fueron guardados en: {log_filename.name}")
    print(f" Ubicación de la APP: {OUTPUT_DIR}")
    print(f"===================================================\n")

if __name__ == "__main__":
    try:
        clean()
        build_frontend()
        compile_app()
        post_build()
    except Exception as e:
        print(f"\n[ERROR INESPERADO]: {e}")
        sys.exit(1)