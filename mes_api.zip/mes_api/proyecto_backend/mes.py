import sys
from pathlib import Path

# Asegurar que el script reconozca los módulos de la carpeta 'app'
# (Asumiendo que el script está guardado dentro de 'proyecto_backend')
sys.path.insert(0, str(Path(__file__).resolve().parent))

import hdbcli.dbapi
from app.config import HANA_CONFIG

def ejecutar_consulta_saphana(material: str):
    print(f"Conectando a SAP HANA para buscar el material: {material}...")
    conn = None
    try:
        conn = hdbcli.dbapi.connect(
            address=HANA_CONFIG["address"],
            port=HANA_CONFIG["port"],
            user=HANA_CONFIG["user"],
            password=HANA_CONFIG["password"],
            databaseName=HANA_CONFIG["database"]
        )
        cursor = conn.cursor()
        schema = HANA_CONFIG["schema"]

        # 1. Buscar un SFC cualquiera asociado a ese material
        print("Buscando un SFC disponible...")
        sql_sfc = f"""
        SELECT TOP 1 "SFC"
        FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
            (placeholder."$$F_GMASITE$$"=>'10', 
            placeholder."$$F_CALDAY$$"=>'20260428', 
            placeholder."$$F_DATA_TEMPERATURE$$"=>'9')
        WHERE "MATERIAL" = ? AND "SFC" IS NOT NULL
        """
        # Se pasa el material como tupla parametrizada
        cursor.execute(sql_sfc, (material,))
        sfc_row = cursor.fetchone()

        if not sfc_row:
            print(f"No se encontró ningún SFC para el material {material} en la fecha indicada.")
            return
        
        sfc_encontrado = sfc_row[0]
        print(f"SFC seleccionado aleatoriamente: {sfc_encontrado}\nExtrayendo registros...")

        # 2. Ejecutar el query principal usando el SFC encontrado
        sql_main = f"""
        SELECT TOP 100000
            "SFC", "RESRCE", "OPERATION", "ACTION_CODE", "MATERIAL", "DATE_TIME"
        FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
            (placeholder."$$F_GMASITE$$"=>'10', 
            placeholder."$$F_CALDAY$$"=>'20260428', 
            placeholder."$$F_DATA_TEMPERATURE$$"=>'9')
        WHERE "MATERIAL" = ? AND "SFC" = ?
        """
        cursor.execute(sql_main, (material, sfc_encontrado))
        rows = cursor.fetchall()
        
        print(f"\nÉxito. Se encontraron {len(rows)} registros:\n")
        for row in rows:
            print(f"SFC: {row[0]}, RESRCE: {row[1]}, OP: {row[2]}, ACTION: {row[3]}, MATERIAL: {row[4]}, DATE_TIME: {row[5]}")

    except Exception as e:
        print(f"Error en la base de datos: {str(e)}")
    finally:
        if conn:
            conn.close()
            print("\nConexión cerrada.")

if __name__ == "__main__":
    # Define únicamente el material que quieres consultar
    MATERIAL_A_BUSCAR = '12150829'
    ejecutar_consulta_saphana(MATERIAL_A_BUSCAR)