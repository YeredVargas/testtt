"""
Pruebas de la logica de tiempos ciclo (sin HANA).
Ejecutar desde proyecto_backend:   python -m pytest tests -q
"""
import os
import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("HANA_ADDRESS", "fake")
os.environ.setdefault("HANA_USER", "fake")

from app.services.mes.ciclo_stats import Evento, calcular_estadisticas, percentil, normalizar_material  # noqa: E402

D0 = datetime(2026, 9, 1, 0, 0, 0)
D1 = datetime(2026, 9, 2, 0, 0, 0)


def ev(sfc, mat, op, act, hh, mm, ss):
    return Evento(sfc, mat, op, act, datetime(2026, 9, 1, hh, mm, ss))


def test_percentil_interpolado():
    assert percentil([10, 20, 30, 40], 0.5) == 25
    assert percentil([5], 0.9) == 5
    assert percentil([], 0.5) is None


def test_normalizar_material():
    assert normalizar_material("000000000012171980") == "12171980"
    assert normalizar_material(" abc ") == "ABC"


def test_proceso_empareja_start_complete_y_retrabajo():
    evs = [
        ev("A", "100", "OP1", "START", 8, 0, 0), ev("A", "100", "OP1", "COMPLETE", 8, 0, 30),
        # retrabajo: segunda pasada del mismo SFC
        ev("A", "100", "OP1", "START", 9, 0, 0), ev("A", "100", "OP1", "COMPLETE", 9, 0, 40),
        ev("B", "100", "OP1", "START", 8, 1, 0), ev("B", "100", "OP1", "COMPLETE", 8, 1, 50),
        # COMPLETE sin START: se ignora
        ev("C", "100", "OP1", "COMPLETE", 8, 5, 0),
    ]
    r = calcular_estadisticas(evs, D0, D1)
    fila = next(x for x in r if x["OPERATION"] == "OP1")
    assert fila["proceso"]["n"] == 3
    assert fila["proceso"]["mediana"] == 40
    assert fila["proceso"]["minimo"] == 30 and fila["proceso"]["maximo"] == 50


def test_salida_start_a_start_con_hueco_excluido():
    evs = [
        ev("A", "100", "OP1", "START", 8, 0, 0),
        ev("B", "200", "OP1", "START", 8, 0, 20),   # otro material: cuenta como siguiente
        ev("C", "100", "OP1", "START", 8, 0, 45),
        ev("D", "100", "OP1", "START", 9, 0, 0),    # hueco de ~1h -> excluido
        ev("E", "100", "OP1", "START", 9, 0, 30),
    ]
    r = calcular_estadisticas(evs, D0, D1, materiales={"100"}, max_gap_sec=600)
    fila = next(x for x in r if x["MATERIAL"] == "100")
    assert fila["salida"]["n"] == 2          # A->B (20s), D->E (30s)
    assert fila["salida"]["excluidos"] == 1  # C->D
    assert fila["salida"]["mediana"] == 25
    assert all(x["MATERIAL"] == "100" for x in r)


def test_restart_mismo_sfc_no_es_pieza_nueva():
    evs = [
        ev("A", "100", "OP1", "START", 8, 0, 0),
        ev("A", "100", "OP1", "START", 8, 0, 5),
        ev("B", "100", "OP1", "START", 8, 0, 30),
    ]
    fila = calcular_estadisticas(evs, D0, D1)[0]
    assert fila["salida"]["n"] == 1 and fila["salida"]["mediana"] == 30


def test_ventana_por_complete_local():
    evs = [
        ev("A", "100", "OP1", "START", 23, 59, 50),
        Evento("A", "100", "OP1", "COMPLETE", datetime(2026, 9, 2, 0, 0, 10)),
    ]
    assert calcular_estadisticas(evs, D0, D1) == [] or calcular_estadisticas(evs, D0, D1)[0]["proceso"]["n"] == 0


def test_servicio_con_hana_simulado():
    """Verifica SQL, numero de parametros y conversion UTC->local."""
    from app.services.mes import mes_service

    filas = [
        ("SFC1", "000000000012171980", "OBC_FASSY_ST010", "START",    "20260901140000", "200159045"),
        ("SFC1", "000000000012171980", "OBC_FASSY_ST010", "COMPLETE", "20260901140045", "200159045"),
        ("SFC2", "000000000012171980", "OBC_FASSY_ST010", "START",    "20260901140030", "200159046"),
        ("SFC2", "000000000012171980", "OBC_FASSY_ST010", "COMPLETE", "20260901140120", "200159046"),
    ]

    class Cursor:
        def execute(self, sql, params=None):
            assert sql.count("?") == len(params), (sql, params)
            assert "'20260901-20260902'" in sql  # rango UTC ampliado un dia
            self.sql, self.params = sql, params
            self._rows = list(filas)
        def fetchmany(self, n):
            out, self._rows = self._rows[:n], self._rows[n:]
            return out

    class Conn:
        def cursor(self):
            return Cursor()
        def close(self):
            pass

    with patch.object(mes_service.hdbcli.dbapi, "connect", return_value=Conn()):
        res = mes_service.HanaService().get_ciclo_estadisticas(
            operations=["OBC_FASSY_ST010"], start_date="20260901", end_date="20260901",
            materials=["12171980"],
        )
    assert res["total_eventos"] == 4
    fila = res["data"][0]
    assert fila["MATERIAL"] == "12171980"
    assert fila["proceso"]["n"] == 2 and fila["proceso"]["mediana"] == 47.5
    assert fila["salida"]["n"] == 1 and fila["salida"]["mediana"] == 30
    assert fila["recursos"] == 2 and fila["lista_recursos"] == ["200159045", "200159046"]


def test_fecha_invalida_es_422():
    from fastapi.testclient import TestClient
    from main import app
    c = TestClient(app)
    r = c.get("/api/hana/ciclo-estadisticas", params={"operations": "X", "start_date": "2026-09-01'--", "end_date": "20260902"})
    assert r.status_code == 422
    r = c.get("/api/hana/promedio-diario-ct", params={"start_date": "20260901' OR 1=1--", "end_date": "20260902"})
    assert r.status_code == 422


def test_cycle_time_ya_no_truena():
    """Fase 0: /cycle-time leia row[4] con un SELECT de 4 columnas."""
    from app.services.mes import mes_service

    class Cursor:
        def execute(self, sql, params=None):
            assert sql.count("?") == len(params)
        def fetchall(self):
            return [("2026-09-01 08:00:30", 30, "SFC1", "12171980")]

    class Conn:
        def cursor(self):
            return Cursor()
        def close(self):
            pass

    with patch.object(mes_service.hdbcli.dbapi, "connect", return_value=Conn()):
        r = mes_service.HanaService().get_cycle_time(operation="OP1")
    assert r == [{"time": "2026-09-01 08:00:30", "series": "OP1", "value": 30.0, "SFC": "SFC1", "MATERIAL": "12171980"}]


def test_recursos_distintos_por_operacion():
    evs = [
        Evento("A", "100", "PCB_SMT_B", "START", datetime(2026, 9, 1, 8, 0, 0), "R1"),
        Evento("B", "100", "PCB_SMT_B", "START", datetime(2026, 9, 1, 8, 0, 20), "R2"),
        Evento("C", "100", "PCB_SMT_B", "START", datetime(2026, 9, 1, 8, 0, 40), "R1"),
    ]
    fila = calcular_estadisticas(evs, D0, D1)[0]
    assert fila["recursos"] == 2
