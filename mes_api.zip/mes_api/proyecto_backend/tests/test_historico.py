"""v3: eleccion de la fila guardada (exacta > mas reciente) sin PostgreSQL."""
import sys
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.services.mes import historico  # noqa: E402


def _r(mat, op, ini, fin, med, cuando, gap=600.0, ct=3600.0):
    return SimpleNamespace(material=mat, operation=op, start_date=ini, end_date=fin, max_gap_sec=gap, max_ct_sec=ct,
                           proceso={"n": 10, "excluidos": 0, "mediana": med}, salida={"n": 10, "excluidos": 0, "mediana": med},
                           recursos=1, lista_recursos=["R1"], consultado_en=cuando)


class _Q:
    def __init__(self, filas): self.filas = filas
    def filter(self, *a): return self
    def all(self): return self.filas


def _db(filas):
    return SimpleNamespace(query=lambda *a: _Q(filas))


FILAS = [
    _r("1", "ST10", "20260901", "20260914", 10.0, datetime(2026, 9, 14)),
    _r("1", "ST10", "20260922", "20261005", 11.0, datetime(2026, 10, 5)),
    _r("1", "ST20", "20260801", "20260810", 20.0, datetime(2026, 8, 10)),
]


def test_prefiere_la_consulta_exacta_aunque_sea_mas_vieja():
    r = historico.recuperar(["ST10", "ST20"], ["1"], "20260901", "20260914", 600, 3600, "10", db=_db(FILAS))
    med = {f["OPERATION"]: f["proceso"]["mediana"] for f in r["data"]}
    assert med == {"ST10": 10.0, "ST20": 20.0}
    assert r["historico"]["exactas"] == 1 and r["historico"]["filas"] == 2


def test_sin_exacta_usa_la_mas_reciente():
    r = historico.recuperar(["ST10"], ["1"], "20260101", "20260110", 600, 3600, "10", db=_db(FILAS))
    assert r["data"][0]["proceso"]["mediana"] == 11.0
    assert r["historico"]["exactas"] == 0


def test_limites_distintos_no_son_exacta():
    r = historico.recuperar(["ST10"], ["1"], "20260901", "20260914", 300, 3600, "10", db=_db(FILAS))
    assert r["historico"]["exactas"] == 0


def test_nada_guardado_regresa_none():
    assert historico.recuperar(["ST99"], ["1"], "20260901", "20260914", 600, 3600, "10", db=_db([])) is None
