from pydantic import BaseModel
from typing import List, Optional
 
class SfcResponse(BaseModel):
    SFC: Optional[str] = None
    HNDL_CREATED_DATE_TIME: Optional[str] = None
    OPERATION: Optional[str] = None
    NC_CODE: Optional[str] = None
    TEXT_LONG: Optional[str] = None
    MATERIAL: Optional[str] = None

class CycleTimeResponse(BaseModel):
    time: Optional[str] = None
    series: Optional[str] = None
    value: Optional[float] = None
    SFC: Optional[str] = None
    MATERIAL: Optional[str] = None

class CycleTimeAverageResponse(BaseModel):
    OPERATION: Optional[str] = None
    MATERIAL: Optional[str] = None
    AVG_CYCLE_TIME_SEC: Optional[float] = None
    TOTAL_PIECES: Optional[int] = None

class DailyCycleTimeResponse(BaseModel):
    DATE: Optional[str] = None
    OPERATION: Optional[str] = None
    MATERIAL: Optional[str] = None
    AVG_CYCLE_TIME_SEC: Optional[float] = None
    TOTAL_PIECES: Optional[int] = None


class OperationsCatalogResponse(BaseModel):
    operations: List[str]
    total: int


class StartToStartResponse(BaseModel):
    DATE_TIME: Optional[str] = None
    CYCLE_TIME_SEC: Optional[float] = None
    SFC: Optional[str] = None
    NEXT_SFC: Optional[str] = None
    MATERIAL: Optional[str] = None

class MaterialsCatalogResponse(BaseModel):
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    total: int
    materials: List[str]

class StationCycleTimeSummary(BaseModel):
    OPERATION: str
    MATERIAL: Optional[str] = None
    AVG_CYCLE_TIME_SEC: Optional[float] = None
    TOTAL_PIECES: int

class LineCycleTimeResponse(BaseModel):
    line_filter: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    material: Optional[str] = None
    total_stations: int
    stations: List[StationCycleTimeSummary]

class MaterialMappingItem(BaseModel):
    MATERIAL: str
    SMT: bool
    FASSY: bool
    EOLT: bool
    REWORK: bool
    BACKEND: bool

class MaterialMappingResponse(BaseModel):
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    total_materials: int
    materials: List[MaterialMappingItem]

class MaterialOperationItem(BaseModel):
    MATERIAL: str
    OPERATION: str
    HAS_COMPLETE: bool
    TOTAL_COMPLETES: int

class MaterialOperationMatrixResponse(BaseModel):
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    total_records: int
    data: List[MaterialOperationItem]

class OperationDetail(BaseModel):
    OPERATION: str
    HAS_COMPLETE: bool
    TOTAL_COMPLETES: int

class MaterialOperationsGroup(BaseModel):
    MATERIAL: str
    total_operations: int
    operations: List[OperationDetail]

class MaterialOperationsGroupResponse(BaseModel):
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    total_materials: int
    data: List[MaterialOperationsGroup]

# ===================== FASE 1 - Comparativa SAP/MES =====================
class EstadisticaCiclo(BaseModel):
    n: int
    excluidos: int
    promedio: Optional[float] = None
    mediana: Optional[float] = None
    p25: Optional[float] = None
    p75: Optional[float] = None
    p90: Optional[float] = None
    minimo: Optional[float] = None
    maximo: Optional[float] = None

class CicloMaterialOperacion(BaseModel):
    MATERIAL: str
    OPERATION: str
    proceso: EstadisticaCiclo   # START -> COMPLETE (seg)
    salida: EstadisticaCiclo    # START -> siguiente START (seg)
    recursos: int = 0           # RESRCE distintos (equipos vistos por MES)
    lista_recursos: List[str] = []

class CicloEstadisticasResponse(BaseModel):
    start_date: str
    end_date: str
    gmasite: str
    tz_offset_sec: int
    max_gap_sec: float
    max_ct_sec: float
    total_eventos: int
    eventos_descartados: int
    data: List[CicloMaterialOperacion]
    # v3: "HANA" = en vivo; "BD" = HANA no respondio y se usa lo guardado.
    fuente: str = "HANA"
    motivo: Optional[str] = None
    guardadas_en_bd: Optional[int] = None
    historico: Optional[dict] = None

class OperacionDeMaterial(BaseModel):
    OPERATION: str
    TOTAL_COMPLETES: int
    RECURSOS: int = 0
    ULTIMO_EVENTO: Optional[str] = None

class OperacionesDeMaterialResponse(BaseModel):
    material: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    total: int
    operations: List[OperacionDeMaterial]
    fuente: str = "HANA"
    motivo: Optional[str] = None
