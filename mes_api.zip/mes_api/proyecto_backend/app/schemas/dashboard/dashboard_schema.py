# app/schemas/dashboard/dashboard_schema.py
from pydantic import BaseModel
from typing import List, Optional

class RegistroHistorico(BaseModel):
    fecha_cambio: str
    tiempo: float
    equipos: int
    tiempo_preparacion: Optional[float] = None
    tiempo_mano_obra: Optional[float] = None
    pzs_hr: Optional[float] = None
    seg_pz: Optional[float] = None
    mejora: Optional[float] = None
    mejora_global: Optional[float] = None
    prev_tiempo: Optional[float] = None
    prev_seg_pz: Optional[float] = None
    prev_pzs_hr: Optional[float] = None

class ProcesoAgrupado(BaseModel):
    nombre_proceso: str
    historial: List[RegistroHistorico]

class DashboardMaterialResponse(BaseModel):
    numero_material: str
    nombre_pieza: Optional[str] = None
    proyecto: str
    procesos: List[ProcesoAgrupado]

# --- NUEVO ENVOLTORIO PARA PAGINACIÓN SERVER-SIDE ---
class PaginatedDashboardResponse(BaseModel):
    total_registros: int
    total_paginas: int
    pagina_actual: int
    registros_por_pagina: int
    datos: List[DashboardMaterialResponse]