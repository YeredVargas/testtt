# app/schemas/graficas/graficas_schema.py
from pydantic import BaseModel, ConfigDict
from typing import List, Optional, Dict


class FiltrosDisponibles(BaseModel):
    """Opciones para poblar los selects con soporte de meses dinámicos."""
    procesos:          List[str]
    numeros_material:  List[str]
    proyectos:         List[str]
    meses:             List[Dict[str, str]]  # [{"value": "2026-06", "label": "Junio 2026"}]

    model_config = ConfigDict(from_attributes=True)


class PuntoGraficaHistorico(BaseModel):
    """Un punto en el tiempo para la trazabilidad de un proceso."""
    fecha:          str
    pzs_hr:         float
    seg_pz:         float
    valor:          float  
    tiempo:         float
    equipos:        int

    model_config = ConfigDict(from_attributes=True)


class ResumenPieza(BaseModel):
    nombre_pieza:    Optional[str] = None
    numero_material: str
    proyecto:        Optional[str] = None
    fecha_reciente:  Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class GraficasTraceabilidadResponse(BaseModel):
    """Respuesta optimizada para la trazabilidad de todos los procesos de una pieza."""
    filtros_aplicados:   dict
    resumen:             Optional[ResumenPieza] = None
    graficas:            Dict[str, List[PuntoGraficaHistorico]]  

    model_config = ConfigDict(from_attributes=True)