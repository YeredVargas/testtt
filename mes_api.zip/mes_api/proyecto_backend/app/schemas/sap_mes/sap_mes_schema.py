# app/schemas/sap_mes/sap_mes_schema.py
from typing import List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class ReglaEntrada(BaseModel):
    """Alta / edicion de una regla de mapeo SAP -> MES."""
    centro: str = Field("0094", min_length=4, max_length=4)
    alcance: Literal["MATERIAL", "CLAVE"] = "MATERIAL"
    numero_material: Optional[str] = Field(None, max_length=50)
    plnal: Optional[str] = Field(None, max_length=10, description="Alternativa. Vacio = todas.")
    operacion_num: Optional[str] = Field(None, max_length=20)
    clave_modelo: Optional[str] = Field(None, max_length=50)
    equipos: int = Field(1, ge=1, le=99)
    agregacion: Literal["SERIE", "PARALELO"] = "SERIE"
    notas: Optional[str] = Field(None, max_length=255)
    activo: bool = True
    mes_operations: List[str] = Field(..., min_length=1, max_length=20)

    @field_validator("numero_material", "plnal", "operacion_num", "clave_modelo", "notas", mode="before")
    @classmethod
    def _vacio_a_none(cls, v):
        if v is None:
            return None
        v = str(v).strip()
        return v or None

    @field_validator("mes_operations")
    @classmethod
    def _limpiar_ops(cls, v):
        limpias, vistas = [], set()
        for op in v:
            op = str(op).strip()
            if op and len(op) <= 100 and op not in vistas:
                vistas.add(op)
                limpias.append(op)
        if not limpias:
            raise ValueError("Indica al menos una operacion MES.")
        return limpias

    @model_validator(mode="after")
    def _llave_segun_alcance(self):
        if self.alcance == "MATERIAL":
            if not self.numero_material or not self.operacion_num:
                raise ValueError("Alcance MATERIAL requiere numero_material y operacion_num.")
            self.clave_modelo = None
            if self.numero_material.isdigit():
                self.numero_material = self.numero_material.lstrip("0") or "0"
        else:
            if not self.clave_modelo:
                raise ValueError("Alcance CLAVE requiere clave_modelo.")
            self.clave_modelo = self.clave_modelo.upper()
            self.numero_material = None
            self.plnal = None
            self.operacion_num = None
        return self


class ReglaSalida(BaseModel):
    id: int
    centro: str
    alcance: str
    numero_material: Optional[str] = None
    plnal: Optional[str] = None
    operacion_num: Optional[str] = None
    clave_modelo: Optional[str] = None
    equipos: int
    agregacion: str
    notas: Optional[str] = None
    activo: bool
    mes_operations: List[str]


# ---------------------------------------------------------------------------
# Grupos de procesos (Fase 11)
# ---------------------------------------------------------------------------
def clave_operacion(op: Optional[str]):
    """Orden natural de VORNR: '0100' < '0110' < '1000'; textos al final."""
    texto = (op or "").strip()
    return (0, int(texto), "") if texto.isdigit() else (1, 0, texto)


class GrupoEntrada(BaseModel):
    """Alta / edicion de un grupo de procesos (rango de operaciones con nombre)."""
    centro: str = Field("0094", min_length=4, max_length=4)
    numero_material: str = Field(..., min_length=1, max_length=50)
    plnal: Optional[str] = Field(None, max_length=10, description="Alternativa. Vacio = todas.")
    nombre: str = Field(..., min_length=1, max_length=60)
    op_inicio: str = Field(..., min_length=1, max_length=20)
    op_fin: str = Field(..., min_length=1, max_length=20)
    orden: int = Field(0, ge=0, le=999)
    activo: bool = True

    @field_validator("numero_material", "plnal", "nombre", "op_inicio", "op_fin", mode="before")
    @classmethod
    def _limpiar(cls, v):
        if v is None:
            return None
        v = str(v).strip()
        return v or None

    @model_validator(mode="after")
    def _normalizar(self):
        if self.numero_material.isdigit():
            self.numero_material = self.numero_material.lstrip("0") or "0"
        if clave_operacion(self.op_inicio) > clave_operacion(self.op_fin):
            raise ValueError("La operacion inicial no puede ser posterior a la final.")
        return self


class GrupoSalida(BaseModel):
    id: int
    centro: str
    numero_material: str
    plnal: Optional[str] = None
    nombre: str
    op_inicio: str
    op_fin: str
    orden: int
    activo: bool
