# app/config.py
import os
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from fastapi.middleware.cors import CORSMiddleware

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_NAME = os.getenv("DB_NAME", "scrap_fassy_db")

SQLALCHEMY_DATABASE_URL = (
    f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

engine = create_engine(SQLALCHEMY_DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

APP_HOST = os.getenv("APP_HOST", "0.0.0.0")
APP_PORT = int(os.getenv("APP_PORT", 8000))

# CORREGIDO (Fase 0): antes allow_origins=["10.113.2.242"], que no es un origen
# valido (le falta esquema y puerto) y no se podia cambiar sin tocar codigo.
# Ahora se lee CORS_ORIGINS del .env (ya estaba documentado en .env.example).
CORS_ORIGINS = [
    o.strip()
    for o in os.getenv(
        "CORS_ORIGINS",
        "http://10.113.2.242:5159,http://localhost:5155,http://localhost:5159",
    ).split(",")
    if o.strip()
]

# API de MES (saphanaconnection). La consume este backend, no el navegador.
MES_API_URL = os.getenv("MES_API_URL", "http://10.113.2.242:8015").rstrip("/")
MES_API_TIMEOUT_SEG = int(os.getenv("MES_API_TIMEOUT_SEG", "120"))


def setup_cors(app):
    permite_todo = CORS_ORIGINS == ["*"]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=CORS_ORIGINS,
        allow_credentials=not permite_todo,
        allow_methods=["*"],
        allow_headers=["*"],
    )