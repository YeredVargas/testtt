# app/models/mes/ciclo_estadistica.py
"""
Historico de estadisticas de ciclo MES (v3).

Cada respuesta correcta de /api/hana/ciclo-estadisticas se guarda aqui, una
fila por (material, operacion, periodo, limites). Si despues HANA no responde,
el endpoint contesta con estas filas (fuente = "BD").

Se guardan estadisticas (no ciclos por pieza), por decision del usuario.
"""
from sqlalchemy import Column, DateTime, Float, Index, Integer, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB

from app.config import Base


class MesCicloEstadistica(Base):
    __tablename__ = "mes_ciclo_estadistica"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    gmasite        = Column(String(10), nullable=False)
    material       = Column(String(50), nullable=False)     # normalizado, sin ceros a la izquierda
    operation      = Column(String(100), nullable=False)
    start_date     = Column(String(8), nullable=False)      # YYYYMMDD
    end_date       = Column(String(8), nullable=False)      # YYYYMMDD inclusive
    max_gap_sec    = Column(Float, nullable=False)
    max_ct_sec     = Column(Float, nullable=False)
    proceso        = Column(JSONB, nullable=False)          # {n, excluidos, promedio, mediana, p25, p75, p90, minimo, maximo}
    salida         = Column(JSONB, nullable=False)
    recursos       = Column(Integer, nullable=False, server_default="0")
    lista_recursos = Column(JSONB)
    consultado_en  = Column(DateTime, nullable=False, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("gmasite", "material", "operation", "start_date", "end_date", "max_gap_sec", "max_ct_sec",
                         name="uq_mes_ciclo_estadistica"),
        Index("ix_mes_ciclo_estadistica_buscar", "gmasite", "material", "operation", "consultado_en"),
    )
