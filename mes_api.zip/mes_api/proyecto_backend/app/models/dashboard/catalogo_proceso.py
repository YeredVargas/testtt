# app/models/dashboard/catalogo_proceso.py
"""
Refleja `catalogo_procesos` tal como la crea la API de SAP.
CORREGIDO (Fase 0): el modelo local no tenia `centro` (parte de la llave
primaria real), `activo`, `bloqueado` ni `modificado_en`.
"""
from sqlalchemy import Column, String, Boolean, TIMESTAMP, func
from app.config import Base


class CatalogoProceso(Base):
    __tablename__ = "catalogo_procesos"

    codigo        = Column(String(50), primary_key=True)
    centro        = Column(String(4), primary_key=True, server_default='0094')
    seccion       = Column(String(50), nullable=False)
    activo        = Column(Boolean, nullable=False, server_default="true")
    bloqueado     = Column(Boolean, nullable=False, server_default="false")
    creado_en     = Column(TIMESTAMP, server_default=func.now())
    modificado_en = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())
