# app/models/dashboard/trazabilidad.py
"""
Modelo de la tabla `trazabilidad` (hoja de ruta por pieza, con historial).

La tabla la CREA y LLENA la API de SAP (api_sap/db/models.py). Este modelo debe
reflejar exactamente esas columnas.

CORREGIDO (Fase 0):
  - Declaraba `creado_el` / `modificado_el`, columnas que NO existen en la BD
    (las reales son `creado_sap` / `modificado_sap`). Cualquier consulta que
    cargara la entidad completa (db.query(Trazabilidad)) fallaba con
    UndefinedColumn. Se agregan tambien las columnas que faltaban.
  - Este archivo tambien definia los modelos de costos, duplicados en
    app/models/costos/costos.py con restricciones distintas. Importar ambos
    provocaba "Table 'costos_ck13n_cabecera' is already defined". Ahora los
    costos viven SOLO en costos.py y aqui se re-exportan para no romper imports.
"""
from sqlalchemy import Column, Integer, String, Numeric, Date, ForeignKey, DateTime
from sqlalchemy.sql import func

from app.config import Base


class Trazabilidad(Base):
    __tablename__ = "trazabilidad"

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    pieza_id           = Column(Integer, ForeignKey("piezas.id", ondelete="CASCADE"), nullable=False)
    operacion_num      = Column(String(20), nullable=False)
    descripcion        = Column(String(255))
    clave_modelo       = Column(String(50))
    codigo_busqueda    = Column(String(50))
    proceso            = Column(String(50), nullable=True)
    steus              = Column(String(20))
    plnnr              = Column(String(40))
    plnal              = Column(String(10))
    aennr              = Column(String(40))
    equipos            = Column(Integer)
    cantidad_base      = Column(Numeric(12, 2))

    tiempo             = Column(Numeric(12, 4))   # VGW01
    tiempo_preparacion = Column(Numeric(12, 4), nullable=True)   # VGW02
    tiempo_mano_obra   = Column(Numeric(12, 4), nullable=True)   # VGW03

    unidad_t           = Column(String(10))   # VGE01
    unidad_preparacion = Column(String(10))   # VGE02
    unidad_mano_obra   = Column(String(10))   # VGE03
    vgwts              = Column(String(10))

    fecha_inicio       = Column(Date)
    fecha_fin          = Column(Date)
    creado_sap         = Column(Date)
    modificado_sap     = Column(Date)
    creado_en          = Column(DateTime, server_default=func.now())
    modificado_en      = Column(DateTime, server_default=func.now(), onupdate=func.now())


# Re-export para compatibilidad (costos_controller importaba desde aqui).
from app.models.costos.costos import (  # noqa: E402,F401
    CostosCK13NCabecera,
    CostosCK13NElementos,
    CostosCK13NProduccion,
)
