# app/models/sap_mes/estadistica_mes.py
"""
Historico de estadisticas MES (Fase 16).

Cada comparativa que obtiene datos de la API de MES guarda aqui lo que MES
respondio, una fila por (material, estacion MES, periodo, limites). Si despues
la API de MES no responde, la comparativa se arma con estas filas.

Se guardan las estadisticas tal como vienen de MES (antes de "MES salida ÷"):
el divisor se sigue aplicando en el comparador, asi un mismo registro sirve
para cualquier divisor.

Por que estadisticas y no ciclos por pieza: decision del usuario (Fase 16).
Limitante: una mediana no se puede recalcular para otro periodo; si no hay una
fila con el mismo periodo y limites, se usa la mas reciente de esa estacion y
la pantalla lo avisa.
"""
from sqlalchemy import Column, DateTime, Float, Index, Integer, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB

from app.config import Base


class SapMesEstadisticaMes(Base):
    __tablename__ = "sap_mes_estadistica_mes"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    material       = Column(String(50), nullable=False)    # normalizado (sin ceros a la izquierda)
    operation      = Column(String(100), nullable=False)   # estacion MES
    start_date     = Column(String(8), nullable=False)     # YYYYMMDD
    end_date       = Column(String(8), nullable=False)     # YYYYMMDD inclusive
    max_gap_sec    = Column(Float, nullable=False)
    max_ct_sec     = Column(Float, nullable=False)
    proceso        = Column(JSONB)                         # {n, excluidos, promedio, mediana, p25, p75, p90, minimo, maximo}
    salida         = Column(JSONB)
    recursos       = Column(Integer, nullable=False, server_default="0")
    lista_recursos = Column(JSONB)
    gmasite        = Column(String(20))
    consultado_en  = Column(DateTime, nullable=False, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("material", "operation", "start_date", "end_date", "max_gap_sec", "max_ct_sec",
                         name="uq_sap_mes_estadistica_mes"),
        Index("ix_sap_mes_estadistica_mes_buscar", "material", "operation", "consultado_en"),
    )
