# app/models/sap_mes/relacion.py
"""
Relacion SAP vs MES operacion por operacion (Fase 17).

Una fila por (centro, material, alternativa SAP, operacion SAP) con la ultima
comparacion: cantidad SAP (tiempo de la hoja de ruta y seg/pz) contra cantidad
MES (seg/pz de proceso y de salida, y piezas medidas), mas la estacion MES con
la que se relaciona. Se llena sola cada vez que se compara un material
(pantalla SAP/MES, /comparativa o /tabla).

Si en una comparacion MES no responde, se actualiza solo la parte SAP y se
conservan los ultimos valores MES que ya habia.
"""
from sqlalchemy import Column, Date, DateTime, Float, Index, Integer, String, UniqueConstraint, func

from app.config import Base


class SapMesRelacion(Base):
    __tablename__ = "sap_mes_relacion"

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    centro             = Column(String(4), nullable=False)
    numero_material    = Column(String(50), nullable=False)
    nombre_pieza       = Column(String(255))
    plnal              = Column(String(10), nullable=False)      # alternativa SAP
    version_sap        = Column(Date)                            # fecha de la version SAP comparada
    operacion_num      = Column(String(20), nullable=False)      # VORNR
    descripcion        = Column(String(255))
    clave_modelo       = Column(String(50))

    # Relacion con MES
    mes_operations     = Column(String(500))                     # estaciones MES, separadas por coma
    mapeo_origen       = Column(String(30))                      # MATERIAL_ALTERNATIVA | MATERIAL | CLAVE | AUTO_T435T
    agregacion         = Column(String(10))                      # SERIE | PARALELO
    equipos            = Column(Integer)
    equipos_origen     = Column(String(10))                      # REGLA | MES | DEFAULT

    # Cantidad SAP
    campo_tiempo       = Column(String(30))                      # tiempo | tiempo_preparacion | tiempo_mano_obra
    sap_tiempo         = Column(Float)                           # valor tal cual en SAP
    sap_unidad         = Column(String(10))
    sap_cantidad_base  = Column(Float)
    sap_seg_pz         = Column(Float)
    sap_seg_pz_equipos = Column(Float)

    # Cantidad MES (ultimo dato obtenido)
    material_mes       = Column(String(50))                      # material con el que se consulto MES
    mes_proceso_seg_pz = Column(Float)
    mes_proceso_piezas = Column(Integer)
    mes_salida_seg_pz  = Column(Float)                           # ya con "MES salida ÷"
    mes_salida_piezas  = Column(Integer)
    divisor_salida     = Column(Float)
    estadistico        = Column(String(10))                      # mediana | promedio | p75 | p90
    mes_desde          = Column(String(8))                       # YYYYMMDD
    mes_hasta          = Column(String(8))
    mes_fuente         = Column(String(10))                      # HANA (en vivo) | BD (guardado por la API de MES)
    mes_actualizado_en = Column(DateTime)

    # Diferencia (MES - SAP)
    dif_proceso_pct    = Column(Float)
    estado_proceso     = Column(String(20))
    dif_salida_pct     = Column(Float)
    estado_salida      = Column(String(20))

    actualizado_en     = Column(DateTime, nullable=False, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("centro", "numero_material", "plnal", "operacion_num", name="uq_sap_mes_relacion"),
        Index("ix_sap_mes_relacion_material", "centro", "numero_material"),
    )
