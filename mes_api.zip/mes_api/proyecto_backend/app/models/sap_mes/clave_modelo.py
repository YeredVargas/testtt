# app/models/sap_mes/clave_modelo.py
"""
Catalogo T435T (texto de cada clave de modelo). Fase 7.

La tabla la CREA y LLENA la API de SAP (POST /api/v1/claves-modelo/sincronizar).
Debe coincidir con api_sap/db/models.py::CatalogoClaveModelo. Este backend solo
la lee; la declara tambien aqui para poder crearla vacia si arranca primero.

Para rutas de produccion: texto de la clave == nombre de la operacion MES.
  RPBSMDT -> "PCB_SMT_T"   (operacion MES PCB_SMT_T)
"""
from sqlalchemy import Boolean, Column, DateTime, String, func

from app.config import Base


class CatalogoClaveModelo(Base):
    __tablename__ = "catalogo_clave_modelo"

    clave_modelo  = Column(String(20), primary_key=True)
    texto         = Column(String(100))
    idioma        = Column(String(2))
    operacion_mes = Column(String(100), index=True)
    activo        = Column(Boolean, nullable=False, server_default="true")
    creado_en     = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())
