# app/models/sap_mes/grupo.py
"""
Grupos de procesos del apartado SAP/MES (Fase 11).

Un grupo es un rango de operaciones de la hoja de ruta, con nombre, que arma el
usuario por material (p. ej. "SMT Top" = 0100..0160). Sirve para filtrar la
comparativa y para ver un resumen SAP vs MES por grupo.

  plnal NULL  -> el grupo aplica a todas las alternativas del material.
  op_inicio / op_fin -> numeros de operacion SAP (VORNR), inclusivos.

Los grupos pueden traslaparse: son vistas, no particionan la ruta.
"""
from sqlalchemy import Boolean, CheckConstraint, Column, DateTime, Index, Integer, String, func

from app.config import Base


class SapMesGrupo(Base):
    __tablename__ = "sap_mes_grupo"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    centro          = Column(String(4), nullable=False, server_default="0094")
    numero_material = Column(String(50), nullable=False)
    plnal           = Column(String(10))
    nombre          = Column(String(60), nullable=False)
    op_inicio       = Column(String(20), nullable=False)
    op_fin          = Column(String(20), nullable=False)
    orden           = Column(Integer, nullable=False, server_default="0")
    activo          = Column(Boolean, nullable=False, server_default="true")
    creado_en       = Column(DateTime, server_default=func.now())
    modificado_en   = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        CheckConstraint("length(trim(nombre)) > 0", name="ck_sap_mes_grupo_nombre"),
        # Un nombre por material y alternativa (NULL = todas, se trata como '').
        Index(
            "uq_sap_mes_grupo_nombre",
            "centro", "numero_material", func.coalesce(plnal, ""), func.lower(nombre),
            unique=True,
        ),
        Index("ix_sap_mes_grupo_material", "centro", "numero_material"),
    )
