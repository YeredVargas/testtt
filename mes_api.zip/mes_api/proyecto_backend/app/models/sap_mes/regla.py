# app/models/sap_mes/regla.py
"""
Mapeo SAP -> MES (Fase 2).

No existe una llave comun entre la operacion de la hoja de ruta SAP
(operacion_num / clave_modelo) y la operacion MES (p. ej. OBC_FASSY_ST010),
asi que el mapeo se captura a mano. Dos niveles, del mas especifico al mas general:

  alcance = 'MATERIAL' : material + operacion_num (+ alternativa opcional).
                         plnal NULL = aplica a todas las alternativas.
  alcance = 'CLAVE'    : clave_modelo (KTSCH) para TODOS los materiales.
                         Ahorra captura cuando la misma clave siempre corre en
                         la misma estacion MES.

Resolucion para una operacion SAP:  (material, alt, op) > (material, *, op) > (clave).

Una operacion SAP puede equivaler a VARIAS estaciones MES (tabla hija):
  agregacion = 'SERIE'    : estaciones una tras otra. Proceso = suma; salida = la mas lenta.
  agregacion = 'PARALELO' : estaciones que hacen lo mismo en paralelo.
                            Proceso = promedio ponderado; salida = capacidad combinada.

`equipos`: maquinas en paralelo para esa operacion SAP. El tiempo SAP de salida
se divide entre este valor. Se captura aqui porque el campo `trazabilidad.equipos`
que llena la API de SAP es el numero de operaciones de la ruta, no de maquinas.
"""
from sqlalchemy import (
    Boolean, CheckConstraint, Column, DateTime, ForeignKey, Index, Integer, String, func,
)
from sqlalchemy.orm import relationship

from app.config import Base

ALCANCES = ("MATERIAL", "CLAVE")
AGREGACIONES = ("SERIE", "PARALELO")


class SapMesRegla(Base):
    __tablename__ = "sap_mes_regla"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    centro          = Column(String(4), nullable=False, server_default="0094")
    alcance         = Column(String(10), nullable=False)
    numero_material = Column(String(50))
    plnal           = Column(String(10))
    operacion_num   = Column(String(20))
    clave_modelo    = Column(String(50))
    equipos         = Column(Integer, nullable=False, server_default="1")
    agregacion      = Column(String(10), nullable=False, server_default="SERIE")
    notas           = Column(String(255))
    activo          = Column(Boolean, nullable=False, server_default="true")
    creado_en       = Column(DateTime, server_default=func.now())
    modificado_en   = Column(DateTime, server_default=func.now(), onupdate=func.now())

    operaciones = relationship(
        "SapMesReglaOperacion",
        back_populates="regla",
        cascade="all, delete-orphan",
        order_by="SapMesReglaOperacion.orden",
    )

    __table_args__ = (
        CheckConstraint("alcance IN ('MATERIAL','CLAVE')", name="ck_sap_mes_regla_alcance"),
        CheckConstraint("agregacion IN ('SERIE','PARALELO')", name="ck_sap_mes_regla_agregacion"),
        CheckConstraint("equipos >= 1", name="ck_sap_mes_regla_equipos"),
        CheckConstraint(
            "(alcance = 'MATERIAL' AND numero_material IS NOT NULL AND operacion_num IS NOT NULL)"
            " OR (alcance = 'CLAVE' AND clave_modelo IS NOT NULL)",
            name="ck_sap_mes_regla_llave",
        ),
        # Una sola regla por llave (NULL se trata como '' para que sea unica).
        Index(
            "uq_sap_mes_regla_llave",
            "centro", "alcance",
            func.coalesce(numero_material, ""), func.coalesce(plnal, ""),
            func.coalesce(operacion_num, ""), func.coalesce(clave_modelo, ""),
            unique=True,
        ),
        Index("ix_sap_mes_regla_material", "centro", "numero_material"),
    )


class SapMesReglaOperacion(Base):
    __tablename__ = "sap_mes_regla_operacion"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    regla_id      = Column(Integer, ForeignKey("sap_mes_regla.id", ondelete="CASCADE"), nullable=False)
    mes_operation = Column(String(100), nullable=False)
    orden         = Column(Integer, nullable=False, server_default="0")

    regla = relationship("SapMesRegla", back_populates="operaciones")

    __table_args__ = (
        Index("uq_sap_mes_regla_operacion", "regla_id", "mes_operation", unique=True),
    )
