# app/models/costos/costos.py
"""
Modelos de costos CK13N. UNICA definicion en este backend.

CORREGIDO (Fase 0): existian dos versiones distintas (aqui y en
dashboard/trazabilidad.py). Esta es la que coincide con la BD real que crea la
API de SAP (api_sap/db/models.py): lleva `variante`, la restriccion unica por
fecha_validez y el modelo de produccion (CKIS) que usa costos_controller.
"""
from sqlalchemy import (
    Column, Integer, String, Numeric, Date, DateTime,
    ForeignKey, UniqueConstraint, ForeignKeyConstraint,
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.config import Base


class CostosCK13NCabecera(Base):
    __tablename__ = 'costos_ck13n_cabecera'

    id = Column(Integer, primary_key=True, index=True)
    numero_material = Column(String(50), nullable=False)
    centro          = Column(String(4), nullable=False, default='0094')
    variante        = Column(String(10), nullable=False, default='PPC1')
    estatus         = Column(String(5), nullable=False)
    fecha_validez   = Column(Date, nullable=False)
    numero_costeo   = Column(String(50), nullable=False)

    total_global   = Column(Numeric(15, 2), nullable=False, default=0)
    total_fijado   = Column(Numeric(15, 2), nullable=False, default=0)
    total_variable = Column(Numeric(15, 2), nullable=False, default=0)

    creado_en     = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint('numero_material', 'centro', 'variante', 'fecha_validez', name='uq_costos_cabecera'),
        ForeignKeyConstraint(
            ['numero_material', 'centro'],
            ['piezas.numero_material', 'piezas.centro'],
            ondelete='CASCADE',
        ),
    )

    elementos = relationship("CostosCK13NElementos", back_populates="cabecera", cascade="all, delete-orphan")
    produccion = relationship("CostosCK13NProduccion", back_populates="cabecera", cascade="all, delete-orphan")


class CostosCK13NElementos(Base):
    __tablename__ = 'costos_ck13n_elementos'

    id          = Column(Integer, primary_key=True, index=True)
    cabecera_id = Column(Integer, ForeignKey('costos_ck13n_cabecera.id', ondelete='CASCADE'), nullable=False)

    componente   = Column(String(10), nullable=False)
    denominacion = Column(String(100))

    total    = Column(Numeric(15, 2), nullable=False, default=0)
    fijado   = Column(Numeric(15, 2), nullable=False, default=0)
    variable = Column(Numeric(15, 2), nullable=False, default=0)

    __table_args__ = (
        UniqueConstraint('cabecera_id', 'componente', name='uq_costos_elementos'),
    )

    cabecera = relationship("CostosCK13NCabecera", back_populates="elementos")


class CostosCK13NProduccion(Base):
    __tablename__ = 'costos_ck13n_produccion'

    id          = Column(Integer, primary_key=True, index=True)
    cabecera_id = Column(Integer, ForeignKey('costos_ck13n_cabecera.id', ondelete='CASCADE'), nullable=False)

    posicion           = Column(String(20))
    centro_coste       = Column(String(50))
    texto_centro_coste = Column(String(200))
    clase_actividad    = Column(String(50))
    texto_actividad    = Column(String(200))
    elemento_coste     = Column(String(50))
    texto_recurso      = Column(String(255))

    cantidad    = Column(Numeric(15, 3), default=0)
    unidad      = Column(String(10))
    valor_total = Column(Numeric(15, 2), default=0)
    moneda      = Column(String(10))

    cabecera = relationship("CostosCK13NCabecera", back_populates="produccion")
