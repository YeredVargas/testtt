# app/services/sap_mes/ruta_sap.py
"""
Versiones de la hoja de ruta SAP guardada en `trazabilidad`.

Cada operacion tiene su propio historial (fecha_inicio / fecha_fin). La "version"
de la ruta a una fecha D es, por cada (hoja de ruta, operacion), la fila con
fecha_inicio <= D <= fecha_fin. Las fechas en que cambio al menos una operacion
son las versiones que se ofrecen en el selector. Por defecto: HOY (vigente) en
la alternativa principal (numero mas bajo).
"""
from datetime import date
from typing import Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from app.models.dashboard.pieza import Pieza
from app.models.dashboard.trazabilidad import Trazabilidad


def orden_alternativa(plnal: Optional[str]):
    texto = (plnal or "").strip()
    return (0, int(texto)) if texto.isdigit() else (1, texto)


def cargar_filas(db: Session, material: str, centro: str) -> Tuple[Optional[Pieza], List[Trazabilidad]]:
    pieza = db.query(Pieza).filter(Pieza.numero_material == material, Pieza.centro == centro).first()
    if not pieza:
        return None, []
    # Solo las columnas que usa el modulo (no la entidad completa): asi no
    # depende de que la tabla tenga exactamente todas las columnas del modelo.
    T = Trazabilidad
    filas = (
        db.query(
            T.plnnr, T.plnal, T.operacion_num, T.aennr, T.fecha_inicio, T.fecha_fin,
            T.descripcion, T.clave_modelo, T.proceso, T.cantidad_base,
            T.tiempo, T.unidad_t,
            T.tiempo_preparacion, T.unidad_preparacion,
            T.tiempo_mano_obra, T.unidad_mano_obra,
        )
        .filter(T.pieza_id == pieza.id)
        .all()
    )
    return pieza, filas


def versiones(filas: List[Trazabilidad]) -> List[dict]:
    """[{plnal, fechas: [date desc], vigente: date|None}] por alternativa."""
    hoy = date.today()
    por_alt: Dict[str, set] = {}
    for f in filas:
        if f.fecha_inicio:
            por_alt.setdefault(f.plnal or "01", set()).add(f.fecha_inicio)
    salida = []
    for alt in sorted(por_alt, key=orden_alternativa):
        fechas = sorted(por_alt[alt], reverse=True)
        vigente = next((d for d in fechas if d <= hoy), fechas[-1] if fechas else None)
        salida.append({"plnal": alt, "fechas": fechas, "vigente": vigente})
    return salida


def ruta_a_fecha(filas: List[Trazabilidad], plnal: str, fecha: date) -> List[Trazabilidad]:
    """Operaciones vigentes de la alternativa `plnal` a la fecha dada."""
    elegidas: Dict[Tuple[str, str], Trazabilidad] = {}
    for f in filas:
        if (f.plnal or "01") != plnal:
            continue
        if f.fecha_inicio and f.fecha_inicio > fecha:
            continue
        if f.fecha_fin and f.fecha_fin < fecha:
            continue
        llave = (f.plnnr or "", f.operacion_num)
        actual = elegidas.get(llave)
        orden = (f.fecha_inicio or date.min, f.aennr or "")
        if actual is None or orden > (actual.fecha_inicio or date.min, actual.aennr or ""):
            elegidas[llave] = f
    return sorted(elegidas.values(), key=lambda f: (f.operacion_num, f.plnnr or ""))
