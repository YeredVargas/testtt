# app/services/sap_mes/relacion.py
"""
Guarda la relacion SAP vs MES operacion por operacion (Fase 17).

Se llama despues de cada comparativa. Usa las mismas filas que la tabla de la
pantalla (comparador.fila_tabla), asi lo guardado es exactamente lo que se ve.
Nunca tumba la comparativa: si la BD falla, se registra y se sigue.
"""
import logging
from datetime import date, datetime
from typing import List, Optional

from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.models.sap_mes.relacion import SapMesRelacion as R
from app.services.sap_mes.comparador import fila_tabla

log = logging.getLogger(__name__)

_COLUMNAS_SAP = (
    "nombre_pieza", "version_sap", "descripcion", "clave_modelo", "mes_operations", "mapeo_origen", "agregacion",
    "equipos", "equipos_origen", "campo_tiempo", "sap_tiempo", "sap_unidad", "sap_cantidad_base", "sap_seg_pz",
    "sap_seg_pz_equipos", "actualizado_en",
)
_COLUMNAS_MES = (
    "material_mes", "mes_proceso_seg_pz", "mes_proceso_piezas", "mes_salida_seg_pz", "mes_salida_piezas",
    "divisor_salida", "estadistico", "mes_desde", "mes_hasta", "mes_fuente", "mes_actualizado_en",
    "dif_proceso_pct", "estado_proceso", "dif_salida_pct", "estado_salida",
)


def _hay_mes(datos: dict) -> bool:
    """MES respondio (en vivo o desde lo guardado por la API de MES)."""
    mes = datos.get("mes") or {}
    return not mes.get("error") and bool(mes.get("operaciones_consultadas"))


def filas_relacion(datos: dict) -> List[dict]:
    """Convierte una comparativa en filas de sap_mes_relacion."""
    version = datos.get("version") or {}
    if not version.get("plnal"):
        return []
    p = datos.get("parametros") or {}
    meta = (datos.get("mes") or {}).get("meta") or {}
    ahora = datetime.now()
    try:
        version_sap = date.fromisoformat(version["fecha"]) if version.get("fecha") else None
    except ValueError:
        version_sap = None
    filas = []
    for op in datos.get("operaciones", []):
        f = fila_tabla(op, incluir_estaciones=False)
        filas.append({
            "centro": datos["centro"],
            "numero_material": datos["numero_material"],
            "nombre_pieza": datos.get("nombre_pieza"),
            "plnal": version["plnal"],
            "version_sap": version_sap,
            "operacion_num": f["operacion_num"],
            "descripcion": f["descripcion"],
            "clave_modelo": f["clave_modelo"],
            "mes_operations": ", ".join(f["mes_operations"]) or None,
            "mapeo_origen": f["mapeo_origen"],
            "agregacion": f["agregacion"],
            "equipos": f["equipos"],
            "equipos_origen": f["equipos_origen"],
            "campo_tiempo": p.get("campo_tiempo"),
            "sap_tiempo": f["tiempo_sap"],
            "sap_unidad": f["unidad_sap"],
            "sap_cantidad_base": f["cantidad_base"],
            "sap_seg_pz": f["sap_seg_pz"],
            "sap_seg_pz_equipos": f["sap_seg_pz_equipos"],
            "material_mes": p.get("material_mes") or datos["numero_material"],
            "mes_proceso_seg_pz": f["mes_proceso"],
            "mes_proceso_piezas": f["mes_proceso_n"],
            "mes_salida_seg_pz": f["mes_salida"],
            "mes_salida_piezas": f["mes_salida_n"],
            "divisor_salida": p.get("divisor_salida"),
            "estadistico": p.get("estadistico"),
            "mes_desde": p.get("start_date"),
            "mes_hasta": p.get("end_date"),
            "mes_fuente": meta.get("fuente") or ("HANA" if meta else None),
            "mes_actualizado_en": ahora,
            "dif_proceso_pct": f["dif_proceso_pct"],
            "estado_proceso": f["estado_proceso"],
            "dif_salida_pct": f["dif_salida_pct"],
            "estado_salida": f["estado_salida"],
            "actualizado_en": ahora,
        })
    return filas


def guardar(db: Session, datos: dict) -> int:
    """Upsert por (centro, material, alternativa, operacion). Regresa cuantas filas guardo."""
    filas = filas_relacion(datos)
    if not filas:
        return 0
    con_mes = _hay_mes(datos)
    if not con_mes:
        # MES no respondio: no borrar el ultimo dato MES bueno. Las filas nuevas
        # entran con MES vacio; las existentes solo actualizan la parte SAP.
        for f in filas:
            for c in _COLUMNAS_MES:
                f[c] = None
    try:
        stmt = insert(R).values(filas)
        columnas = _COLUMNAS_SAP + (_COLUMNAS_MES if con_mes else ())
        stmt = stmt.on_conflict_do_update(
            constraint="uq_sap_mes_relacion",
            set_={c: stmt.excluded[c] for c in columnas},
        )
        db.execute(stmt)
        db.commit()
        return len(filas)
    except SQLAlchemyError:
        db.rollback()
        log.exception("No se pudo guardar la relacion SAP/MES")
        return 0


def listar(db: Session, centro: str, numero_material: Optional[str], plnal: Optional[str] = None,
           limite: int = 2000) -> List[dict]:
    q = db.query(R).filter(R.centro == centro)
    if numero_material:
        q = q.filter(R.numero_material == numero_material)
    if plnal:
        q = q.filter(R.plnal == plnal)
    q = q.order_by(R.numero_material, R.plnal, R.operacion_num).limit(limite)
    salida = []
    for r in q.all():
        d = {c.name: getattr(r, c.name) for c in R.__table__.columns}
        for k in ("version_sap", "mes_actualizado_en", "actualizado_en"):
            if d[k] is not None:
                d[k] = d[k].isoformat(timespec="minutes") if isinstance(d[k], datetime) else d[k].isoformat()
        salida.append(d)
    return salida
