# app/services/sap_mes/mes_historico.py
"""
Guardar y leer estadisticas MES en Postgres (Fase 16, llenado "al comparar").

- guardar(): despues de una respuesta correcta de la API de MES.
- recuperar(): cuando la API de MES no responde.
    1) misma consulta: mismo periodo y mismos limites (exacta);
    2) si no, la consulta mas reciente guardada de esa estacion (aproximada).
Nunca tumba la comparativa: si la BD falla, se registra y se sigue.
"""
import logging
from datetime import datetime
from typing import Dict, Iterable, List, Tuple

from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.models.sap_mes.estadistica_mes import SapMesEstadisticaMes

log = logging.getLogger(__name__)


def guardar(db: Session, material: str, filas: Iterable[dict], start_date: str, end_date: str,
            max_gap_sec: float, max_ct_sec: float, gmasite=None) -> int:
    """Upsert de las filas que MES devolvio para `material`. Regresa cuantas guardo."""
    valores = []
    ahora = datetime.now()
    for f in filas:
        op = str(f.get("OPERATION") or "").strip()
        if not op:
            continue
        valores.append({
            "material": material,
            "operation": op,
            "start_date": start_date,
            "end_date": end_date,
            "max_gap_sec": float(max_gap_sec),
            "max_ct_sec": float(max_ct_sec),
            "proceso": f.get("proceso"),
            "salida": f.get("salida"),
            "recursos": int(f.get("recursos") or 0),
            "lista_recursos": f.get("lista_recursos") or [],
            "gmasite": gmasite,
            "consultado_en": ahora,
        })
    if not valores:
        return 0
    try:
        stmt = insert(SapMesEstadisticaMes).values(valores)
        stmt = stmt.on_conflict_do_update(
            constraint="uq_sap_mes_estadistica_mes",
            set_={k: stmt.excluded[k] for k in
                  ("proceso", "salida", "recursos", "lista_recursos", "gmasite", "consultado_en")},
        )
        db.execute(stmt)
        db.commit()
        return len(valores)
    except SQLAlchemyError:
        db.rollback()
        log.exception("No se pudo guardar el historico MES")
        return 0


def _fila(r: SapMesEstadisticaMes) -> dict:
    return {
        "MATERIAL": r.material,
        "OPERATION": r.operation,
        "proceso": r.proceso,
        "salida": r.salida,
        "recursos": r.recursos,
        "lista_recursos": r.lista_recursos or [],
    }


def _origen(r: SapMesEstadisticaMes, exacta: bool) -> dict:
    return {
        "start_date": r.start_date,
        "end_date": r.end_date,
        "max_gap_sec": r.max_gap_sec,
        "max_ct_sec": r.max_ct_sec,
        "consultado_en": r.consultado_en.isoformat(timespec="minutes") if r.consultado_en else None,
        "exacta": exacta,
    }


def recuperar(db: Session, material: str, operations: List[str], start_date: str, end_date: str,
              max_gap_sec: float, max_ct_sec: float) -> Tuple[Dict[str, dict], Dict[str, dict]]:
    """
    Regresa (filas_por_operacion, origen_por_operacion). Llave = operacion en MAYUSCULAS,
    igual que stats_por_op del comparador.
    """
    filas, origen = {}, {}
    try:
        for op in operations:
            base = db.query(SapMesEstadisticaMes).filter(
                SapMesEstadisticaMes.material == material,
                SapMesEstadisticaMes.operation == op,
            )
            r = base.filter(
                SapMesEstadisticaMes.start_date == start_date,
                SapMesEstadisticaMes.end_date == end_date,
                SapMesEstadisticaMes.max_gap_sec == float(max_gap_sec),
                SapMesEstadisticaMes.max_ct_sec == float(max_ct_sec),
            ).first()
            exacta = r is not None
            if r is None:
                r = base.order_by(SapMesEstadisticaMes.consultado_en.desc(), SapMesEstadisticaMes.id.desc()).first()
            if r is not None:
                llave = op.strip().upper()
                filas[llave] = _fila(r)
                origen[llave] = _origen(r, exacta)
    except SQLAlchemyError:
        db.rollback()
        log.exception("No se pudo leer el historico MES")
    return filas, origen


def listar(db: Session, material: str, limite: int = 200) -> List[dict]:
    """Lo guardado de un material, lo mas reciente primero (para revisar)."""
    q = (db.query(SapMesEstadisticaMes)
         .filter(SapMesEstadisticaMes.material == material)
         .order_by(SapMesEstadisticaMes.consultado_en.desc(), SapMesEstadisticaMes.operation)
         .limit(limite))
    return [{**_fila(r), **_origen(r, True)} for r in q.all()]
