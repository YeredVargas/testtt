# app/services/sap_mes/schema.py
"""
Crea las tablas del modulo SAP/MES si no existen (idempotente, nunca borra).

Por que al arrancar y no con un script aparte: este snapshot del backend no tiene
un runner de migraciones, y la API de SAP ya sigue este mismo patron con sus
tablas. create_all(checkfirst) solo crea lo que falta. El SQL equivalente para
revisarlo o correrlo a mano esta en database/migrations/sap_mes/001_sap_mes.sql.
"""
import logging

from app.config import Base, engine
from app.models.sap_mes.clave_modelo import CatalogoClaveModelo
from app.models.sap_mes.grupo import SapMesGrupo
from app.models.sap_mes.relacion import SapMesRelacion
from app.models.sap_mes.regla import SapMesRegla, SapMesReglaOperacion

log = logging.getLogger(__name__)


def asegurar_tablas_sap_mes() -> bool:
    try:
        Base.metadata.create_all(
            bind=engine,
            # catalogo_clave_modelo la llena la API de SAP; aqui solo se crea vacia
            # si todavia no existe, para que la comparativa no falle.
            tables=[SapMesRegla.__table__, SapMesReglaOperacion.__table__, CatalogoClaveModelo.__table__,
                    SapMesGrupo.__table__, SapMesRelacion.__table__],
            checkfirst=True,
        )
        print("-> SAP/MES: tablas de mapeo, grupos y relacion SAP/MES verificadas.")
        return True
    except Exception as e:  # No tumbar el sistema si la BD no esta disponible al arrancar.
        print(f"-> [ERROR] SAP/MES: no se pudieron verificar las tablas de mapeo: {e}")
        log.exception("Error creando tablas SAP/MES")
        return False
