# app/services/sap_mes/conversion.py
"""
Conversion del tiempo de la hoja de ruta SAP a SEGUNDOS POR PIEZA.

En SAP, VGW01 (`trazabilidad.tiempo`) es el tiempo para `cantidad_base` (BMSCH)
piezas, expresado en la unidad `unidad_t` (VGE01). Por eso:

    seg/pz = tiempo * factor_a_segundos(unidad_t) / cantidad_base

El resto del sistema asume hoy horas por 1000 piezas (1000 / tiempo). Aqui se
usan las columnas reales para no depender de ese supuesto; si alguna fila tiene
otra unidad o base, la comparacion contra MES sigue siendo correcta.
"""
from typing import Optional, Tuple

# Regla de planta: tiempos simbolicos (0.001, 0.01) se toman como 0. SAP los
# usa para que la operacion "tenga" valor sin representar un tiempo real.
TIEMPO_MINIMO = 0.01


def es_tiempo_real(valor) -> bool:
    try:
        return valor is not None and float(valor) > TIEMPO_MINIMO
    except (TypeError, ValueError):
        return False

# Codigos internos de SAP (T006) y codigos ISO mas comunes.
FACTOR_SEGUNDOS = {
    "S": 1, "SEC": 1, "SEK": 1,
    "MIN": 60, "MI": 60,
    "H": 3600, "HR": 3600, "HUR": 3600, "STD": 3600,
    "D": 86400, "TAG": 86400, "DAY": 86400,
}


def factor_unidad(unidad: Optional[str]) -> Optional[int]:
    if unidad is None:
        return None
    return FACTOR_SEGUNDOS.get(str(unidad).strip().upper())


def seg_por_pieza(tiempo, unidad_t, cantidad_base) -> Tuple[Optional[float], Optional[str]]:
    """Devuelve (segundos por pieza, aviso). Si no se puede calcular, (None, motivo)."""
    try:
        t = float(tiempo) if tiempo is not None else 0.0
    except (TypeError, ValueError):
        return None, "Tiempo SAP no numerico."
    if t <= 0:
        return None, "La operacion no tiene tiempo en SAP."
    if t <= TIEMPO_MINIMO:
        return None, f"Tiempo SAP simbolico ({t:g}): se toma como 0."
    f = factor_unidad(unidad_t)
    if f is None:
        return None, f"Unidad de tiempo desconocida: {unidad_t!r}."
    try:
        base = float(cantidad_base) if cantidad_base is not None else 0.0
    except (TypeError, ValueError):
        base = 0.0
    if base <= 0:
        return None, "La operacion no tiene cantidad base en SAP."
    return t * f / base, None


# ---------------------------------------------------------------------------
# Tiempos de la hoja de ruta que se pueden comparar contra MES.
# Cada uno trae su propia unidad (VGE0x); la cantidad base (BMSCH) es comun.
# ---------------------------------------------------------------------------
CAMPOS_TIEMPO = {
    "tiempo":             {"vgw": "VGW01", "unidad": "unidad_t",           "etiqueta": "Tiempo de operación"},
    "tiempo_preparacion": {"vgw": "VGW02", "unidad": "unidad_preparacion", "etiqueta": "Tiempo de preparación"},
    "tiempo_mano_obra":   {"vgw": "VGW03", "unidad": "unidad_mano_obra",   "etiqueta": "Mano de obra"},
}
CAMPO_TIEMPO_DEFAULT = "tiempo"


def valor_y_unidad(fila, campo: str) -> Tuple[Optional[float], Optional[str], bool]:
    """
    (valor, unidad, unidad_heredada) del campo de tiempo elegido.
    SAP deja VGE02/VGE03 vacios en algunas rutas aunque haya valor; en ese caso
    se usa la unidad de VGW01 (VGE01) y se marca unidad_heredada=True.
    """
    info = CAMPOS_TIEMPO[campo]
    valor = getattr(fila, campo, None)
    unidad = getattr(fila, info["unidad"], None)
    heredada = False
    if (unidad is None or not str(unidad).strip()) and campo != "tiempo":
        unidad, heredada = getattr(fila, "unidad_t", None), True
    return (float(valor) if valor is not None else None), unidad, heredada
