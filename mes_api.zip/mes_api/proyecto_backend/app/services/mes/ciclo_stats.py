# app/services/mes/ciclo_stats.py
"""
FASE 1 - Calculo de tiempos ciclo MES a partir de eventos crudos START/COMPLETE.

Por que en Python y no en SQL:
  HANA solo entrega los eventos (SFC, MATERIAL, OPERATION, ACTION_CODE, DATE_TIME).
  El emparejamiento y las estadisticas se hacen aqui porque:
    - el SQL queda igual de simple que las consultas que ya funcionan hoy;
    - la logica se puede probar sin HANA (ver tests/test_ciclo_stats.py);
    - no dependemos de funciones (PERCENTILE_CONT, LAG) cuyo soporte en la
      vista calculada no esta verificado.

Dos metricas por (material, operacion):

  PROCESO (START -> COMPLETE)
    Tiempo que una pieza pasa en la estacion. Cada COMPLETE se empareja con el
    START inmediato anterior del MISMO SFC en la MISMA operacion. Asi una pieza
    que pasa dos veces (retrabajo) genera dos ciclos correctos, en lugar del
    MAX(START)/MAX(COMPLETE) anterior que mezclaba pasadas.

  SALIDA (START -> siguiente START en la operacion)
    Intervalo real entre piezas que entran a la estacion, sin importar el
    material de la siguiente pieza (es el ritmo de la estacion). Se atribuye
    al material de la pieza actual. Si la estacion tiene equipos en paralelo,
    este intervalo ya refleja la capacidad combinada.
    Los intervalos mayores a `max_gap_sec` se excluyen (comidas, cambios de
    turno, paros, cambios de modelo) y se reportan como excluidos.
"""
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict, Iterable, List, Optional, Tuple


@dataclass(frozen=True)
class Evento:
    sfc: str
    material: str
    operation: str
    action: str          # 'START' | 'COMPLETE'
    ts: datetime         # hora LOCAL
    resrce: str = ""     # recurso (maquina) MES; Fase 6


def normalizar_material(valor) -> str:
    """Igual que en OpTimeSAP: sin espacios ni ceros a la izquierda."""
    texto = str(valor).strip() if valor is not None else ""
    if texto.isdigit():
        return texto.lstrip("0") or "0"
    return texto.upper()


def parsear_ts(date_time: str, offset_sec: int) -> Optional[datetime]:
    """DATE_TIME de BW viene como 'YYYYMMDDHHMISS' en UTC."""
    if date_time is None:
        return None
    texto = str(date_time).strip()[:14]
    try:
        return datetime.strptime(texto, "%Y%m%d%H%M%S") + timedelta(seconds=offset_sec)
    except ValueError:
        return None


def percentil(ordenados: List[float], p: float) -> Optional[float]:
    """Percentil con interpolacion lineal (equivale a PERCENTILE_CONT)."""
    n = len(ordenados)
    if n == 0:
        return None
    if n == 1:
        return ordenados[0]
    pos = (n - 1) * p
    bajo = math.floor(pos)
    alto = math.ceil(pos)
    if bajo == alto:
        return ordenados[bajo]
    return ordenados[bajo] + (ordenados[alto] - ordenados[bajo]) * (pos - bajo)


def resumir(valores: List[float], excluidos: int) -> Dict[str, Optional[float]]:
    v = sorted(valores)
    n = len(v)
    if n == 0:
        return {
            "n": 0, "excluidos": excluidos, "promedio": None, "mediana": None,
            "p25": None, "p75": None, "p90": None, "minimo": None, "maximo": None,
        }
    r = lambda x: round(x, 2) if x is not None else None  # noqa: E731
    return {
        "n": n,
        "excluidos": excluidos,
        "promedio": r(sum(v) / n),
        "mediana": r(percentil(v, 0.5)),
        "p25": r(percentil(v, 0.25)),
        "p75": r(percentil(v, 0.75)),
        "p90": r(percentil(v, 0.90)),
        "minimo": r(v[0]),
        "maximo": r(v[-1]),
    }


def calcular_estadisticas(
    eventos: Iterable[Evento],
    desde: datetime,
    hasta: datetime,
    materiales: Optional[set] = None,
    max_gap_sec: float = 600,
    max_ct_sec: float = 3600,
) -> List[dict]:
    """
    eventos: todos los START/COMPLETE de las operaciones pedidas (todos los
             materiales: la metrica SALIDA necesita saber cuando entro la
             siguiente pieza aunque sea de otro material).
    desde/hasta: ventana LOCAL [desde, hasta). Un ciclo pertenece a la ventana
             segun su COMPLETE (proceso) o su START (salida).
    materiales: si se indica, solo se reportan esos materiales (normalizados).
    """
    por_sfc_op: Dict[Tuple[str, str], List[Evento]] = defaultdict(list)
    starts_por_op: Dict[str, List[Evento]] = defaultdict(list)
    for ev in eventos:
        por_sfc_op[(ev.sfc, ev.operation)].append(ev)
        if ev.action == "START":
            starts_por_op[ev.operation].append(ev)

    def incluir(material: str) -> bool:
        return not materiales or material in materiales

    proceso: Dict[Tuple[str, str], List[float]] = defaultdict(list)
    proceso_excl: Dict[Tuple[str, str], int] = defaultdict(int)
    recursos: Dict[Tuple[str, str], set] = defaultdict(set)

    # ---- PROCESO: COMPLETE emparejado con el START inmediato anterior ----
    for (_sfc, _op), lista in por_sfc_op.items():
        # START antes que COMPLETE si caen en el mismo segundo.
        lista.sort(key=lambda e: (e.ts, 0 if e.action == "START" else 1))
        previo: Optional[Evento] = None
        for ev in lista:
            if ev.action == "COMPLETE" and previo is not None and previo.action == "START":
                if desde <= ev.ts < hasta and incluir(ev.material):
                    llave = (ev.material, ev.operation)
                    ct = (ev.ts - previo.ts).total_seconds()
                    if 0 < ct <= max_ct_sec:
                        proceso[llave].append(ct)
                    else:
                        proceso_excl[llave] += 1
            previo = ev

    # ---- SALIDA: START -> siguiente START de la operacion ----
    salida: Dict[Tuple[str, str], List[float]] = defaultdict(list)
    salida_excl: Dict[Tuple[str, str], int] = defaultdict(int)
    for op, lista in starts_por_op.items():
        lista.sort(key=lambda e: (e.ts, e.sfc))
        # Un re-START del mismo SFC seguido no es una pieza nueva.
        depurada: List[Evento] = []
        for ev in lista:
            if depurada and depurada[-1].sfc == ev.sfc:
                continue
            depurada.append(ev)
        for actual, siguiente in zip(depurada, depurada[1:]):
            if not (desde <= actual.ts < hasta) or not incluir(actual.material):
                continue
            llave = (actual.material, op)
            if actual.resrce:
                recursos[llave].add(actual.resrce)
            gap = (siguiente.ts - actual.ts).total_seconds()
            if 0 < gap <= max_gap_sec:
                salida[llave].append(gap)
            else:
                salida_excl[llave] += 1

        # El ultimo START de la operacion no tiene "siguiente", pero su recurso cuenta.
        if depurada:
            ultimo = depurada[-1]
            if desde <= ultimo.ts < hasta and incluir(ultimo.material) and ultimo.resrce:
                recursos[(ultimo.material, op)].add(ultimo.resrce)

    llaves = set(proceso) | set(proceso_excl) | set(salida) | set(salida_excl)
    resultado = []
    for material, op in sorted(llaves):
        llave = (material, op)
        resultado.append({
            "MATERIAL": material,
            "OPERATION": op,
            "proceso": resumir(proceso.get(llave, []), proceso_excl.get(llave, 0)),
            "salida": resumir(salida.get(llave, []), salida_excl.get(llave, 0)),
            "recursos": len(recursos.get(llave, ())),
            "lista_recursos": sorted(recursos.get(llave, ())),
        })
    return resultado
