# app/services/mes/historico.py
"""
Guardar y recuperar estadisticas de ciclo MES en PostgreSQL (v3).

- guardar(): despues de cada respuesta correcta de HANA.
- recuperar(): cuando HANA no responde. Por (material, operacion):
    1) la misma consulta (mismo periodo y limites)  -> exacta
    2) si no, la consulta guardada mas reciente      -> aproximada
- operaciones_guardadas(): respaldo de /material-operaciones.

Nada de esto tumba la API: si PostgreSQL no esta disponible se registra y la
API sigue funcionando con HANA como antes.
"""
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional

from sqlalchemy import func
from sqlalchemy.dialects.postgresql import insert

from app.config import Base, SessionLocal, engine
from app.models.mes.ciclo_estadistica import MesCicloEstadistica as T

log = logging.getLogger(__name__)

_tabla_lista = False
_ultimo_fallo = 0.0
_REINTENTO_SEG = 60   # si PostgreSQL no esta, no volver a intentarlo en cada consulta


def asegurar_tabla() -> bool:
    """Crea la tabla si no existe (idempotente). Se llama al arrancar y antes de usarla."""
    global _tabla_lista, _ultimo_fallo
    if _tabla_lista:
        return True
    if _ultimo_fallo and time.monotonic() - _ultimo_fallo < _REINTENTO_SEG:
        return False
    try:
        Base.metadata.create_all(bind=engine, tables=[T.__table__], checkfirst=True)
        _tabla_lista = True
        print("[INFO] Historico MES: tabla mes_ciclo_estadistica verificada.")
    except Exception as e:  # noqa: BLE001 - la BD es opcional para esta API
        _ultimo_fallo = time.monotonic()
        print(f"[WARN] Historico MES desactivado: no se pudo conectar a PostgreSQL ({e.__class__.__name__}).")
        log.warning("Historico MES sin PostgreSQL: %s", e)
    return _tabla_lista


def guardar(respuesta: dict, gmasite: str) -> int:
    """Upsert de todas las filas de una respuesta de ciclo-estadisticas. Regresa cuantas guardo."""
    if not asegurar_tabla():
        return 0
    ahora = datetime.now()
    valores = [{
        "gmasite": gmasite,
        "material": str(f["MATERIAL"]),
        "operation": str(f["OPERATION"]),
        "start_date": respuesta["start_date"],
        "end_date": respuesta["end_date"],
        "max_gap_sec": float(respuesta["max_gap_sec"]),
        "max_ct_sec": float(respuesta["max_ct_sec"]),
        "proceso": f["proceso"],
        "salida": f["salida"],
        "recursos": int(f.get("recursos") or 0),
        "lista_recursos": f.get("lista_recursos") or [],
        "consultado_en": ahora,
    } for f in respuesta.get("data", [])]
    if not valores:
        return 0
    db = SessionLocal()
    try:
        stmt = insert(T).values(valores)
        stmt = stmt.on_conflict_do_update(
            constraint="uq_mes_ciclo_estadistica",
            set_={k: stmt.excluded[k] for k in ("proceso", "salida", "recursos", "lista_recursos", "consultado_en")},
        )
        db.execute(stmt)
        db.commit()
        return len(valores)
    except Exception as e:  # noqa: BLE001
        db.rollback()
        log.warning("No se pudo guardar el historico MES: %s", e)
        return 0
    finally:
        db.close()


def _fila(r: T) -> dict:
    return {
        "MATERIAL": r.material,
        "OPERATION": r.operation,
        "proceso": r.proceso,
        "salida": r.salida,
        "recursos": r.recursos,
        "lista_recursos": r.lista_recursos or [],
    }


def _origen(r: T, exacta: bool) -> dict:
    return {
        "material": r.material,
        "operation": r.operation,
        "start_date": r.start_date,
        "end_date": r.end_date,
        "max_gap_sec": r.max_gap_sec,
        "max_ct_sec": r.max_ct_sec,
        "consultado_en": r.consultado_en.strftime("%Y-%m-%d %H:%M") if r.consultado_en else None,
        "exacta": exacta,
    }


def recuperar(operations: List[str], materials: List[str], start_date: str, end_date: str,
              max_gap_sec: float, max_ct_sec: float, gmasite: str, db=None) -> Optional[dict]:
    """
    Arma una respuesta de ciclo-estadisticas con lo guardado. None si no hay nada.
    Sin `materials`: todos los materiales guardados de esas operaciones.
    """
    if db is None and not asegurar_tabla():
        return None
    propia = db is None
    db = db or SessionLocal()
    try:
        q = db.query(T).filter(T.gmasite == gmasite, T.operation.in_(operations))
        if materials:
            q = q.filter(T.material.in_(materials))
        filas = q.all()
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudo leer el historico MES: %s", e)
        return None
    finally:
        if propia:
            db.close()

    # Por (material, operacion): la exacta si existe; si no, la mas reciente.
    elegidas: Dict[tuple, tuple] = {}
    for r in filas:
        llave = (r.material, r.operation)
        exacta = (r.start_date == start_date and r.end_date == end_date
                  and r.max_gap_sec == float(max_gap_sec) and r.max_ct_sec == float(max_ct_sec))
        actual = elegidas.get(llave)
        if actual is None:
            elegidas[llave] = (r, exacta)
        elif exacta and not actual[1]:
            elegidas[llave] = (r, True)
        elif exacta == actual[1] and (r.consultado_en or datetime.min) > (actual[0].consultado_en or datetime.min):
            elegidas[llave] = (r, exacta)
    if not elegidas:
        return None

    ordenadas = [elegidas[k] for k in sorted(elegidas)]
    origenes = [_origen(r, ex) for r, ex in ordenadas]
    periodos = {}
    for o in origenes:
        periodos[(o["start_date"], o["end_date"], o["max_gap_sec"], o["max_ct_sec"], o["consultado_en"])] = {
            k: o[k] for k in ("start_date", "end_date", "max_gap_sec", "max_ct_sec", "consultado_en")}
    return {
        "data": [_fila(r) for r, _ in ordenadas],
        "historico": {
            "filas": len(ordenadas),
            "exactas": sum(1 for _, ex in ordenadas if ex),
            "periodos": sorted(periodos.values(), key=lambda p: p["consultado_en"] or "", reverse=True),
            "detalle": origenes,
        },
    }


def operaciones_guardadas(material: str, gmasite: str) -> List[dict]:
    """Operaciones guardadas de un material (respaldo de /material-operaciones)."""
    if not asegurar_tabla():
        return []
    db = SessionLocal()
    try:
        filas = (db.query(T.operation,
                          func.max(T.recursos),
                          func.max(T.consultado_en))
                 .filter(T.gmasite == gmasite, T.material == material)
                 .group_by(T.operation).order_by(T.operation).all())
        # TOTAL_COMPLETES: piezas de la consulta mas reciente de cada operacion.
        resultado = []
        for op, recursos, ultimo in filas:
            r = (db.query(T).filter(T.gmasite == gmasite, T.material == material, T.operation == op)
                 .order_by(T.consultado_en.desc()).first())
            resultado.append({
                "OPERATION": op,
                "TOTAL_COMPLETES": int((r.proceso or {}).get("n", 0) + (r.proceso or {}).get("excluidos", 0)) if r else 0,
                "RECURSOS": int(recursos or 0),
                "ULTIMO_EVENTO": None,
            })
        return resultado
    except Exception as e:  # noqa: BLE001
        log.warning("No se pudo leer el historico MES: %s", e)
        return []
    finally:
        db.close()


def listar(material: Optional[str], gmasite: str, limite: int = 200) -> List[dict]:
    if not asegurar_tabla():
        return []
    db = SessionLocal()
    try:
        q = db.query(T).filter(T.gmasite == gmasite)
        if material:
            q = q.filter(T.material == material)
        q = q.order_by(T.consultado_en.desc(), T.material, T.operation).limit(limite)
        return [{**_fila(r), **_origen(r, True)} for r in q.all()]
    finally:
        db.close()
