import hdbcli.dbapi
from datetime import datetime
from typing import List, Dict, Any, Optional
from app.config import HANA_CONFIG
from app.services.mes.hana_utils import (
    calday_placeholder as _calday,
    calday_historico as _calday_hist,
    validar_rango,
    gmasite_sql,
    tz_offset,
)

# Sitio MES y desfase horario (configurables por .env; antes fijos '10' y -21600).
_SITE = gmasite_sql()
_TZ = tz_offset()

class HanaService:
    def __init__(self):
        self.conn = None

    def open(self):
        self.conn = hdbcli.dbapi.connect(
            address=HANA_CONFIG["address"],
            port=HANA_CONFIG["port"],
            user=HANA_CONFIG["user"],
            password=HANA_CONFIG["password"],
            databaseName=HANA_CONFIG["database"]
        )

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def get_cycle_time(
        self, 
        operation: str = "OBC_FASSY_ST010", 
        start_date: Optional[str] = None, 
        end_date: Optional[str] = None,
        limit: int = 60
    ) -> List[Dict[str, Any]]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]
            
            calday_placeholder = _calday(start_date, end_date, dias_atras=1)

            sql = f"""
            WITH base AS (
              SELECT
                al."SFC",
                al."MATERIAL",
                ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS START_TS,
                ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS COMPLETE_TS
              FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                (
                  placeholder."$$F_GMASITE$$"          => {_SITE},
                  placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                  placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                ) al
              WHERE
                al."OPERATION" = ?
                AND al."ACTION_CODE" IN ('START','COMPLETE')
              GROUP BY al."SFC", al."MATERIAL"
              HAVING
                MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END) IS NOT NULL
                AND MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END) IS NOT NULL
            )
            SELECT
              TO_VARCHAR(COMPLETE_TS, 'YYYY-MM-DD HH24:MI:SS') AS "time",
              SECONDS_BETWEEN(START_TS, COMPLETE_TS)           AS "value",
              "SFC",
              "MATERIAL"
            FROM base
            WHERE COMPLETE_TS >= START_TS
            ORDER BY "time" DESC
            LIMIT ?;
            """

            cursor.execute(sql, (operation, limit))
            rows = cursor.fetchall()

            result = []
            for row in rows:
                # CORREGIDO (Fase 0): el SELECT regresa 4 columnas (time, value,
                # SFC, MATERIAL). Antes se leia row[4] -> IndexError en cuanto
                # habia datos, y "series" recibia el valor numerico.
                result.append({
                    "time": row[0],
                    "series": operation,
                    "value": float(row[1]) if row[1] is not None else None,
                    "SFC": row[2],
                    "MATERIAL": row[3],
                })
            return result

        finally:
            self.close()

    def get_avg_cycle_time(
        self, 
        operation: str = "OBC_FASSY_ST010", 
        start_date: Optional[str] = None, 
        end_date: Optional[str] = None,
        limit: int = 60
    ) -> List[Dict[str, Any]]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            calday_placeholder = _calday(start_date, end_date, dias_atras=1)

            sql = f"""
            WITH base AS (
              SELECT
                al."SFC",
                al."MATERIAL",
                al."OPERATION",
                ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS START_TS,
                ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS COMPLETE_TS
              FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                (
                  placeholder."$$F_GMASITE$$"          => {_SITE},
                  placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                  placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                ) al
              WHERE
                al."OPERATION" = ?
                AND al."ACTION_CODE" IN ('START','COMPLETE')
              GROUP BY al."SFC", al."MATERIAL", al."OPERATION"
              HAVING
                MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END) IS NOT NULL
                AND MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END) IS NOT NULL
            ),
            ultimas_piezas AS (
              SELECT
                OPERATION,
                MATERIAL,
                COMPLETE_TS,
                SECONDS_BETWEEN(START_TS, COMPLETE_TS) AS CT_SECONDS
              FROM base
              WHERE COMPLETE_TS >= START_TS
              ORDER BY COMPLETE_TS DESC
              LIMIT ?
            )
            SELECT
              OPERATION,
              MATERIAL,
              ROUND(AVG(CT_SECONDS), 2) AS AVG_CYCLE_TIME_SEC,
              COUNT(*)                  AS TOTAL_PIECES
            FROM ultimas_piezas
            GROUP BY OPERATION, MATERIAL;
            """

            cursor.execute(sql, (operation, limit))
            rows = cursor.fetchall()

            result = []
            for row in rows:
                result.append({
                    "OPERATION": row[0],
                    "MATERIAL": row[1],
                    "AVG_CYCLE_TIME_SEC": float(row[2]) if row[2] is not None else None,
                    "TOTAL_PIECES": row[3],
                })
            return result

        finally:
            self.close()

    def get_daily_cycle_time(
        self, 
        operation: str = "OBC_FASSY_ST010", 
        material: Optional[str] = None,
        start_date: Optional[str] = None, 
        end_date: Optional[str] = None,
        limit: int = 60
    ) -> List[Dict[str, Any]]:
        # Fase 0: las fechas se insertan en el placeholder; se validan antes de conectar.
        start_date, end_date = validar_rango(start_date, end_date)
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            material_clause = "AND al.\"MATERIAL\" = ?" if material else ""

            if start_date and end_date:
                sql = f"""
                WITH base AS (
                  SELECT
                    al."SFC",
                    al."MATERIAL",
                    al."OPERATION",
                    ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS START_TS,
                    ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS COMPLETE_TS
                  FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                    (
                      placeholder."$$F_GMASITE$$"          => {_SITE},
                      placeholder."$$F_CALDAY$$"           => '{start_date}-{end_date}',
                      placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                    ) al
                  WHERE
                    al."OPERATION" = ?
                    {material_clause}
                    AND al."ACTION_CODE" IN ('START','COMPLETE')
                  GROUP BY al."SFC", al."MATERIAL", al."OPERATION"
                  HAVING
                    MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END) IS NOT NULL
                    AND MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END) IS NOT NULL
                )
                SELECT
                  TO_VARCHAR(COMPLETE_TS, 'YYYY-MM-DD') AS "DATE",
                  OPERATION,
                  MATERIAL,
                  ROUND(AVG(SECONDS_BETWEEN(START_TS, COMPLETE_TS)), 2) AS AVG_CYCLE_TIME_SEC,
                  COUNT(*)                                             AS TOTAL_PIECES
                FROM base
                WHERE COMPLETE_TS >= START_TS
                GROUP BY TO_VARCHAR(COMPLETE_TS, 'YYYY-MM-DD'), OPERATION, MATERIAL
                ORDER BY "DATE" ASC, MATERIAL ASC;
                """
                params = [operation, material] if material else [operation]
                cursor.execute(sql, params)
            else:
                sql = f"""
                WITH base AS (
                  SELECT
                    al."SFC",
                    al."MATERIAL",
                    al."OPERATION",
                    ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS START_TS,
                    ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS COMPLETE_TS
                  FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                    (
                      placeholder."$$F_GMASITE$$"          => {_SITE},
                      placeholder."$$F_CALDAY$$"           => TO_NVARCHAR(ADD_DAYS(CURRENT_DATE, -1), 'YYYYMMDD') || '-' || TO_NVARCHAR(CURRENT_DATE, 'YYYYMMDD'),
                      placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                    ) al
                  WHERE
                    al."OPERATION" = ?
                    {material_clause}
                    AND al."ACTION_CODE" IN ('START','COMPLETE')
                  GROUP BY al."SFC", al."MATERIAL", al."OPERATION"
                  HAVING
                    MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END) IS NOT NULL
                    AND MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END) IS NOT NULL
                ),
                ultimas_piezas AS (
                  SELECT
                    OPERATION,
                    MATERIAL,
                    COMPLETE_TS,
                    SECONDS_BETWEEN(START_TS, COMPLETE_TS) AS CT_SECONDS
                  FROM base
                  WHERE COMPLETE_TS >= START_TS
                  ORDER BY COMPLETE_TS DESC
                  LIMIT ?
                )
                SELECT
                  TO_VARCHAR(CURRENT_DATE, 'YYYY-MM-DD') AS "DATE",
                  OPERATION,
                  MATERIAL,
                  ROUND(AVG(CT_SECONDS), 2) AS AVG_CYCLE_TIME_SEC,
                  COUNT(*)                  AS TOTAL_PIECES
                FROM ultimas_piezas
                GROUP BY OPERATION, MATERIAL;
                """
                params = [operation, material, limit] if material else [operation, limit]
                cursor.execute(sql, params)

            rows = cursor.fetchall()

            result = []
            for row in rows:
                result.append({
                    "DATE": row[0],
                    "OPERATION": row[1],
                    "MATERIAL": row[2],
                    "AVG_CYCLE_TIME_SEC": float(row[3]) if row[3] is not None else None,
                    "TOTAL_PIECES": row[4],
                })
            return result

        finally:
            self.close()

    def get_available_operations(self) -> List[str]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]
            sql = f"""
            SELECT DISTINCT "OPERATION"
            FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
              (
                placeholder."$$F_GMASITE$$"          => {_SITE},
                placeholder."$$F_CALDAY$$"           => TO_NVARCHAR(ADD_DAYS(CURRENT_DATE, -30), 'YYYYMMDD') || '-' || TO_NVARCHAR(CURRENT_DATE, 'YYYYMMDD'),
                placeholder."$$F_DATA_TEMPERATURE$$" => '9'
              )
            WHERE "OPERATION" IS NOT NULL
            ORDER BY "OPERATION" ASC;
            """

            cursor.execute(sql)
            rows = cursor.fetchall()
            operations = [row[0] for row in rows if row[0]]
            return operations

        finally:
            self.close()

    def get_start_to_start_cycle_time(
        self,
        operation: str = "OBC_FASSY_ST010",
        material: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 60
    ) -> List[Dict[str, Any]]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            calday_placeholder = _calday(start_date, end_date, dias_atras=1)

            material_clause = "AND al.\"MATERIAL\" = ?" if material else ""

            sql = f"""
            WITH start_events AS (
                SELECT
                    al."SFC",
                    al."MATERIAL",
                    ADD_SECONDS(TO_TIMESTAMP(al."DATE_TIME", 'YYYYMMDDHH24MISS'), {_TZ}) AS START_TS
                FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                    (
                        placeholder."$$F_GMASITE$$"          => {_SITE},
                        placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                        placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                    ) al
                WHERE al."OPERATION"   = ?
                  {material_clause}
                  AND al."ACTION_CODE" = 'START'
            ),
            lead_calc AS (
                SELECT
                    "SFC",
                    "MATERIAL",
                    START_TS,
                    LEAD("SFC") OVER (ORDER BY START_TS ASC)    AS NEXT_SFC,
                    LEAD(START_TS) OVER (ORDER BY START_TS ASC) AS NEXT_START_TS
                FROM start_events
            )
            SELECT
                TO_VARCHAR(START_TS, 'YYYY-MM-DD HH24:MI:SS') AS "DATE_TIME",
                SECONDS_BETWEEN(START_TS, NEXT_START_TS)      AS "CYCLE_TIME_SEC",
                "SFC",
                "NEXT_SFC",
                "MATERIAL"
            FROM lead_calc
            WHERE NEXT_START_TS IS NOT NULL
            ORDER BY START_TS DESC
            LIMIT ?;
            """

            params = [operation, material, limit] if material else [operation, limit]
            cursor.execute(sql, params)
            rows = cursor.fetchall()

            result = []
            for row in rows:
                result.append({
                    "DATE_TIME": row[0],
                    "CYCLE_TIME_SEC": float(row[1]) if row[1] is not None else None,
                    "SFC": row[2],
                    "NEXT_SFC": row[3],
                    "MATERIAL": row[4],
                })
            return result

        finally:
            self.close()

    def get_available_materials(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[str]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            calday_placeholder = _calday_hist(start_date, end_date)

            sql = f"""
            SELECT DISTINCT "MATERIAL"
            FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
              (
                placeholder."$$F_GMASITE$$"          => {_SITE},
                placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                placeholder."$$F_DATA_TEMPERATURE$$" => '9'
              )
            WHERE "MATERIAL" IS NOT NULL
            ORDER BY "MATERIAL" ASC;
            """

            cursor.execute(sql)
            rows = cursor.fetchall()
            materials = [row[0] for row in rows if row[0]]
            return materials

        finally:
            self.close()

    def get_materials_process_mapping(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            calday_placeholder = _calday_hist(start_date, end_date)

            sql = f"""
            WITH base_operaciones AS (
                SELECT DISTINCT
                    al."MATERIAL",
                    al."OPERATION",
                    CASE 
                        WHEN UPPER(al."OPERATION") LIKE '%SMT%'  OR UPPER(al."OPERATION") LIKE '%PCB%'  THEN 'SMT'
                        WHEN UPPER(al."OPERATION") LIKE '%FASSY%'                                       THEN 'FASSY'
                        WHEN UPPER(al."OPERATION") LIKE '%EOL%'   OR UPPER(al."OPERATION") LIKE '%EOLT%' THEN 'EOLT'
                        WHEN UPPER(al."OPERATION") LIKE '%REW%'   OR UPPER(al."OPERATION") LIKE '%NC%'   THEN 'REWORK'
                        ELSE 'BACKEND'
                    END AS CATEGORIA
                FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                    (
                        placeholder."$$F_GMASITE$$"          => {_SITE},
                        placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                        placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                    ) al
                WHERE al."MATERIAL" IS NOT NULL 
                  AND al."OPERATION" IS NOT NULL
            )
            SELECT
                "MATERIAL",
                MAX(CASE WHEN CATEGORIA = 'SMT'     THEN 1 ELSE 0 END) AS PASA_POR_SMT,
                MAX(CASE WHEN CATEGORIA = 'FASSY'   THEN 1 ELSE 0 END) AS PASA_POR_FASSY,
                MAX(CASE WHEN CATEGORIA = 'EOLT'    THEN 1 ELSE 0 END) AS PASA_POR_EOLT,
                MAX(CASE WHEN CATEGORIA = 'REWORK'  THEN 1 ELSE 0 END) AS PASA_POR_REWORK,
                MAX(CASE WHEN CATEGORIA = 'BACKEND' THEN 1 ELSE 0 END) AS PASA_POR_BACKEND
            FROM base_operaciones
            GROUP BY "MATERIAL"
            ORDER BY "MATERIAL" ASC;
            """

            cursor.execute(sql)
            rows = cursor.fetchall()

            result = []
            for row in rows:
                result.append({
                    "MATERIAL": row[0],
                    "SMT": bool(row[1]),
                    "FASSY": bool(row[2]),
                    "EOLT": bool(row[3]),
                    "REWORK": bool(row[4]),
                    "BACKEND": bool(row[5])
                })
            return result

        finally:
            self.close()

    def get_line_cycle_time_summary(
        self,
        line_filter: str = "FASSY",
        material: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            calday_placeholder = _calday(start_date, end_date, dias_atras=14)

            material_clause = "AND al.\"MATERIAL\" = ?" if material else ""

            # 3. Consulta SQL unificada para toda la línea
            sql = f"""
            WITH base AS (
              SELECT
                al."SFC",
                al."MATERIAL",
                al."OPERATION",
                ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS START_TS,
                ADD_SECONDS(TO_TIMESTAMP(MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END), 'YYYYMMDDHH24MISS'), {_TZ}) AS COMPLETE_TS
              FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                (
                  placeholder."$$F_GMASITE$$"          => {_SITE},
                  placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                  placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                ) al
              WHERE
                al."OPERATION" LIKE ?
                {material_clause}
                AND al."ACTION_CODE" IN ('START','COMPLETE')
              GROUP BY al."SFC", al."MATERIAL", al."OPERATION"
              HAVING
                MAX(CASE WHEN al."ACTION_CODE" = 'START' THEN al."DATE_TIME" END) IS NOT NULL
                AND MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."DATE_TIME" END) IS NOT NULL
            )
            SELECT
              OPERATION,
              MATERIAL,
              ROUND(AVG(SECONDS_BETWEEN(START_TS, COMPLETE_TS)), 2) AS AVG_CYCLE_TIME_SEC,
              COUNT(*)                                             AS TOTAL_PIECES
            FROM base
            WHERE COMPLETE_TS >= START_TS
            GROUP BY OPERATION, MATERIAL
            ORDER BY OPERATION ASC, MATERIAL ASC;
            """
            search_pattern = f"%{line_filter}%"
            params = [search_pattern, material] if material else [search_pattern]

            cursor.execute(sql, params)
            rows = cursor.fetchall()

            result = []
            for row in rows:
                result.append({
                    "OPERATION": row[0],
                    "MATERIAL": row[1],
                    "AVG_CYCLE_TIME_SEC": float(row[2]) if row[2] is not None else None,
                    "TOTAL_PIECES": row[3],
                })
            return result

        finally:
            self.close()


    def get_material_operation_matrix(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        material: Optional[str] = None,
        line_filter: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            calday_placeholder = _calday_hist(start_date, end_date)

            where_clauses = ["al.\"MATERIAL\" IS NOT NULL", "al.\"OPERATION\" IS NOT NULL"]
            params = []

            if material:
                where_clauses.append("al.\"MATERIAL\" = ?")
                params.append(material)

            if line_filter:
                where_clauses.append("al.\"OPERATION\" LIKE ?")
                params.append(f"%{line_filter}%")

            where_str = " AND ".join(where_clauses)

            sql = f"""
            SELECT
                al."MATERIAL",
                al."OPERATION",
                MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN 1 ELSE 0 END) AS HAS_COMPLETE,
                COUNT(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."SFC" END) AS TOTAL_COMPLETES
            FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                (
                    placeholder."$$F_GMASITE$$"          => {_SITE},
                    placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                    placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                ) al
            WHERE {where_str}
            GROUP BY al."MATERIAL", al."OPERATION"
            ORDER BY al."MATERIAL" ASC, al."OPERATION" ASC;
            """

            cursor.execute(sql, params)
            rows = cursor.fetchall()

            result = []
            for row in rows:
                result.append({
                    "MATERIAL": row[0],
                    "OPERATION": row[1],
                    "HAS_COMPLETE": bool(row[2]),
                    "TOTAL_COMPLETES": row[3]
                })
            return result

        finally:
            self.close()

    def get_material_operations_grouped(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        material: Optional[str] = None,
        line_filter: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]

            calday_placeholder = _calday_hist(start_date, end_date)

            where_clauses = ["al.\"MATERIAL\" IS NOT NULL", "al.\"OPERATION\" IS NOT NULL"]
            params = []

            if material:
                where_clauses.append("al.\"MATERIAL\" = ?")
                params.append(material)

            if line_filter:
                where_clauses.append("al.\"OPERATION\" LIKE ?")
                params.append(f"%{line_filter}%")

            where_str = " AND ".join(where_clauses)

            sql = f"""
            SELECT
                al."MATERIAL",
                al."OPERATION",
                MAX(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN 1 ELSE 0 END) AS HAS_COMPLETE,
                COUNT(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN al."SFC" END) AS TOTAL_COMPLETES
            FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
                (
                    placeholder."$$F_GMASITE$$"          => {_SITE},
                    placeholder."$$F_CALDAY$$"           => {calday_placeholder},
                    placeholder."$$F_DATA_TEMPERATURE$$" => '9'
                ) al
            WHERE {where_str}
            GROUP BY al."MATERIAL", al."OPERATION"
            ORDER BY al."MATERIAL" ASC, al."OPERATION" ASC;
            """

            cursor.execute(sql, params)
            rows = cursor.fetchall()

            grouped_data = {}
            for row in rows:
                mat = row[0]
                op_info = {
                    "OPERATION": row[1],
                    "HAS_COMPLETE": bool(row[2]),
                    "TOTAL_COMPLETES": row[3]
                }
                
                if mat not in grouped_data:
                    grouped_data[mat] = []
                
                grouped_data[mat].append(op_info)

            result = []
            for mat, ops in grouped_data.items():
                result.append({
                    "MATERIAL": mat,
                    "total_operations": len(ops),
                    "operations": ops
                })

            return result

        finally:
            self.close()

    # =====================================================================
    # FASE 1 - Comparativa SAP/MES
    # =====================================================================
    def _eventos_start_complete(self, operations: List[str], calday_ini: str, calday_fin: str):
        """Eventos crudos START/COMPLETE de las operaciones indicadas (todos los materiales)."""
        schema = HANA_CONFIG["schema"]
        marcadores = ", ".join(["?"] * len(operations))
        sql = f"""
        SELECT
          al."SFC",
          al."MATERIAL",
          al."OPERATION",
          al."ACTION_CODE",
          al."DATE_TIME",
          al."RESRCE"
        FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
          (
            placeholder."$$F_GMASITE$$"          => {_SITE},
            placeholder."$$F_CALDAY$$"           => '{calday_ini}-{calday_fin}',
            placeholder."$$F_DATA_TEMPERATURE$$" => '9'
          ) al
        WHERE
          al."ACTION_CODE" IN ('START','COMPLETE')
          AND al."OPERATION" IN ({marcadores})
        """
        cursor = self.conn.cursor()
        cursor.execute(sql, list(operations))
        while True:
            lote = cursor.fetchmany(20000)
            if not lote:
                break
            for fila in lote:
                yield fila

    def get_ciclo_estadisticas(
        self,
        operations: List[str],
        start_date: str,
        end_date: str,
        materials: Optional[List[str]] = None,
        max_gap_sec: float = 600,
        max_ct_sec: float = 3600,
    ) -> Dict[str, Any]:
        from app.services.mes.ciclo_stats import Evento, calcular_estadisticas, normalizar_material, parsear_ts
        from app.services.mes.hana_utils import rango_local_con_margen

        calday_ini, calday_fin, desde_txt, hasta_txt = rango_local_con_margen(start_date, end_date)
        desde = datetime.strptime(desde_txt, "%Y-%m-%d %H:%M:%S")
        hasta = datetime.strptime(hasta_txt, "%Y-%m-%d %H:%M:%S")
        filtro_mat = {normalizar_material(m) for m in (materials or []) if str(m).strip()} or None

        try:
            self.open()
            eventos = []
            descartados = 0
            for sfc, material, operation, action, date_time, resrce in self._eventos_start_complete(
                operations, calday_ini, calday_fin
            ):
                ts = parsear_ts(date_time, _TZ)
                if ts is None or not sfc or not operation:
                    descartados += 1
                    continue
                eventos.append(Evento(
                    sfc=str(sfc),
                    material=normalizar_material(material),
                    operation=str(operation),
                    action=str(action).strip().upper(),
                    ts=ts,
                    resrce=str(resrce).strip() if resrce is not None else "",
                ))
        finally:
            self.close()

        datos = calcular_estadisticas(
            eventos, desde, hasta, materiales=filtro_mat,
            max_gap_sec=max_gap_sec, max_ct_sec=max_ct_sec,
        )
        return {
            "start_date": start_date,
            "end_date": end_date,
            "gmasite": _SITE.strip("'"),
            "tz_offset_sec": _TZ,
            "max_gap_sec": max_gap_sec,
            "max_ct_sec": max_ct_sec,
            "total_eventos": len(eventos),
            "eventos_descartados": descartados,
            "data": datos,
        }

    def get_operaciones_de_material(
        self,
        material: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        dias_atras: int = 60,
    ) -> List[Dict[str, Any]]:
        """Operaciones MES por las que ha pasado un material (para capturar el mapeo)."""
        from app.services.mes.ciclo_stats import normalizar_material, parsear_ts

        material_norm = normalizar_material(material)
        if not material_norm:
            raise ValueError("material es obligatorio.")
        calday = _calday(start_date, end_date, dias_atras=dias_atras)
        try:
            self.open()
            cursor = self.conn.cursor()
            schema = HANA_CONFIG["schema"]
            sql = f"""
            SELECT
              al."OPERATION",
              COUNT(CASE WHEN al."ACTION_CODE" = 'COMPLETE' THEN 1 END) AS TOTAL_COMPLETES,
              MAX(al."DATE_TIME") AS ULTIMO,
              COUNT(DISTINCT al."RESRCE") AS RECURSOS
            FROM "{schema}"."kostal.sapme.bwdatamodel::BW_ACTIVITY_LOG"
              (
                placeholder."$$F_GMASITE$$"          => {_SITE},
                placeholder."$$F_CALDAY$$"           => {calday},
                placeholder."$$F_DATA_TEMPERATURE$$" => '9'
              ) al
            WHERE al."MATERIAL" IS NOT NULL
              AND al."OPERATION" IS NOT NULL
              AND UPPER(LTRIM(al."MATERIAL", '0')) = ?
            GROUP BY al."OPERATION"
            ORDER BY al."OPERATION" ASC
            """
            cursor.execute(sql, [material_norm])
            filas = cursor.fetchall()
        finally:
            self.close()

        resultado = []
        for operation, completes, ultimo, recursos in filas:
            ts = parsear_ts(ultimo, _TZ)
            resultado.append({
                "OPERATION": operation,
                "TOTAL_COMPLETES": int(completes or 0),
                "RECURSOS": int(recursos or 0),
                "ULTIMO_EVENTO": ts.strftime("%Y-%m-%d %H:%M:%S") if ts else None,
            })
        return resultado
