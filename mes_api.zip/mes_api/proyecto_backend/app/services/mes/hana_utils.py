# app/services/mes/hana_utils.py
"""
Utilidades compartidas por las consultas a SAP HANA (BW_ACTIVITY_LOG).

FASE 0 - Seguridad:
  Las fechas llegaban por query string y se pegaban con f-string dentro del
  placeholder $$F_CALDAY$$ (inyeccion SQL). Ahora TODA fecha pasa por
  `validar_fecha()` (formato YYYYMMDD y fecha real) antes de tocar el SQL.
  El valor del placeholder no se puede enviar como parametro "?" de forma
  confiable en la vista calculada, por eso se valida en lugar de parametrizar.
"""
import re
from datetime import datetime, timedelta
from typing import Optional, Tuple

from app.config import MES_GMASITE, MES_TZ_OFFSET_SEC

_RE_FECHA = re.compile(r"^\d{8}$")


def validar_fecha(valor: Optional[str], nombre: str = "fecha") -> Optional[str]:
    """Devuelve la fecha YYYYMMDD validada, o None. Lanza ValueError si es invalida."""
    if valor is None or str(valor).strip() == "":
        return None
    texto = str(valor).strip()
    if not _RE_FECHA.match(texto):
        raise ValueError(f"{nombre} debe tener formato YYYYMMDD (recibido: {texto!r}).")
    try:
        datetime.strptime(texto, "%Y%m%d")
    except ValueError:
        raise ValueError(f"{nombre} no es una fecha valida: {texto!r}.")
    return texto


def validar_rango(start_date: Optional[str], end_date: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
    inicio = validar_fecha(start_date, "start_date")
    fin = validar_fecha(end_date, "end_date")
    if inicio and fin and inicio > fin:
        raise ValueError("start_date no puede ser mayor que end_date.")
    return inicio, fin


def calday_placeholder(start_date: Optional[str], end_date: Optional[str], dias_atras: int) -> str:
    """
    Fragmento SQL para $$F_CALDAY$$.
    - Con ambas fechas: rango literal ya validado.
    - Sin fechas: los ultimos `dias_atras` dias hasta hoy (calculado en HANA).
    """
    inicio, fin = validar_rango(start_date, end_date)
    if inicio and fin:
        return f"'{inicio}-{fin}'"
    return (
        f"TO_NVARCHAR(ADD_DAYS(CURRENT_DATE, -{int(dias_atras)}), 'YYYYMMDD') "
        f"|| '-' || TO_NVARCHAR(CURRENT_DATE, 'YYYYMMDD')"
    )


def calday_historico(start_date: Optional[str], end_date: Optional[str]) -> str:
    """Igual que calday_placeholder pero sin fechas = historico completo (desde 2010)."""
    inicio, fin = validar_rango(start_date, end_date)
    if inicio and fin:
        return f"'{inicio}-{fin}'"
    return "'20100101-' || TO_NVARCHAR(CURRENT_DATE, 'YYYYMMDD')"


def gmasite_sql() -> str:
    """Literal SQL del sitio MES (validado en config: solo digitos)."""
    return f"'{MES_GMASITE}'"


def tz_offset() -> int:
    return int(MES_TZ_OFFSET_SEC)


def rango_local_con_margen(start_date: str, end_date: str) -> Tuple[str, str, str, str]:
    """
    FASE 1 - Corte de dia correcto.
    DATE_TIME del activity log viene en UTC y $$F_CALDAY$$ filtra por fecha UTC.
    El dia local D (UTC-6) va de D 06:00 UTC a D+1 06:00 UTC, asi que se consulta
    CALDAY [inicio, fin+1] y despues se filtra por la hora LOCAL ya convertida.

    Devuelve (calday_inicio, calday_fin, ts_local_desde, ts_local_hasta_exclusivo).
    """
    inicio, fin = validar_rango(start_date, end_date)
    if not (inicio and fin):
        raise ValueError("start_date y end_date son obligatorios.")
    d_ini = datetime.strptime(inicio, "%Y%m%d")
    d_fin = datetime.strptime(fin, "%Y%m%d")
    margen = timedelta(days=1)
    calday_ini = (d_ini - margen).strftime("%Y%m%d") if MES_TZ_OFFSET_SEC > 0 else inicio
    calday_fin = (d_fin + margen).strftime("%Y%m%d") if MES_TZ_OFFSET_SEC < 0 else fin
    desde = d_ini.strftime("%Y-%m-%d 00:00:00")
    hasta = (d_fin + margen).strftime("%Y-%m-%d 00:00:00")
    return calday_ini, calday_fin, desde, hasta
