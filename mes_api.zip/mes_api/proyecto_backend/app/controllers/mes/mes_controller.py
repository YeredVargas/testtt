from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from app.services.mes.mes_service import HanaService
from app.services.mes import historico
from app.services.mes.ciclo_stats import normalizar_material
from app.config import MES_GMASITE, MES_TZ_OFFSET_SEC
import logging
from app.schemas.mes.mes_schema import (
    OperationsCatalogResponse, 
    SfcResponse, 
    CycleTimeResponse, 
    CycleTimeAverageResponse, 
    DailyCycleTimeResponse, 
    StartToStartResponse, 
    MaterialsCatalogResponse, 
    LineCycleTimeResponse,  
    StationCycleTimeSummary,
    MaterialMappingResponse,
    MaterialOperationsGroupResponse,
    MaterialOperationMatrixResponse,
    CicloEstadisticasResponse,
    OperacionesDeMaterialResponse,
    )
from datetime import date, datetime, timedelta
 
router = APIRouter()
log = logging.getLogger(__name__)
 
@router.get("/buscar/{sfc}", response_model=List[SfcResponse])
def buscar_sfc(sfc: str):
    service = HanaService()
    try:
        data = service.get_sfc_data(sfc)
        if not data:
            raise HTTPException(status_code=404, detail="SFC no encontrado")
        return data
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/cycle-time", response_model=List[CycleTimeResponse])
def obtener_tiempo_ciclo(
    operation: str = Query("OBC_FASSY_ST010", description="Estación / Operación del MES"),
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Opcional)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Opcional)"),
    limit: int = Query(60, description="Límite de registros a retornar")
):
    service = HanaService()
    try:
        data = service.get_cycle_time(
            operation=operation, 
            start_date=start_date, 
            end_date=end_date, 
            limit=limit
        )
        return data
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando SAP HANA: {str(e)}")


@router.get("/promedio-tiempo-ciclo", response_model=List[CycleTimeAverageResponse])
def obtener_promedio_tiempo_ciclo(
    operation: str = Query("OBC_FASSY_ST010", description="Estación / Operación del MES"),
    limit: int = Query(60, description="Cantidad N de últimas piezas a promediar"),
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Opcional)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Opcional)")
):
    service = HanaService()
    try:
        data = service.get_avg_cycle_time(
            operation=operation, 
            limit=limit,
            start_date=start_date, 
            end_date=end_date
        )
        return data
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando SAP HANA: {str(e)}")

@router.get("/promedio-diario-ct", response_model=List[DailyCycleTimeResponse])
def obtener_promedio_diario_tiempo_ciclo(
    operation: str = Query("OBC_FASSY_ST010", description="Estación / Operación del MES"),
    material: Optional[str] = Query(None, description="Número de parte / Material (Opcional)"),
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Ej: 20260721)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Ej: 20260803)"),
    limit: int = Query(60, description="Cantidad N de piezas si no se proveen fechas")
):
    service = HanaService()
    try:
        data = service.get_daily_cycle_time(
            operation=operation, 
            material=material,
            start_date=start_date, 
            end_date=end_date,
            limit=limit
        )
        return data
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando SAP HANA: {str(e)}")


@router.get("/operaciones", response_model=OperationsCatalogResponse)
def obtener_operaciones_disponibles():
    service = HanaService()
    try:
        ops = service.get_available_operations()
        return {
            "operations": ops,
            "total": len(ops)
        }
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando operaciones en SAP HANA: {str(e)}")

@router.get("/start-to-start", response_model=List[StartToStartResponse])
def obtener_tiempo_ciclo_start_to_start(
    operation: str = Query("OBC_FASSY_ST010", description="Estación / Operación del MES"),
    material: Optional[str] = Query(None, description="Número de parte / Material (Opcional)"),
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Ej: 20260721)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Ej: 20260803)"),
    limit: int = Query(60, description="Cantidad N de registros a retornar")
):
    service = HanaService()
    try:
        data = service.get_start_to_start_cycle_time(
            operation=operation,
            material=material,
            start_date=start_date,
            end_date=end_date,
            limit=limit
        )
        return data
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando SAP HANA: {str(e)}")

@router.get("/materiales", response_model=MaterialsCatalogResponse)
def obtener_materiales_disponibles(
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Opcional - Si no se envía consulta histórico)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Opcional - Si no se envía consulta histórico)")
):
    service = HanaService()
    try:
        mats = service.get_available_materials(start_date=start_date, end_date=end_date)
        return {
            "start_date": start_date if start_date else "HISTÓRICO COMPLETO",
            "end_date": end_date if end_date else "HOY",
            "total": len(mats),
            "materials": mats
        }
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Error consultando materiales en SAP HANA: {str(e)}"
        )


@router.get("/promedio-linea", response_model=LineCycleTimeResponse)
def obtener_promedio_tiempo_ciclo_linea(
    line_filter: str = Query("FASSY", description="Filtro para las operaciones de la línea (Ej: FASSY, SMT, EOL)"),
    material: Optional[str] = Query(None, description="Número de parte / Material específico (Opcional)"),
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Ej: 20260801)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Ej: 20260805)")
):
    service = HanaService()
    try:
        stations_data = service.get_line_cycle_time_summary(
            line_filter=line_filter,
            material=material,
            start_date=start_date,
            end_date=end_date
        )
        
        return {
            "line_filter": line_filter,
            "start_date": start_date,
            "end_date": end_date,
            "material": material if material else "TODOS",
            "total_stations": len(stations_data),
            "stations": stations_data
        }
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando la línea en SAP HANA: {str(e)}")


@router.get("/mapeo-materiales", response_model=MaterialMappingResponse)
def obtener_mapeo_materiales_por_linea(
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Opcional - Si no se envía consulta histórico)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Opcional - Si no se envía consulta histórico)")
):
    service = HanaService()
    try:
        mapping_data = service.get_materials_process_mapping(start_date=start_date, end_date=end_date)
        return {
            "start_date": start_date if start_date else "HISTÓRICO COMPLETO",
            "end_date": end_date if end_date else "HOY",
            "total_materials": len(mapping_data),
            "materials": mapping_data
        }
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Error consultando mapeo de materiales en SAP HANA: {str(e)}"
        )
    
@router.get("/matriz-operaciones", response_model=MaterialOperationMatrixResponse)
def obtener_matriz_desglosada_material_operacion(
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Opcional)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Opcional)"),
    material: Optional[str] = Query(None, description="Filtrar por un material específico (Opcional)"),
    line_filter: Optional[str] = Query(None, description="Filtrar por línea/estación, Ej: FASSY, SMT (Opcional)")
):
    service = HanaService()
    try:
        matrix_data = service.get_material_operation_matrix(
            start_date=start_date,
            end_date=end_date,
            material=material,
            line_filter=line_filter
        )
        return {
            "start_date": start_date if start_date else "HISTÓRICO COMPLETO",
            "end_date": end_date if end_date else "HOY",
            "total_records": len(matrix_data),
            "data": matrix_data
        }
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Error consultando matriz material-operación en SAP HANA: {str(e)}"
        )

@router.get("/materiales-operaciones-agrupadas", response_model=MaterialOperationsGroupResponse)
def obtener_materiales_con_sus_operaciones(
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (Opcional)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (Opcional)"),
    material: Optional[str] = Query(None, description="Filtrar por un material específico (Opcional)"),
    line_filter: Optional[str] = Query(None, description="Filtrar por línea/estación, Ej: FASSY, SMT (Opcional)")
):
    service = HanaService()
    try:
        grouped_result = service.get_material_operations_grouped(
            start_date=start_date,
            end_date=end_date,
            material=material,
            line_filter=line_filter
        )
        return {
            "start_date": start_date if start_date else "HISTÓRICO COMPLETO",
            "end_date": end_date if end_date else "HOY",
            "total_materials": len(grouped_result),
            "data": grouped_result
        }
    except ValueError as e:
        # Fase 0: parametros invalidos (p. ej. fechas) -> 422, no 500.
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Error consultando operaciones por material en SAP HANA: {str(e)}"
        )


# =====================================================================
# FASE 1 - Comparativa SAP/MES
# =====================================================================
MAX_DIAS_RANGO = 62
MAX_OPERACIONES = 60
MAX_MATERIALES = 200


def _lista_csv(valor: Optional[str]) -> List[str]:
    if not valor:
        return []
    vistos, salida = set(), []
    for parte in valor.split(","):
        p = parte.strip()
        if p and p not in vistos:
            vistos.add(p)
            salida.append(p)
    return salida


@router.get("/ciclo-estadisticas", response_model=CicloEstadisticasResponse)
def obtener_ciclo_estadisticas(
    operations: str = Query(..., description="Operaciones MES separadas por coma (Ej: OBC_FASSY_ST010,OBC_FASSY_ST020)"),
    materials: Optional[str] = Query(None, description="Materiales separados por coma (opcional; se normalizan sin ceros a la izquierda)"),
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (hora local). Default: hace 14 dias"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD inclusive (hora local). Default: hoy"),
    max_gap_sec: float = Query(600, gt=0, le=86400, description="SALIDA: intervalos START->START mayores a esto se excluyen (paros, comidas)"),
    max_ct_sec: float = Query(3600, gt=0, le=86400, description="PROCESO: ciclos START->COMPLETE mayores a esto se excluyen (piezas detenidas)"),
):
    """
    Tiempo ciclo real por material y operacion, en SEGUNDOS por pieza:

    - **proceso**: START -> COMPLETE del mismo SFC (tiempo en la estacion).
    - **salida**: START -> siguiente START en la operacion (ritmo real de la estacion).

    Se reporta n, mediana (valor recomendado para comparar), promedio, P25/P75/P90,
    minimo, maximo y cuantos ciclos se excluyeron por los limites.
    """
    try:
        ops = _lista_csv(operations)
        mats = _lista_csv(materials)
        if not ops:
            raise ValueError("Indica al menos una operacion en 'operations'.")
        if len(ops) > MAX_OPERACIONES:
            raise ValueError(f"Maximo {MAX_OPERACIONES} operaciones por consulta.")
        if len(mats) > MAX_MATERIALES:
            raise ValueError(f"Maximo {MAX_MATERIALES} materiales por consulta.")

        hoy = date.today()
        end_date = end_date or hoy.strftime("%Y%m%d")
        start_date = start_date or (hoy - timedelta(days=13)).strftime("%Y%m%d")
        dias = (datetime.strptime(end_date, "%Y%m%d") - datetime.strptime(start_date, "%Y%m%d")).days + 1 \
            if start_date.isdigit() and end_date.isdigit() and len(start_date) == 8 and len(end_date) == 8 else 0
        if dias > MAX_DIAS_RANGO:
            raise ValueError(f"El rango maximo es de {MAX_DIAS_RANGO} dias.")

    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

    try:
        respuesta = HanaService().get_ciclo_estadisticas(
            operations=ops,
            start_date=start_date,
            end_date=end_date,
            materials=mats,
            max_gap_sec=max_gap_sec,
            max_ct_sec=max_ct_sec,
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        # v3: HANA no respondio -> contestar con lo guardado en PostgreSQL.
        log.warning("HANA sin respuesta en ciclo-estadisticas: %s", e)
        guardado = historico.recuperar(
            ops, [normalizar_material(m) for m in mats], start_date, end_date,
            max_gap_sec, max_ct_sec, MES_GMASITE,
        )
        if guardado is None:
            raise HTTPException(
                status_code=503,
                detail=f"SAP HANA no respondio y no hay datos guardados para esta consulta: {str(e)}",
            )
        return {
            "start_date": start_date,
            "end_date": end_date,
            "gmasite": MES_GMASITE,
            "tz_offset_sec": MES_TZ_OFFSET_SEC,
            "max_gap_sec": max_gap_sec,
            "max_ct_sec": max_ct_sec,
            "total_eventos": 0,
            "eventos_descartados": 0,
            "data": guardado["data"],
            "fuente": "BD",
            "motivo": f"SAP HANA no respondio: {e.__class__.__name__}",
            "historico": guardado["historico"],
        }

    respuesta["fuente"] = "HANA"
    respuesta["guardadas_en_bd"] = historico.guardar(respuesta, MES_GMASITE)
    return respuesta


@router.get("/material-operaciones", response_model=OperacionesDeMaterialResponse)
def obtener_operaciones_de_material(
    material: str = Query(..., description="Numero de material (con o sin ceros a la izquierda)"),
    start_date: Optional[str] = Query(None, description="Fecha inicio YYYYMMDD (opcional)"),
    end_date: Optional[str] = Query(None, description="Fecha fin YYYYMMDD (opcional)"),
    dias_atras: int = Query(60, ge=1, le=365, description="Si no hay fechas: ultimos N dias"),
):
    """Operaciones MES por las que ha pasado el material. Se usa para capturar el mapeo SAP -> MES."""
    try:
        ops = HanaService().get_operaciones_de_material(
            material=material, start_date=start_date, end_date=end_date, dias_atras=dias_atras
        )
        return {
            "material": material,
            "start_date": start_date,
            "end_date": end_date,
            "total": len(ops),
            "operations": ops,
            "fuente": "HANA",
        }
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        # v3: respaldo con las operaciones que ya se guardaron de este material.
        log.warning("HANA sin respuesta en material-operaciones: %s", e)
        ops = historico.operaciones_guardadas(normalizar_material(material), MES_GMASITE)
        if not ops:
            raise HTTPException(status_code=503,
                                detail=f"SAP HANA no respondio y no hay datos guardados de este material: {str(e)}")
        return {
            "material": material,
            "start_date": start_date,
            "end_date": end_date,
            "total": len(ops),
            "operations": ops,
            "fuente": "BD",
            "motivo": f"SAP HANA no respondio: {e.__class__.__name__}",
        }


@router.get("/historico", tags=["Historico"])
def ver_historico(
    material: Optional[str] = Query(None, description="Material (opcional). Sin material: lo mas reciente de todos."),
    limite: int = Query(200, ge=1, le=2000),
):
    """Estadisticas de ciclo guardadas en PostgreSQL (v3), lo mas reciente primero."""
    mat = normalizar_material(material) if material else None
    filas = historico.listar(mat, MES_GMASITE, limite)
    return {"material": mat, "total": len(filas), "filas": filas}
