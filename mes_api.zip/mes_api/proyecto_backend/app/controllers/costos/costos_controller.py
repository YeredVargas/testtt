# app/controllers/costos/costos_controller.py
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from collections import defaultdict

from app.config import SessionLocal
from app.models.dashboard.pieza import Pieza
from app.models.dashboard.trazabilidad import CostosCK13NCabecera, CostosCK13NElementos, CostosCK13NProduccion 

router = APIRouter(prefix="/costos", tags=["Costos Financieros (BD Local)"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def parsear_fecha_segura(fecha_str):
    try:
        fecha_limpia = str(fecha_str).strip()
        if not fecha_limpia or fecha_limpia == "00000000": return datetime.now().date()
        if "-" in fecha_limpia: return datetime.strptime(fecha_limpia, "%Y-%m-%d").date()
        return datetime.strptime(fecha_limpia, "%Y%m%d").date()
    except Exception: 
        return datetime.now().date()

@router.get("")
def listar_costos_guardados(centro: str = Query("0094"), db: Session = Depends(get_db)):
    """Lista los costos almacenados localmente y agrupa el historial por variante."""
    resultados = db.query(CostosCK13NCabecera, Pieza.nombre_pieza, Pieza.proyecto)\
                   .outerjoin(Pieza, (CostosCK13NCabecera.numero_material == Pieza.numero_material) & (CostosCK13NCabecera.centro == Pieza.centro))\
                   .filter(CostosCK13NCabecera.centro == centro)\
                   .order_by(CostosCK13NCabecera.numero_material, CostosCK13NCabecera.variante, CostosCK13NCabecera.fecha_validez.desc()).all()
    
    agrupado = defaultdict(lambda: {"variantes": defaultdict(list)})
    
    for cabecera, nombre_pieza, proyecto in resultados:
        mat = cabecera.numero_material
        var = cabecera.variante.strip() if cabecera.variante else "Y001"
        
        if mat not in agrupado:
            agrupado[mat]["numero_material"] = mat
            agrupado[mat]["centro"] = cabecera.centro
            agrupado[mat]["nombre_pieza"] = nombre_pieza or "SIN RUTA"
            agrupado[mat]["proyecto"] = proyecto or "SIN PROYECTO"
            
        agrupado[mat]["variantes"][var].append({
            "numero_costeo": cabecera.numero_costeo,
            "estatus": cabecera.estatus,
            "fecha_validez": str(cabecera.fecha_validez),
            "total_global": float(cabecera.total_global),
            "total_fijado": float(cabecera.total_fijado),
            "total_variable": float(cabecera.total_variable),
            "actualizado": cabecera.modificado_en
        })
    
    lista_costos = []
    for mat_data in agrupado.values():
        variantes_array = []
        for var_nombre, historial in mat_data["variantes"].items():
            variantes_array.append({
                "variante": var_nombre,
                "historial": historial
            })
        mat_data["variantes"] = variantes_array
        lista_costos.append(mat_data)
        
    return lista_costos

@router.get("/{material}/produccion/{fecha_validez}")
def obtener_detalle_produccion(material: str, fecha_validez: str, centro: str = Query("0094"), variante: str = Query("Y001"), db: Session = Depends(get_db)):
    """Obtiene el detalle CKIS buscando por la fecha de validez Y variante."""
    fecha_dt = parsear_fecha_segura(fecha_validez)
    cabecera = db.query(CostosCK13NCabecera).filter_by(
        numero_material=material.strip(), centro=centro, variante=variante, fecha_validez=fecha_dt
    ).first()
    
    if not cabecera: 
        return {"elementos": []}
        
    prods = db.query(CostosCK13NProduccion).filter_by(cabecera_id=cabecera.id).order_by(CostosCK13NProduccion.posicion).all()
    
    # 🔴 Este es el return que estaba mal alineado. Ahora está perfectamente dentro de la función.
    return {"elementos": [{
        "posicion": p.posicion, "centro_coste": p.centro_coste, "texto_centro_coste": p.texto_centro_coste,
        "clase_actividad": p.clase_actividad, "texto_actividad": p.texto_actividad, "elemento_coste": p.elemento_coste,
        "texto_recurso": p.texto_recurso, 
        "cantidad": float(p.cantidad), "unidad": p.unidad,
        "valor_total": float(p.valor_total), "moneda": p.moneda
    } for p in prods]}
@router.get("/{material}/elementos/{fecha_validez}")
def obtener_detalle_costo(material: str, fecha_validez: str, centro: str = Query("0094"), variante: str = Query("Y001"), db: Session = Depends(get_db)):
    """Obtiene la Vista 10 financiera buscando por la fecha de validez Y variante."""
    fecha_dt = parsear_fecha_segura(fecha_validez)
    cabecera = db.query(CostosCK13NCabecera).filter_by(
        numero_material=material.strip(), centro=centro, variante=variante, fecha_validez=fecha_dt
    ).first()
    
    if not cabecera: raise HTTPException(status_code=404, detail="No hay costos guardados")
    elementos = db.query(CostosCK13NElementos).filter_by(cabecera_id=cabecera.id).order_by(CostosCK13NElementos.componente).all()
    return {
        "fecha_validez": cabecera.fecha_validez,
        "total_global": float(cabecera.total_global),
        "total_fijado": float(cabecera.total_fijado),
        "total_variable": float(cabecera.total_variable),
        "elementos": [{"componente": e.componente, "denominacion": e.denominacion, "total": float(e.total), "fijado": float(e.fijado), "variable": float(e.variable)} for e in elementos]
    }   