from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from app.config import SessionLocal
from app.models.dashboard.pieza import Pieza
from app.models.dashboard.trazabilidad import Trazabilidad
from app.schemas.graficas.graficas_schema import (
    FiltrosDisponibles,
    GraficasTraceabilidadResponse,
)

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

MESES_NOMBRES = {
    1: "Enero", 2: "Febrero", 3: "Marzo", 4: "Abril", 5: "Mayo", 6: "Junio",
    7: "Julio", 8: "Agosto", 9: "Septiembre", 10: "Octubre", 11: "Noviembre", 12: "Diciembre"
}

@router.get("/filtros", response_model=FiltrosDisponibles)
def get_filtros(
    proceso:          Optional[str] = Query(None),
    numero_material:  Optional[str] = Query(None),
    mes:              Optional[str] = Query(None),  
    centro:           str = Query("0094"), 
    db: Session = Depends(get_db),
):
    """Devuelve las opciones de filtrado dinámico según las selecciones previas y centro."""
    q_mats = db.query(Pieza.numero_material).filter(Pieza.centro == centro).distinct()
    if proceso:
        q_mats = q_mats.join(Trazabilidad, Trazabilidad.pieza_id == Pieza.id).filter(
            func.upper(Trazabilidad.proceso) == proceso.upper()
        )
    numeros_material = [r[0] for r in q_mats.order_by(Pieza.numero_material).all() if r[0]]

    q_procesos = (
        db.query(Trazabilidad.proceso)
        .join(Pieza, Trazabilidad.pieza_id == Pieza.id)
        .filter(Pieza.centro == centro)
        .filter(Trazabilidad.proceso.isnot(None))
        .filter(Trazabilidad.proceso != "")
        .distinct()
    )
    if numero_material:
        q_procesos = q_procesos.filter(Pieza.numero_material == numero_material)
    procesos = [r[0] for r in q_procesos.order_by(Trazabilidad.proceso).all() if r[0]]

    q_proy = db.query(Pieza.proyecto).filter(Pieza.centro == centro).filter(Pieza.proyecto.isnot(None)).distinct()
    if numero_material:
        q_proy = q_proy.filter(Pieza.numero_material == numero_material)
    proyectos = [r[0] for r in q_proy.order_by(Pieza.proyecto).all() if r[0]]

    q_fechas = (
        db.query(Trazabilidad.fecha_inicio)
        .join(Pieza, Trazabilidad.pieza_id == Pieza.id)
        .filter(Pieza.centro == centro)
        .filter(Trazabilidad.fecha_inicio.isnot(None))
        .distinct()
    )
    if numero_material:
        q_fechas = q_fechas.filter(Pieza.numero_material == numero_material)
    if proceso:
        q_fechas = q_fechas.filter(func.upper(Trazabilidad.proceso) == proceso.upper())

    fechas_set = set()
    for r in q_fechas.all():
        fecha = r[0] if isinstance(r, tuple) else r.fecha_inicio
        if fecha:
            fechas_set.add((fecha.year, fecha.month))

    meses_list = []
    for y, m in sorted(list(fechas_set), key=lambda x: (x[0], x[1]), reverse=True):
        meses_list.append({
            "value": f"{y}-{str(m).zfill(2)}",
            "label": f"{MESES_NOMBRES.get(m, '')} {y}"
        })

    return {
        "procesos":         procesos,
        "numeros_material": numeros_material,
        "proyectos":        proyectos,
        "meses":            meses_list,
    }


@router.get("/datos", response_model=GraficasTraceabilidadResponse)
def get_datos_graficas(
    numero_material: str = Query(...),
    proceso:         Optional[str] = Query(None),
    mes:             Optional[str] = Query(None),  
    centro:          str = Query("0094"), 
    db: Session = Depends(get_db),
):
    pieza = db.query(Pieza).filter(Pieza.numero_material == numero_material, Pieza.centro == centro).first()
    if not pieza:
        return {
            "filtros_aplicados": {"numero_material": numero_material, "proceso": proceso, "mes": mes, "centro": centro},
            "resumen": None,
            "graficas": {},
        }

    q_rows = (
        db.query(
            Trazabilidad.proceso,
            Trazabilidad.plnal, # <-- AGREGAMOS plnal A LA CONSULTA
            Trazabilidad.fecha_inicio,
            func.sum(Trazabilidad.tiempo).label("tiempo"),
            func.max(Trazabilidad.equipos).label("equipos"),
        )
        .filter(Trazabilidad.pieza_id == pieza.id)
        .filter(Trazabilidad.tiempo.isnot(None))
        .filter(Trazabilidad.tiempo > 0)
        .filter(Trazabilidad.equipos.isnot(None))
        .filter(Trazabilidad.equipos > 0)
    )

    if proceso and proceso.upper() != "TODOS":
        # Como la BD ya tiene el texto exacto (Ej. "SMT" o "SMT (Alt 02)"), 
        # filtramos con una coincidencia directa para no mezclar variantes.
        q_rows = q_rows.filter(Trazabilidad.proceso == proceso)

    # CORREGIDO (Fase 0): este bloque estaba indentado DENTRO del if anterior.
    # Sin proceso (o con "TODOS") la variable `rows` no existia -> error 500.
    rows = (
        q_rows.group_by(Trazabilidad.proceso, Trazabilidad.plnal, Trazabilidad.fecha_inicio)
        .order_by(Trazabilidad.proceso, Trazabilidad.plnal, Trazabilidad.fecha_inicio)
        .all()
    )

    procesos_data = {}
    fecha_reciente = None

    for row in rows:
        # --- SEPARAR LAS GRÁFICAS POR ALTERNATIVA ---
        alt_limpio = row.plnal.lstrip('0') if row.plnal else '1'
        p_name = f"{row.proceso} (Linea {alt_limpio})" 
        
        if p_name not in procesos_data:
            procesos_data[p_name] = []

        if row.fecha_inicio:
            if fecha_reciente is None or row.fecha_inicio > fecha_reciente:
                fecha_reciente = row.fecha_inicio

        t = float(row.tiempo)
        e = int(row.equipos)
        pzs_hr = (1000 / t) / e
        seg_pz = 3600 / pzs_hr if pzs_hr > 0 else 0

        procesos_data[p_name].append({
            "fecha_obj": row.fecha_inicio,
            "fecha": row.fecha_inicio.strftime("%d.%m.%Y"),
            "tiempo": round(t, 4),
            "equipos": e,
            "pzs_hr": round(pzs_hr, 2),
            "seg_pz": round(seg_pz, 2),
            "valor": 0.0,
        })

    graficas_final = {}
    for p_name, registros in procesos_data.items():
        puntos_filtrados = []
        for idx, reg in enumerate(registros):
            mejora = 0.0
            if idx > 0:
                ant = registros[idx - 1]
                if ant["pzs_hr"] > 0:
                    mejora = ((reg["pzs_hr"] - ant["pzs_hr"]) / ant["pzs_hr"]) * 100

            reg["valor"] = round(mejora, 2)

            if mes:
                f_obj = reg["fecha_obj"]
                reg_mes = f"{f_obj.year}-{str(f_obj.month).zfill(2)}"
                if reg_mes == mes:
                    puntos_filtrados.append(reg)
            else:
                puntos_filtrados.append(reg)

        if puntos_filtrados:
            for p in puntos_filtrados:
                p.pop("fecha_obj", None)
            graficas_final[p_name] = puntos_filtrados

    return {
        "filtros_aplicados": {
            "numero_material": numero_material,
            "proceso":         proceso,
            "mes":             mes,
            "proyecto":        pieza.proyecto,
            "centro":          centro
        },
        "resumen": {
            "nombre_pieza":    pieza.nombre_pieza,
            "numero_material": pieza.numero_material,
            "proyecto":        pieza.proyecto,
            "fecha_reciente":  fecha_reciente.strftime("%d.%m.%Y") if fecha_reciente else None,
        },
        "graficas": graficas_final,
    }