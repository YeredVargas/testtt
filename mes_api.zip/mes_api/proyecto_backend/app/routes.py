# app/routes.py 
from fastapi import APIRouter

from app.controllers.dashboard.dashboard_controller import router as dashboard_router
from app.controllers.graficas.graficas_controller   import router as graficas_router
from app.controllers.costos.costos_controller       import router as costos_router # <-- 1. Importamos el nuevo controlador
from app.controllers.sap_mes.sap_mes_controller     import router as sap_mes_router

router = APIRouter()

router.include_router(dashboard_router, prefix="/api/dashboard", tags=["Dashboard"])
router.include_router(graficas_router,  prefix="/api/graficas",  tags=["Graficas"])

# 2. Registramos el router de costos.
# Se usa prefix="/api" porque el controlador ya trae "/costos" por dentro.
router.include_router(costos_router, prefix="/api")

# Apartado SAP/MES (comparativa de tiempo de operacion SAP vs tiempo ciclo MES)
router.include_router(sap_mes_router, prefix="/api/sap-mes", tags=["SAP/MES"])
