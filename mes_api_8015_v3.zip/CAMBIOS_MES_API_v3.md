# API de MES v3 (puerto 8015): estadísticas MES guardadas en PostgreSQL

Se parte de **mes_api_8015_v2**, la versión que funcionaba con HANA. No se cambió ninguna consulta a HANA.

## Qué hace
- **Cada vez que `/api/hana/ciclo-estadisticas` responde desde HANA, guarda el resultado** en la tabla `mes_ciclo_estadistica` de PostgreSQL. Es la base que ya está en el `.env` de esta API (`DB_HOST`, `DB_NAME`). Hay una fila por material, estación, periodo y límites; si se repite la consulta, la fila se actualiza en lugar de duplicarse.
- **Si HANA no responde, la API contesta con lo guardado** en lugar del error 500:
  1. Primero busca **la misma consulta**: mismo periodo y límites.
  2. Si no la encuentra, usa **la consulta guardada más reciente** de esa estación.
  3. La respuesta trae `"fuente": "BD"`, el `motivo` y un `historico` con los periodos y la hora de cada consulta.
  4. Si tampoco hay nada guardado, responde **503** con mensaje claro.
- **`/api/hana/material-operaciones`** también responde con lo guardado cuando HANA falla.
- **Nuevo: `GET /api/hana/historico?material=12171980`** para ver lo guardado.
- **Si PostgreSQL no está disponible, la API sigue funcionando con HANA igual que la v2.** Lo avisa al arrancar y reintenta la conexión cada 60 s.

**Por qué en la API de MES y no en OpTimeSAP:** la API es la que habla con HANA. Guardar ahí protege a cualquier sistema que la use, no solo a OpTimeSAP, y deja un solo lugar de guardado.

**Limitación (porque se guardan estadísticas):** una mediana no se puede recalcular para otro periodo. Si pides un periodo que nunca se consultó con HANA arriba, recibes el más reciente guardado, y la respuesta lo indica.

## Instalación (carpeta propia, separada de OpTimeSAP)
🖥 **SERVER**: detén la API de MES que corre en el 8015.

🖥 **SERVER**: descomprime `mes_api_8015_v3.zip` en **su propia carpeta**, por ejemplo `C:\Apps\mes_api_8015`. **No** la pongas encima de la carpeta de OpTimeSAP.

🖥 **SERVER**: copia el `.env` que ya funcionaba con la v2 (con `HANA_*` y `DB_*`) a `proyecto_backend\.env`.

🖥 **SERVER**: instala dependencias. No hay librerías nuevas, pero así te aseguras de que el venv esté completo:
```powershell
cd "C:\Apps\mes_api_8015\proyecto_backend"
```
```powershell
pip install -r requirements.txt
```

🖥 **SERVER**: arranca:
```powershell
python .\main.py
```
En la consola debe salir:
```
[INFO] Configuración de SAP HANA cargada correctamente.
[INFO] Historico MES: tabla mes_ciclo_estadistica verificada.
```
Si sale `[WARN] Historico MES desactivado`, la API funciona, pero sin guardar. Revisa `DB_*` en el `.env`. Si sale `no pg_hba.conf entry`, PostgreSQL no permite la conexión desde ese equipo; lo más fácil es correr la API en el mismo servidor de la base (10.113.2.242).

🖥 **SERVER (.exe)**: para generar el ejecutable:
```powershell
python .\script\build.py
```

## Verificar
🌐 **BROWSER**: `http://10.113.2.242:8015/docs` debe mostrar **ciclo-estadisticas**, **material-operaciones** e **historico**.

🌐 **BROWSER**: en OpTimeSAP, compara un material con HANA funcionando. Después abre `http://10.113.2.242:8015/api/hana/historico?material=12171980` y deben aparecer filas.

## SQL
La tabla se crea sola al arrancar. Para crearla o revisarla a mano: `proyecto_backend/database/migrations/001_mes_ciclo_estadistica.sql`.
