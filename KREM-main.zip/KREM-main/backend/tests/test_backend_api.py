"""KREM Plant Headcount Planner - backend API pytest suite.

Covers: root/seed, areas, positions, people, milestones, headcount cells/bulk,
stats, and XLSX/PDF exports.
"""
import io
import os
import zipfile
from typing import Optional

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    # Fall back to frontend .env if not exported in this shell
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.strip().split("=", 1)[1].rstrip("/")
                break
API = f"{BASE_URL}/api"


@pytest.fixture(scope="session")
def client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="session", autouse=True)
def seeded(client):
    # ensure defaults exist for the whole test run
    r = client.post(f"{API}/seed", timeout=30)
    assert r.status_code == 200, r.text
    return True


# ---------------- Core / seed ----------------
class TestCore:
    def test_root_metadata(self, client):
        r = client.get(f"{API}/")
        assert r.status_code == 200
        data = r.json()
        assert data["service"] == "KREM Headcount Planner"
        assert "time" in data

    def test_seed_idempotent(self, client):
        r1 = client.post(f"{API}/seed")
        r2 = client.post(f"{API}/seed")
        assert r1.status_code == 200 and r2.status_code == 200
        # After two seed calls counts should still equal defaults
        areas = client.get(f"{API}/areas").json()
        codes = {a["code"] for a in areas}
        assert {"SMT", "BE", "APF", "AQA", "AP1", "APL", "AZ", "MAINT", "LOG", "MGMT"}.issubset(codes)


# ---------------- Areas ----------------
class TestAreas:
    def test_default_areas(self, client):
        r = client.get(f"{API}/areas")
        assert r.status_code == 200
        areas = r.json()
        codes = {a["code"] for a in areas}
        expected = {"SMT", "BE", "APF", "AQA", "AP1", "APL", "AZ", "MAINT", "LOG", "MGMT"}
        assert expected.issubset(codes), f"Missing: {expected - codes}"

    def test_area_crud(self, client):
        payload = {"name": "TEST_AREA", "code": "TST", "description": "test area"}
        r = client.post(f"{API}/areas", json=payload)
        assert r.status_code == 200
        created = r.json()
        assert created["name"] == "TEST_AREA"
        aid = created["id"]

        # Update
        upd = {"name": "TEST_AREA_2", "code": "TST", "description": "upd"}
        r = client.patch(f"{API}/areas/{aid}", json=upd)
        assert r.status_code == 200
        assert r.json()["name"] == "TEST_AREA_2"

        # Delete
        r = client.delete(f"{API}/areas/{aid}")
        assert r.status_code == 200

    def test_area_delete_rejected_when_in_use(self, client):
        # SMT has positions, deletion should fail
        areas = client.get(f"{API}/areas").json()
        smt = next(a for a in areas if a["code"] == "SMT")
        r = client.delete(f"{API}/areas/{smt['id']}")
        assert r.status_code == 400
        assert "position" in r.json().get("detail", "").lower()


# ---------------- Positions ----------------
class TestPositions:
    def test_default_positions_count_and_classifications(self, client):
        positions = client.get(f"{API}/positions").json()
        assert len(positions) == 56, f"expected 56 positions, got {len(positions)}"
        by_class = {}
        for p in positions:
            by_class[p["classification"]] = by_class.get(p["classification"], 0) + 1
        assert set(by_class.keys()) == {"DL", "IL", "DLNUN"}
        # Water Spider + Logistics Operator should be DLNUN
        dlnun_names = {p["name"] for p in positions if p["classification"] == "DLNUN"}
        assert {"Water Spider", "Logistics Operator"}.issubset(dlnun_names)
        # Operators are DL
        for p in positions:
            if p["name"].startswith("Operator ("):
                assert p["classification"] == "DL", p
        # Engineers/Managers must be IL
        il_hint_words = ["Engineer", "Manager", "Leader", "Planner", "Coordinator", "Supervisor", "Chief", "Support", "Analysis", "Quality"]
        for p in positions:
            if any(w in p["name"] for w in ["Manager", "Production Leader"]):
                assert p["classification"] == "IL"

    def test_position_invalid_classification_rejected(self, client):
        areas = client.get(f"{API}/areas").json()
        aid = areas[0]["id"]
        r = client.post(
            f"{API}/positions",
            json={"name": "TEST_bad", "area_id": aid, "classification": "XX"},
        )
        assert r.status_code == 400

    def test_position_crud_and_cascade(self, client):
        areas = client.get(f"{API}/areas").json()
        aid = areas[0]["id"]
        # Create
        r = client.post(
            f"{API}/positions",
            json={"name": "TEST_pos_x", "area_id": aid, "classification": "DL", "shift": "1st"},
        )
        assert r.status_code == 200
        pid = r.json()["id"]

        # Set a cell for this position
        r = client.post(f"{API}/headcount/cell", json={"position_id": pid, "year": 2025, "cw": 30, "count": 5})
        assert r.status_code == 200

        # Update classification
        r = client.patch(f"{API}/positions/{pid}", json={"classification": "IL"})
        assert r.status_code == 200
        assert r.json()["classification"] == "IL"

        # Bad classification patch
        r = client.patch(f"{API}/positions/{pid}", json={"classification": "ZZ"})
        assert r.status_code == 400

        # Delete cascades
        r = client.delete(f"{API}/positions/{pid}")
        assert r.status_code == 200
        hc = client.get(f"{API}/headcount").json()
        assert pid not in hc


# ---------------- People ----------------
class TestPeople:
    def test_person_crud(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        payload = {
            "name": "TEST_John",
            "position_id": pid,
            "origin": "KEMMX",
            "classification": "DL",
            "shift": "1st",
            "employee_id": "E001",
            "custom_fields": {"badge": "B123", "level": "Sr"},
            "status": "planned",
        }
        r = client.post(f"{API}/people", json=payload)
        assert r.status_code == 200
        person = r.json()
        assert person["name"] == "TEST_John"
        assert person["origin"] == "KEMMX"
        assert person["custom_fields"]["badge"] == "B123"
        person_id = person["id"]

        # Patch
        r = client.patch(f"{API}/people/{person_id}", json={"name": "TEST_John_Updated", "status": "active"})
        assert r.status_code == 200
        assert r.json()["name"] == "TEST_John_Updated"
        assert r.json()["status"] == "active"

        # Confirm list contains
        people = client.get(f"{API}/people").json()
        assert any(p["id"] == person_id for p in people)

        # Delete
        r = client.delete(f"{API}/people/{person_id}")
        assert r.status_code == 200
        r = client.delete(f"{API}/people/{person_id}")
        assert r.status_code == 404

    def test_person_tbd_defaults(self, client):
        r = client.post(f"{API}/people", json={"name": "TBD"})
        assert r.status_code == 200
        pid = r.json()["id"]
        client.delete(f"{API}/people/{pid}")


# ---------------- Milestones ----------------
class TestMilestones:
    def test_default_milestones(self, client):
        ms = client.get(f"{API}/milestones").json()
        names = {m["name"] for m in ms}
        assert {"Transfer", "Trial Run", "SOP"}.issubset(names)
        for m in ms:
            if m["name"] == "Transfer":
                assert m["type"] == "transfer"
                assert m["year"] == 2025 and m["cw"] == 35

    def test_milestone_crud_and_type_validation(self, client):
        r = client.post(
            f"{API}/milestones",
            json={"name": "TEST_ms", "type": "bogus", "date": "2025-09-01", "year": 2025, "cw": 36},
        )
        assert r.status_code == 400

        r = client.post(
            f"{API}/milestones",
            json={"name": "TEST_ms", "type": "custom", "date": "2025-09-01", "year": 2025, "cw": 36, "color": "#000"},
        )
        assert r.status_code == 200
        mid = r.json()["id"]

        r = client.patch(f"{API}/milestones/{mid}", json={"name": "TEST_ms2"})
        assert r.status_code == 200 and r.json()["name"] == "TEST_ms2"

        r = client.patch(f"{API}/milestones/{mid}", json={"type": "nope"})
        assert r.status_code == 400

        r = client.delete(f"{API}/milestones/{mid}")
        assert r.status_code == 200


# ---------------- Headcount cells ----------------
class TestHeadcount:
    def test_set_cell_and_get(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.post(f"{API}/headcount/cell", json={"position_id": pid, "year": 2025, "cw": 27, "count": 3})
        assert r.status_code == 200
        r = client.post(f"{API}/headcount/cell", json={"position_id": pid, "year": 2025, "cw": 28, "count": 4})
        assert r.status_code == 200
        hc = client.get(f"{API}/headcount").json()
        assert hc[pid]["2025-CW27"] == 3
        assert hc[pid]["2025-CW28"] == 4

    def test_set_cell_negative_rejected(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[0]["id"]
        r = client.post(f"{API}/headcount/cell", json={"position_id": pid, "year": 2025, "cw": 27, "count": -1})
        assert r.status_code == 400

    def test_bulk_cells(self, client):
        positions = client.get(f"{API}/positions").json()
        pid = positions[1]["id"]
        payload = {"cells": [
            {"position_id": pid, "year": 2025, "cw": 40, "count": 1},
            {"position_id": pid, "year": 2025, "cw": 41, "count": 2},
            {"position_id": pid, "year": 2025, "cw": 42, "count": 3},
        ]}
        r = client.post(f"{API}/headcount/bulk", json=payload)
        assert r.status_code == 200
        assert r.json()["count"] == 3
        hc = client.get(f"{API}/headcount").json()
        assert hc[pid]["2025-CW40"] == 1
        assert hc[pid]["2025-CW41"] == 2
        assert hc[pid]["2025-CW42"] == 3


# ---------------- Stats ----------------
class TestStats:
    def test_stats(self, client):
        r = client.get(f"{API}/stats")
        assert r.status_code == 200
        d = r.json()
        for k in ("areas", "positions_total", "positions_by_class", "people_tbd", "planned_total_sum"):
            assert k in d, f"missing key {k}"
        assert d["areas"] >= 10
        assert d["positions_total"] >= 56
        assert set(d["positions_by_class"].keys()) == {"DL", "IL", "DLNUN"}


# ---------------- Exports ----------------
class TestReports:
    def test_xlsx_export(self, client):
        r = client.get(f"{API}/reports/headcount.xlsx?year=2025&start_cw=27&weeks=52")
        assert r.status_code == 200
        assert r.content[:2] == b"PK", "file does not have zip magic"
        # Should be a valid zip / xlsx
        zf = zipfile.ZipFile(io.BytesIO(r.content))
        assert any(n.startswith("xl/") for n in zf.namelist())

    def test_pdf_export(self, client):
        r = client.get(f"{API}/reports/headcount.pdf?year=2025&start_cw=27&weeks=52")
        assert r.status_code == 200
        assert r.content[:4] == b"%PDF", "not a valid PDF"
        assert len(r.content) > 1000
