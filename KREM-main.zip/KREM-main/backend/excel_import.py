"""Import KREM headcount data from the original Excel template.

Reads a workbook that contains a sheet with:
- Row 23 : header row with 'AREA' (col 2), 'Staff' (col 3, classification), 'CW27..' onwards.
- Row 24 : section header (skipped).
- Row 25..N : position rows with weekly counts.

Handles the workbook's layout of 78 columns spanning CW27..CW52 (year_start),
CW01..CW26 (year_start+1), CW27..CW52 (year_start+1).
"""
from __future__ import annotations

import io
import re
from typing import Any, Dict, List, Tuple

from openpyxl import load_workbook


# Regex helpers
CW_RX = re.compile(r"^CW(\d{1,2})$", re.IGNORECASE)

# Explicit mapping from Excel position name -> our area code.
# Anything not in this dict falls back to _area_from_name.
POSITION_AREA_OVERRIDES: Dict[str, str] = {
    "Manager": "MGMT",
    "Production Leader SMT & BE": "MGMT",
    "SMT & BE Water Spider": "LOG",
    "SMT & BE Process Chief": "MAINT",
    "SMT & BE Maintenance Chief": "MAINT",
    "Test Engineer Coordinator": "APL",
    "Test Engineer": "APL",
    "MES Engineer": "APL",
}


def _area_from_name(name: str) -> str:
    n = name.strip()
    if "Water Spider" in n or "Logistics" in n:
        return "LOG"
    if "Maintenance" in n:
        return "MAINT"
    if "Test Engineer" in n or "MES" in n:
        return "APL"
    if n.startswith("SMT "):
        return "SMT"
    if n.startswith("BE ") or n.startswith("BE(") or n.startswith("BE "):
        return "BE"
    return "MGMT"


def area_for_position(name: str) -> str:
    return POSITION_AREA_OVERRIDES.get(name.strip(), _area_from_name(name))


VALID_CLASSES = {"DL", "IL", "DLNUN"}


def parse_headcount_workbook(
    xlsx_bytes: bytes,
    year_start: int = 2025,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Parse the workbook and return (positions, cells).

    positions: [{name, area_code, classification, shift, order}]
    cells:     [{position_name, year, cw, count}]
    """
    wb = load_workbook(io.BytesIO(xlsx_bytes), data_only=True)

    # Prefer 'HC SMT + BE (KREM)' if present.
    sheet_name = None
    for n in wb.sheetnames:
        if "HC" in n.upper() or "HEADCOUNT" in n.upper():
            sheet_name = n
            break
    ws = wb[sheet_name] if sheet_name else wb.active

    # Locate the header row: the one that has "AREA" (col 2 area B) and CW columns.
    header_row = None
    for r in range(1, min(50, ws.max_row + 1)):
        v = ws.cell(r, 2).value
        if isinstance(v, str) and v.strip().upper() == "AREA":
            header_row = r
            break
    if header_row is None:
        # Fall back to row 23 which is the template default.
        header_row = 23

    # Discover CW columns: dict col_idx -> (year, cw)
    cw_columns: Dict[int, Tuple[int, int]] = {}
    prev_cw = None
    current_year = year_start
    for c in range(1, ws.max_column + 1):
        v = ws.cell(header_row, c).value
        if not isinstance(v, str):
            continue
        m = CW_RX.match(v.strip())
        if not m:
            continue
        cw = int(m.group(1))
        if 1 <= cw <= 52:
            # Roll the year forward when we jump from a higher CW to a lower one
            # (e.g. from CW52 to CW01).
            if prev_cw is not None and cw < prev_cw:
                current_year += 1
            cw_columns[c] = (current_year, cw)
            prev_cw = cw

    positions: List[Dict[str, Any]] = []
    cells: List[Dict[str, Any]] = []
    seen_positions: set = set()
    order = 0

    for r in range(header_row + 1, ws.max_row + 1):
        name = ws.cell(r, 2).value
        cls  = ws.cell(r, 3).value
        if not isinstance(name, str):
            continue
        n = name.strip()
        if not n:
            continue
        # Skip section headers and totals
        if cls is None:
            continue
        if n.lower() in {"grand total", "total"}:
            continue
        if not isinstance(cls, str):
            continue
        classification = cls.strip().upper()
        if classification not in VALID_CLASSES:
            continue

        if n not in seen_positions:
            positions.append({
                "name": n,
                "area_code": area_for_position(n),
                "classification": classification,
                "shift": "N/A",
                "order": order,
            })
            order += 1
            seen_positions.add(n)

        for col_idx, (year, cw) in cw_columns.items():
            val = ws.cell(r, col_idx).value
            if val is None or val == "":
                continue
            try:
                cnt = int(val)
            except (TypeError, ValueError):
                continue
            if cnt < 0:
                continue
            cells.append({
                "position_name": n,
                "year": year,
                "cw": cw,
                "count": cnt,
            })

    return positions, cells
