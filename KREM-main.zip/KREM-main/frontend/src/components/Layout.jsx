import { NavLink, Outlet, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Grid3x3,
  Users,
  Briefcase,
  Flag,
  FileDown,
  Factory,
} from "lucide-react";

const NAV = [
  { to: "/",           label: "Dashboard",  icon: LayoutDashboard, testId: "nav-dashboard" },
  { to: "/matrix",     label: "Matrix",     icon: Grid3x3,          testId: "nav-matrix" },
  { to: "/people",     label: "People",     icon: Users,            testId: "nav-people" },
  { to: "/positions",  label: "Positions",  icon: Briefcase,        testId: "nav-positions" },
  { to: "/milestones", label: "Milestones", icon: Flag,             testId: "nav-milestones" },
  { to: "/reports",    label: "Reports",    icon: FileDown,         testId: "nav-reports" },
];

export default function Layout() {
  const location = useLocation();
  return (
    <div className="min-h-screen flex bg-[#f8fafc]">
      {/* Sidebar */}
      <aside className="hidden md:flex md:flex-col w-64 shrink-0 border-r border-slate-200 bg-white" data-testid="sidebar">
        <div className="h-16 flex items-center gap-3 px-5 border-b border-slate-200">
          <div className="w-9 h-9 rounded-md bg-blue-800 text-white grid place-items-center">
            <Factory className="w-5 h-5" />
          </div>
          <div>
            <div className="font-heading font-bold text-[15px] text-slate-900 leading-tight">KREM Planner</div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Headcount OS</div>
          </div>
        </div>
        <nav className="flex-1 py-4 px-3">
          {NAV.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                data-testid={item.testId}
                end={item.to === "/"}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-md mb-1 text-sm font-medium transition-colors duration-150 ${
                    isActive
                      ? "bg-blue-50 text-blue-700"
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
        <div className="px-5 py-4 border-t border-slate-200">
          <div className="text-[10px] uppercase tracking-[0.2em] text-slate-400">Fiscal Cycle</div>
          <div className="font-heading font-semibold text-sm text-slate-700 mt-1">CW27 → CW26</div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-white border-b border-slate-200 flex items-center px-4 z-40" data-testid="mobile-topbar">
        <div className="w-8 h-8 rounded-md bg-blue-800 text-white grid place-items-center mr-3">
          <Factory className="w-4 h-4" />
        </div>
        <div className="font-heading font-bold text-slate-900">KREM Planner</div>
      </div>

      <main className="flex-1 min-w-0 pt-14 md:pt-0" data-testid="app-main">
        {/* Mobile nav bar */}
        <div className="md:hidden flex overflow-x-auto border-b border-slate-200 bg-white sticky top-14 z-30">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.to;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                data-testid={`${item.testId}-mobile`}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs whitespace-nowrap border-b-2 ${
                  active ? "border-blue-600 text-blue-700" : "border-transparent text-slate-600"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {item.label}
              </NavLink>
            );
          })}
        </div>

        <Outlet />
      </main>
    </div>
  );
}
