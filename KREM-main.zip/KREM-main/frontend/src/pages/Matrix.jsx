import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { RotateCcw, ChevronDown, ChevronRight } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, endpoints } from "@/lib/api";
import { generateFiscalYear } from "@/lib/cw";

function MatrixCell({ positionId, week, initial, onSave }) {
  const [val, setVal] = useState(initial ?? "");
  useEffect(() => { setVal(initial ?? ""); }, [initial]);
  const has = val !== "" && Number(val) > 0;
  return (
    <input
      type="number"
      min={0}
      max={999}
      value={val}
      data-testid={`cell-${positionId}-${week.key}`}
      onChange={(e) => setVal(e.target.value.replace(/[^0-9]/g, ""))}
      onBlur={() => {
        const n = val === "" ? 0 : parseInt(val, 10);
        if (Number.isNaN(n)) return;
        if (n !== (initial ?? 0)) onSave(n);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") e.currentTarget.blur();
        if (e.key === "Escape") { setVal(initial ?? ""); e.currentTarget.blur(); }
      }}
      className={`matrix-cell-input ${has ? "has-value" : ""}`}
    />
  );
}

export default function MatrixPage() {
  const [areas, setAreas] = useState([]);
  const [positions, setPositions] = useState([]);
  const [plan, setPlan] = useState({});
  const [milestones, setMilestones] = useState([]);
  const [startYear, setStartYear] = useState(2025);
  const [startCw, setStartCw] = useState(27);
  const [collapsed, setCollapsed] = useState({});
  const [classFilter, setClassFilter] = useState("all");
  const [saving, setSaving] = useState(false);
  const scrollRef = useRef(null);

  const weeks = useMemo(() => generateFiscalYear(startYear, startCw, 52), [startYear, startCw]);

  async function load() {
    const [a, p, hc, ms] = await Promise.all([
      api.get(endpoints.areas),
      api.get(endpoints.positions),
      api.get(endpoints.headcount),
      api.get(endpoints.milestones),
    ]);
    setAreas(a.data);
    setPositions(p.data);
    setPlan(hc.data);
    setMilestones(ms.data);
  }
  useEffect(() => { load(); }, []);

  const areaById = useMemo(() => Object.fromEntries(areas.map((a) => [a.id, a])), [areas]);
  const msByKey = useMemo(() => Object.fromEntries(milestones.map((m) => [`${m.year}-CW${String(m.cw).padStart(2,"0")}`, m])), [milestones]);

  const filteredPositions = useMemo(() => {
    let base = positions;
    if (classFilter !== "all") base = base.filter((p) => p.classification === classFilter);
    return base;
  }, [positions, classFilter]);

  const grouped = useMemo(() => {
    const map = new Map();
    filteredPositions.forEach((p) => {
      if (!map.has(p.area_id)) map.set(p.area_id, []);
      map.get(p.area_id).push(p);
    });
    return Array.from(map.entries()).map(([aid, list]) => ({
      area: areaById[aid] || { name: "Unknown", id: aid },
      positions: list,
    }));
  }, [filteredPositions, areaById]);

  async function saveCell(pos, week, count) {
    setSaving(true);
    try {
      await api.post(endpoints.headcountCell, {
        position_id: pos.id,
        year: week.year,
        cw: week.cw,
        count,
      });
      setPlan((prev) => ({ ...prev, [pos.id]: { ...(prev[pos.id] || {}), [week.key]: count } }));
    } catch {
      toast.error("Save failed");
    } finally {
      setSaving(false);
    }
  }

  function totalForPosition(posId) {
    return Object.values(plan[posId] || {}).reduce((s, v) => s + (v || 0), 0);
  }

  function grandTotalForWeek(key) {
    return filteredPositions.reduce((acc, p) => acc + (plan[p.id]?.[key] || 0), 0);
  }

  return (
    <>
      <PageHeader
        title="Headcount Matrix"
        subtitle="Excel-like planning grid — click any cell to type the target count"
        testId="matrix-header"
        actions={
          <div className="flex items-center gap-2">
            <Select value={String(startYear)} onValueChange={(v) => setStartYear(parseInt(v, 10))}>
              <SelectTrigger className="w-[110px] h-9" data-testid="matrix-year-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[2024, 2025, 2026, 2027].map((y) => (
                  <SelectItem key={y} value={String(y)}>FY {y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={String(startCw)} onValueChange={(v) => setStartCw(parseInt(v, 10))}>
              <SelectTrigger className="w-[110px] h-9" data-testid="matrix-startcw-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {Array.from({ length: 52 }, (_, i) => i + 1).map((w) => (
                  <SelectItem key={w} value={String(w)}>Start CW{String(w).padStart(2, "0")}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-[130px] h-9" data-testid="matrix-class-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="DL">DL only</SelectItem>
                <SelectItem value="IL">IL only</SelectItem>
                <SelectItem value="DLNUN">DLNUN only</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="sm"
              data-testid="matrix-reset-btn"
              onClick={() => scrollRef.current?.scrollTo({ left: 0, behavior: "smooth" })}
              className="text-slate-600"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset scroll
            </Button>
          </div>
        }
      />

      <div className="px-6 lg:px-8 py-6 space-y-4">
        <div className="flex items-center gap-3 flex-wrap text-xs">
          <span className="text-overline">Legend</span>
          <span className="classification-badge class-DL">DL · Direct</span>
          <span className="classification-badge class-IL">IL · Indirect</span>
          <span className="classification-badge class-DLNUN">DLNUN · Non-Union</span>
          <span className="text-slate-400">•</span>
          <div className="flex items-center gap-1.5">
            {milestones.map((m) => (
              <span key={m.id} className="inline-flex items-center gap-1.5 px-2 py-1 rounded-sm text-white text-xs font-semibold" style={{ backgroundColor: m.color }}>
                {m.name}
              </span>
            ))}
          </div>
          <span className="ml-auto text-xs text-slate-500 flex items-center gap-2">
            {saving && <span className="animate-pulse text-blue-600">Saving…</span>}
            <span data-testid="matrix-positions-count">{filteredPositions.length} positions · {weeks.length} weeks</span>
          </span>
        </div>

        <div className="matrix-scroll" ref={scrollRef} data-testid="matrix-scroll">
          <table>
            <thead>
              <tr>
                <th className="sticky-col col-1">Area</th>
                <th className="sticky-col col-2">Position</th>
                <th className="sticky-col col-3">Class</th>
                <th className="sticky-col col-4">Shift</th>
                {weeks.map((w) => {
                  const ms = msByKey[w.key];
                  return (
                    <th
                      key={w.key}
                      style={ms ? { background: ms.color, color: "#fff" } : undefined}
                      className={ms ? "milestone-col" : undefined}
                    >
                      <div className="text-[10px] opacity-80">{w.monthLabel || "\u00A0"}</div>
                      <div>{w.label}</div>
                      {ms && <div className="text-[9px] font-semibold mt-0.5">{ms.name}</div>}
                    </th>
                  );
                })}
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {grouped.map(({ area, positions: aps }) => {
                const isCollapsed = collapsed[area.id];
                return (
                  <Fragment key={area.id}>
                    <tr className="area-row">
                      <td
                        colSpan={4 + weeks.length + 1}
                        className="sticky-col col-1"
                        style={{ position: "sticky", left: 0, background: "#eff6ff", color: "#1e3a8a", fontWeight: 700, textAlign: "left", padding: "6px 12px", borderBottom: "2px solid #93c5fd" }}
                      >
                        <button
                          data-testid={`area-toggle-${area.id}`}
                          onClick={() => setCollapsed((prev) => ({ ...prev, [area.id]: !isCollapsed }))}
                          className="inline-flex items-center gap-1.5 text-xs font-heading tracking-wide"
                        >
                          {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          {area.name} <span className="text-slate-500 font-normal">· {aps.length}</span>
                        </button>
                      </td>
                    </tr>
                    {!isCollapsed && aps.map((p) => (
                      <tr key={p.id}>
                        <td className="sticky-col col-1 text-xs text-slate-500">{area.code || area.name}</td>
                        <td className="sticky-col col-2" data-testid={`pos-name-${p.id}`}>{p.name}</td>
                        <td className="sticky-col col-3">
                          <span className={`classification-badge class-${p.classification}`}>{p.classification}</span>
                        </td>
                        <td className="sticky-col col-4 text-xs text-slate-500">{p.shift}</td>
                        {weeks.map((w) => {
                          const isMs = !!msByKey[w.key];
                          return (
                            <td key={w.key} className={isMs ? "milestone-col" : undefined}>
                              <MatrixCell
                                positionId={p.id}
                                week={w}
                                initial={plan[p.id]?.[w.key] ?? 0}
                                onSave={(v) => saveCell(p, w, v)}
                              />
                            </td>
                          );
                        })}
                        <td className="font-semibold text-slate-700 tabular-nums">{totalForPosition(p.id)}</td>
                      </tr>
                    ))}
                  </Fragment>
                );
              })}
              <tr className="grand-total-row">
                <td className="sticky-col col-1">TOTAL</td>
                <td className="sticky-col col-2">Grand Total (all classes shown)</td>
                <td className="sticky-col col-3">—</td>
                <td className="sticky-col col-4">—</td>
                {weeks.map((w) => (
                  <td key={w.key}>{grandTotalForWeek(w.key)}</td>
                ))}
                <td>{filteredPositions.reduce((acc, p) => acc + totalForPosition(p.id), 0)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
