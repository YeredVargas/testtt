import { useState } from "react";
import { toast } from "sonner";
import { FileSpreadsheet, FileText, Download, Info, BarChart3 } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { endpoints, API_BASE } from "@/lib/api";

export default function ReportsPage() {
  const [year, setYear] = useState(2025);
  const [startCw, setStartCw] = useState(27);
  const [weeks, setWeeks] = useState(52);

  async function downloadFile(url, filename) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("Bad response");
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast.success(`${filename} downloaded`);
    } catch (e) {
      toast.error("Download failed. Make sure you have positions and cells configured.");
    }
  }

  const xlsxUrl = endpoints.xlsx(year, startCw, weeks);
  const pdfUrl  = endpoints.pdf(year, startCw, weeks);
  const kremUrl = endpoints.krem(year, startCw, weeks);

  return (
    <>
      <PageHeader
        title="Reports"
        subtitle="Export the general headcount plan — KREM Original Format with charts, compact XLSX or PDF."
        testId="reports-header"
      />
      <div className="px-6 lg:px-8 py-6 space-y-6">
        <div className="bg-white border border-slate-200 rounded-md p-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
            <div>
              <Label>Fiscal year (start)</Label>
              <Select value={String(year)} onValueChange={(v) => setYear(parseInt(v, 10))}>
                <SelectTrigger data-testid="report-year"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[2024, 2025, 2026, 2027].map((y) => (
                    <SelectItem key={y} value={String(y)}>FY {y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Start CW</Label>
              <Select value={String(startCw)} onValueChange={(v) => setStartCw(parseInt(v, 10))}>
                <SelectTrigger data-testid="report-start-cw"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">
                  {Array.from({ length: 52 }, (_, i) => i + 1).map((w) => (
                    <SelectItem key={w} value={String(w)}>CW{String(w).padStart(2, "0")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Weeks to include</Label>
              <Input
                data-testid="report-weeks"
                type="number"
                min={1}
                max={104}
                value={weeks}
                onChange={(e) => setWeeks(parseInt(e.target.value || "52", 10))}
              />
            </div>
          </div>

          <div className="rounded-md border border-blue-100 bg-blue-50 p-4 flex gap-3 items-start mb-5">
            <Info className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
            <div className="text-sm text-slate-700">
              All three formats render the <b>same general view</b> as the Matrix screen. The <b>KREM Original Format</b> matches
              your source Excel layout column-by-column (Month row · AREA · Staff · CW columns) and adds a second sheet
              with 3 native Excel charts you can further edit — stacked headcount by week, total trend, and area distribution.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => downloadFile(kremUrl, `KREM_headcount_FY${year}_CW${String(startCw).padStart(2, "0")}.xlsx`)}
              className="text-left bg-white border-2 border-blue-500 rounded-md p-5 hover:-translate-y-[1px] transition-transform duration-150 relative"
              data-testid="download-krem-btn"
            >
              <div className="absolute top-3 right-3 text-[9px] font-bold uppercase tracking-[0.15em] bg-blue-600 text-white px-2 py-0.5 rounded-sm">
                Recommended
              </div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-md bg-blue-100 text-blue-700 grid place-items-center">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-overline">XLSX + Charts</div>
                  <div className="font-heading font-bold text-lg text-slate-900">KREM Original Format</div>
                </div>
                <Download className="ml-auto w-4 h-4 text-slate-400" />
              </div>
              <div className="text-sm text-slate-600">
                Same layout as your source template (Month row, AREA/Staff/CW columns) plus a second sheet with
                <b> 3 native Excel charts </b> — stacked bars, headcount trend and area distribution.
              </div>
            </button>

            <button
              onClick={() => downloadFile(xlsxUrl, `headcount_FY${year}_CW${String(startCw).padStart(2, "0")}.xlsx`)}
              className="text-left bg-white border border-slate-200 rounded-md p-5 hover:-translate-y-[1px] transition-transform duration-150"
              data-testid="download-xlsx-btn"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-md bg-emerald-100 text-emerald-700 grid place-items-center">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-overline">XLSX</div>
                  <div className="font-heading font-bold text-lg text-slate-900">Compact Matrix</div>
                </div>
                <Download className="ml-auto w-4 h-4 text-slate-400" />
              </div>
              <div className="text-sm text-slate-600">
                Compact spreadsheet with frozen headers, milestones highlighted and totals row. No charts.
              </div>
            </button>

            <button
              onClick={() => downloadFile(pdfUrl, `headcount_FY${year}_CW${String(startCw).padStart(2, "0")}.pdf`)}
              className="text-left bg-white border border-slate-200 rounded-md p-5 hover:-translate-y-[1px] transition-transform duration-150"
              data-testid="download-pdf-btn"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-md bg-rose-100 text-rose-700 grid place-items-center">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-overline">PDF</div>
                  <div className="font-heading font-bold text-lg text-slate-900">Printable Report</div>
                </div>
                <Download className="ml-auto w-4 h-4 text-slate-400" />
              </div>
              <div className="text-sm text-slate-600">
                Landscape A3 layout with the full matrix, ready to share with stakeholders and print.
              </div>
            </button>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-md p-5">
          <h3 className="font-heading font-semibold text-base text-slate-900 mb-2">Run locally</h3>
          <p className="text-sm text-slate-600 mb-2">
            Host this app on your own PC with your local MongoDB. Requires Python 3.11+, Node 20+ and MongoDB.
          </p>
          <ol className="list-decimal pl-5 space-y-1.5 text-sm text-slate-700">
            <li>Push the code to GitHub from Emergent (&quot;Save to GitHub&quot;), then <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">git clone</code> it.</li>
            <li><b>Windows</b>: double-click <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">install.bat</code> once, then double-click <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">start.bat</code> to launch.</li>
            <li><b>Mac / Linux</b>: <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">chmod +x install.sh start.sh &amp;&amp; ./install.sh &amp;&amp; ./start.sh</code></li>
            <li>See <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">LOCAL_SETUP.md</code> for the full walkthrough (backup, troubleshooting).</li>
          </ol>
        </div>
      </div>
    </>
  );
}
