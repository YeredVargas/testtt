import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, Flag } from "lucide-react";

import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api, endpoints } from "@/lib/api";
import { isoWeekOfDate } from "@/lib/cw";

const TYPES = [
  { value: "transfer",  label: "Transfer",  color: "#8B5CF6" },
  { value: "trial_run", label: "Trial Run", color: "#EAB308" },
  { value: "sop",       label: "SOP",       color: "#10B981" },
  { value: "custom",    label: "Custom",    color: "#64748B" },
];

export default function MilestonesPage() {
  const [milestones, setMilestones] = useState([]);
  const [dialog, setDialog] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "Transfer", type: "transfer", date: "", color: "#8B5CF6", description: "" });

  async function load() {
    const r = await api.get(endpoints.milestones);
    setMilestones(r.data);
  }
  useEffect(() => { load(); }, []);

  function openCreate() {
    setEditing(null);
    setForm({ name: "Transfer", type: "transfer", date: "", color: "#8B5CF6", description: "" });
    setDialog(true);
  }
  function openEdit(m) {
    setEditing(m);
    setForm({ name: m.name, type: m.type, date: m.date, color: m.color || "#64748B", description: m.description || "" });
    setDialog(true);
  }

  async function submit(e) {
    e.preventDefault();
    if (!form.date) { toast.error("Please pick a date"); return; }
    const { year, cw } = isoWeekOfDate(form.date);
    const payload = { ...form, year, cw };
    try {
      if (editing) {
        await api.patch(`${endpoints.milestones}/${editing.id}`, payload);
      } else {
        await api.post(endpoints.milestones, payload);
      }
      toast.success("Milestone saved");
      setDialog(false);
      await load();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Save failed");
    }
  }

  async function remove(m) {
    if (!confirm(`Delete ${m.name}?`)) return;
    try {
      await api.delete(`${endpoints.milestones}/${m.id}`);
      toast.success("Deleted");
      await load();
    } catch {
      toast.error("Delete failed");
    }
  }

  return (
    <>
      <PageHeader
        title="Milestones"
        subtitle="Editable dates that appear as vertical markers in the Matrix and Dashboard."
        testId="milestones-header"
        actions={
          <Button data-testid="add-milestone-btn" onClick={openCreate} className="bg-blue-700 hover:bg-blue-800">
            <Plus className="w-4 h-4 mr-1" /> Add Milestone
          </Button>
        }
      />
      <div className="px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {milestones.length === 0 && (
            <div className="col-span-full text-center py-16 border border-dashed border-slate-300 rounded-md bg-white" data-testid="milestones-empty">
              <Flag className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <div className="text-sm text-slate-500">No milestones. Create Transfer, Trial Run and SOP.</div>
            </div>
          )}
          {milestones.map((m) => (
            <button
              key={m.id}
              onClick={() => openEdit(m)}
              data-testid={`milestone-card-${m.id}`}
              className="text-left bg-white border border-slate-200 rounded-md p-5 hover:-translate-y-[1px] transition-transform duration-150 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-1.5 h-full" style={{ backgroundColor: m.color || "#64748B" }} />
              <div className="flex items-start justify-between">
                <div className="pl-2">
                  <div className="text-overline">{m.type.replace("_", " ")}</div>
                  <h3 className="font-heading font-bold text-lg text-slate-900">{m.name}</h3>
                  <div className="text-2xl font-mono font-semibold text-slate-800 mt-1">{m.date}</div>
                  <div className="text-xs text-slate-500 mt-1">CW{String(m.cw).padStart(2, "0")} · {m.year}</div>
                  {m.description && <div className="text-sm text-slate-500 mt-2">{m.description}</div>}
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); remove(m); }}
                  className="text-slate-300 hover:text-red-600 transition-colors duration-150"
                  data-testid={`delete-milestone-${m.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </button>
          ))}
        </div>
      </div>

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent data-testid="milestone-dialog">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit milestone" : "Add milestone"}</DialogTitle>
            <DialogDescription>Pick a date. The system computes the ISO calendar week automatically.</DialogDescription>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            <div>
              <Label>Name</Label>
              <Input
                data-testid="form-ms-name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select
                  value={form.type}
                  onValueChange={(v) => {
                    const t = TYPES.find((x) => x.value === v);
                    setForm({ ...form, type: v, color: t?.color || form.color });
                  }}
                >
                  <SelectTrigger data-testid="form-ms-type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Date</Label>
                <Input
                  data-testid="form-ms-date"
                  type="date"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Color</Label>
                <Input
                  data-testid="form-ms-color"
                  type="color"
                  value={form.color}
                  onChange={(e) => setForm({ ...form, color: e.target.value })}
                  className="h-10"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Input
                  data-testid="form-ms-desc"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Optional"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialog(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-700 hover:bg-blue-800" data-testid="save-milestone-btn">Save</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
