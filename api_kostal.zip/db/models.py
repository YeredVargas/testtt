from sqlalchemy import (
    Column, Integer, String, Numeric, Date, ForeignKey, DateTime,
    UniqueConstraint, Boolean, Index, ForeignKeyConstraint
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from db.database import Base


class Pieza(Base):
    __tablename__ = "piezas"
    
    id = Column(Integer, primary_key=True, unique=True, index=True, autoincrement=True)
    nombre_pieza = Column(String(255))
    
    numero_material = Column(String(50), nullable=False, index=True)
    centro = Column(String(4), nullable=False, server_default='0094') 
    proyecto = Column(String(50), nullable=False, server_default='SIN PROYECTO')
    
    creado_en = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    __table_args__ = (
        UniqueConstraint('numero_material', 'centro', name='uq_piezas_mat_centro'),
    )


class CatalogoProceso(Base):
    __tablename__ = "catalogo_procesos"
    
    codigo = Column(String(50), primary_key=True)
    centro = Column(String(4), primary_key=True, server_default='0094') 
    
    seccion = Column(String(50), nullable=False)
    activo = Column(Boolean, nullable=False, server_default="true")
    bloqueado = Column(Boolean, nullable=False, server_default="false")
    
    creado_en = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())


class Trazabilidad(Base):
    __tablename__ = "trazabilidad"

    id = Column(Integer, primary_key=True, index=True)
    
    pieza_id = Column(Integer, ForeignKey("piezas.id", ondelete="CASCADE"), nullable=False)
    
    operacion_num = Column(String(20), nullable=False)
    descripcion = Column(String(255))
    clave_modelo = Column(String(50))
    codigo_busqueda = Column(String(50))
    proceso = Column(String(50), nullable=False, server_default='SMT')
    steus = Column(String(20))
    plnnr = Column(String(40))
    plnal = Column(String(10))
    aennr = Column(String(40), nullable=False, server_default='')
    equipos = Column(Integer)
    cantidad_base = Column(Numeric(12, 2))

    tiempo = Column(Numeric(12, 4))
    tiempo_preparacion = Column(Numeric(12, 4))
    tiempo_mano_obra = Column(Numeric(12, 4))

    unidad_t = Column(String(10))
    unidad_preparacion = Column(String(10))
    unidad_mano_obra = Column(String(10))

    vgwts = Column(String(10))

    fecha_inicio = Column(Date)
    fecha_fin = Column(Date)
    creado_sap = Column(Date)
    modificado_sap = Column(Date)
    creado_en = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint(
            'pieza_id', 'operacion_num', 'fecha_inicio', 'aennr', 'plnnr', 'plnal',
            name='uq_trazabilidad_hist'
        ),
        Index('ix_trazabilidad_pieza_proceso', 'pieza_id', 'proceso'),
    )


class CostosCK13NCabecera(Base):
    __tablename__ = 'costos_ck13n_cabecera'

    id = Column(Integer, primary_key=True, index=True)
    numero_material = Column(String(50), nullable=False)
    centro = Column(String(4), nullable=False, default='0094')
    variante = Column(String(10), nullable=False, default='PPC1')
    estatus = Column(String(5), nullable=False)
    fecha_validez = Column(Date, nullable=False)
    numero_costeo = Column(String(50), nullable=False)
    
    total_global = Column(Numeric(15, 2), nullable=False, default=0)
    total_fijado = Column(Numeric(15, 2), nullable=False, default=0)
    total_variable = Column(Numeric(15, 2), nullable=False, default=0)
    
    creado_en = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        # 🔴 REGLA CORREGIDA: Exclusividad basada en 'fecha_validez', no en 'numero_costeo'
        UniqueConstraint('numero_material', 'centro', 'variante', 'fecha_validez', name='uq_costos_cabecera'),
        ForeignKeyConstraint(
            ['numero_material', 'centro'], 
            ['piezas.numero_material', 'piezas.centro'], 
            ondelete='CASCADE'
        ),
    )

    elementos = relationship("CostosCK13NElementos", back_populates="cabecera", cascade="all, delete-orphan")
    # 🔴 RELACIÓN AGREGADA
    produccion = relationship("CostosCK13NProduccion", back_populates="cabecera", cascade="all, delete-orphan")


class CostosCK13NElementos(Base):
    __tablename__ = 'costos_ck13n_elementos'

    id = Column(Integer, primary_key=True, index=True)
    cabecera_id = Column(Integer, ForeignKey('costos_ck13n_cabecera.id', ondelete='CASCADE'), nullable=False)
    
    componente = Column(String(10), nullable=False)
    denominacion = Column(String(100))
    
    total = Column(Numeric(15, 2), nullable=False, default=0)
    fijado = Column(Numeric(15, 2), nullable=False, default=0)
    variable = Column(Numeric(15, 2), nullable=False, default=0)

    __table_args__ = (
        UniqueConstraint('cabecera_id', 'componente', name='uq_costos_elementos'),
    )

    cabecera = relationship("CostosCK13NCabecera", back_populates="elementos")


class CostosCK13NProduccion(Base):
    __tablename__ = 'costos_ck13n_produccion'

    id = Column(Integer, primary_key=True, index=True)
    cabecera_id = Column(Integer, ForeignKey('costos_ck13n_cabecera.id', ondelete='CASCADE'), nullable=False)
    
    posicion = Column(String(20))
    centro_coste = Column(String(50))
    texto_centro_coste = Column(String(200))
    clase_actividad = Column(String(50))
    texto_actividad = Column(String(200))
    elemento_coste = Column(String(50))
    texto_recurso = Column(String(255))
    
    cantidad = Column(Numeric(15, 3), default=0)
    unidad = Column(String(10))
    valor_total = Column(Numeric(15, 2), default=0)
    moneda = Column(String(10))

    cabecera = relationship("CostosCK13NCabecera", back_populates="produccion")


class CatalogoClaveModelo(Base):
    """
    Textos de clave de modelo de SAP (tabla T435T).

    Para las rutas de produccion el TEXTO de la clave coincide con el nombre de
    la operacion en MES. Ejemplo: clave RPBSMDT -> texto PCB_SMT_T -> operacion
    MES PCB_SMT_T. OpTimeSAP usa esta tabla para cruzar SAP con MES sin captura.

    Se llena con POST /api/v1/claves-modelo/sincronizar. Las claves que
    desaparecen de SAP no se borran: quedan con activo = false.
    """
    __tablename__ = "catalogo_clave_modelo"

    clave_modelo  = Column(String(20), primary_key=True)          # T435T-VLSCH
    texto         = Column(String(100))                            # T435T-TXT tal cual
    idioma        = Column(String(2))                              # idioma del texto elegido
    operacion_mes = Column(String(100), index=True)                # texto normalizado (MAYUSCULAS, sin espacios extremos)
    activo        = Column(Boolean, nullable=False, server_default="true")
    creado_en     = Column(DateTime, server_default=func.now())
    modificado_en = Column(DateTime, server_default=func.now(), onupdate=func.now())
