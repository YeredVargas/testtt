# db/setup_db.py
"""
Configuracion de la BD al arrancar la API.

CAMBIO v7.0: antes todo el SQL se ejecutaba como UN solo bloque. Si una sola
sentencia fallaba (p. ej. las vistas, que usaban columnas creado_el /
modificado_el que no existen en trazabilidad), se hacia rollback de TODO,
incluida la carga de catalogo_procesos. Por eso esa tabla estaba vacia.
Ahora cada paso corre en su propia transaccion y se reporta por separado.
"""
from sqlalchemy import text
from db.database import engine, Base, SessionLocal

# IMPORTANTE: Al importar esto, SQLAlchemy "lee" tus clases y sabe que tablas crear.
import db.models  # noqa: F401


PASOS_SQL = [
    ("Funcion fn_set_modificado_en", """
        CREATE OR REPLACE FUNCTION fn_set_modificado_en() RETURNS TRIGGER LANGUAGE plpgsql AS $$
        BEGIN NEW.modificado_en := CURRENT_TIMESTAMP; RETURN NEW; END; $$;
    """),

    ("Triggers modificado_en", """
        DROP TRIGGER IF EXISTS trg_piezas_modificado ON piezas;
        CREATE TRIGGER trg_piezas_modificado BEFORE UPDATE ON piezas FOR EACH ROW EXECUTE FUNCTION fn_set_modificado_en();

        DROP TRIGGER IF EXISTS trg_catalogo_procesos_modificado ON catalogo_procesos;
        CREATE TRIGGER trg_catalogo_procesos_modificado BEFORE UPDATE ON catalogo_procesos FOR EACH ROW EXECUTE FUNCTION fn_set_modificado_en();

        DROP TRIGGER IF EXISTS trg_trazabilidad_modificado ON trazabilidad;
        CREATE TRIGGER trg_trazabilidad_modificado BEFORE UPDATE ON trazabilidad FOR EACH ROW EXECUTE FUNCTION fn_set_modificado_en();
    """),

    # La clasificacion por familia se elimino. Este trigger buscaba el proyecto
    # en catalogo_material_proyecto; si la tabla ya no existe, cualquier INSERT
    # en piezas con proyecto 'SIN PROYECTO' fallaria. Se quita siempre al arrancar.
    ("Quitar trigger de clasificacion en piezas", """
        DROP TRIGGER IF EXISTS trg_piezas_asignar_proyecto ON piezas;
        DROP FUNCTION IF EXISTS fn_piezas_asignar_proyecto();
    """),

    ("Semilla catalogo_procesos", """
        INSERT INTO catalogo_procesos (codigo, centro, seccion)
        SELECT codigo, '0094', 'PENDIENTE' FROM unnest(ARRAY['WS_KEMM','RPBCCO','RPBCOC','RPBCOA','RPBCOO','RCOAT','RPBPIN','RPING','RPING1','RPBLMMY','RPBSKT','RPBMASY','RMASSY','RMASSY2','RPBWAV','RWAVE','RPBAOI','RPBOIA','RPBMIL','RMILL','RGLUE','RPBGLU','RPBAXI','RPBICT','RICT','RPBLM','RPBSPPB','RPBSPIB','RPBSMDB','RPBRFLB','RPBAOIB','RPBOIAB','RPBFSH','RLASER','RSPP_B','RSPI_B','RSMT_B','ROVEN_B','RAOI_B','ROIA_B','RFLASH','RPBSPPT','RPBSPIT','RPBSMDT','RPBRFLT','RPBAOIT','RPBOIAT','RSPP_T','RSPI_T','RSMT_T','ROVEN_T','RAOI_T','ROIA_T','ROWED','RRIWED','ROWEMI','RRIWEMI','ROE','RRIE','RESEAL','REEOL','REVIS','REDRA','ROEPCK','RCLEAN','RFLIP']) AS codigo
        ON CONFLICT (codigo, centro) DO NOTHING;
    """),

    ("Secciones de catalogo_procesos", """
        UPDATE catalogo_procesos SET seccion = CASE WHEN codigo = 'WS_KEMM' THEN 'WATER SPIDER' WHEN codigo IN ('RPBCCO','RPBCOC','RPBCOA','RPBCOO','RCOAT') THEN 'CONFORMAL' WHEN codigo IN ('RPBPIN','RPING','RPING1') THEN 'PINNING' WHEN codigo LIKE 'RPBLMMY%' THEN 'LASER' WHEN codigo LIKE 'RPBSKT%' THEN 'SOCKET' WHEN codigo IN ('RPBMASY','RMASSY','RMASSY2','RPBWAV','RWAVE','RPBAOI','RPBOIA') THEN 'ENSAMBLE MANUAL' WHEN codigo IN ('RPBMIL','RMILL') THEN 'ROUTER OFFLINE' WHEN codigo IN ('RGLUE','RPBGLU') THEN 'SILICON' WHEN codigo LIKE 'RPBAXI%' THEN 'AXI' WHEN codigo IN ('RPBICT','RICT') THEN 'ICT OFFLINE' WHEN codigo LIKE 'RPB%' OR codigo LIKE 'RSPP%' OR codigo LIKE 'RSPI%' OR codigo LIKE 'RSMT%' OR codigo LIKE 'ROVEN%' OR codigo LIKE 'RAOI%' OR codigo LIKE 'ROIA%' OR codigo LIKE 'RFLASH%' OR codigo LIKE 'RLASER%' OR codigo LIKE 'ROF%' OR codigo LIKE 'RRIF%' OR codigo LIKE 'RMEF%' OR codigo LIKE 'RFAS%' THEN 'SMT' WHEN codigo LIKE 'ROWED%' OR codigo LIKE 'RRIWED%' OR codigo LIKE 'ROWEMI%' OR codigo LIKE 'RRIWEMI%' OR codigo LIKE 'ROE%' OR codigo LIKE 'RRIE%' OR codigo IN ('RESEAL','REEOL','REVIS','REDRA','ROEPCK') THEN 'ENSAMBLE MANUAL' WHEN codigo IN ('RCLEAN','RFLIP') THEN 'ENSAMBLE MANUAL' ELSE 'SMT' END, modificado_en = CURRENT_TIMESTAMP
        WHERE bloqueado = FALSE;
    """),

    ("Vistas de trazabilidad", """
        DROP VIEW IF EXISTS vw_trazabilidad_vigente;
        DROP VIEW IF EXISTS vw_trazabilidad_historial;

        CREATE OR REPLACE VIEW vw_trazabilidad_historial AS
        SELECT t.id, p.numero_material, p.centro, p.nombre_pieza, p.proyecto, t.operacion_num, t.descripcion,
               t.clave_modelo, t.codigo_busqueda, t.proceso, t.steus, t.plnnr, t.plnal, t.aennr, t.equipos,
               t.cantidad_base, t.tiempo, t.tiempo_preparacion, t.tiempo_mano_obra, t.unidad_t,
               t.unidad_preparacion, t.unidad_mano_obra,
               t.fecha_inicio, t.fecha_fin, t.creado_en, t.modificado_en
        FROM trazabilidad t
        JOIN piezas p ON p.id = t.pieza_id;

        CREATE OR REPLACE VIEW vw_trazabilidad_vigente AS
        SELECT * FROM (
            -- Fase 0: se particiona tambien por hoja de ruta y alternativa; antes
            -- una operacion 0010 de la Alt 01 y otra de la Alt 02 competian entre si
            -- y la vista solo devolvia una de las dos.
            SELECT v.*, ROW_NUMBER() OVER (PARTITION BY v.numero_material, v.centro, v.plnnr, v.plnal, v.operacion_num
                                           ORDER BY v.fecha_inicio DESC NULLS LAST, v.aennr DESC) AS rn
            FROM vw_trazabilidad_historial v
        ) q WHERE rn = 1;
    """),
]


def inicializar_base_datos(reiniciar_todo: bool = False):
    if reiniciar_todo:
        print("PRECAUCION: Borrando TODAS las tablas de la base de datos...")
        Base.metadata.drop_all(bind=engine)
        print("Tablas borradas.")

    print("Verificando y creando tablas faltantes...")
    Base.metadata.create_all(bind=engine)

    errores = 0
    for nombre, sql in PASOS_SQL:
        sesion = SessionLocal()
        try:
            sesion.execute(text(sql))
            sesion.commit()
            print(f"-> DB Setup OK: {nombre}")
        except Exception as e:
            sesion.rollback()
            errores += 1
            print(f"[ERROR DB Setup] {nombre}: {e}")
        finally:
            sesion.close()

    if errores:
        print(f"-> DB Setup terminado con {errores} paso(s) con error. Revisa los mensajes de arriba.")
    else:
        print("-> DB Setup: Triggers, Vistas y Catalogos configurados exitosamente.")


if __name__ == "__main__":
    print("Iniciando setup manual de BD...")
    # Antes esto estaba en reiniciar_todo=True: correr este archivo a mano
    # BORRABA TODAS LAS TABLAS (incluidos los costos). Solo cambialo a True
    # si de verdad quieres empezar desde cero.
    inicializar_base_datos(reiniciar_todo=False)
