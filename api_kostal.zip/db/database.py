from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from core.config import pg_config

DATABASE_URL = (
    f"postgresql://{pg_config['user']}:{pg_config['password']}"
    f"@{pg_config['host']}:{pg_config['port']}/{pg_config['dbname']}"
)

# pool_pre_ping: la sincronizacion completa puede tardar mucho; sin esto, las
# conexiones que el firewall cierra por inactividad revientan a mitad de la corrida.
engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_recycle=1800)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """Generador de sesiones de base de datos para los endpoints."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
