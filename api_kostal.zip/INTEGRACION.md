# API de SAP (api_kostal) — v7.4

Extrae datos de SAP vía RFC y los guarda en PostgreSQL. La lectura para el frontend
la hace el backend principal (OpTimeSAP, `/api/...`). Excepción: `/deliveries/consultar`
consulta SAP en vivo y no escribe nada en BD; `/mes-ready/evaluar` solo lee la BD.

## Endpoints

Base: `http://<servidor>:5158/api/v1`

| Método | Ruta | Quién lo usa | Qué hace |
|---|---|---|---|
| `POST` | `/tiempo_operacion/sincronizar/todo_dinamico?centro=` | Dashboard, Gráficas, Comparativa, Tiempos | Lee los materiales del centro (MAPL) y descarga sus hojas de ruta |
| `POST` | `/tiempo_operacion/nuevo_material/{material}?centro=` | NuevoMaterialModal (paso 1) | Alta de un material + hojas de ruta |
| `POST` | `/costos/sincronizar-material/{material}?centro=` | NuevoMaterialModal (paso 2) | Costos CK13N de un material (síncrono) |
| `POST` | `/costos/sincronizar-todos?centro=` | CostosPage | Costos de todas las piezas **en segundo plano**; responde `job_id` |
| `GET` | `/sincronizar-bg/status/{job_id}` | CostosPage (polling) | `status`: `running` \| `completed` \| `failed`, más avance y errores |
| `POST` | `/deliveries/consultar` | — (nuevo) | Consulta deliveries en SAP (LIKP + LIPS), solo lectura |
| `POST` | `/mes-ready/evaluar` | — (nuevo) | Clasifica materiales en MES_READY / LEGACY / SIN_DATOS, leyendo la BD |
| `GET` | `/` | — | Health check |

## Deliveries (v7.1)

`POST /api/v1/deliveries/consultar` con body `{"deliveries": ["21464700", "EXT-555"]}` (máx. 200).

Cada número se busca en este orden: interno SAP (`LIKP-VBELN`), externo (`LIFEX`), referencia (`VERUR`).
Responde una fila por posición; se omiten las posiciones 9xxxxx (empaque). Los deliveries
no encontrados, sin posiciones o con error también regresan una fila, con `estatus`
`NO_ENCONTRADO` / `SIN_POSICIONES` / `ERROR` y el detalle en `mensaje`.
Fechas en `YYYY-MM-DD`; `null` si SAP no las tiene (p. ej. sin salida de mercancía).
Si no hay conexión a SAP responde **503**.

## MES Ready (v7.2)

`POST /api/v1/mes-ready/evaluar` con body `{"centro": "0094", "materiales": ["12171980", ...]}` (máx. 10 000).
Lee `piezas` + `trazabilidad`; no consulta SAP.

- `MES_READY`: al menos una operación vigente con `tiempo_preparacion` (VGW02) o `tiempo_mano_obra` (VGW03) > 0.
- `LEGACY`: todas sus operaciones vigentes solo con `tiempo` (VGW01).
- `SIN_DATOS`: no está en BD para ese centro, o no tiene operaciones vigentes.

Vigente = `fecha_inicio <= hoy` y (`fecha_fin >= hoy` o vacía), en cualquier alternativa.
Los números se normalizan (sin espacios ni ceros a la izquierda) y se quitan duplicados.
`pct_mes_ready` = MES_READY / (MES_READY + LEGACY), igual que el KPI del Dashboard.

## Tablas que escribe

| Tabla | Llenada por |
|---|---|
| `piezas` | `nuevo_material`, `todo_dinamico`, `sincronizar-material` |
| `trazabilidad` | `nuevo_material`, `todo_dinamico` |
| `catalogo_procesos` | Semilla automática al arrancar (código de operación → sección) |
| `costos_ck13n_cabecera` / `_elementos` / `_produccion` | `sincronizar-material`, `sincronizar-todos` |

## Cambios v7.4 (respecto a v7.3)

**Nuevo: catálogo de claves de modelo (T435T)** para cruzar SAP con MES.
- `POST /api/v1/claves-modelo/sincronizar`: lee T435T (VLSCH, SPRAS, TXT) y guarda en
  `catalogo_clave_modelo` un texto por clave (idioma S > E > D). Las claves que ya no
  están en SAP quedan `activo = false`. Responde totales y los textos compartidos por
  varias claves. Sin conexión a SAP responde **503**.
- `GET /api/v1/claves-modelo`: el catálogo guardado (no consulta SAP).
- La tabla se crea sola al arrancar. Sin migración manual.
- Por qué: el texto de la clave es el nombre de la operación en MES
  (RPBSMDT → `PCB_SMT_T`), así OpTimeSAP cruza SAP y MES sin captura manual.

## Cambios v7.3 (respecto a v7.2)

**Corregido**
- `trazabilidad.unidad_preparacion` y `unidad_mano_obra` existían en el modelo pero nunca se llenaban:
  ahora se guardan VGE02 y VGE03 al sincronizar (se llenan en la siguiente sincronización).
- `vw_trazabilidad_vigente` particionaba solo por material/centro/operación: con varias
  alternativas (Alt 01, Alt 02) devolvía una sola. Ahora particiona también por `plnnr` y `plnal`.
  La vista se recrea sola al arrancar la API.
- `nuevo_material` / `todo_dinamico`: el material y el centro se insertaban sin validar en las
  OPTIONS de `RFC_READ_TABLE`. Ahora se valida el formato; un valor inválido responde **422**.

**Sin cambios de esquema.** No hay migración que correr.

## Cambios v7.0 (respecto a v6.4)

**Eliminado**
- Toda la clasificación por familia: 8 endpoints `/clasificacion/*`, `clasificacion_service.py`,
  `clasificacion_rules.py`, `sap/rfc_utils.py`, clase `ConexionSAP`, tabla
  `catalogo_material_proyecto` y el trigger `trg_piezas_asignar_proyecto`.
  No cambia ningún dato visible: `procesar_pieza_logic` ya sobrescribía `piezas.proyecto`
  con la descripción de SAP, así que la familia calculada nunca llegaba al dashboard.
- `POST /tiempo_operacion/sincronizar/pieza/{material}` (sin uso).
- `GET /costos`, `GET /costos/{material}`, `GET /costos/{material}/produccion`
  (duplicados de `/api/costos` del backend principal; sin uso).
- Tablas `sync_log` y `sync_jobs` (vacías; la segunda sin referencias en código).
- `api/endpoints/tst.py` (script de prueba suelto), dependencias `apscheduler` y `requests`,
  variables `CRON_*` y `CLASIF_*` del `.env`.

**Corregido**
- `sincronizar-todos` ahora corre en segundo plano y devuelve `job_id`, que es lo que el
  frontend ya esperaba. Antes respondía síncrono sin `job_id`: el botón quedaba bloqueado
  o el request moría por el timeout de 15 s de `sapClient`.
- `setup_db`: cada paso SQL corre en su propia transacción. Antes un error en las vistas
  (columnas `creado_el`/`modificado_el` inexistentes) hacía rollback de todo, por eso
  `catalogo_procesos` estaba vacía y las operaciones quedaban como `SIN CLASIFICAR`.
- `python db/setup_db.py` ya no borra todas las tablas por defecto.
- Swagger mostraba el grupo de costos dos veces (dos tags en el mismo router).
- La lógica de guardado de costos estaba copiada en dos endpoints; ahora vive una vez en
  `services/costos_service.py::guardar_costos_material`.

## Migración de BD

Ejecutar `migrations/002_quitar_clasificacion_y_sync.sql` (instrucciones dentro del archivo).
`schema_completo.sql` y `001_*.sql` se conservan como historial; ya no reflejan el esquema vigente.
