# services/jobs_service.py
"""
Registro EN MEMORIA de tareas largas en segundo plano.

Por que en memoria y no en una tabla: la API corre como un solo proceso
(uvicorn / .exe) y solo hay un tipo de tarea larga (sincronizar todos los
costos). Si la API se reinicia a mitad de una corrida, el estado se pierde,
pero los costos ya guardados se quedan en la BD y basta con relanzarla.
"""
import threading
import uuid
from datetime import datetime

_jobs = {}
_lock = threading.Lock()
_MAX_JOBS_GUARDADOS = 50


def crear_job(tipo: str, clave: str):
    """
    Crea un job si no hay otro corriendo con la misma clave.
    Devuelve (job_id, es_nuevo). Si ya hay uno corriendo, regresa ese mismo.
    """
    with _lock:
        for job_id, job in _jobs.items():
            if job["clave"] == clave and job["status"] == "running":
                return job_id, False

        if len(_jobs) >= _MAX_JOBS_GUARDADOS:
            terminados = sorted(
                (j for j in _jobs.items() if j[1]["status"] != "running"),
                key=lambda j: j[1]["inicio"],
            )
            for job_id, _ in terminados[: len(_jobs) - _MAX_JOBS_GUARDADOS + 1]:
                _jobs.pop(job_id, None)

        job_id = uuid.uuid4().hex
        _jobs[job_id] = {
            "job_id": job_id, "tipo": tipo, "clave": clave, "status": "running",
            "total": 0, "procesados": 0, "exitosos": [], "errores": [],
            "error": None, "inicio": datetime.now(), "fin": None,
        }
        return job_id, True


def actualizar_job(job_id: str, **campos):
    with _lock:
        if job_id in _jobs:
            _jobs[job_id].update(campos)


def agregar_resultado(job_id: str, exito: str = None, error: dict = None):
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return
        if exito is not None:
            job["exitosos"].append(exito)
        if error is not None:
            job["errores"].append(error)


def marcar_material_procesado(job_id: str):
    with _lock:
        if job_id in _jobs:
            _jobs[job_id]["procesados"] += 1


def obtener_job(job_id: str):
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return None
        copia = dict(job)
        copia["exitosos"] = list(job["exitosos"])
        copia["errores"] = list(job["errores"])
        copia.pop("clave", None)
        return copia
