# services/claves_modelo_service.py
"""
Sincroniza la tabla T435T de SAP (textos de clave de modelo) con PostgreSQL.

Por que una tabla en BD y no leer T435T en cada comparativa:
  - Es dato maestro (cientos de filas) que casi no cambia.
  - La comparativa de OpTimeSAP no debe depender de que SAP (RFC) este arriba.
  - OpTimeSAP no tiene conexion RFC; solo lee Postgres. Esta API es la unica que
    habla con SAP, igual que para hojas de ruta y costos.

Idioma: se leen todos y se elige por clave S (espanol) > E > D > el primero.
En las claves de produccion el texto es el mismo en todos los idiomas.
"""
from datetime import datetime

from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from db.models import CatalogoClaveModelo
from services.tiempo_operacion_service import safe_call_rfc_read_table, normalize_value

PRIORIDAD_IDIOMA = ["S", "E", "D"]


def normalizar_operacion(texto: str) -> str:
    return normalize_value(texto).upper()


def leer_t435t(conn_sap) -> dict:
    """{clave_modelo: (texto, idioma)} eligiendo idioma por prioridad."""
    resultado = safe_call_rfc_read_table(conn_sap, "T435T", ["VLSCH", "SPRAS", "TXT"])
    if not resultado["ok"]:
        raise Exception(f"No se pudo leer T435T: {resultado['error']}")

    por_clave = {}
    for fila in resultado["rows"]:
        clave = normalize_value(fila.get("VLSCH")).upper()
        texto = normalize_value(fila.get("TXT"))
        idioma = normalize_value(fila.get("SPRAS")).upper()
        if clave and texto:
            por_clave.setdefault(clave, {})[idioma] = texto

    elegidos = {}
    for clave, textos in por_clave.items():
        idioma = next((i for i in PRIORIDAD_IDIOMA if i in textos), sorted(textos)[0])
        elegidos[clave] = (textos[idioma], idioma)
    return elegidos


def sincronizar_claves_modelo(conn_sap, db: Session) -> dict:
    datos = leer_t435t(conn_sap)
    if not datos:
        return {"status": "warning", "mensaje": "SAP no devolvio registros de T435T.", "total_sap": 0}

    existentes = {c.clave_modelo: c for c in db.query(CatalogoClaveModelo).all()}
    nuevas = [k for k in datos if k not in existentes]
    cambiadas = [
        k for k, (texto, idioma) in datos.items()
        if k in existentes and (existentes[k].texto != texto or not existentes[k].activo)
    ]
    desactivar = [k for k, c in existentes.items() if k not in datos and c.activo]

    try:
        filas = [
            {
                "clave_modelo": clave,
                "texto": texto,
                "idioma": idioma,
                "operacion_mes": normalizar_operacion(texto),
                "activo": True,
            }
            for clave, (texto, idioma) in datos.items()
        ]
        stmt = insert(CatalogoClaveModelo).values(filas)
        stmt = stmt.on_conflict_do_update(
            index_elements=[CatalogoClaveModelo.clave_modelo],
            set_={
                "texto": stmt.excluded.texto,
                "idioma": stmt.excluded.idioma,
                "operacion_mes": stmt.excluded.operacion_mes,
                "activo": True,
                "modificado_en": datetime.now(),
            },
        )
        db.execute(stmt)
        if desactivar:
            db.query(CatalogoClaveModelo).filter(CatalogoClaveModelo.clave_modelo.in_(desactivar)).update(
                {"activo": False, "modificado_en": datetime.now()}, synchronize_session=False
            )
        db.commit()
    except Exception:
        db.rollback()
        raise

    # Aviso: varias claves con el mismo texto (no es error, pero conviene saberlo).
    por_texto = {}
    for clave, (texto, _) in datos.items():
        por_texto.setdefault(normalizar_operacion(texto), []).append(clave)
    duplicados = {t: sorted(c) for t, c in por_texto.items() if len(c) > 1}

    return {
        "status": "success",
        "total_sap": len(datos),
        "nuevas": len(nuevas),
        "actualizadas": len(cambiadas),
        "desactivadas": len(desactivar),
        "textos_compartidos": duplicados,
    }
