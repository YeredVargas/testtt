# services/mes_ready_service.py
"""
Evaluacion MES Ready de materiales, leyendo la hoja de ruta ya guardada en BD.

Criterio (el mismo que usa el frontend en Dashboard y Comparativa):
  - MES_READY : al menos UNA operacion vigente tiene tiempos separados,
                es decir tiempo_preparacion (VGW02) > 0 o tiempo_mano_obra (VGW03) > 0.
  - LEGACY    : tiene operaciones vigentes, pero todas traen solo 'tiempo'
                (VGW01) y las otras dos en cero o vacias ("caja negra").
  - SIN_DATOS : el material no esta sincronizado en la BD para ese centro,
                o no tiene operaciones vigentes.

Operacion vigente: fecha_inicio <= hoy y (fecha_fin >= hoy o fecha_fin vacia).
Normalmente es la version con fecha_fin = 9999-12-31; ademas se excluye una
version con fecha de inicio a futuro que SAP ya tenga cargada.
Se consideran todas las alternativas (plnal) de la hoja de ruta.

Solo LECTURA de PostgreSQL. No consulta SAP.
"""
from datetime import date

from sqlalchemy import and_, case, func, or_
from sqlalchemy.orm import Session

from db.models import Pieza, Trazabilidad

TAMANO_LOTE_IN = 1000

MES_READY = "MES_READY"
LEGACY = "LEGACY"
SIN_DATOS = "SIN_DATOS"


def normalizar_material(valor) -> str:
    """Quita espacios y ceros a la izquierda (asi se guardan en 'piezas')."""
    texto = str(valor).strip() if valor is not None else ""
    if texto.isdigit():
        return texto.lstrip("0") or "0"
    return texto.upper()


def limpiar_lista(materiales):
    """Normaliza, quita vacios y duplicados, respeta el orden recibido."""
    limpios, vistos = [], set()
    for m in materiales:
        m = normalizar_material(m)
        if m and m not in vistos:
            vistos.add(m)
            limpios.append(m)
    return limpios


def _conteos_por_material(db: Session, centro: str, materiales: list, hoy: date) -> dict:
    """
    Devuelve {numero_material: (operaciones_vigentes, operaciones_con_tiempos_separados)}
    solo para los materiales que existen en 'piezas' para ese centro.
    Los materiales sin operaciones vigentes aparecen con (0, 0).
    """
    tiempos_separados = or_(
        func.coalesce(Trazabilidad.tiempo_preparacion, 0) > 0,
        func.coalesce(Trazabilidad.tiempo_mano_obra, 0) > 0,
    )
    vigente = and_(
        or_(Trazabilidad.fecha_inicio.is_(None), Trazabilidad.fecha_inicio <= hoy),
        or_(Trazabilidad.fecha_fin.is_(None), Trazabilidad.fecha_fin >= hoy),
    )

    resultado = {}
    for i in range(0, len(materiales), TAMANO_LOTE_IN):
        lote = materiales[i:i + TAMANO_LOTE_IN]
        filas = (
            db.query(
                Pieza.numero_material,
                func.count(Trazabilidad.id).label("ops_vigentes"),
                func.coalesce(func.sum(case((tiempos_separados, 1), else_=0)), 0).label("ops_separadas"),
            )
            # outer join con la condicion de vigencia dentro del ON: asi un material
            # que existe pero no tiene operaciones vigentes regresa con conteo 0.
            .outerjoin(Trazabilidad, and_(Trazabilidad.pieza_id == Pieza.id, vigente))
            .filter(Pieza.centro == centro)
            .filter(Pieza.numero_material.in_(lote))
            .group_by(Pieza.numero_material)
            .all()
        )
        for numero_material, ops_vigentes, ops_separadas in filas:
            resultado[numero_material] = (int(ops_vigentes), int(ops_separadas))
    return resultado


def evaluar_mes_ready(db: Session, centro: str, materiales: list, hoy: date = None) -> dict:
    hoy = hoy or date.today()
    conteos = _conteos_por_material(db, centro, materiales, hoy)

    detalle = []
    for material in materiales:
        if material not in conteos:
            estado, motivo, ops, separadas = SIN_DATOS, "No está sincronizado en la BD para este centro.", 0, 0
        else:
            ops, separadas = conteos[material]
            if ops == 0:
                estado, motivo = SIN_DATOS, "Existe en la BD, pero no tiene operaciones vigentes."
            elif separadas > 0:
                estado, motivo = MES_READY, ""
            else:
                estado, motivo = LEGACY, "Todas sus operaciones vigentes traen solo tiempo total (sin preparación ni mano de obra)."

        detalle.append({
            "material": material,
            "estado": estado,
            "operaciones_vigentes": ops,
            "operaciones_con_tiempos_separados": separadas,
            "motivo": motivo,
        })

    total_ready = sum(1 for d in detalle if d["estado"] == MES_READY)
    total_legacy = sum(1 for d in detalle if d["estado"] == LEGACY)
    total_sin_datos = sum(1 for d in detalle if d["estado"] == SIN_DATOS)
    con_datos = total_ready + total_legacy

    return {
        "resumen": {
            "total_evaluados": len(detalle),
            "mes_ready": total_ready,
            "no_mes_ready": total_legacy + total_sin_datos,
            "legacy": total_legacy,
            "sin_datos": total_sin_datos,
            # Porcentaje sobre materiales CON datos, igual que el KPI del Dashboard.
            "pct_mes_ready": round(total_ready / con_datos * 100, 1) if con_datos else 0.0,
        },
        "no_mes_ready": [
            {"material": d["material"], "estado": d["estado"], "motivo": d["motivo"]}
            for d in detalle if d["estado"] != MES_READY
        ],
        "detalle": detalle,
    }
