# services/delivery_service.py
"""
Consulta de deliveries (entregas) en SAP: cabecera LIKP + posiciones LIPS.

Origen: delyvery5.py. Cambios respecto al script:
  - Usa la conexion central (sap/rfc_client.py -> .env), no credenciales en codigo.
  - Devuelve una lista PLANA: una fila por posicion del delivery. Los deliveries
    no encontrados / sin posiciones / con error tambien regresan una fila, con
    los campos de datos en null y el estatus correspondiente, para que quien
    consume siempre reciba una fila por cada delivery pedido.
  - Fechas en ISO (YYYY-MM-DD) y null cuando SAP trae vacio o 00000000
    (p. ej. un delivery sin salida de mercancia todavia).
  - cantidad como numero, no como texto.
Solo LECTURA: no escribe nada en PostgreSQL.
"""
from datetime import datetime
from decimal import Decimal, InvalidOperation

MAX_POSICIONES = 2000

# Posiciones 9xxxxx suelen ser empaque, carton, dummy, etc.
PREFIJO_POSICION_EMPAQUE = "9"

CAMPOS_LIKP = ["VBELN", "LIFEX", "VERUR", "LFART", "LFDAT", "WADAT", "WADAT_IST", "ERDAT", "VSTEL"]
CAMPOS_LIPS = ["VBELN", "POSNR", "MATNR", "ARKTX", "LFIMG", "VRKME", "WERKS", "LGORT", "VGBEL", "VGPOS"]

UNIDADES_AMIGABLES = {"ST": "pzas", "PC": "pzas", "PCE": "pzas"}


# =========================================================
# UTILIDADES
# =========================================================
def normalizar(valor):
    return str(valor).strip() if valor is not None else ""


def escapar_sap(valor):
    return normalizar(valor).replace("'", "''")


def formatear_documento_sap(numero):
    """21464700 -> 0021464700 (VBELN mide 10 posiciones)."""
    numero = normalizar(numero)
    return numero.zfill(10) if numero.isdigit() else numero.upper()


def a_decimal(valor):
    texto = normalizar(valor).replace(" ", "")
    if not texto:
        return Decimal("0")
    if "," in texto and "." in texto:
        if texto.rfind(",") > texto.rfind("."):
            texto = texto.replace(".", "").replace(",", ".")
        else:
            texto = texto.replace(",", "")
    elif "," in texto:
        texto = texto.replace(",", ".")
    try:
        return Decimal(texto)
    except InvalidOperation:
        return Decimal("0")


def material_externo(material):
    material = normalizar(material)
    return (material.lstrip("0") or "0") if material.isdigit() else material


def unidad_amigable(unidad):
    unidad = normalizar(unidad).upper()
    return UNIDADES_AMIGABLES.get(unidad, unidad)


def fecha_iso(valor):
    """'20260105' -> '2026-01-05'. Vacio o '00000000' -> None."""
    texto = normalizar(valor)
    if not texto or texto == "00000000":
        return None
    try:
        return datetime.strptime(texto, "%Y%m%d").date().isoformat()
    except ValueError:
        return texto


# =========================================================
# RFC_READ_TABLE
# =========================================================
def _construir_options(condiciones):
    partes = [f"{campo} = '{escapar_sap(valor)}'" for campo, valor in condiciones.items() if normalizar(valor)]
    if not partes:
        return []
    return [partes[0]] + [f"AND {p}" for p in partes[1:]]


def leer_tabla(conn, tabla, campos, condiciones=None, rowcount=MAX_POSICIONES):
    parametros = {
        "QUERY_TABLE": tabla.upper(),
        "DELIMITER": "|",
        "FIELDS": [{"FIELDNAME": c} for c in campos],
        "ROWCOUNT": rowcount,
    }
    opciones = _construir_options(condiciones or {})
    if opciones:
        parametros["OPTIONS"] = [{"TEXT": o} for o in opciones]

    resultado = conn.call("RFC_READ_TABLE", **parametros)

    campos_resultado = [normalizar(c.get("FIELDNAME")) for c in resultado.get("FIELDS", [])] or campos
    filas = []
    for registro in resultado.get("DATA", []):
        valores = registro.get("WA", "").split("|")
        filas.append({
            campo: normalizar(valores[i]) if i < len(valores) else ""
            for i, campo in enumerate(campos_resultado)
        })
    return filas


# =========================================================
# CONSULTAS
# =========================================================
def resolver_deliveries_sap(conn, delivery_input):
    """
    Busca el numero en este orden y se detiene en la primera coincidencia:
      1. Delivery interno SAP (LIKP-VBELN, con ceros a la izquierda)
      2. Delivery externo (LIKP-LIFEX)
      3. Referencia (LIKP-VERUR)
    Puede devolver mas de una cabecera.
    """
    for campo, valor in (("VBELN", formatear_documento_sap(delivery_input)),
                         ("LIFEX", delivery_input),
                         ("VERUR", delivery_input)):
        registros = leer_tabla(conn, "LIKP", CAMPOS_LIKP, {campo: valor}, rowcount=20)
        if registros:
            return registros
    return []


def obtener_posiciones_delivery(conn, delivery_interno, excluir_empaque=True):
    posiciones = leer_tabla(conn, "LIPS", CAMPOS_LIPS, {"VBELN": delivery_interno})
    if excluir_empaque:
        posiciones = [p for p in posiciones if not normalizar(p.get("POSNR")).startswith(PREFIJO_POSICION_EMPAQUE)]
    return posiciones


def _fila(delivery_buscado, estatus, mensaje="", cabecera=None, posicion=None):
    """Arma una fila con el contrato de salida del endpoint."""
    cabecera = cabecera or {}
    posicion = posicion or {}
    unidad = normalizar(posicion.get("VRKME")) or None

    return {
        "delivery_buscado": delivery_buscado,
        "delivery_interno_sap": normalizar(cabecera.get("VBELN")) or None,
        "delivery_externo": (normalizar(cabecera.get("LIFEX")) or normalizar(cabecera.get("VERUR"))) or None,
        "fecha_delivery": fecha_iso(cabecera.get("LFDAT")),
        "fecha_salida_mercancia": fecha_iso(cabecera.get("WADAT_IST")),
        "material": material_externo(posicion.get("MATNR")) if posicion else None,
        "descripcion": normalizar(posicion.get("ARKTX")) or None,
        "cantidad": float(a_decimal(posicion.get("LFIMG"))) if posicion else None,
        "unidad": unidad,
        "unidad_amigable": unidad_amigable(unidad) if unidad else None,
        "centro": normalizar(posicion.get("WERKS")) or None,
        "almacen": normalizar(posicion.get("LGORT")) or None,
        "pedido_origen": normalizar(posicion.get("VGBEL")) or None,
        "estatus": estatus,
        "mensaje": mensaje,
    }


def consultar_delivery(conn, delivery_input):
    """Devuelve la lista de filas de UN delivery (al menos una fila)."""
    cabeceras = resolver_deliveries_sap(conn, delivery_input)
    if not cabeceras:
        return [_fila(delivery_input, "NO_ENCONTRADO", "No se encontró el delivery en LIKP.")]

    filas = []
    for cabecera in cabeceras:
        delivery_interno = normalizar(cabecera.get("VBELN"))
        for posicion in obtener_posiciones_delivery(conn, delivery_interno):
            filas.append(_fila(delivery_input, "OK", cabecera=cabecera, posicion=posicion))

    if not filas:
        return [_fila(delivery_input, "SIN_POSICIONES",
                      "El delivery existe, pero no tiene posiciones válidas en LIPS.", cabecera=cabeceras[0])]
    return filas


def limpiar_lista(deliveries):
    """Quita vacios y duplicados, respetando el orden recibido."""
    limpios, vistos = [], set()
    for d in deliveries:
        d = normalizar(d)
        if d and d not in vistos:
            vistos.add(d)
            limpios.append(d)
    return limpios


def consultar_varios_deliveries(conn, deliveries_limpios):
    """Un error en un delivery no detiene a los demas."""
    filas = []
    for delivery in deliveries_limpios:
        try:
            filas.extend(consultar_delivery(conn, delivery))
        except Exception as error:
            filas.append(_fila(delivery, "ERROR", str(error)))
    return filas
