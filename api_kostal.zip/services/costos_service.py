# services/costos_service.py
import os
import time
import logging
from decimal import Decimal
from pyrfc import Connection, CommunicationError

logger = logging.getLogger(__name__)

def normalizar(valor):
    return str(valor).strip() if valor is not None else ""

def escapar_sap(valor):
    return normalizar(valor).replace("'", "''")

def formatear_material_sap(material):
    material = normalizar(material)
    if not material: return ""
    return material.zfill(18) if material.isdigit() else material.upper()

def formatear_centro(centro):
    centro = normalizar(centro)
    return centro.zfill(4) if centro.isdigit() else centro.upper()

def numero_para_ordenar(valor):
    try: return int(normalizar(valor))
    except ValueError: return -1

def quitar_ceros_iniciales(valor):
    valor = normalizar(valor)
    if valor.isdigit(): return valor.lstrip("0") or "0"
    return valor

def obtener_primer_valor(registro, campos):
    for campo in campos:
        val = normalizar(registro.get(campo))
        if val: return val
    return ""

def convertir_numero_sap(valor):
    texto = normalizar(valor).replace(" ", "")
    if not texto: return 0.0
    try:
        if "," in texto and "." in texto:
            if texto.rfind(",") > texto.rfind("."):
                texto = texto.replace(".", "").replace(",", ".")
            else:
                texto = texto.replace(",", "")
        elif "," in texto:
            texto = texto.replace(",", ".")
        return float(texto)
    except ValueError:
        return 0.0

def obtener_metadata_tabla(conn, tabla):
    try:
        resultado = conn.call("DDIF_FIELDINFO_GET", TABNAME=tabla.upper(), LANGU="S", ALL_TYPES="X")
        return {normalizar(r.get("FIELDNAME")) for r in resultado.get("DFIES_TAB", []) if normalizar(r.get("FIELDNAME"))}
    except Exception as exc:
        logger.warning(f"No se pudo obtener metadata de {tabla}: {exc}")
        return set()

def filtrar_campos_existentes(metadata, campos):
    if not metadata: return campos
    return [c for c in campos if c in metadata]

def leer_tabla_sap_segura(conn, tabla, campos, condiciones=None):
    condiciones = condiciones or {}
    metadata = obtener_metadata_tabla(conn, tabla)
    
    campos_validos = filtrar_campos_existentes(metadata, [c.upper() for c in dict.fromkeys(campos) if c])
    if not campos_validos: return []
    
    partes = []
    for campo, valor in condiciones.items():
        if valor: partes.append(f"{campo} = '{escapar_sap(valor)}'")
            
    options = [{"TEXT": partes[0]}] + [{"TEXT": f" AND {p}"} for p in partes[1:]] if partes else []

    try:
        resultado = conn.call(
            "RFC_READ_TABLE", QUERY_TABLE=tabla.upper(), DELIMITER="|",
            FIELDS=[{"FIELDNAME": c} for c in campos_validos], OPTIONS=options, ROWCOUNT=0
        )
    except Exception as e:
        error_str = str(e).upper()
        if "TABLE_WITHOUT_DATA" in error_str or "NOT_FOUND" in error_str: return []
        raise e

    campos_resultado = [normalizar(r.get("FIELDNAME")) for r in resultado.get("FIELDS", [])] or campos_validos
    filas = []
    for registro in resultado.get("DATA", []):
        valores = registro.get("WA", "").split("|")
        fila = {}
        for idx, c in enumerate(campos_resultado):
            fila[c] = normalizar(valores[idx]) if idx < len(valores) else ""
        filas.append(fila)
    return filas

def obtener_costos_ck13n(numero_material: str, centro: str = None) -> dict:
    if centro is None: centro = os.getenv('SAP_CENTRO', '0094')

    conn_params = {
        'mshost': os.getenv('SAP_MSHOST'), 'sysid': os.getenv('SAP_SYSID'),
        'group': os.getenv('SAP_GROUP'), 'client': os.getenv('SAP_CLIENT'),
        'user': os.getenv('SAP_USER'), 'passwd': os.getenv('SAP_PASSWD'),
        'lang': os.getenv('SAP_LANG', 'ES')
    }

    max_reintentos = int(os.getenv('RFC_MAX_REINTENTOS', 3))
    espera_segundos = int(os.getenv('RFC_ESPERA_REINTENTO_SEG', 2))

    for intento in range(max_reintentos):
        try:
            conn = Connection(**conn_params)
            material_sap = formatear_material_sap(numero_material)
            centro_sap = formatear_centro(centro)
            
            campos_keko = ["KALNR", "KALKA", "MATNR", "WERKS", "KLVAR", "TVERS", "KADKY", "KADAT", "BWVAR", "FREIG", "FEH_STA", "BZOBJ"]
            registros_keko = leer_tabla_sap_segura(conn, "KEKO", campos_keko, {"MATNR": material_sap, "WERKS": centro_sap})

            if not registros_keko:
                return {"error": f"No se encontraron cálculos en KEKO para {numero_material} en el centro {centro}."}

            grupos_variantes = {}
            for reg in registros_keko:
                if normalizar(reg.get("BZOBJ")) not in ("", "0"): continue
                var = normalizar(reg.get("KLVAR"))
                if var: 
                    if var not in grupos_variantes: grupos_variantes[var] = []
                    grupos_variantes[var].append(reg)

            if not grupos_variantes: return {"error": "Registros en KEKO inválidos (BZOBJ no es 0)."}

            resultados_variantes = []
            cache_actividades = {}
            cache_centros = {}
            
            # CACHÉ PARA TEXTOS DE PUESTOS DE TRABAJO (MÁQUINAS) VÍA ARBID
            cache_workcenters = {} 

            for variante, calculos in grupos_variantes.items():
                calc_ordenados = sorted(calculos, key=lambda x: (numero_para_ordenar(x.get("TVERS")), normalizar(x.get("KADKY")), normalizar(x.get("KADAT"))), reverse=True)
                
                for calculo_activo in calc_ordenados[:10]:
                    kalnr_actual = calculo_activo.get("KALNR", "")
                    fecha_calculo = normalizar(calculo_activo.get("KADKY", ""))
                    kalka_actual = normalizar(calculo_activo.get("KALKA", ""))
                    
                    try:
                        res_detail = conn.call(
                            "BAPI_COSTESTIMATE_GETDETAIL",
                            COSTINGNUMBER=kalnr_actual, COSTINGTYPE=kalka_actual,
                            COSTINGDATE=fecha_calculo, COSTINGVERSION=calculo_activo.get("TVERS", ""),
                            VALUATIONVARIANT=calculo_activo.get("BWVAR", ""), REFERENCEOBJECT=calculo_activo.get("BZOBJ", "0"),
                            COST_COMPONENT_VIEW="10", COST_COMPONENTS=[]
                        )
                        componentes = res_detail.get("COST_COMPONENTS", [])
                    except Exception as e_bapi:
                        logger.warning(f"Error BAPI Vista 10: {e_bapi}")
                        componentes = []

                    filas_out = []
                    tot_global = fij_global = Decimal(0)
                    for c in componentes:
                        tot = Decimal(str(c.get("TOTAL_AMT", 0) or 0))
                        fijo = Decimal(str(c.get("FIXED_AMT", 0) or 0))
                        tot_global += tot; fij_global += fijo
                        filas_out.append({
                            "comp": str(c.get("COST_COMP", "")).strip(), "denominacion": str(c.get("COCOMPNAME", "")).strip(),
                            "total": float(tot), "fijado": float(fijo), "variable": float(tot - fijo)
                        })

                    # --- FILTRO ESTRICTO CKIS ---
                    condiciones_ckis = {
                        "KALNR": kalnr_actual,
                        "KADKY": fecha_calculo,
                        "KALKA": kalka_actual,
                        "TVERS": normalizar(calculo_activo.get("TVERS")),
                        "BWVAR": normalizar(calculo_activo.get("BWVAR")),
                        "TYPPS": "E"
                    }
                    
                    campos_ckis = [
                        "KALNR", "KADKY", "KALKA", "TVERS", "BWVAR", "POSNR", "TYPPS", 
                        "KOKRS", "KOSTL", "LSTAR", "KSTAR", "MENGE", "MEEHT", 
                        "WERTN", "WERTB", "WRTFW_POS", "WRTFW_KPF", 
                        "HWAER", "FWAER", "FWAER_KPF", 
                        "TXZ01", "LTEXT", "KTEXT", "TEXT1", "SGTXT", "LTX01", 
                        "ARBID" # <-- LECTURA DEL CAMPO INTERNO DE LA MÁQUINA
                    ]
                    
                    ckis_data = leer_tabla_sap_segura(conn, "CKIS", campos_ckis, condiciones_ckis)
                    
                    filas_produccion = []

                    for row in ckis_data:
                        if normalizar(row.get("TYPPS")) != "E": continue
                        if normalizar(row.get("KADKY")) and normalizar(row.get("KADKY")) != fecha_calculo: continue
                        if normalizar(row.get("KALKA")) and normalizar(row.get("KALKA")) != kalka_actual: continue

                        kokrs = normalizar(row.get("KOKRS"))
                        kostl_int = normalizar(row.get("KOSTL"))
                        lstar_int = normalizar(row.get("LSTAR"))
                        kstar_int = normalizar(row.get("KSTAR"))
                        
                        # EXTRACCIÓN DEL ARBID
                        arbid_int = normalizar(row.get("ARBID")) 
                        
                        kostl = quitar_ceros_iniciales(kostl_int)
                        lstar = quitar_ceros_iniciales(lstar_int)
                        kstar = quitar_ceros_iniciales(kstar_int)

                        if (kokrs, kostl_int) not in cache_centros and kostl_int:
                            cskt = leer_tabla_sap_segura(conn, "CSKT", ["LTEXT", "KTEXT"], {"KOKRS": kokrs, "KOSTL": kostl_int, "SPRAS": "S"})
                            cache_centros[(kokrs, kostl_int)] = obtener_primer_valor(cskt[0], ["LTEXT", "KTEXT"]) if cskt else ""

                        if (kokrs, lstar_int) not in cache_actividades and lstar_int:
                            cslt = leer_tabla_sap_segura(conn, "CSLT", ["LTEXT", "KTEXT"], {"KOKRS": kokrs, "LSTAR": lstar_int, "SPRAS": "S"})
                            cache_actividades[(kokrs, lstar_int)] = obtener_primer_valor(cslt[0], ["LTEXT", "KTEXT"]) if cslt else ""

                        # CONSULTA DEL TEXTO EXACTO DE LA MÁQUINA A LA TABLA CRTX
                        if arbid_int and arbid_int not in cache_workcenters:
                            crtx = leer_tabla_sap_segura(conn, "CRTX", ["KTEXT"], {"OBJTY": "A", "OBJID": arbid_int, "SPRAS": "S"})
                            cache_workcenters[arbid_int] = obtener_primer_valor(crtx[0], ["KTEXT"]) if crtx else ""

                        texto_directo = obtener_primer_valor(row, ["SGTXT", "LTX01", "TXZ01", "LTEXT", "KTEXT", "TEXT1"])
                        
                        # PRIORIDAD 1: TABLA CRTX (NOMBRE DE LA MÁQUINA)
                        texto_recurso = cache_workcenters.get(arbid_int, "") or texto_directo or cache_actividades.get((kokrs, lstar_int), "") or cache_centros.get((kokrs, kostl_int), "")

                        # SELECCIÓN INTELIGENTE DEL VALOR MÁXIMO (EVITA CEROS Y TOMA EL MONTO EN MXP)
                        val_1 = convertir_numero_sap(row.get("WERTN"))
                        val_2 = convertir_numero_sap(row.get("WRTFW_POS"))
                        val_3 = convertir_numero_sap(row.get("WRTFW_KPF"))
                        val_4 = convertir_numero_sap(row.get("WERTB"))
                        valor_tot = max(val_1, val_2, val_3, val_4)

                        cantidad = convertir_numero_sap(row.get("MENGE"))
                        
                        moneda_calc = obtener_primer_valor(row, ["HWAER", "FWAER", "FWAER_KPF"])
                        if not moneda_calc: moneda_calc = "MXP"

                        filas_produccion.append({
                            "posicion": normalizar(row.get("POSNR")),
                            "centro_coste": kostl, "texto_centro_coste": cache_centros.get((kokrs, kostl_int), ""),
                            "clase_actividad": lstar, "texto_actividad": cache_actividades.get((kokrs, lstar_int), ""),
                            "elemento_coste": kstar, "texto_recurso": texto_recurso,
                            "cantidad": cantidad, "unidad": normalizar(row.get("MEEHT")),
                            "valor_total": valor_tot, "moneda": moneda_calc
                        })

                resultados_variantes.append({
                    "variante": variante,
                    "metadatos_calculo": {"estatus": "FR" if calculo_activo.get("FREIG") == "X" else "KA", "fecha_validez": calculo_activo.get("KADAT", ""), "numero_costeo": kalnr_actual, "fecha_calculo": fecha_calculo},
                    "gran_total": {"total": float(tot_global), "fijado": float(fij_global), "variable": float(tot_global - fij_global)},
                    "elementos": filas_out, "produccion": filas_produccion
                })

            return {"variantes_descargadas": resultados_variantes}

        except CommunicationError as e:
            logger.warning(f"Falla red SAP: {e}")
            if intento == max_reintentos - 1: return {"error": f"Error conexión SAP: {e}"}
            time.sleep(espera_segundos)
        except Exception as e:
            return {"error": f"Error interno: {str(e)}"}
        finally:
            if 'conn' in locals() and getattr(conn, 'alive', False): conn.close()

# =========================================================
# PERSISTENCIA EN BD
# Antes este bloque estaba copiado dos veces (sincronizar-todos y
# sincronizar-material). Ahora vive aqui una sola vez.
# =========================================================
from datetime import datetime
from sqlalchemy.orm import Session
from db.models import CostosCK13NCabecera, CostosCK13NElementos, CostosCK13NProduccion


def parsear_fecha_segura(fecha_str):
    try:
        fecha_limpia = str(fecha_str).strip()
        if not fecha_limpia or fecha_limpia == "00000000": return datetime.now().date()
        if "-" in fecha_limpia: return datetime.strptime(fecha_limpia, "%Y-%m-%d").date()
        return datetime.strptime(fecha_limpia, "%Y%m%d").date()
    except Exception: return datetime.now().date()


def guardar_costos_material(db: Session, material: str, centro: str) -> dict:
    """
    Descarga de SAP (CK13N) los costos de un material y los guarda en BD.
    La pieza debe existir en 'piezas' (FK de costos_ck13n_cabecera).
    Devuelve {"variantes": [...]} o {"error": "..."} si SAP no trae costos.
    Las excepciones de BD se propagan; quien llama hace el rollback.
    """
    datos_sap = obtener_costos_ck13n(material, centro=centro)
    if "error" in datos_sap:
        return {"error": datos_sap["error"]}

    variantes = []
    for var_data in datos_sap.get("variantes_descargadas", []):
        variante = var_data["variante"]
        meta = var_data["metadatos_calculo"]
        gran_total = var_data["gran_total"]
        fecha_validez_dt = parsear_fecha_segura(meta.get("fecha_validez"))

        cabecera = db.query(CostosCK13NCabecera).filter_by(
            numero_material=material, centro=centro, variante=variante, fecha_validez=fecha_validez_dt
        ).first()
        if not cabecera:
            cabecera = CostosCK13NCabecera(
                numero_material=material, centro=centro, variante=variante, estatus=meta.get("estatus", "KA"),
                fecha_validez=fecha_validez_dt, numero_costeo=meta.get("numero_costeo", ""),
                total_global=gran_total["total"], total_fijado=gran_total["fijado"], total_variable=gran_total["variable"]
            )
            db.add(cabecera); db.commit(); db.refresh(cabecera)
        else:
            cabecera.total_global = gran_total["total"]
            cabecera.total_fijado = gran_total["fijado"]
            cabecera.total_variable = gran_total["variable"]
            cabecera.estatus = meta.get("estatus", "KA")
            cabecera.numero_costeo = meta.get("numero_costeo", "")
            db.commit()

        db.query(CostosCK13NElementos).filter_by(cabecera_id=cabecera.id).delete()
        db.add_all([
            CostosCK13NElementos(
                cabecera_id=cabecera.id, componente=e["comp"], denominacion=e["denominacion"],
                total=e["total"], fijado=e["fijado"], variable=e["variable"]
            ) for e in var_data["elementos"]
        ])

        db.query(CostosCK13NProduccion).filter_by(cabecera_id=cabecera.id).delete()
        db.add_all([
            CostosCK13NProduccion(
                cabecera_id=cabecera.id, posicion=p["posicion"], centro_coste=p["centro_coste"],
                texto_centro_coste=p["texto_centro_coste"], clase_actividad=p["clase_actividad"],
                texto_actividad=p["texto_actividad"], elemento_coste=p["elemento_coste"],
                texto_recurso=p["texto_recurso"], cantidad=p["cantidad"], unidad=p["unidad"],
                valor_total=p["valor_total"], moneda=p["moneda"]
            ) for p in var_data.get("produccion", [])
        ])
        db.commit()
        variantes.append(variante)

    return {"variantes": variantes}
