# services/tiempo_operacion_service.py
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from pyrfc import ABAPApplicationError, ABAPRuntimeError
from db.models import Pieza, Trazabilidad, CatalogoProceso

import re

# Fase 0: material y centro llegan por URL y se insertan en las OPTIONS de
# RFC_READ_TABLE (texto tipo WHERE). Se valida el formato antes de usarlos.
_RE_MATERIAL = re.compile(r"^[A-Za-z0-9._/-]{1,40}$")
_RE_CENTRO = re.compile(r"^[A-Za-z0-9]{4}$")


def validar_material_centro(material: str, centro: str):
    material = (material or "").strip()
    centro = (centro or "").strip()
    if not _RE_MATERIAL.match(material):
        raise ValueError(f"Numero de material invalido: {material!r}")
    if not _RE_CENTRO.match(centro):
        raise ValueError(f"Centro invalido: {centro!r}")
    return material, centro


def normalize_value(v):
    return str(v).strip() if v is not None else ""

def to_float(valor, default=0.0):
    try:
        return float(str(valor).strip().replace(",", ".")) if valor is not None else default
    except Exception: return default

def formatear_fecha_sap(fecha_str):
    fecha_str = normalize_value(fecha_str)
    if not fecha_str or fecha_str in ("", "00000000") or len(fecha_str) != 8: return None
    return datetime.strptime(fecha_str, '%Y%m%d').date()

def obtener_codigo_busqueda(descripcion, clave_modelo):
    desc_upper = normalize_value(descripcion).upper()
    if "WATER SPIDER" in desc_upper: return "WS_KEMM"
    return normalize_value(clave_modelo) or None

def safe_call_rfc_read_table(conn_sap, table_name, fields, options=None, batch_size=500):
    rows_all = []; rowskips = 0; options = options or []
    try:
        while True:
            result = conn_sap.call(
                "RFC_READ_TABLE", 
                QUERY_TABLE=table_name, 
                DELIMITER="|", 
                FIELDS=[{"FIELDNAME": f} for f in fields], 
                OPTIONS=[{"TEXT": opt} for opt in options], 
                ROWCOUNT=batch_size, 
                ROWSKIPS=rowskips
            )
            data = result.get("DATA", [])
            if not data: break
            for row in data:
                values = row.get("WA", "").split("|")
                rows_all.append({field: (values[i].strip() if i < len(values) else "") for i, field in enumerate(fields)})
            if len(data) < batch_size: break
            rowskips += batch_size
        return {"ok": True, "rows": rows_all, "error": None}
    except Exception as e: return {"ok": False, "rows": [], "error": str(e)}

def obtener_materiales_desde_sap(conn_sap, centro="0094", plnty="N"):
    _, centro = validar_material_centro("X", centro)
    if not re.match(r"^[A-Z0-9]{1,2}$", str(plnty)):
        raise ValueError(f"PLNTY invalido: {plnty!r}")
    options = [f"WERKS = '{centro}'", f"AND PLNTY = '{plnty}'"]
    result = safe_call_rfc_read_table(conn_sap, "MAPL", fields=["MATNR"], options=options)
    if not result["ok"]: raise Exception(f"No se pudo leer MAPL: {result['error']}")
    return sorted({normalize_value(r.get("MATNR")).lstrip("0") for r in result["rows"] if normalize_value(r.get("MATNR"))})

# =========================================================
# LÓGICA DE ALTERNATIVAS
# =========================================================
def formatear_alternativa(alt):
    alt = normalize_value(alt)
    if not alt: return "01"
    return alt.zfill(2) if alt.isdigit() else alt

def obtener_mapeo_alternativas(conn_sap, material_sap, centro):
    map_vornr_plnal = {}
    
    res_mapl = safe_call_rfc_read_table(
        conn_sap, "MAPL", ["PLNNR"], 
        [f"MATNR = '{material_sap}'", f"AND WERKS = '{centro}'", "AND PLNTY = 'N'"]
    )
    if not res_mapl["ok"] or not res_mapl["rows"]: return {}
    plnnrs = list(set([r["PLNNR"] for r in res_mapl["rows"] if r["PLNNR"]]))
    if not plnnrs: return {}
    
    for plnnr in plnnrs:
        res_plas = safe_call_rfc_read_table(
            conn_sap, "PLAS", ["PLNAL", "PLNKN"], 
            [f"PLNNR = '{plnnr}'", "AND PLNTY = 'N'", "AND LOEKZ = ''"]
        )
        map_plas = {}
        for r in res_plas.get("rows", []):
            node = r["PLNKN"]
            if node not in map_plas: map_plas[node] = set()
            map_plas[node].add(formatear_alternativa(r["PLNAL"]))
            
        res_plpo = safe_call_rfc_read_table(
            conn_sap, "PLPO", ["PLNKN", "VORNR"], 
            [f"PLNNR = '{plnnr}'", "AND PLNTY = 'N'"]
        )
        for r in res_plpo.get("rows", []):
            vornr = r["VORNR"]
            node = r["PLNKN"]
            if node in map_plas:
                key = (plnnr, vornr)
                if key not in map_vornr_plnal: map_vornr_plnal[key] = set()
                map_vornr_plnal[key].update(map_plas[node])
                
    return {k: list(v) for k, v in map_vornr_plnal.items()}

# =========================================================
# LÓGICA DE IDIOMAS Y DESCRIPCIÓN (INTEGRACIÓN DEL SCRIPT)
# =========================================================
def obtener_descripcion_material(conn_sap, material_sap):
    """
    Consulta las descripciones mediante BAPI_MATERIAL_GET_ALL
    y selecciona primero español, inglés o alemán.
    """
    try:
        resultado_sap = conn_sap.call("BAPI_MATERIAL_GET_ALL", MATERIAL=material_sap)
        
        # Verificar si hay errores críticos en la respuesta
        mensajes = resultado_sap.get("RETURN", [])
        if isinstance(mensajes, dict): mensajes = [mensajes]
        errores = [normalize_value(m.get("MESSAGE")) for m in mensajes if normalize_value(m.get("TYPE")) in ("E", "A")]
        if errores: return ""

        descripciones = []
        for registro in resultado_sap.get("MATERIALDESCRIPTION", []):
            idioma = normalize_value(registro.get("LANGU"))
            idioma_iso = normalize_value(registro.get("LANGU_ISO")).upper()
            descripcion = normalize_value(registro.get("MATL_DESC"))
            if descripcion:
                descripciones.append({"idioma": idioma, "idioma_iso": idioma_iso, "descripcion": descripcion})

        if not descripciones: return ""

        # Prioridad 1: Código interno SAP (S = español, E = inglés, D = alemán)
        for idioma_deseado in ["S", "E", "D"]:
            for r in descripciones:
                if r["idioma"] == idioma_deseado:
                    return r["descripcion"]

        # Prioridad 2: Código ISO
        equivalencias_iso = {"S": "ES", "E": "EN", "D": "DE"}
        for idioma_deseado in ["S", "E", "D"]:
            idioma_iso = equivalencias_iso.get(idioma_deseado)
            for r in descripciones:
                if r["idioma_iso"] == idioma_iso:
                    return r["descripcion"]

        # Si no coincide ninguno, devuelve el primero disponible
        return descripciones[0]["descripcion"]
    except Exception:
        return ""

def determinar_proceso_operacion(clave_modelo, descripcion, reglas_catalogo, centro):
    clave_modelo_upper = normalize_value(clave_modelo).upper()
    desc_upper = normalize_value(descripcion).upper()
    
    if clave_modelo_upper:
        for regla in reglas_catalogo:
            if regla.codigo.upper() == clave_modelo_upper and regla.centro == centro:
                return regla.seccion
                
    if desc_upper:
        for regla in reglas_catalogo:
            if regla.seccion.upper() in desc_upper and regla.centro == centro:
                return regla.seccion

    return "SIN CLASIFICAR"

# =========================================================
# EXTRACCIÓN PRINCIPAL
# =========================================================
def procesar_pieza_logic(conn_sap, db: Session, material: str, centro="0094"):
    material, centro = validar_material_centro(material, centro)
    material_sap = material.zfill(18) 
    fecha_consulta = datetime.now().strftime('%Y%m%d') 
    historial_unico = {}      
    nombre_pieza = f"Material {material}"  # Respaldo si SAP no trae descripción
    
    # 🔴 EXTRAER DESCRIPCIÓN CON LA NUEVA LÓGICA
    try:
        desc_sap = obtener_descripcion_material(conn_sap, material_sap)
        if desc_sap:
            nombre_pieza = desc_sap
    except Exception as e:
        error_msg = str(e)
        if "RFC_COMMUNICATION_FAILURE" in error_msg or "WSAECONNRESET" in error_msg:
            raise Exception(f"Conexión con SAP perdida al obtener detalle de {material}.")
    
    mapa_alternativas = obtener_mapeo_alternativas(conn_sap, material_sap, centro)
    
    saltos = 0

    while fecha_consulta:
        try:
            resultado = conn_sap.call('Y_ROUTING_READ_001', I_MATNR=material_sap, I_WERKS=centro, I_DATUV=fecha_consulta)
            operaciones_crudas = resultado.get('T_PLPO', [])
            if not operaciones_crudas: break                
            
            rutas = {}
            for op in operaciones_crudas:
                r_plnnr = normalize_value(op.get("PLNNR"))
                vornr = normalize_value(op.get("VORNR"))
                
                alternativas_reales = mapa_alternativas.get((r_plnnr, vornr), [])
                
                if not alternativas_reales:
                    alternativas_reales = ["01"]
                
                for alt in alternativas_reales:
                    clave_ruta = (r_plnnr, alt)
                    if clave_ruta not in rutas:
                        rutas[clave_ruta] = []
                    
                    op_clon = op.copy()
                    op_clon["PLNAL_INYECTADO"] = alt
                    rutas[clave_ruta].append(op_clon)
                
            fecha_mas_reciente = "00000000"              
            
            for clave_ruta, operaciones in rutas.items():
                cantidad_entradas = len(operaciones)
                
                for op in operaciones:
                    op_num = normalize_value(op.get('VORNR'))
                    valido_desde = normalize_value(op.get('DATUV'))  
                    if not op_num or not valido_desde or valido_desde == "00000000": continue
                    
                    plnnr = clave_ruta[0]
                    plnal = op.get("PLNAL_INYECTADO")
                    aennr = normalize_value(op.get("AENNR"))
                    llave_unica = f"{op_num}|{valido_desde}|{plnnr}|{plnal}|{aennr}"
                    
                    if llave_unica not in historial_unico:
                        historial_unico[llave_unica] = {
                            "operacion_num": op_num, "descripcion": normalize_value(op.get('LTXA1')),
                            "cantidad_base": to_float(op.get('BMSCH', 0.0)), "tiempo": to_float(op.get('VGW01', 0.0)),
                            "tiempo_preparacion": to_float(op.get('VGW02', 0.0)), "tiempo_mano_obra": to_float(op.get('VGW03', 0.0)),
                            "unidad_t": normalize_value(op.get('VGE01')), "vgwts": normalize_value(op.get('VGWTS')),
                            # Fase 0: las columnas existian en el modelo pero nunca se llenaban.
                            "unidad_preparacion": normalize_value(op.get('VGE02')) or None,
                            "unidad_mano_obra": normalize_value(op.get('VGE03')) or None,
                            "fecha_inicio": valido_desde, "creado_sap": normalize_value(op.get('ANDAT')), 
                            "modificado_sap": normalize_value(op.get('AEDAT')), "equipos": cantidad_entradas, 
                            "clave_modelo": normalize_value(op.get('KTSCH')), "steus": normalize_value(op.get("STEUS")),
                            "plnnr": plnnr, "plnal": plnal, "aennr": aennr, "fecha_fin": None 
                        }                
                    if valido_desde > fecha_mas_reciente and valido_desde <= fecha_consulta:
                        fecha_mas_reciente = valido_desde                
            
            if fecha_mas_reciente == "00000000": break
            
            fecha_obj = datetime.strptime(fecha_mas_reciente, '%Y%m%d')
            fecha_siguiente_salto = (fecha_obj - timedelta(days=1)).strftime('%Y%m%d')
            if fecha_siguiente_salto >= fecha_consulta: break            
            fecha_consulta = fecha_siguiente_salto
            saltos += 1
            if saltos >= 1000: break
        except Exception as e: 
            raise Exception(f"Error extrayendo de SAP: {e}")
            
    if not historial_unico:
        return {"status": "warning", "mensaje": f"Sin datos en SAP para el material {material}."}
        
    operaciones_agrupadas = {}
    for op in historial_unico.values():
        key = (op["operacion_num"], normalize_value(op.get("plnnr")), normalize_value(op.get("plnal")))
        if key not in operaciones_agrupadas: operaciones_agrupadas[key] = []
        operaciones_agrupadas[key].append(op)
        
    datos_finales = []
    for _, lista_ops in operaciones_agrupadas.items():
        lista_ops.sort(key=lambda x: (normalize_value(x["fecha_inicio"]), normalize_value(x.get("aennr"))))
        for i in range(len(lista_ops)):
            if i < len(lista_ops) - 1:
                sig_fecha = datetime.strptime(lista_ops[i+1]['fecha_inicio'], '%Y%m%d')
                lista_ops[i]['fecha_fin'] = (sig_fecha - timedelta(days=1)).strftime('%Y%m%d')
            else:
                lista_ops[i]['fecha_fin'] = '99991231' 
            datos_finales.append(lista_ops[i])
            
    try:
        pieza = db.query(Pieza).filter(Pieza.numero_material == material, Pieza.centro == centro).first()
        if not pieza:
            # 🔴 ASIGNAR LA DESCRIPCIÓN COMO SI FUERA EL PROYECTO (PLATAFORMA)
            pieza = Pieza(nombre_pieza=nombre_pieza, numero_material=material, proyecto=nombre_pieza, centro=centro)
            db.add(pieza)
            db.flush() 
        else:
            # 🔴 REEMPLAZAR LA PLATAFORMA POR LA DESCRIPCIÓN DEL MATERIAL
            pieza.proyecto = nombre_pieza
            pieza.nombre_pieza = nombre_pieza
            
        db.query(Trazabilidad).filter(Trazabilidad.pieza_id == pieza.id).delete()
        
        reglas_procesos = db.query(CatalogoProceso).filter(
            CatalogoProceso.activo == True,
            CatalogoProceso.centro == centro
        ).all()
        
        alts_presentes = set()
        for d in datos_finales:
            val = normalize_value(d.get('plnal'))
            if val:
                alts_presentes.add(formatear_alternativa(val))
                
        alts_ordenadas = sorted(list(alts_presentes), key=lambda x: int(x) if x.isdigit() else 999)
        alternativa_principal = alts_ordenadas[0] if alts_ordenadas else "01"
        
        registros_nuevos = 0
        for d in datos_finales:
            proceso_base = determinar_proceso_operacion(d['clave_modelo'], d['descripcion'], reglas_procesos, centro)
            alt_formateada = formatear_alternativa(d.get('plnal'))
            
            if alt_formateada == alternativa_principal:
                proceso_asignado = proceso_base
            else:
                proceso_asignado = f"{proceso_base} (Alt {alt_formateada})"
            
            nueva_trazabilidad = Trazabilidad(
                pieza_id=pieza.id,
                operacion_num=d['operacion_num'],
                proceso=proceso_asignado,
                descripcion=d['descripcion'],
                clave_modelo=d['clave_modelo'],
                codigo_busqueda=obtener_codigo_busqueda(d['descripcion'], d['clave_modelo']),
                steus=d['steus'],
                plnnr=d['plnnr'],
                plnal=d['plnal'],
                aennr=d['aennr'],
                equipos=d['equipos'],
                cantidad_base=d['cantidad_base'],
                tiempo=d['tiempo'],
                tiempo_preparacion=d.get('tiempo_preparacion'),
                tiempo_mano_obra=d.get('tiempo_mano_obra'),
                unidad_t=d['unidad_t'],
                unidad_preparacion=d.get('unidad_preparacion'),
                unidad_mano_obra=d.get('unidad_mano_obra'),
                vgwts=d.get('vgwts'),
                fecha_inicio=formatear_fecha_sap(d['fecha_inicio']),
                fecha_fin=formatear_fecha_sap(d['fecha_fin']),
                creado_sap=formatear_fecha_sap(d.get('creado_sap')),
                modificado_sap=formatear_fecha_sap(d.get('modificado_sap'))
            )
            db.add(nueva_trazabilidad)
            registros_nuevos += 1
            
        db.commit()
        return {"status": "success", "material": material, "nombre": nombre_pieza, "registros_procesados": registros_nuevos}
    except Exception as e:
        db.rollback()
        raise Exception(f"Error en BD: {e}")