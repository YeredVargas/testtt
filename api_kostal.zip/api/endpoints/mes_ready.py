# api/endpoints/mes_ready.py
from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from core.config import CENTRO_DEFAULT
from db.database import get_db
from services.mes_ready_service import limpiar_lista, evaluar_mes_ready

router = APIRouter(prefix="/mes-ready", tags=["MES Ready"])

MAX_MATERIALES_POR_CONSULTA = 10000


class ConsultaMesReady(BaseModel):
    centro: str = Field(CENTRO_DEFAULT, min_length=1, max_length=4, examples=["0094"])
    materiales: List[str] = Field(..., min_length=1, examples=[["12171980", "12171981"]])


@router.post("/evaluar")
def evaluar(body: ConsultaMesReady, db: Session = Depends(get_db)):
    """
    Indica cuáles materiales son MES Ready y cuáles no, a partir de la hoja de ruta
    guardada en BD (no consulta SAP; sincroniza antes los materiales que falten).

    - **MES_READY**: al menos una operación vigente con tiempo de preparación (VGW02)
      o de mano de obra (VGW03) mayor a cero.
    - **LEGACY**: solo tiempo total (VGW01) en todas sus operaciones vigentes.
    - **SIN_DATOS**: no está en BD para ese centro o no tiene operaciones vigentes.

    `pct_mes_ready` se calcula sobre los materiales con datos (MES_READY + LEGACY).
    """
    materiales = limpiar_lista(body.materiales)
    if not materiales:
        raise HTTPException(status_code=422, detail="La lista de materiales está vacía.")
    if len(materiales) > MAX_MATERIALES_POR_CONSULTA:
        raise HTTPException(
            status_code=422,
            detail=f"Máximo {MAX_MATERIALES_POR_CONSULTA} materiales por consulta (recibidos: {len(materiales)}).",
        )

    centro = body.centro.strip()
    resultado = evaluar_mes_ready(db, centro, materiales)

    return {
        "centro": centro,
        "fecha_consulta": datetime.now().isoformat(timespec="seconds"),
        "total_materiales_recibidos": len(body.materiales),
        **resultado,
    }
