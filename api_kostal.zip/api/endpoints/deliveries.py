# api/endpoints/deliveries.py
from datetime import datetime
from typing import List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from sap.rfc_client import get_sap_connection
from services.delivery_service import limpiar_lista, consultar_varios_deliveries

router = APIRouter(prefix="/deliveries", tags=["Deliveries SAP"])

MAX_DELIVERIES_POR_CONSULTA = 200


class ConsultaDeliveries(BaseModel):
    deliveries: List[str] = Field(
        ...,
        min_length=1,
        description="Números de delivery: interno SAP (VBELN), externo (LIFEX) o referencia (VERUR).",
        examples=[["21464700", "21467087"]],
    )


@router.post("/consultar")
def consultar_deliveries(body: ConsultaDeliveries):
    """
    Consulta deliveries en SAP (LIKP + LIPS). Solo lectura, no escribe en BD.

    Regresa una fila por posición. Los deliveries que no existen, no tienen
    posiciones o fallaron también regresan una fila, con `estatus`
    NO_ENCONTRADO / SIN_POSICIONES / ERROR y el detalle en `mensaje`.
    """
    deliveries = limpiar_lista(body.deliveries)
    if not deliveries:
        raise HTTPException(status_code=422, detail="La lista de deliveries está vacía.")
    if len(deliveries) > MAX_DELIVERIES_POR_CONSULTA:
        raise HTTPException(
            status_code=422,
            detail=f"Máximo {MAX_DELIVERIES_POR_CONSULTA} deliveries por consulta (recibidos: {len(deliveries)}).",
        )

    conn = None
    try:
        conn = get_sap_connection()
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"No fue posible conectar a SAP: {e}")

    try:
        resultados = consultar_varios_deliveries(conn, deliveries)
    finally:
        conn.close()

    return {
        "fecha_consulta": datetime.now().isoformat(timespec="seconds"),
        "total_deliveries_recibidos": len(body.deliveries),
        "total_deliveries_consultados": len(deliveries),
        "total_filas": len(resultados),
        "resultados": resultados,
    }
