# api/endpoints/claves_modelo.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db.database import get_db
from db.models import CatalogoClaveModelo
from sap.rfc_client import get_sap_connection
from services.claves_modelo_service import sincronizar_claves_modelo

router = APIRouter(prefix="/claves-modelo", tags=["Claves de modelo (T435T)"])


@router.post("/sincronizar")
def sincronizar(db: Session = Depends(get_db)):
    """
    Lee T435T (texto de cada clave de modelo) y lo guarda en `catalogo_clave_modelo`.
    OpTimeSAP usa el texto para cruzar la operacion SAP con la operacion MES.
    """
    conn_sap = None
    try:
        conn_sap = get_sap_connection()
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Sin conexion a SAP: {e}")
    try:
        return sincronizar_claves_modelo(conn_sap, db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        try:
            conn_sap.close()
        except Exception:
            pass


@router.get("")
def listar(db: Session = Depends(get_db)):
    """Catalogo guardado en BD (no consulta SAP)."""
    filas = db.query(CatalogoClaveModelo).order_by(CatalogoClaveModelo.clave_modelo).all()
    return [
        {
            "clave_modelo": f.clave_modelo, "texto": f.texto, "idioma": f.idioma,
            "operacion_mes": f.operacion_mes, "activo": f.activo,
            "modificado_en": f.modificado_en.isoformat() if f.modificado_en else None,
        }
        for f in filas
    ]
