# api/endpoints/jobs.py
from fastapi import APIRouter, HTTPException
from services.jobs_service import obtener_job

# La ruta coincide con la que ya consulta el frontend:
# CostosService.getSyncStatus -> GET /api/v1/sincronizar-bg/status/{jobId}
router = APIRouter(prefix="/sincronizar-bg", tags=["Tareas en segundo plano"])


@router.get("/status/{job_id}")
def estado_job(job_id: str):
    """status: running | completed | failed"""
    job = obtener_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Tarea no encontrada (¿se reinició la API?).")
    return job
