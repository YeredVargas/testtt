# api/endpoints/tiempo_operacion.py
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session

from core.config import CENTRO_DEFAULT
from db.database import get_db
from services.tiempo_operacion_service import procesar_pieza_logic, obtener_materiales_desde_sap
from sap.rfc_client import get_sap_connection

router = APIRouter(prefix="/tiempo_operacion", tags=["Tiempos de Operación"])


@router.post("/sincronizar/todo_dinamico")
def sincronizar_todo_dinamico(centro: str = Query(CENTRO_DEFAULT), db: Session = Depends(get_db)):
    """Lee los materiales del centro desde SAP (MAPL) y descarga sus hojas de ruta."""
    conn_sap = None
    resultados = []
    try:
        conn_sap = get_sap_connection()
        materiales = obtener_materiales_desde_sap(conn_sap, centro=centro)

        if not materiales:
            return {"status": "info", "mensaje": f"SAP no devolvió materiales en la tabla MAPL para el centro {centro}."}

        total_procesados = 0
        for material in materiales:
            material = material.strip()
            try:
                resultados.append(procesar_pieza_logic(conn_sap, db, material, centro=centro))
                total_procesados += 1
            except Exception as item_error:
                db.rollback()
                resultados.append({"status": "error", "material": material, "error": str(item_error)})

        return {"status": "completado_dinamico", "total_materiales": total_procesados, "detalles": resultados}
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn_sap:
            conn_sap.close()


@router.post("/nuevo_material/{material}")
def agregar_nuevo_material(material: str, centro: str = Query(CENTRO_DEFAULT), db: Session = Depends(get_db)):
    """
    Da de alta un material y descarga sus hojas de ruta (trazabilidad).
    Los costos se descargan aparte con POST /costos/sincronizar-material/{material}.
    """
    material = material.strip()
    conn_sap = None
    try:
        conn_sap = get_sap_connection()
        res_tiempos = procesar_pieza_logic(conn_sap, db, material, centro=centro)
        return {"status": "success", "material": material, "centro": centro, "tiempos": res_tiempos}
    except ValueError as e:
        # Fase 0: material/centro con formato invalido -> 422
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        db.rollback()
        print(f"ERROR FATAL IMPORTANDO MATERIAL: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn_sap:
            conn_sap.close()
