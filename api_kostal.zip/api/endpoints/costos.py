# api/endpoints/costos.py
"""
Escritura de costos CK13N desde SAP hacia PostgreSQL.

La LECTURA de costos la hace el backend principal (OpTimeSAP, /api/costos).
Los GET que vivian aqui eran duplicados y nadie los usaba; se quitaron.
"""
from datetime import datetime

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from core.config import CENTRO_DEFAULT
from db.database import get_db, SessionLocal
from db.models import Pieza
from services.costos_service import guardar_costos_material
from services import jobs_service

router = APIRouter(tags=["Costos SAP CK13N"])


def _sincronizar_todos_worker(job_id: str, centro: str, materiales: list):
    """Corre en segundo plano con su propia sesion de BD."""
    db: Session = SessionLocal()
    try:
        for material in materiales:
            material = material.strip()
            try:
                res = guardar_costos_material(db, material, centro)
                if "error" in res:
                    jobs_service.agregar_resultado(job_id, error={"material": material, "error": res["error"]})
                else:
                    for variante in res["variantes"]:
                        jobs_service.agregar_resultado(job_id, exito=f"{material} ({variante})")
            except Exception as e:
                db.rollback()
                jobs_service.agregar_resultado(job_id, error={"material": material, "error": f"Error BD: {str(e)}"})
            finally:
                jobs_service.marcar_material_procesado(job_id)

        jobs_service.actualizar_job(job_id, status="completed", fin=datetime.now())
    except Exception as e:
        jobs_service.actualizar_job(job_id, status="failed", error=str(e), fin=datetime.now())
    finally:
        db.close()


@router.post("/sincronizar-todos")
def sincronizar_todos_los_costos(background: BackgroundTasks,
                                 centro: str = Query(CENTRO_DEFAULT),
                                 db: Session = Depends(get_db)):
    """
    Lanza la descarga de costos de TODAS las piezas del centro en segundo plano
    y responde de inmediato con un job_id.
    Seguimiento: GET /api/v1/sincronizar-bg/status/{job_id}
    """
    piezas = db.query(Pieza.numero_material).filter(Pieza.centro == centro).all()
    if not piezas:
        raise HTTPException(status_code=404, detail=f"No hay piezas en la BD para {centro}.")
    materiales = [m for (m,) in piezas]

    job_id, es_nuevo = jobs_service.crear_job("COSTOS_TODOS", clave=f"COSTOS_TODOS|{centro}")
    if es_nuevo:
        jobs_service.actualizar_job(job_id, total=len(materiales))
        background.add_task(_sincronizar_todos_worker, job_id, centro, materiales)

    return {
        "job_id": job_id,
        "status": "running",
        "ya_estaba_corriendo": not es_nuevo,
        "total_materiales": len(materiales),
        "seguimiento": f"/api/v1/sincronizar-bg/status/{job_id}",
    }


@router.post("/sincronizar-material/{material}")
def sincronizar_costos_un_material(material: str, centro: str = Query(CENTRO_DEFAULT),
                                   db: Session = Depends(get_db)):
    """Descarga y guarda los costos de un solo material (sincrono)."""
    material = material.strip()
    try:
        if not db.query(Pieza).filter_by(numero_material=material, centro=centro).first():
            db.add(Pieza(numero_material=material, centro=centro))
            db.commit()

        res = guardar_costos_material(db, material, centro)
        if "error" in res:
            return {"exitosos": [], "errores": [{"material": material, "error": res["error"]}]}

        return {"exitosos": [f"Variante {v} guardada con éxito." for v in res["variantes"]], "errores": []}
    except Exception as e:
        db.rollback()
        return {"exitosos": [], "errores": [{"material": material, "error": f"Error BD: {str(e)}"}]}
