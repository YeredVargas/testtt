from fastapi import APIRouter
from api.endpoints import tiempo_operacion, costos, jobs, deliveries, mes_ready, claves_modelo

api_router = APIRouter()

api_router.include_router(tiempo_operacion.router)
# Un solo tag: antes el router traia "Costos SAP CK13N" y aqui se le agregaba
# "Costos Financieros", por eso Swagger mostraba el mismo grupo dos veces.
api_router.include_router(costos.router, prefix="/costos")
api_router.include_router(jobs.router)
api_router.include_router(deliveries.router)
api_router.include_router(mes_ready.router)
api_router.include_router(claves_modelo.router)
