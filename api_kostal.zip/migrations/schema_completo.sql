-- =====================================================================
--  SAP_OpTime_VizReport - ESQUEMA COMPLETO
--  Version 7.0
--
--  INSTALACION DESDE CERO. Crea tablas, funciones, triggers, indices,
--  catalogos semilla y vistas.
--
--  >>> ESTE SCRIPT ES LA UNICA FUENTE DE VERDAD DEL ESQUEMA. <<<
--  Ni la API de extraccion ni proyecto_backend deben volver a ejecutar
--  Base.metadata.create_all() ni drop_all(). Todo cambio de estructura
--  se hace aqui o en un archivo de migracion numerado.
--
--  USO:
--    createdb -h <host> -U <admin> SAP_OpTime_VizReport
--    psql -h <host> -U <admin> -d SAP_OpTime_VizReport -f schema_completo.sql
--
--  Si YA tienes datos en produccion, NO uses este archivo:
--  usa migrations/001_tiempos_y_clasificacion.sql, que es incremental.
-- =====================================================================

SET client_min_messages = WARNING;

BEGIN;

-- =====================================================================
-- 1. TABLAS
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1.1 catalogo_material_proyecto
--     Mapa material -> proyecto/familia (MACH-E, RIVIAN, ...).
--     Lo llena la busqueda automatica de familia, pero las filas con
--     origen='MANUAL' nunca se sobreescriben: una correccion humana
--     siempre gana sobre lo que deduzca SAP.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS catalogo_material_proyecto (
    numero_material          VARCHAR(50)  PRIMARY KEY,
    proyecto                 VARCHAR(50)  NOT NULL,
    activo                   BOOLEAN      NOT NULL DEFAULT TRUE,

    -- Metadatos de la clasificacion automatica
    origen                   VARCHAR(20)  NOT NULL DEFAULT 'MANUAL',
    familia                  VARCHAR(50),
    variantes                VARCHAR(100),
    fuente_clasificacion     VARCHAR(50),
    material_heredado_desde  VARCHAR(50),
    regla_detectada          TEXT,
    texto_match              TEXT,
    tuvo_errores_tecnicos    BOOLEAN      DEFAULT FALSE,
    detalle_errores_tecnicos TEXT,
    clasificado_en           TIMESTAMP,

    creado_en                TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    modificado_en            TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT ck_cmp_origen CHECK (origen IN ('MANUAL', 'AUTOMATICO'))
);

COMMENT ON TABLE  catalogo_material_proyecto IS 'Mapa material -> proyecto. Alimentado por /api/v1/clasificacion/ejecutar.';
COMMENT ON COLUMN catalogo_material_proyecto.origen IS 'MANUAL = puesto por una persona, intocable. AUTOMATICO = deducido de SAP, recalculable.';
COMMENT ON COLUMN catalogo_material_proyecto.fuente_clasificacion IS 'En que paso de la cascada se detecto: descripcion_propia | datos_maestros_adicionales | heredada_material_hijo | hoja_ruta | bom_directa | bom_inversa | sin_senal';
COMMENT ON COLUMN catalogo_material_proyecto.tuvo_errores_tecnicos IS 'TRUE = la busqueda fallo por un error de SAP (autorizacion, red). Distinto de "el material no tiene familia".';

CREATE INDEX IF NOT EXISTS ix_cmp_proyecto ON catalogo_material_proyecto (proyecto);
CREATE INDEX IF NOT EXISTS ix_cmp_origen   ON catalogo_material_proyecto (origen);


-- ---------------------------------------------------------------------
-- 1.2 piezas
--     Un renglon por material. numero_material se guarda SIN ceros a la
--     izquierda (12171980, no 000000000012171980).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS piezas (
    id               SERIAL       PRIMARY KEY,
    nombre_pieza     VARCHAR(255),
    numero_material  VARCHAR(50)  NOT NULL UNIQUE,
    proyecto         VARCHAR(50)  NOT NULL DEFAULT 'SIN PROYECTO',
    creado_en        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    modificado_en    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON COLUMN piezas.numero_material IS 'Formato externo, sin ceros a la izquierda. SAP lo maneja con zfill(18).';

CREATE INDEX IF NOT EXISTS ix_piezas_proyecto ON piezas (proyecto);


-- ---------------------------------------------------------------------
-- 1.3 catalogo_procesos
--     Codigo de operacion -> seccion productiva (SMT, CONFORMAL, ...).
--     bloqueado=TRUE protege las secciones corregidas a mano.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS catalogo_procesos (
    codigo         VARCHAR(50)  PRIMARY KEY,
    seccion        VARCHAR(50)  NOT NULL,
    activo         BOOLEAN      NOT NULL DEFAULT TRUE,
    bloqueado      BOOLEAN      NOT NULL DEFAULT FALSE,
    creado_en      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    modificado_en  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON COLUMN catalogo_procesos.bloqueado IS 'TRUE = seccion fijada a mano. El reseed del arranque no la toca.';


-- ---------------------------------------------------------------------
-- 1.4 trazabilidad
--     Historico de operaciones de hoja de ruta (SCD tipo 2 por fechas).
--
--     MAPEO DE TIEMPOS - transaccion CA03, "Hoja de ruta especifica
--     visual: resumen operacion". Las columnas del ALV salen en el orden
--     de los parametros de la clave de valor prefijado (VGWTS):
--
--       Columna en CA03        Campo PLPO   Unidad   Clase actividad
--       ---------------------  -----------  -------  ---------------
--       Tiempo de Operacion    VGW01        VGE01    LAR01
--       Tiempo Preparacion     VGW02        VGE02    LAR02
--       Tiempo Mano de obra    VGW03        VGE03    LAR03
--
--     Hasta la v6.3, tiempo_mano_obra guardaba VGW02 (preparacion) y
--     VGW03 no se extraia nunca.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS trazabilidad (
    id                  SERIAL        PRIMARY KEY,
    pieza_id            INTEGER       NOT NULL REFERENCES piezas(id) ON DELETE CASCADE,

    -- Identificacion de la operacion
    operacion_num       VARCHAR(20)   NOT NULL,        -- VORNR
    descripcion         VARCHAR(255),                  -- LTXA1
    clave_modelo        VARCHAR(50),                   -- KTSCH
    codigo_busqueda     VARCHAR(50),                   -- KTSCH normalizado
    proceso             VARCHAR(50)   NOT NULL DEFAULT 'SMT',
    steus               VARCHAR(20),                   -- STEUS (clave de control)

    -- Identificacion de la hoja de ruta
    plnnr               VARCHAR(40),                   -- Grupo de hojas de ruta
    plnal               VARCHAR(10),                   -- Contador de hoja alternativa
    aennr               VARCHAR(40)   NOT NULL DEFAULT '',  -- Numero de modificacion

    -- Cantidades
    equipos             INTEGER,
    cantidad_base       NUMERIC(12,2),                 -- BMSCH

    -- Tiempos
    tiempo              NUMERIC(12,4),                 -- VGW01
    tiempo_preparacion  NUMERIC(12,4),                 -- VGW02
    tiempo_mano_obra    NUMERIC(12,4),                 -- VGW03

    -- Unidades
    unidad_t            VARCHAR(10),                   -- VGE01
    unidad_preparacion  VARCHAR(10),                   -- VGE02
    unidad_mano_obra    VARCHAR(10),                   -- VGE03

    -- Clave de valor prefijado: define QUE significa cada VGWnn
    vgwts               VARCHAR(10),

    -- Ventana de vigencia
    fecha_inicio        DATE,                          -- DATUV
    fecha_fin           DATE,                          -- calculada: siguiente inicio - 1 dia
    creado_sap          DATE,                          -- ANDAT
    modificado_sap      DATE,                          -- AEDAT

    creado_en           TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    modificado_en       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,

    -- Clave natural. Incluye plnnr/plnal: sin ellos, dos hojas de ruta
    -- alternativas del mismo material con la misma operacion+fecha+aennr
    -- chocaban y tumbaban la pieza completa con IntegrityError.
    CONSTRAINT uq_trazabilidad_hist
        UNIQUE (pieza_id, operacion_num, fecha_inicio, aennr, plnnr, plnal)
);

COMMENT ON COLUMN trazabilidad.tiempo             IS 'VGW01 - Tiempo de Operacion (CA03)';
COMMENT ON COLUMN trazabilidad.tiempo_preparacion IS 'VGW02 - Tiempo Preparacion (CA03)';
COMMENT ON COLUMN trazabilidad.tiempo_mano_obra   IS 'VGW03 - Tiempo Mano de obra (CA03)';
COMMENT ON COLUMN trazabilidad.vgwts              IS 'Clave de valor prefijado. Si varia entre centros, el orden de VGWnn puede cambiar: verificar con SELECT DISTINCT vgwts.';
COMMENT ON COLUMN trazabilidad.fecha_fin          IS '99991231 marca el registro vigente.';
COMMENT ON COLUMN trazabilidad.equipos            IS 'ATENCION: hoy se llena con el numero de operaciones que devolvio el RFC, no con el numero real de equipos. Es el divisor del KPI pzs_hr. Pendiente de validar con negocio.';

CREATE INDEX IF NOT EXISTS ix_trazabilidad_pieza_proceso ON trazabilidad (pieza_id, proceso);
CREATE INDEX IF NOT EXISTS ix_trazabilidad_fecha_inicio  ON trazabilidad (fecha_inicio DESC);
CREATE INDEX IF NOT EXISTS ix_trazabilidad_proceso       ON trazabilidad (proceso);


-- ---------------------------------------------------------------------
-- 1.5 sync_log
--     Bitacora de corridas. Sin esto no hay forma de saber si el job
--     nocturno se ejecuto, cuanto tardo, ni que fallo.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sync_log (
    id           SERIAL       PRIMARY KEY,
    tipo         VARCHAR(30)  NOT NULL,
    estado       VARCHAR(20)  NOT NULL,
    inicio       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    fin          TIMESTAMP,
    total_items  INTEGER      DEFAULT 0,
    items_ok     INTEGER      DEFAULT 0,
    items_error  INTEGER      DEFAULT 0,
    detalle      TEXT,

    CONSTRAINT ck_sync_tipo   CHECK (tipo   IN ('SINCRONIZACION', 'CLASIFICACION')),
    CONSTRAINT ck_sync_estado CHECK (estado IN ('EN_CURSO', 'OK', 'ERROR'))
);

CREATE INDEX IF NOT EXISTS ix_sync_log_tipo_inicio ON sync_log (tipo, inicio DESC);


-- =====================================================================
-- 2. FUNCIONES Y TRIGGERS
-- =====================================================================

-- ---------------------------------------------------------------------
-- 2.1 Sello automatico de modificado_en
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_set_modificado_en()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.modificado_en := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_catalogo_material_proyecto_modificado ON catalogo_material_proyecto;
CREATE TRIGGER trg_catalogo_material_proyecto_modificado
    BEFORE UPDATE ON catalogo_material_proyecto
    FOR EACH ROW EXECUTE FUNCTION fn_set_modificado_en();

DROP TRIGGER IF EXISTS trg_piezas_modificado ON piezas;
CREATE TRIGGER trg_piezas_modificado
    BEFORE UPDATE ON piezas
    FOR EACH ROW EXECUTE FUNCTION fn_set_modificado_en();

DROP TRIGGER IF EXISTS trg_catalogo_procesos_modificado ON catalogo_procesos;
CREATE TRIGGER trg_catalogo_procesos_modificado
    BEFORE UPDATE ON catalogo_procesos
    FOR EACH ROW EXECUTE FUNCTION fn_set_modificado_en();

DROP TRIGGER IF EXISTS trg_trazabilidad_modificado ON trazabilidad;
CREATE TRIGGER trg_trazabilidad_modificado
    BEFORE UPDATE ON trazabilidad
    FOR EACH ROW EXECUTE FUNCTION fn_set_modificado_en();


-- ---------------------------------------------------------------------
-- 2.2 Asignacion automatica de proyecto a las piezas
--     Si la pieza llega sin proyecto util, lo toma del catalogo.
--     Es el puente entre la busqueda automatica de familia y el dashboard:
--     en cuanto el clasificador escribe en catalogo_material_proyecto,
--     la siguiente sincronizacion propaga el proyecto sola.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_piezas_asignar_proyecto()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
    v_proyecto VARCHAR(50);
BEGIN
    IF NEW.proyecto IS NULL
       OR BTRIM(NEW.proyecto) = ''
       OR UPPER(BTRIM(NEW.proyecto)) IN ('TODOS', 'SIN PROYECTO') THEN

        SELECT cmp.proyecto INTO v_proyecto
          FROM catalogo_material_proyecto cmp
         WHERE cmp.numero_material = NEW.numero_material
           AND cmp.activo = TRUE
         LIMIT 1;

        NEW.proyecto := COALESCE(v_proyecto, 'SIN PROYECTO');
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_piezas_asignar_proyecto ON piezas;
CREATE TRIGGER trg_piezas_asignar_proyecto
    BEFORE INSERT OR UPDATE ON piezas
    FOR EACH ROW EXECUTE FUNCTION fn_piezas_asignar_proyecto();


-- ---------------------------------------------------------------------
-- 2.3 Resolucion de la seccion productiva a partir del codigo
--     Reglas de respaldo cuando el codigo no esta en catalogo_procesos.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_resolver_proceso(p_codigo TEXT, p_descripcion TEXT)
RETURNS VARCHAR(50) LANGUAGE plpgsql AS $$
DECLARE
    v_codigo TEXT := UPPER(COALESCE(BTRIM(p_codigo), ''));
    v_desc   TEXT := UPPER(COALESCE(BTRIM(p_descripcion), ''));
BEGIN
    -- La descripcion manda sobre el codigo
    IF v_desc LIKE '%WATER SPIDER%' THEN RETURN 'WATER SPIDER'; END IF;
    IF v_desc LIKE '%INLINE%' OR v_desc LIKE '%IN LINE%' THEN RETURN 'SMT'; END IF;

    RETURN CASE
        WHEN v_codigo = 'WS_KEMM' THEN 'WATER SPIDER'
        WHEN v_codigo IN ('RPBCCO','RPBCOC','RPBCOA','RPBCOO','RCOAT') THEN 'CONFORMAL'
        WHEN v_codigo IN ('RPBPIN','RPING','RPING1') THEN 'PINNING'
        WHEN v_codigo LIKE 'RPBLMMY%' THEN 'LASER'
        WHEN v_codigo LIKE 'RPBSKT%'  THEN 'SOCKET'
        WHEN v_codigo IN ('RPBMASY','RMASSY','RMASSY2','RPBWAV','RWAVE','RPBAOI','RPBOIA') THEN 'ENSAMBLE MANUAL'
        WHEN v_codigo IN ('RPBMIL','RMILL') THEN 'ROUTER OFFLINE'
        WHEN v_codigo IN ('RGLUE','RPBGLU') THEN 'SILICON'
        WHEN v_codigo LIKE 'RPBAXI%' THEN 'AXI'
        WHEN v_codigo IN ('RPBICT','RICT') THEN 'ICT OFFLINE'
        WHEN v_codigo LIKE 'RPB%'   OR v_codigo LIKE 'RSPP%'  OR v_codigo LIKE 'RSPI%'
          OR v_codigo LIKE 'RSMT%'  OR v_codigo LIKE 'ROVEN%' OR v_codigo LIKE 'RAOI%'
          OR v_codigo LIKE 'ROIA%'  OR v_codigo LIKE 'RFLASH%' OR v_codigo LIKE 'RLASER%'
          OR v_codigo LIKE 'ROF%'   OR v_codigo LIKE 'RRIF%'  OR v_codigo LIKE 'RMEF%'
          OR v_codigo LIKE 'RFAS%'  THEN 'SMT'
        WHEN v_codigo LIKE 'ROWED%'  OR v_codigo LIKE 'RRIWED%' OR v_codigo LIKE 'ROWEMI%'
          OR v_codigo LIKE 'RRIWEMI%' OR v_codigo LIKE 'ROE%'   OR v_codigo LIKE 'RRIE%'
          OR v_codigo IN ('RESEAL','REEOL','REVIS','REDRA','ROEPCK') THEN 'ENSAMBLE MANUAL'
        WHEN v_codigo IN ('RCLEAN','RFLIP') THEN 'ENSAMBLE MANUAL'
        ELSE 'SMT'
    END;
END;
$$;

COMMENT ON FUNCTION fn_resolver_proceso IS 'El ELSE devuelve SMT: es un cajon de sastre. Vigilar cuantas filas caen ahi con: SELECT proceso, COUNT(*) FROM trazabilidad GROUP BY 1.';


-- ---------------------------------------------------------------------
-- 2.4 Autoclasificacion de la operacion al insertar/actualizar
--     Resuelve codigo_busqueda y proceso, y da de alta los codigos nuevos
--     en el catalogo para que despues se puedan corregir a mano.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_trazabilidad_autoclasificar()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
    v_codigo_final     VARCHAR(50);
    v_seccion_catalogo VARCHAR(50);
BEGIN
    v_codigo_final := NULLIF(BTRIM(COALESCE(NEW.codigo_busqueda, NEW.clave_modelo)), '');

    IF UPPER(COALESCE(NEW.descripcion, '')) LIKE '%WATER SPIDER%' THEN
        v_codigo_final := 'WS_KEMM';
    END IF;
    NEW.codigo_busqueda := v_codigo_final;

    IF UPPER(COALESCE(NEW.descripcion, '')) LIKE '%INLINE%'
       OR UPPER(COALESCE(NEW.descripcion, '')) LIKE '%IN LINE%' THEN
        NEW.proceso := 'SMT';
    ELSE
        SELECT cp.seccion INTO v_seccion_catalogo
          FROM catalogo_procesos cp
         WHERE cp.codigo = v_codigo_final AND cp.activo = TRUE
         LIMIT 1;

        IF v_seccion_catalogo IS NULL THEN
            v_seccion_catalogo := fn_resolver_proceso(v_codigo_final, NEW.descripcion);
        END IF;
        NEW.proceso := COALESCE(v_seccion_catalogo, 'SMT');
    END IF;

    -- Alta automatica del codigo nuevo. Si ya existe y esta bloqueado,
    -- se respeta la seccion fijada a mano.
    IF v_codigo_final IS NOT NULL AND BTRIM(v_codigo_final) <> '' THEN
        INSERT INTO catalogo_procesos (codigo, seccion, activo)
        VALUES (v_codigo_final, NEW.proceso, TRUE)
        ON CONFLICT (codigo) DO UPDATE
            SET seccion       = CASE WHEN catalogo_procesos.bloqueado
                                     THEN catalogo_procesos.seccion
                                     ELSE EXCLUDED.seccion END,
                activo        = TRUE,
                modificado_en = CURRENT_TIMESTAMP;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_trazabilidad_autoclasificar ON trazabilidad;
CREATE TRIGGER trg_trazabilidad_autoclasificar
    BEFORE INSERT OR UPDATE ON trazabilidad
    FOR EACH ROW EXECUTE FUNCTION fn_trazabilidad_autoclasificar();


-- =====================================================================
-- 3. CATALOGO SEMILLA DE PROCESOS
--     Los materiales YA NO se siembran a mano: los descubre
--     POST /api/v1/clasificacion/ejecutar
-- =====================================================================
INSERT INTO catalogo_procesos (codigo, seccion)
SELECT codigo, 'PENDIENTE'
  FROM unnest(ARRAY[
    'WS_KEMM','RPBCCO','RPBCOC','RPBCOA','RPBCOO','RCOAT','RPBPIN','RPING','RPING1',
    'RPBLMMY','RPBSKT','RPBMASY','RMASSY','RMASSY2','RPBWAV','RWAVE','RPBAOI','RPBOIA',
    'RPBMIL','RMILL','RGLUE','RPBGLU','RPBAXI','RPBICT','RICT','RPBLM','RPBSPPB',
    'RPBSPIB','RPBSMDB','RPBRFLB','RPBAOIB','RPBOIAB','RPBFSH','RLASER','RSPP_B',
    'RSPI_B','RSMT_B','ROVEN_B','RAOI_B','ROIA_B','RFLASH','RPBSPPT','RPBSPIT',
    'RPBSMDT','RPBRFLT','RPBAOIT','RPBOIAT','RSPP_T','RSPI_T','RSMT_T','ROVEN_T',
    'RAOI_T','ROIA_T','ROWED','RRIWED','ROWEMI','RRIWEMI','ROE','RRIE','RESEAL',
    'REEOL','REVIS','REDRA','ROEPCK','RCLEAN','RFLIP'
  ]) AS codigo
ON CONFLICT (codigo) DO NOTHING;

-- Resuelve la seccion de los codigos recien sembrados.
-- El WHERE es la diferencia critica contra la version anterior: aquel
-- UPDATE no tenia WHERE y reclasificaba TODO en cada arranque de la API,
-- borrando cualquier correccion manual.
UPDATE catalogo_procesos
   SET seccion       = fn_resolver_proceso(codigo, NULL),
       modificado_en = CURRENT_TIMESTAMP
 WHERE bloqueado = FALSE
   AND seccion = 'PENDIENTE';


-- =====================================================================
-- 4. VISTAS
-- =====================================================================

-- 4.1 Historico completo, ya unido con la pieza.
CREATE OR REPLACE VIEW vw_trazabilidad_historial AS
SELECT t.id,
       p.numero_material,
       p.nombre_pieza,
       p.proyecto,
       t.operacion_num,
       t.descripcion,
       t.clave_modelo,
       t.codigo_busqueda,
       t.proceso,
       t.steus,
       t.plnnr,
       t.plnal,
       t.aennr,
       t.equipos,
       t.cantidad_base,
       t.tiempo,
       t.tiempo_preparacion,
       t.tiempo_mano_obra,
       t.unidad_t,
       t.unidad_preparacion,
       t.unidad_mano_obra,
       t.vgwts,
       t.fecha_inicio,
       t.fecha_fin,
       t.creado_sap,
       t.modificado_sap,
       t.creado_en,
       t.modificado_en
  FROM trazabilidad t
  JOIN piezas p ON p.id = t.pieza_id;

-- 4.2 Solo la version vigente de cada operacion.
--     Esta es la vista que deberia consumir proyecto_backend en lugar de
--     rearmar el JOIN a mano en el ORM.
CREATE OR REPLACE VIEW vw_trazabilidad_vigente AS
SELECT *
  FROM (
    SELECT v.*,
           ROW_NUMBER() OVER (
               PARTITION BY v.numero_material, v.operacion_num
               ORDER BY v.fecha_inicio DESC NULLS LAST, v.aennr DESC
           ) AS rn
      FROM vw_trazabilidad_historial v
  ) q
 WHERE rn = 1;

-- 4.3 Resumen de la clasificacion automatica.
CREATE OR REPLACE VIEW vw_clasificacion_resumen AS
SELECT proyecto,
       origen,
       fuente_clasificacion,
       COUNT(*)                                        AS total,
       COUNT(*) FILTER (WHERE tuvo_errores_tecnicos)   AS con_errores,
       MAX(clasificado_en)                             AS ultima_clasificacion
  FROM catalogo_material_proyecto
 GROUP BY proyecto, origen, fuente_clasificacion;

-- 4.4 Materiales que hay que revisar a mano:
--     sin familia, o con errores tecnicos durante la busqueda.
CREATE OR REPLACE VIEW vw_materiales_por_revisar AS
SELECT cmp.numero_material,
       p.nombre_pieza,
       cmp.proyecto,
       cmp.fuente_clasificacion,
       cmp.regla_detectada,
       cmp.detalle_errores_tecnicos,
       cmp.clasificado_en
  FROM catalogo_material_proyecto cmp
  LEFT JOIN piezas p ON p.numero_material = cmp.numero_material
 WHERE cmp.origen = 'AUTOMATICO'
   AND (cmp.proyecto = 'SIN PROYECTO' OR cmp.tuvo_errores_tecnicos = TRUE);

COMMIT;


-- =====================================================================
-- 5. ROLES Y PERMISOS  (opcional pero recomendado)
--
--     Hoy la API de extraccion y proyecto_backend usan el MISMO usuario,
--     con permisos de escritura. El backend solo lee: no tiene por que
--     poder borrar trazabilidad.
--
--     Descomenta y ajusta las contraseñas antes de ejecutar.
-- =====================================================================
-- CREATE ROLE optime_extractor LOGIN PASSWORD 'CAMBIAR';
-- CREATE ROLE optime_lector    LOGIN PASSWORD 'CAMBIAR';
--
-- GRANT CONNECT ON DATABASE "SAP_OpTime_VizReport" TO optime_extractor, optime_lector;
-- GRANT USAGE   ON SCHEMA public TO optime_extractor, optime_lector;
--
-- -- Extractor: lectura y escritura, SIN permiso de DDL.
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES    IN SCHEMA public TO optime_extractor;
-- GRANT USAGE, SELECT                  ON ALL SEQUENCES IN SCHEMA public TO optime_extractor;
--
-- -- Backend: solo lectura.
-- GRANT SELECT ON ALL TABLES IN SCHEMA public TO optime_lector;
--
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public
--   GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO optime_extractor;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public
--   GRANT SELECT ON TABLES TO optime_lector;


-- =====================================================================
-- 6. VERIFICACION
-- =====================================================================
-- Estructura creada:
--   \dt
--   \dv
--   \df fn_*
--
-- Mapeo de tiempos del material del ejemplo (op 0050 debe dar
-- 0.8490 / 0.0300 / 4.2470):
--   SELECT operacion_num, tiempo, tiempo_preparacion, tiempo_mano_obra, vgwts
--     FROM vw_trazabilidad_vigente
--    WHERE numero_material = '12171980'
--    ORDER BY operacion_num;
--
-- Confirmar que la clave de valor prefijado es homogenea
-- (si sale mas de un valor, el orden de VGWnn puede variar por centro):
--   SELECT vgwts, COUNT(*) FROM trazabilidad GROUP BY 1;
--
-- Sospecha sobre 'equipos' (deberia dar un solo valor por material,
-- igual al numero de operaciones, lo que confirma que NO son equipos):
--   SELECT numero_material, COUNT(DISTINCT equipos) AS valores_distintos,
--          MIN(equipos) AS valor, COUNT(*) AS operaciones
--     FROM vw_trazabilidad_vigente
--    GROUP BY numero_material
--    HAVING COUNT(DISTINCT equipos) = 1
--    LIMIT 20;
--
-- Cuantas filas caen en el cajon de sastre 'SMT':
--   SELECT proceso, COUNT(*) FROM trazabilidad GROUP BY 1 ORDER BY 2 DESC;
--
-- Materiales que hay que revisar a mano:
--   SELECT * FROM vw_materiales_por_revisar;
