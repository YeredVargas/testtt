-- =====================================================================
-- MIGRACION 001 - Correccion de tiempos + busqueda automatica de familia
--
-- CORRER UNA SOLA VEZ, ANTES de levantar la nueva version de la API.
-- Es idempotente (se puede repetir sin romper nada).
--
--   psql -h 10.113.2.242 -U <usuario> -d SAP_OpTime_VizReport \
--        -f 001_tiempos_y_clasificacion.sql
--
-- HAZ RESPALDO ANTES:
--   pg_dump -Fc -h 10.113.2.242 -U <usuario> SAP_OpTime_VizReport > backup.dump
-- =====================================================================

BEGIN;

-- ---------------------------------------------------------------------
-- 1) TRAZABILIDAD: nuevas columnas de tiempo
--
-- En CA03 el ALV muestra, en este orden:
--   Tiempo de Operacion -> VGW01 (unidad VGE01, clase de actividad LAR01)
--   Tiempo Preparacion  -> VGW02 (unidad VGE02, clase de actividad LAR02)
--   Tiempo Mano de obra -> VGW03 (unidad VGE03, clase de actividad LAR03)
--
-- La columna tiempo_mano_obra venia guardando VGW02, o sea preparacion.
-- ---------------------------------------------------------------------
ALTER TABLE trazabilidad ADD COLUMN IF NOT EXISTS tiempo_preparacion NUMERIC(12,4);
ALTER TABLE trazabilidad ADD COLUMN IF NOT EXISTS unidad_preparacion VARCHAR(10);
ALTER TABLE trazabilidad ADD COLUMN IF NOT EXISTS unidad_mano_obra   VARCHAR(10);
ALTER TABLE trazabilidad ADD COLUMN IF NOT EXISTS vgwts              VARCHAR(10);

COMMENT ON COLUMN trazabilidad.tiempo             IS 'VGW01 - Tiempo de Operacion (CA03)';
COMMENT ON COLUMN trazabilidad.tiempo_preparacion IS 'VGW02 - Tiempo Preparacion (CA03)';
COMMENT ON COLUMN trazabilidad.tiempo_mano_obra   IS 'VGW03 - Tiempo Mano de obra (CA03)';
COMMENT ON COLUMN trazabilidad.vgwts              IS 'Clave de valor prefijado: define que significa cada VGWnn';

-- ---------------------------------------------------------------------
-- 2) RESCATE DE LOS DATOS HISTORICOS
--
-- Lo que hoy esta en tiempo_mano_obra es en realidad preparacion. Se mueve
-- a su columna correcta y se deja tiempo_mano_obra en NULL, para que se vea
-- claramente que ese dato NUNCA se extrajo y hay que re-sincronizar.
--
-- Si prefieres no tocar el historico y simplemente re-sincronizar todo desde
-- SAP, comenta este bloque completo.
-- ---------------------------------------------------------------------
UPDATE trazabilidad
   SET tiempo_preparacion = tiempo_mano_obra,
       tiempo_mano_obra   = NULL
 WHERE tiempo_preparacion IS NULL
   AND tiempo_mano_obra IS NOT NULL;

-- ---------------------------------------------------------------------
-- 3) RESTRICCION UNICA CORREGIDA
--
-- La anterior no incluia plnnr/plnal. Dos hojas de ruta alternativas del
-- mismo material con la misma operacion+fecha+aennr chocaban entre si y
-- tumbaban la pieza completa con IntegrityError.
-- ---------------------------------------------------------------------
ALTER TABLE trazabilidad DROP CONSTRAINT IF EXISTS uq_trazabilidad_hist;

-- Limpia duplicados que la constraint nueva no permitiria (deja el id mayor).
DELETE FROM trazabilidad t
 USING trazabilidad d
 WHERE t.id < d.id
   AND t.pieza_id      = d.pieza_id
   AND t.operacion_num = d.operacion_num
   AND t.fecha_inicio IS NOT DISTINCT FROM d.fecha_inicio
   AND t.aennr         = d.aennr
   AND COALESCE(t.plnnr,'') = COALESCE(d.plnnr,'')
   AND COALESCE(t.plnal,'') = COALESCE(d.plnal,'');

ALTER TABLE trazabilidad
  ADD CONSTRAINT uq_trazabilidad_hist
  UNIQUE (pieza_id, operacion_num, fecha_inicio, aennr, plnnr, plnal);

CREATE INDEX IF NOT EXISTS ix_trazabilidad_pieza_proceso
  ON trazabilidad (pieza_id, proceso);

-- ---------------------------------------------------------------------
-- 4) CATALOGO MATERIAL-PROYECTO: metadatos de la clasificacion automatica
--
-- origen='MANUAL' protege las correcciones humanas: el clasificador
-- automatico nunca las sobreescribe.
-- ---------------------------------------------------------------------
ALTER TABLE catalogo_material_proyecto
  ADD COLUMN IF NOT EXISTS origen                   VARCHAR(20) NOT NULL DEFAULT 'MANUAL',
  ADD COLUMN IF NOT EXISTS familia                  VARCHAR(50),
  ADD COLUMN IF NOT EXISTS variantes                VARCHAR(100),
  ADD COLUMN IF NOT EXISTS fuente_clasificacion     VARCHAR(50),
  ADD COLUMN IF NOT EXISTS material_heredado_desde  VARCHAR(50),
  ADD COLUMN IF NOT EXISTS regla_detectada          TEXT,
  ADD COLUMN IF NOT EXISTS texto_match              TEXT,
  ADD COLUMN IF NOT EXISTS tuvo_errores_tecnicos    BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS detalle_errores_tecnicos TEXT,
  ADD COLUMN IF NOT EXISTS clasificado_en           TIMESTAMP;

-- Las 44 filas que ya existian venian del seed hardcodeado: son manuales.
UPDATE catalogo_material_proyecto
   SET origen = 'MANUAL'
 WHERE origen IS NULL OR origen = '';

-- ---------------------------------------------------------------------
-- 5) NORMALIZACION DEL NOMBRE DE PROYECTO
--
-- El seed viejo escribio 'MACH-E'; el clasificador produce 'MACH E'.
-- Sin esto, el dashboard mostraria dos proyectos distintos para lo mismo.
-- El canonico elegido es 'MACH-E' (el que ya existe en la BD).
-- Si prefieres 'MACH E', invierte estos UPDATE y cambia
-- MAPA_FAMILIA_A_PROYECTO en core/clasificacion_rules.py.
-- ---------------------------------------------------------------------
UPDATE catalogo_material_proyecto
   SET proyecto = 'MACH-E'
 WHERE UPPER(BTRIM(proyecto)) IN ('MACH E', 'MACHE');

UPDATE piezas
   SET proyecto = 'MACH-E'
 WHERE UPPER(BTRIM(proyecto)) IN ('MACH E', 'MACHE');

-- ---------------------------------------------------------------------
-- 6) CATALOGO DE PROCESOS: proteger las clasificaciones manuales
--
-- El arranque de la API corria un UPDATE sin WHERE que reclasificaba TODAS
-- las filas segun un CASE hardcodeado, borrando cualquier correccion hecha
-- a mano. Con esta bandera, las filas marcadas ya no se tocan.
-- ---------------------------------------------------------------------
ALTER TABLE catalogo_procesos
  ADD COLUMN IF NOT EXISTS bloqueado BOOLEAN NOT NULL DEFAULT FALSE;

-- ---------------------------------------------------------------------
-- 7) BITACORA DE CORRIDAS
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sync_log (
    id           SERIAL PRIMARY KEY,
    tipo         VARCHAR(30) NOT NULL,
    estado       VARCHAR(20) NOT NULL,
    inicio       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fin          TIMESTAMP,
    total_items  INTEGER DEFAULT 0,
    items_ok     INTEGER DEFAULT 0,
    items_error  INTEGER DEFAULT 0,
    detalle      TEXT
);

CREATE INDEX IF NOT EXISTS ix_sync_log_tipo_inicio ON sync_log (tipo, inicio DESC);

-- ---------------------------------------------------------------------
-- 8) VISTAS ACTUALIZADAS con las columnas nuevas
--
-- Hay que DROP y volver a crear: CREATE OR REPLACE VIEW solo permite
-- AGREGAR columnas al final, no insertarlas en medio. Como
-- tiempo_preparacion va entre tiempo y tiempo_mano_obra, PostgreSQL
-- rechaza el REPLACE con:
--   "cannot change name of view column tiempo_mano_obra to tiempo_preparacion"
--
-- El orden importa: vigente depende de historial.
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS vw_trazabilidad_vigente;
DROP VIEW IF EXISTS vw_trazabilidad_historial;

CREATE OR REPLACE VIEW vw_trazabilidad_historial AS
SELECT t.id, p.numero_material, p.nombre_pieza, p.proyecto,
       t.operacion_num, t.descripcion, t.clave_modelo, t.codigo_busqueda,
       t.proceso, t.steus, t.plnnr, t.plnal, t.aennr, t.equipos,
       t.cantidad_base,
       t.tiempo, t.tiempo_preparacion, t.tiempo_mano_obra,
       t.unidad_t, t.unidad_preparacion, t.unidad_mano_obra, t.vgwts,
       t.fecha_inicio, t.fecha_fin, t.creado_sap, t.modificado_sap,
       t.creado_en, t.modificado_en
  FROM trazabilidad t
  JOIN piezas p ON p.id = t.pieza_id;

CREATE OR REPLACE VIEW vw_trazabilidad_vigente AS
SELECT * FROM (
    SELECT v.*, ROW_NUMBER() OVER (
             PARTITION BY v.numero_material, v.operacion_num
             ORDER BY v.fecha_inicio DESC NULLS LAST, v.aennr DESC
           ) AS rn
      FROM vw_trazabilidad_historial v
) q
WHERE rn = 1;

COMMIT;

-- =====================================================================
-- VERIFICACION (correr despues, fuera de la transaccion)
-- =====================================================================
-- Confirma que los tiempos ya no son identicos entre si:
--   SELECT operacion_num, tiempo, tiempo_preparacion, tiempo_mano_obra, vgwts
--     FROM vw_trazabilidad_vigente
--    WHERE numero_material = '12171980'
--    ORDER BY operacion_num;
--
-- Para el material 12171980, la operacion 0050 deberia dar:
--   tiempo = 0.8490 | tiempo_preparacion = 0.0300 | tiempo_mano_obra = 4.2470
--
-- Cuantos materiales quedaron por familia:
--   SELECT proyecto, origen, COUNT(*) FROM catalogo_material_proyecto
--    GROUP BY 1,2 ORDER BY 3 DESC;
--
-- Confirma la sospecha sobre 'equipos' (deberia dar 12 en TODAS las filas
-- de ese material, porque es el conteo de operaciones, no equipos reales):
--   SELECT DISTINCT equipos FROM vw_trazabilidad_vigente
--    WHERE numero_material = '12171980';
