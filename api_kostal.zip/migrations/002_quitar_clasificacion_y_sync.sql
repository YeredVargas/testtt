-- =====================================================================
--  002 - Quitar clasificacion por familia y tablas de sync sin uso
--  API de SAP v7.0
--
--  Ejecutar UNA vez en DBeaver sobre la BD (uzziel_dev3 / produccion)
--  DESPUES de haber detenido la API vieja y ANTES de arrancar la v7.0.
--
--  NO se toca catalogo_procesos: es el diccionario que asigna cada
--  operacion a su seccion (SMT, CONFORMAL, PINNING...). Estaba vacia
--  porque el setup viejo fallaba y hacia rollback; la v7.0 la llena
--  sola al arrancar.
-- =====================================================================


-- ---------------------------------------------------------------------
-- PASO 1 (solo lectura): revisar que nada mas dependa de estas tablas.
-- Si esta consulta devuelve filas, NO sigas y revisa esas vistas.
-- ---------------------------------------------------------------------
SELECT view_schema, view_name, table_name
FROM information_schema.view_table_usage
WHERE table_name IN ('catalogo_material_proyecto', 'sync_log', 'sync_jobs');


-- ---------------------------------------------------------------------
-- PASO 2 (solo lectura): conteo antes de borrar, para dejar evidencia.
-- ---------------------------------------------------------------------
SELECT 'catalogo_material_proyecto' AS tabla, COUNT(*) FROM catalogo_material_proyecto
UNION ALL SELECT 'sync_log',  COUNT(*) FROM sync_log
UNION ALL SELECT 'sync_jobs', COUNT(*) FROM sync_jobs;


-- ---------------------------------------------------------------------
-- PASO 3: borrado. Todo en una transaccion: o se aplica todo o nada.
-- ---------------------------------------------------------------------
BEGIN;

-- El trigger de piezas consultaba catalogo_material_proyecto. Hay que
-- quitarlo ANTES que la tabla o los INSERT en piezas empezarian a fallar.
DROP TRIGGER  IF EXISTS trg_piezas_asignar_proyecto ON piezas;
DROP FUNCTION IF EXISTS fn_piezas_asignar_proyecto();

DROP TABLE IF EXISTS catalogo_material_proyecto;
DROP TABLE IF EXISTS sync_log;
DROP TABLE IF EXISTS sync_jobs;

COMMIT;


-- ---------------------------------------------------------------------
-- PASO 4 (despues de arrancar la API v7.0): verificar el catalogo.
-- Debe devolver ~66 filas para el centro 0094.
-- ---------------------------------------------------------------------
-- SELECT centro, seccion, COUNT(*) FROM catalogo_procesos GROUP BY centro, seccion ORDER BY 1, 2;
