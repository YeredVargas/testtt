# main.py
import os
import sys
import logging
from fastapi import FastAPI
from contextlib import asynccontextmanager
from core.config import get_base_path, setup_cors
from db.setup_db import inicializar_base_datos
from api.router_master import api_router

base_path = get_base_path()

if getattr(sys, 'frozen', False):
    log_path = os.path.join(base_path, "kostal_sap_api.log")
    log_file = open(log_path, "a", buffering=1, encoding="utf-8")
    sys.stdout = log_file
    sys.stderr = log_file
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s: %(message)s",
        stream=log_file,
        force=True,
    )

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Iniciando API y verificando Base de Datos...")
    inicializar_base_datos()
    yield
    print("Apagando API...")

app = FastAPI(title="KOSTAL SAP API", version="7.4", lifespan=lifespan)

setup_cors(app)
app.include_router(api_router, prefix="/api/v1")

@app.get("/")
def home():
    return {"mensaje": "API de Sincronización SAP On-Demand activa."}

if __name__ == "__main__":
    import uvicorn
    host = os.getenv("APP_HOST", "0.0.0.0")
    port = int(os.getenv("APP_PORT", 5158))
    print(f"-> Servidor levantándose en http://{host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info", access_log=False)