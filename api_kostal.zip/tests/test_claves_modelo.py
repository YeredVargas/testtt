"""Prueba de lectura de T435T (sin SAP ni BD).  python -m pytest tests -q"""
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.modules.setdefault("pyrfc", types.SimpleNamespace(ABAPApplicationError=Exception, ABAPRuntimeError=Exception, Connection=None))

from services.claves_modelo_service import leer_t435t, normalizar_operacion  # noqa: E402


class ConnFalsa:
    def __init__(self, filas):
        self.filas = filas

    def call(self, fm, **kw):
        sk, n = kw["ROWSKIPS"], kw["ROWCOUNT"]
        return {"DATA": [{"WA": r} for r in self.filas[sk:sk + n]]}


def test_prioridad_de_idioma_y_paginacion():
    filas = [f"RX{i:04d}|S|TXT_{i}" for i in range(1200)]           # > 1 pagina de 500
    filas += ["RPBSMDT|E|PCB_SMT_T_EN", "RPBSMDT|S|PCB_SMT_T", "RSOLO|D|NUR_DE"]
    d = leer_t435t(ConnFalsa(filas))
    assert len(d) == 1202
    assert d["RPBSMDT"] == ("PCB_SMT_T", "S")
    assert d["RSOLO"] == ("NUR_DE", "D")


def test_normalizar_operacion():
    assert normalizar_operacion("  Glue ") == "GLUE"
