import os
import sys

# =========================================================
# PARCHE DE SEGURIDAD PARA PYTHON 3.8+ EN WINDOWS SERVER
# Autoriza explicitamente a Python a leer los DLLs de SAP
# =========================================================
if os.name == 'nt' and hasattr(os, 'add_dll_directory'):
    # Ruta 1: Busca en la carpeta _internal del ejecutable
    if getattr(sys, 'frozen', False):
        internal_dir = os.path.join(os.path.dirname(sys.executable), "_internal")
        if os.path.exists(internal_dir):
            os.add_dll_directory(internal_dir)

    # Ruta 2: Busca en el disco C: oficial (por si acaso)
    if os.path.exists(r"C:\nwrfc750\lib"):
        os.add_dll_directory(r"C:\nwrfc750\lib")

# Una vez autorizados los DLLs, importamos pyrfc de forma segura
from pyrfc import Connection
from core.config import sap_config


def get_sap_connection():
    """Devuelve una conexion activa a SAP."""
    return Connection(**sap_config)
