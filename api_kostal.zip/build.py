import os
import sys
import shutil
import subprocess
from pathlib import Path

# =========================================================
# RUTAS DEL PROYECTO
# =========================================================
BUILD_DIR = Path(__file__).resolve().parent

# Usar el Python del entorno virtual
VENV_PYTHON = BUILD_DIR / "venv" / "Scripts" / "python.exe"
PYTHON = str(VENV_PYTHON) if VENV_PYTHON.exists() else sys.executable

DIST_PATH = BUILD_DIR / "release"
WORK_PATH = BUILD_DIR / "work"

# ¡CORRECCIÓN!: Ahora coincide exactamente con el nombre que genera PyInstaller
OUTPUT_DIR = DIST_PATH / "api_kostal"

def clean():
    print("-> Limpiando compilaciones anteriores...")
    for folder in (DIST_PATH, WORK_PATH):
        if folder.exists():
            if sys.platform == "win32":
                subprocess.run(["cmd", "/c", "rd", "/s", "/q", str(folder)], check=False)
            else:
                shutil.rmtree(folder)

def compile_app():
    print("\n===================================================")
    print("PASO 1: Compilando Backend Python a .EXE...")
    print("===================================================")
    
    # Librerías críticas
    hidden_imports = [
        "uvicorn.logging", "uvicorn.loops", "uvicorn.loops.auto",
        "uvicorn.protocols", "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
        "uvicorn.protocols.websockets.auto", "uvicorn.lifespan.on",
        "sqlalchemy.dialects.postgresql", "sqlalchemy.dialects.postgresql.psycopg2",
        "psycopg2", "pyrfc",
    ]
    
    cmd = [
        PYTHON, "-m", "PyInstaller",
        str(BUILD_DIR / "main.py"),
        "--name", "api_kostal",
        "--onedir",
        "--noconfirm",
        "--noconsole",
        "--specpath", str(BUILD_DIR),
        "--distpath", str(DIST_PATH),
        "--workpath", str(WORK_PATH),
        "--copy-metadata", "pyrfc",
        "--collect-all", "pyrfc",  
    ]
    
    for imp in hidden_imports:
        cmd += ["--hidden-import", imp]
        
    result = subprocess.run(cmd, cwd=str(BUILD_DIR))
    if result.returncode != 0:
        sys.exit(result.returncode)

def post_build():
    print("\n===================================================")
    print("PASO 2: Ensamblando archivos finales...")
    print("===================================================")
    
    env_file = BUILD_DIR / ".env"
    
    # ¡LA CLAVE!: Nos aseguramos de que la carpeta destino exista antes de copiar
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # Copiar .env para que el EXE lo pueda leer
    if env_file.exists():
        shutil.copy2(env_file, OUTPUT_DIR / ".env")
        print("-> Archivo '.env' copiado exitosamente.")
    else:
        print("-> ADVERTENCIA: No se encontró el archivo .env original.")
        
    # Crear script de arranque
    bat_path = OUTPUT_DIR / "Iniciar_API.bat"
    bat_path.write_text(
        "@echo off\r\n"
        "echo Iniciando API KOSTAL (No cierres esta ventana si quieres ver los logs en tiempo real)...\r\n"
        "api_kostal.exe\r\n"
        "pause\r\n",
        encoding="utf-8",
    )
    print(f"\n✅ COMPILACIÓN EXITOSA. Copia esta carpeta a tu servidor: {OUTPUT_DIR}")

if __name__ == "__main__":
    clean()
    compile_app()
    post_build()