import os
import json
from sap.rfc_client import get_sap_connection

def extraer_claves_modelo():
    conn = None
    try:
        # Reutilizamos tu conexión centralizada
        conn = get_sap_connection()
        print("-> Conexión a SAP establecida correctamente.\n")

        # Configuración para leer la tabla T435T (Textos de Clave de Modelo)
        tabla = "T435T"
        campos = [
            {"FIELDNAME": "VLSCH"},  # Clave de modelo
            {"FIELDNAME": "TXT"}     # Texto descriptivo
        ]
        
        # Filtramos por idioma Español ('S') para no traer duplicados en otros idiomas
        opciones = [{"TEXT": "SPRAS = 'S'"}]

        print(f"Consultando la tabla {tabla} vía RFC_READ_TABLE...")
        resultado = conn.call(
            "RFC_READ_TABLE",
            QUERY_TABLE=tabla,
            DELIMITER="|",
            FIELDS=campos,
            OPTIONS=opciones
        )

        datos = resultado.get("DATA", [])
        print(f"-> Se encontraron {len(datos)} entradas.\n")

        lista_claves = []
        
        # Formato de salida en consola
        print(f"{'CLV.MOD.':<15} | {'TEXTO PARA CLAVE DE MODELO'}")
        print("-" * 60)

        for row in datos:
            # Separamos los valores usando el delimitador
            valores = row.get("WA", "").split("|")
            
            # Limpiamos los espacios en blanco
            clave = valores[0].strip() if len(valores) > 0 else ""
            texto = valores[1].strip() if len(valores) > 1 else ""
            
            lista_claves.append({
                "clave_modelo": clave,
                "texto": texto
            })
            
            print(f"{clave:<15} | {texto}")

        # Guardamos el resultado en un archivo JSON para que puedas usarlo después
        ruta_salida = os.path.join(os.path.dirname(__file__), "claves_modelo_sap.json")
        with open(ruta_salida, "w", encoding="utf-8") as f:
            json.dump(lista_claves, f, indent=4, ensure_ascii=False)
            
        print(f"\nExtracción finalizada. Datos guardados en: {ruta_salida}")

    except Exception as e:
        print(f"\n[ERROR] Ocurrió un problema al extraer los datos: {e}")
    finally:
        if conn and getattr(conn, 'alive', False):
            conn.close()

if __name__ == "__main__":
    extraer_claves_modelo()