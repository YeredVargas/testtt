import os
import sys
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware


def get_base_path():
    """Detecta si estamos corriendo como .exe o como script de Python normal."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


base_path = get_base_path()
load_dotenv(os.path.join(base_path, ".env"))

sap_config = {
    "mshost": os.getenv("SAP_MSHOST"),
    "sysid": os.getenv("SAP_SYSID"),
    "group": os.getenv("SAP_GROUP"),
    "client": os.getenv("SAP_CLIENT"),
    "user": os.getenv("SAP_USER"),
    "passwd": os.getenv("SAP_PASSWD"),
    "lang": os.getenv("SAP_LANG"),
}

pg_config = {
    "dbname": os.getenv("PG_DBNAME"),
    "user": os.getenv("PG_USER"),
    "password": os.getenv("PG_PASSWORD"),
    "host": os.getenv("PG_HOST"),
    "port": os.getenv("PG_PORT"),
}

# =========================================================
# PARAMETROS DE EXTRACCION (antes hardcodeados en el servicio)
# =========================================================
CENTRO_DEFAULT = os.getenv("SAP_CENTRO", "0094")
PLNTY_DEFAULT = os.getenv("SAP_PLNTY", "N")

# Puerto de la propia API.
APP_HOST = os.getenv("APP_HOST", "0.0.0.0")
APP_PORT = int(os.getenv("APP_PORT", 5158))

# Origenes permitidos para CORS (coma-separados). "*" solo para desarrollo.
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()]


def setup_cors(app):
    """Configura los permisos para el frontend."""
    permite_todo = CORS_ORIGINS == ["*"]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=CORS_ORIGINS,
        # allow_credentials=True es incompatible con allow_origins=["*"]:
        # los navegadores rechazan esa combinacion.
        allow_credentials=not permite_todo,
        allow_methods=["*"],
        allow_headers=["*"],
    )
