# OpTimeSAP v15

Es la v14 (tabla de relación SAP vs MES) más un cambio:

- El indicador **"API MES conectada"** ahora también revisa que la API que está en `MES_API_URL` tenga `/api/hana/ciclo-estadisticas`. Si no lo tiene, dice **"API MES incorrecta"** y, al pasar el mouse, explica por qué. Antes bastaba con que la API contestara, así que una carpeta mezclada salía "conectada" aunque cada comparación diera 404.

Instalación: ver `INSTALACION_LIMPIA.md`.
