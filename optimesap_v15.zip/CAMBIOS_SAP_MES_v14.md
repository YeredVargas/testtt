# OpTimeSAP v14: tabla de relación SAP vs MES operación por operación

## Qué hace
La tabla nueva **`sap_mes_relacion`** guarda, por **centro + número de material + alternativa SAP + operación**, la cantidad SAP y la cantidad MES de la última comparación:

| Grupo | Columnas |
|---|---|
| Identificador | `centro`, `numero_material`, `nombre_pieza`, `plnal`, `version_sap`, `operacion_num`, `descripcion`, `clave_modelo` |
| Relación con MES | `mes_operations` (estaciones MES), `mapeo_origen`, `agregacion`, `equipos`, `equipos_origen` |
| **Cantidad SAP** | `campo_tiempo` (VGW01/02/03), `sap_tiempo`, `sap_unidad`, `sap_cantidad_base`, **`sap_seg_pz`**, `sap_seg_pz_equipos` |
| **Cantidad MES** | `material_mes`, **`mes_proceso_seg_pz`**, `mes_proceso_piezas`, **`mes_salida_seg_pz`** (ya con ÷), `mes_salida_piezas`, `divisor_salida`, `estadistico`, `mes_desde`, `mes_hasta`, `mes_fuente` (HANA = en vivo, BD = guardado por la API de MES), `mes_actualizado_en` |
| Diferencia | `dif_proceso_pct`, `estado_proceso`, `dif_salida_pct`, `estado_salida` |
| Control | `actualizado_en` |

**Cómo se llena:** sola, cada vez que se compara un material (pantalla SAP/MES, `/comparativa` o `/tabla`). Hay una fila por operación; si comparas otra vez, la fila se actualiza en lugar de duplicarse.

**Por qué así:**
- La relación entre la operación SAP y la estación MES (el mapeo) solo existe en OpTimeSAP; por eso la tabla vive aquí y no en la API de MES.
- Se guardan las mismas filas que se ven en la tabla de la pantalla, así que los números siempre coinciden.
- Si en una comparación MES no responde, **se actualiza solo la parte SAP y se conservan los últimos valores MES buenos**. Así una caída de MES no borra datos.

## Endpoint nuevo
`GET /api/sap-mes/relacion?numero_material=12171980`

- Sin `numero_material` devuelve todos los materiales ya comparados.
- Filtros opcionales: `centro` (default 0094), `plnal` y `limite`.

## Consulta en DBeaver
```sql
SELECT operacion_num, descripcion, mes_operations,
       sap_seg_pz, mes_proceso_seg_pz, mes_proceso_piezas,
       sap_seg_pz_equipos, mes_salida_seg_pz, mes_salida_piezas,
       dif_proceso_pct, estado_proceso, mes_fuente, actualizado_en
FROM sap_mes_relacion
WHERE centro = '0094' AND numero_material = '12171980'
ORDER BY plnal, operacion_num;
```
El SQL para crear la tabla a mano está en `database/migrations/sap_mes/003_sap_mes_relacion.sql`. No hace falta correrlo: el backend la crea al arrancar.

## Despliegue
🖥 **SERVER**: detén OpTimeSAP.

🖥 **SERVER**: copia `proyecto_backend\app` y `proyecto_backend\database` del ZIP encima del proyecto de **OpTimeSAP**. Tu `.env` no se toca y el frontend no cambia.

🖥 **SERVER**: si usas el .exe, vuelve a generarlo:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```

🖥 **SERVER**: arranca. En la consola debe salir:
```
-> SAP/MES: tablas de mapeo, grupos y relacion SAP/MES verificadas.
```

🌐 **BROWSER**: compara un material en SAP/MES. Después abre `http://10.113.2.242:5159/api/sap-mes/relacion?numero_material=12171980`.
