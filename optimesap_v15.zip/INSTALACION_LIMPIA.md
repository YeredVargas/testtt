# Instalación limpia: API de SAP, API de MES y OpTimeSAP

## Qué estaba mal (revisión de tus 3 ZIP)

| Proyecto | Estado | Problema |
|---|---|---|
| **API de SAP** (`api_kostal`, puerto 5158) | ✅ Bien | Idéntica a la v7.4. No hay que cambiar nada. |
| **API de MES** (`mes_api`, puerto 8015) | ❌ Mezclada | `main.py`, `app/routes.py` y `app/config.py` son **de OpTimeSAP**, y además trae todo `dashboard`, `costos` y `sap_mes`. Por eso tiene **0 rutas `/api/hana`** y cada comparación da **404**. Al arrancar intentaba crear tablas de OpTimeSAP; de ahí el error de PostgreSQL. |
| **API de MES**, `.env` | ❌ Puerto | `DB_PORT=5432`. `uzziel_dev1` está en el **5433**, el mismo que usan OpTimeSAP y la API de SAP. El 5432 es otra instancia que rechaza la conexión (`pg_hba` / `server closed the connection`). |
| **OpTimeSAP** (puerto 5159) | ⚠️ Incompleta | Es una v12 a medias: tiene los archivos nuevos de la v12, pero el comparador y el controlador siguen en v11. Le faltan la v13, la v14 (tabla de relación SAP vs MES) y la v15. No tiene cambios tuyos que haya que conservar. |

**Regla para que no vuelva a pasar:** cada proyecto va en **su propia carpeta**. Nunca se descomprime un ZIP encima de otro proyecto.

```
C:\Apps\api_sap\           <- API de SAP   (5158)
C:\Apps\mes_api\           <- API de MES   (8015)
C:\Apps\optimesap\         <- OpTimeSAP    (5159; frontend de desarrollo en 5155)
```

---

## Paso 0: respaldo
💻 **WINDOWS**: detén las tres aplicaciones (Ctrl+C en cada consola). Luego renombra las carpetas actuales agregando `_old`, por ejemplo `mes_api_8015_v2` → `mes_api_8015_v2_old`. De ahí copiarás los `.env`.

## Paso 1: API de SAP (sin cambios)
Se queda como está, en su carpeta, con su `.env`. Solo arráncala:
```powershell
cd "C:\ruta\api_kostal"
```
```powershell
python .\main.py
```
🌐 Verifica en `http://localhost:5158/docs`.

## Paso 2: API de MES v3.1 (carpeta nueva)
💻 Descomprime `mes_api_8015_v3.1.zip` en `C:\Apps\mes_api`.

💻 Copia tu `.env` viejo:
```powershell
Copy-Item "C:\Users\balde011\Downloads\mes_api_8015_v2_old\proyecto_backend\.env" "C:\Apps\mes_api\proyecto_backend\.env"
```

💻 Abre `C:\Apps\mes_api\proyecto_backend\.env` y **cambia el puerto de PostgreSQL**:
```
DB_PORT=5433
```
Usa en `DB_USER` y `DB_PASSWORD` los mismos datos que tiene el `.env` de OpTimeSAP, porque es la misma base.

💻 Crea un venv nuevo e instala dependencias:
```powershell
cd "C:\Apps\mes_api\proyecto_backend"
```
```powershell
python -m venv venv
```
```powershell
.\venv\Scripts\Activate.ps1
```
```powershell
pip install -r requirements.txt
```
```powershell
python .\main.py
```

✅ En la consola debe salir:
```
[INFO] Configuración de SAP HANA cargada correctamente.
[INFO] API de MES: 14 rutas /api/hana registradas.
[INFO] Historico MES: tabla mes_ciclo_estadistica verificada.
```
🌐 `http://localhost:8015/docs` debe mostrar la sección **Hana**, con `ciclo-estadisticas` e `historico`.

## Paso 3: OpTimeSAP v15 (carpeta nueva)
💻 Descomprime `optimesap_v15.zip` en `C:\Apps\optimesap`.

💻 Copia tus dos `.env` viejos:
```powershell
Copy-Item "C:\ruta\optimesap_old\proyecto_backend\.env" "C:\Apps\optimesap\proyecto_backend\.env"
```
```powershell
Copy-Item "C:\ruta\optimesap_old\proyecto_frontend\.env" "C:\Apps\optimesap\proyecto_frontend\.env"
```
Revisa que el `.env` del backend tenga `DB_PORT=5433` y `MES_API_URL=http://127.0.0.1:8015`. Tu `.env` actual ya los tiene así.

💻 Backend:
```powershell
cd "C:\Apps\optimesap\proyecto_backend"
```
```powershell
python -m venv venv
```
```powershell
.\venv\Scripts\Activate.ps1
```
```powershell
pip install -r requirements.txt
```
```powershell
python .\main.py
```
✅ Debe salir: `-> SAP/MES: tablas de mapeo, grupos y relacion SAP/MES verificadas.`

💻 Frontend de desarrollo (5155), en otra consola:
```powershell
cd "C:\Apps\optimesap\proyecto_frontend"
```
```powershell
npm install
```
```powershell
npm run dev
```

## Paso 4: comprobar que todo funciona
1. 🌐 `http://localhost:5155/app/sap-mes`: el indicador debe decir **"API MES conectada"** en verde. Si dice **"API MES incorrecta"**, `MES_API_URL` apunta a una API que no es la de MES.
2. Elige **12171980**, pon fechas MES y presiona **Comparar**. La columna MES debe llenarse y no debe aparecer el aviso de 404.
3. 🌐 `http://localhost:5159/api/sap-mes/relacion?numero_material=12171980`: es la **tabla de relación SAP vs MES** operación por operación, guardada en `sap_mes_relacion`.
4. 🌐 `http://localhost:8015/api/hana/historico?material=12171980`: son las estadísticas MES que guardó la API de MES.

## Para el servidor
Es lo mismo, en carpetas separadas. Si usas .exe:
- **API de MES:** `python .\script\build.py`
- **OpTimeSAP:** `python build.py`

**Ojo al compilar el frontend para el servidor:** quita o renombra `proyecto_frontend\.env`. Con `VITE_SAP_API_URL=http://127.0.0.1:5158`, los navegadores de otras PCs buscarían la API de SAP en su propia máquina. Sin esa variable, se usa automáticamente el mismo servidor en el puerto 5158. El `dist` que viene en el ZIP ya está compilado así.

## Seguridad
Los ZIP que me mandaste incluían los `.env` con usuarios y contraseñas de SAP, HANA y PostgreSQL. Además, la contraseña de HANA salió completa en una foto. Te recomiendo **cambiar esas contraseñas** y actualizar los `.env`. Los ZIP que te regreso **no** traen `.env`.
