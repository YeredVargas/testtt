# OpTimeSAP v3: selector de tiempo SAP + auditoría de Comparativa

Este ZIP parte de tu versión `OPtimeSAP_mes` (incluye tu filtro por estaciones en Comparativa). Trae el proyecto completo, este documento y en `_cambios/` un diff por fase. **No incluye `.env`.**

| Fase | Estado |
|---|---|
| 9. Selector "Tiempo SAP a comparar" en SAP/MES | ✅ Entregada y probada |
| 10. Comparativa con lógica correcta | ⏸ Diseñada, esperando tus datos (ver abajo) |

No hay cambios en la BD, en la API de SAP ni en la API de MES. No hay variables de entorno nuevas.

---

## Fase 9: selector de tiempo SAP

En **SAP / MES** hay un nuevo select: **Tiempo SAP a comparar**. Lista las tres columnas de tiempo que guarda `trazabilidad`:

| Opción | Columna | Unidad |
|---|---|---|
| Tiempo de operación (VGW01) | `tiempo` | `unidad_t` (VGE01) |
| Tiempo de preparación (VGW02) | `tiempo_preparacion` | `unidad_preparacion` (VGE02) |
| Mano de obra (VGW03) | `tiempo_mano_obra` | `unidad_mano_obra` (VGE03) |

- Cada tiempo se convierte a seg/pz con **su propia unidad** y la cantidad base (BMSCH).
  - Si SAP dejó la unidad vacía (pasa con VGE02/VGE03), se usa la de VGW01.
  - Esa operación muestra un ⚠ con la explicación.
- Después de comparar, el select indica cuántas operaciones traen cada tiempo, por ejemplo `Mano de obra (VGW03) · 3/11 ops`.
- Si el tiempo elegido no existe en ninguna operación de esa versión, aparece un aviso.
- El encabezado del resultado dice qué tiempo se comparó. El cuello de botella SAP también se calcula con ese tiempo.
- Al cambiar el filtro y volver a comparar, la tabla anterior queda atenuada mientras llega la nueva, en lugar de vaciarse.
- **Default: VGW01**, así que sin tocar el select todo se comporta igual que antes.

Backend:
- `GET /api/sap-mes/{material}/comparativa` acepta `campo_tiempo=tiempo|tiempo_preparacion|tiempo_mano_obra`.
- La respuesta trae `campos_tiempo`, con las operaciones que tienen valor en cada campo.
- `/materiales` ahora incluye materiales que solo tienen VGW02 o VGW03.

Pruebas: `python -m pytest tests -q` → 11 pasan (3 nuevas).

---

## Fase 10: auditoría de Comparativa (sin cambios todavía)

### Hallazgo principal: qué significa `equipos`
En la API de SAP (`tiempo_operacion_service.py`), `equipos = len(operaciones)` de la hoja de ruta. **Es el número de operaciones, no de máquinas.**

Dashboard, Tiempos y Gráficas calculan `pzs/hr = (1000 / tiempo) / equipos`. Cuando todas las operaciones traen el mismo VGW01 (como en la pantalla de SAP: 0.180 H en cada una), eso es `1000 / Σ VGW01`. Es decir: **el VGW01 de cada operación es una parte del tiempo de la línea**, y la suma es el tiempo de la línea por 1000 piezas. Necesito que lo confirmes con datos reales.

### Problemas de la página actual
| # | Qué hace hoy | Por qué no es verídico |
|---|---|---|
| 1 | Elige la versión de la ruta detectando cuando el número de operación "reinicia" | Puede tomar una versión vieja u otra alternativa. Debe usar `fecha_inicio`/`fecha_fin` y la alternativa, como SAP/MES. |
| 2 | Asume que todo está en horas por 1000 piezas | Ignora `unidad_t` y `cantidad_base`. |
| 3 | Capacidad por turno = 7.5 h ÷ (VGW01 máximo / 1000) | Si VGW01 es una parte del tiempo de línea, la capacidad real es `7.5 h × 1000 / Σ VGW01`. Además el título dice 8 h y el cálculo usa 7.5. |
| 4 | "Balanceo de línea" grafica VGW01 por operación y alinea los materiales por posición | Muestra partes del tiempo de línea, no tiempos de estación. La operación 3 de un material se compara con la 3 de otro aunque sea otro proceso. Debe alinearse por clave de modelo (T435T). |
| 5 | Personas equivalentes = Σ mano de obra ÷ Σ máquina | Lo estándar es `Σ mano de obra por pieza ÷ ciclo de la línea`. |
| 6 | Valor de producción detenida = costo total ÷ Σ horas por 1000 | Mezcla unidades. Lo correcto es `piezas/hora de la línea × costo por pieza`. Para eso hay que saber el tamaño de lote del costeo. |
| 7 | Al filtrar estaciones, el costo se escala por la proporción de tiempo | El material no depende del tiempo. Solo se puede prorratear el costo de actividades (mano de obra y máquina). |
| 8 | Filtros "Mes exacto", "Fecha inicio" y "Fecha fin" | No se aplican a nada. Deben cambiarse por "versión de la ruta vigente a la fecha". |

### Propuesta para la Fase 10 (cuando confirmes)
- Un endpoint nuevo en el backend, `GET /api/comparativa/lineas`, hace todos los cálculos en un solo lugar y con pruebas. Recibe materiales, fecha, alternativa y rango de estaciones.
- El frontend solo dibuja.
- Las fórmulas quedan en funciones separadas, para que la regla de la planta se cambie en un solo sitio.

### Lo que necesito
1. Confirmar si la línea produce 1000 piezas en Σ VGW01 horas.
2. Qué significan VGW02 y VGW03 en las rutas "MES Ready", y qué clave VGWTS usan.
3. El tamaño de lote del costeo CK13N (`total_global`): ¿es por 1 pieza, por 1000 o por otro tamaño?
4. Las horas efectivas de un turno.
5. El CSV de `trazabilidad` y de los costos de 3 a 5 materiales (consultas en el mensaje del chat), y sus filas en Resumen_total.

---

## Despliegue (solo OpTimeSAP)

🖥 **SERVER**: detén OpTimeSAP y respalda la carpeta.

🖥 **SERVER**: descomprime `optimesap_v3.zip` encima. Tu `.env` no se toca. Ya trae `proyecto_frontend/dist` compilado.

🖥 **SERVER**: si empaquetas con PyInstaller:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: arranca como siempre (o con `iniciar_api.bat`).

🌐 **BROWSER**: entra a `http://10.113.2.242:5159/app/sap-mes`.
1. Elige un material y presiona **Comparar**.
2. Cambia **Tiempo SAP a comparar** a "Mano de obra (VGW03)" y vuelve a comparar.
3. El encabezado debe decir "Mano de obra (VGW03)", y el select debe mostrar cuántas operaciones traen ese tiempo.
