# OpTimeSAP v5: personas equivalentes y % mano de obra con la regla de planta

Este ZIP parte de la v4: trae el selector de tiempo SAP y los grupos de procesos. Incluye el proyecto completo y en `_cambios/` un diff por fase. **No incluye `.env`.** Solo cambia el frontend de **Comparativa**; no hay cambios en la BD ni en el backend.

## Fase 12: regla de cálculo

Aplica a las operaciones elegidas: todas las de la ruta, o las del rango **Estación inicial / Estación final**.

1. Se toma la mano de obra de cada operación (VGW03, `tiempo_mano_obra`).
2. El valor que **más se repite** equivale a **1 persona**. Ejemplo: 5.
3. Cada operación cuenta como `VGW03 / referencia` personas:
   - 5 → 1 persona;
   - 2.5 → 0.5 (una persona atiende dos de esas operaciones);
   - 10 → 2 personas;
   - 0 → operación automática.
4. **Personas equivalentes** = la suma de lo anterior.
5. **% mano de obra** = personas / número de operaciones × 100.
6. **% automatización** = 100 − % mano de obra.

Ejemplo de tu mensaje: 12 personas / 23 operaciones → **52.2 % mano de obra · 47.8 % automatización**. Verificado con el mismo caso en la función.

### Casos especiales
| Caso | Qué hace |
|---|---|
| Empate en el valor que más se repite (p. ej. 2.1, 6.5 y 9, una vez cada uno) | Toma el **mayor** como 1 persona, para que las demás queden como fracciones. |
| Alguna operación pide más de una persona y el % pasa de 100 | La gráfica se topa en 100 %; las personas se reportan completas. |
| El material no tiene VGW03 en ninguna operación | 0 personas, 100 % automatización, y el tooltip dice "Sin tiempo de mano de obra (VGW03) en SAP". |
| Valores casi iguales (5 y 5.00001) | Cuentan como el mismo (se redondea a 4 decimales). |

Supone que VGW03 viene en la misma unidad y base en todas las operaciones de la ruta, que es como lo guarda SAP en una misma hoja de ruta.

## En pantalla
- **Automatización vs Mano de Obra (%)**, antes "Máquina vs Mano de Obra": barras con % automatización y % mano de obra según la regla.
- **Personas Equivalentes (1 persona = VGW03 más repetido)**: personas por material.
- El tooltip de ambas gráficas muestra:
  - cuánto vale 1 persona y cuántas veces se repite;
  - operaciones con mano de obra y operaciones automáticas;
  - personas / operaciones;
  - los dos porcentajes.
- El filtro de estaciones recalcula todo al momento.

La regla vive en `src/utils/manoObra.js`, una función pura. Cuando hagamos la Fase 10 (Comparativa con cálculos en el backend), se porta tal cual.

## Despliegue (solo OpTimeSAP)

🖥 **SERVER**: detén OpTimeSAP y respalda la carpeta.

🖥 **SERVER**: descomprime `optimesap_v5.zip` encima. Tu `.env` no se toca. Ya trae `proyecto_frontend/dist` compilado.

🖥 **SERVER**: si empaquetas con PyInstaller:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: arranca como siempre.

🌐 **BROWSER**: entra a `http://10.113.2.242:5159/app/comparativa`.
1. Agrega un material.
2. Pasa el mouse sobre su barra en **Automatización vs Mano de Obra**. El tooltip debe decir cuánto vale 1 persona y "Personas / operaciones".
3. Cambia la estación inicial o la final: los porcentajes y las personas deben cambiar.
