# OpTimeSAP v11: endpoint de la tabla SAP/MES

## Qué hace
`GET /api/sap-mes/{numero_material}/tabla`

Recibe un número de material y regresa **solo la tabla** de la pantalla SAP/MES: una fila por operación. No trae KPIs, resumen, grupos ni datos para la gráfica.

**Por qué se hizo así:** el endpoint usa la misma función que la pantalla (`construir_comparativa`) y solo recorta el resultado. Así los números son exactamente los que ves en la tabla, y cualquier cambio futuro en el cálculo aplica a los dos sin mantener dos lógicas.

## Uso mínimo
Solo el material es obligatorio. Todo lo demás toma los mismos valores por defecto que la pantalla:

| Parámetro | Default |
|---|---|
| `centro` | 0094 |
| alternativa | la principal, versión vigente |
| periodo MES | últimos 14 días |
| `estadistico` | mediana |
| `campo_tiempo` | VGW01 tiempo |
| `divisor_salida` | 1 |
| `tolerancia_pct` | ±10 % |

```
http://localhost:5159/api/sap-mes/12171980/tabla
```

## Parámetros opcionales
Son los mismos filtros que tiene la pantalla:

| Parámetro | Ejemplo | Para qué |
|---|---|---|
| `centro` | `0094` | Centro SAP |
| `plnal` | `01` | Alternativa SAP |
| `fecha` | `2026-04-28` | Versión SAP vigente a esa fecha |
| `start_date` / `end_date` | `20260922` / `20261005` | Periodo MES (YYYYMMDD) |
| `estadistico` | `mediana`, `promedio`, `p75`, `p90` | Estadístico MES |
| `campo_tiempo` | `tiempo`, `tiempo_preparacion`, `tiempo_mano_obra` | VGW01 / VGW02 / VGW03 |
| `divisor_salida` | `4` | MES salida ÷ |
| `material_mes` | `12171980` | Datos MES de otro material |
| `tolerancia_pct` | `10` | Tolerancia ±% |
| `max_gap_sec` / `max_ct_sec` | `600` / `3600` | Límites de paros |
| `grupo_id` | `5` | Solo las operaciones de ese grupo de procesos |
| `estaciones` | `false` | Quita el detalle por estación MES (respuesta más corta) |

## Respuesta
El encabezado trae `numero_material`, `nombre_pieza`, `centro`, `version`, `parametros`, `grupo` y `mes_error`. Después viene `filas`, una por operación:

| Campo | Columna en pantalla |
|---|---|
| `operacion_num`, `descripcion`, `clave_modelo` | Operación |
| `equipos`, `equipos_origen` (REGLA / MES / DEFAULT) | Equipos |
| `tiempo_sap`, `unidad_sap`, `cantidad_base` | Tiempo SAP |
| `sap_seg_pz`, `sap_aviso` | SAP seg/pz |
| `mes_proceso`, `mes_proceso_n` | MES proceso (y su n) |
| `dif_proceso_seg`, `dif_proceso_pct`, `estado_proceso` | Δ proceso |
| `sap_seg_pz_equipos` | SAP ÷ equipos |
| `mes_salida`, `mes_salida_n` | MES salida (ya dividida si usas `divisor_salida`) |
| `dif_salida_seg`, `dif_salida_pct`, `estado_salida` | Δ salida |
| `mes_operations`, `mapeo_origen`, `agregacion`, `mes_incompleto` | Mapeo MES |
| `estaciones[]` | Detalle al expandir la fila: proceso y salida (mediana, promedio, P25, P75, P90, n, excluidos) y recursos |

Valores de `estado_*`: `OK`, `MES_MAS_LENTO`, `MES_MAS_RAPIDO`, `SIN_DATOS_MES`, `SIN_TIEMPO_SAP`, `SIN_MAPEO`.

Errores:
- **404** si el material no existe en ese centro.
- **404** si el `grupo_id` no existe para ese material.
- **422** si un parámetro es inválido.

## Despliegue
🖥 **SERVER**: detén OpTimeSAP.

🖥 **SERVER**: copia `proyecto_backend\app` del ZIP encima del proyecto. Tu `.env` no se toca. En esta versión el frontend no cambió.

🖥 **SERVER**: si corres el .exe, vuelve a generarlo:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```

🖥 **SERVER**: arranca de nuevo.

🌐 **BROWSER**: abre `http://10.113.2.242:5159/docs`. El endpoint aparece como **GET /api/sap-mes/{numero_material}/tabla** y ahí mismo lo puedes probar con "Try it out".

💻 **WINDOWS (PowerShell)**: prueba rápida:
```powershell
$r = Invoke-RestMethod "http://10.113.2.242:5159/api/sap-mes/12171980/tabla?estaciones=false"
```
```powershell
$r.filas | Format-Table operacion_num, descripcion, sap_seg_pz, mes_proceso, estado_proceso, mes_salida, estado_salida
```
