# OpTimeSAP v4: grupos de procesos en SAP/MES

Este ZIP parte de la v3: trae el selector de tiempo SAP y tu filtro por estaciones en Comparativa. Incluye el proyecto completo, este documento y en `_cambios/` un diff por fase. **No incluye `.env`.**

| Fase | Estado |
|---|---|
| 9. Selector "Tiempo SAP a comparar" | ✅ (v3) |
| 11. Grupos de procesos en SAP/MES | ✅ Entregada y probada |
| 10. Comparativa con lógica correcta | ⏸ Esperando tus datos (ver `CAMBIOS_SAP_MES_v3.md`) |

Comparativa no se tocó: su filtro de estaciones sigue igual.

---

## Fase 11: grupos de procesos

Un **grupo** es un rango de operaciones con nombre, por ejemplo "SMT Top" de la 0100 a la 0160.
- Lo arma el usuario y queda guardado **por material**.
- Puede aplicar a una sola alternativa o a todas.
- Los grupos se pueden traslapar: son vistas de la ruta, no la dividen.

### En pantalla (SAP / MES, después de Comparar)
- El panel **Grupos de procesos** tiene un chip por grupo y un chip **Toda la ruta**.
  - Al elegir un grupo se filtran la gráfica, la tabla de detalle y los KPIs de arriba.
  - Los cuellos de botella pasan a ser los de ese grupo.
- **Nuevo grupo** abre un formulario en línea:
  - nombre;
  - operación inicial y operación final, en selects con las operaciones de la ruta;
  - casilla "Solo Alt XX".
  - El lápiz edita un grupo y el bote lo elimina, con confirmación en la misma fila.
- La tabla **Resumen por grupo** muestra, por grupo:

| Columna | Cálculo |
|---|---|
| SAP Σ proceso / MES Σ proceso | Suma del seg/pz de las operaciones que tienen **SAP y MES** (comparables). Indica cuántas son, por ejemplo "7/7 comparables". |
| Δ proceso | (MES − SAP) / SAP de esas sumas, con la misma tolerancia de la comparativa. |
| Cuello SAP ÷ equipos / Cuello MES salida | La operación más lenta del grupo (seg/pz y pzs/hr). Marca el ritmo de salida del grupo. |
| Δ salida | (cuello MES − cuello SAP) / cuello SAP. |

**Por qué solo se suman las operaciones comparables:** si una operación no tiene datos en MES, sumar todo lo de SAP contra solo una parte de MES haría que MES pareciera más rápido de lo que es.

**Por qué el cuello y no la suma para la salida:** en un grupo en serie, las piezas salen al ritmo de la estación más lenta.

Los cálculos usan el **tiempo SAP elegido** (VGW01, 02 o 03) y el estadístico de MES de la comparación.

### Cache corto de MES
Al guardar o borrar un grupo, la comparativa se vuelve a armar para recalcular los resúmenes. Para no repetir la consulta a HANA, el backend guarda **5 minutos** en memoria la respuesta de MES, con los mismos parámetros.
- Lo mismo aplica al cambiar el tiempo SAP a comparar: ahora es casi instantáneo.
- Si cambian el rango de fechas, los límites o el mapeo, la consulta es otra y va a HANA.

### Backend
- Tabla nueva `sap_mes_grupo`.
  - El backend la crea sola al arrancar.
  - El SQL está en `database/migrations/sap_mes/002_sap_mes_grupos.sql`, para revisarlo o correrlo a mano.
  - No toca ninguna tabla existente.
- Endpoints nuevos: `GET /api/sap-mes/grupos?numero_material=…`, `POST /grupos`, `PUT /grupos/{id}` y `DELETE /grupos/{id}`.
  - El nombre es único por material y alternativa, sin distinguir mayúsculas.
  - La operación inicial no puede ir después de la final.
- La comparativa ahora devuelve `grupos`: un resumen por grupo, con sus propios KPIs.
- Pruebas: `python -m pytest tests -q` → 14 pasan (3 nuevas: rango de operaciones, resumen de grupo y cache de MES).

---

## Despliegue (solo OpTimeSAP)

🖥 **SERVER**: detén OpTimeSAP y respalda la carpeta.

🖥 **SERVER**: descomprime `optimesap_v4.zip` encima. Tu `.env` no se toca. Ya trae `proyecto_frontend/dist` compilado.

🖥 **SERVER**: si empaquetas con PyInstaller:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: arranca como siempre. En el log debe aparecer:
```
-> SAP/MES: tablas de mapeo y grupos verificadas.
```

🌐 **BROWSER**: entra a `http://10.113.2.242:5159/app/sap-mes`.
1. Elige un material y presiona **Comparar**.
2. En **Grupos de procesos**, presiona **Nuevo grupo**. Ponle nombre "SMT Top" y elige de la 0100 a la última operación SMT. Guarda.
3. Debe aparecer el chip y su fila en el resumen. Al tocar el chip, la gráfica y la tabla muestran solo esas operaciones.

Si prefieres crear la tabla antes de arrancar, en DBeaver:
```sql
-- contenido de database/migrations/sap_mes/002_sap_mes_grupos.sql
```
