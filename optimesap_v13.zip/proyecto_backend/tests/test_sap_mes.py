"""
Pruebas del calculo SAP/MES (no requieren BD ni MES).
Ejecutar desde proyecto_backend:   python -m pytest tests -q
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.services.sap_mes.conversion import seg_por_pieza  # noqa: E402
from app.services.sap_mes.comparador import agregar_estaciones, diferencia  # noqa: E402


def test_conversion_horas_por_mil():
    assert round(seg_por_pieza(8.3333, "H", 1000)[0], 2) == 30.0


def test_conversion_minutos_base_1():
    assert seg_por_pieza(0.75, "MIN", 1)[0] == 45.0


def test_conversion_sin_base_o_unidad():
    assert seg_por_pieza(5, "H", 0)[0] is None
    assert seg_por_pieza(5, "XYZ", 1000)[1].startswith("Unidad")
    assert seg_por_pieza(0, "H", 1000)[0] is None


def _est(op, pr, sa, n=100):
    return {"operation": op, "proceso": {"n": n, "mediana": pr}, "salida": {"n": n, "mediana": sa}}


def test_agregacion_serie():
    r = agregar_estaciones([_est("A", 27, 31), _est("B", 18, 30)], "SERIE", "mediana")
    assert r["proceso"] == 45 and r["salida"] == 31


def test_agregacion_paralelo():
    r = agregar_estaciones([_est("A", 26, 50), _est("B", 24, 50)], "PARALELO", "mediana")
    assert r["proceso"] == 25 and r["salida"] == 25


def test_agregacion_incompleta():
    r = agregar_estaciones([_est("A", 27, 31), {"operation": "B", "proceso": {"n": 0}, "salida": {"n": 0}}], "SERIE", "mediana")
    assert r["incompleto"] is True and r["proceso"] == 27


def test_diferencia_estados():
    assert diferencia(33, 30, 10)["estado"] == "OK"
    assert diferencia(40, 30, 10)["estado"] == "MES_MAS_LENTO"
    assert diferencia(20, 30, 10)["estado"] == "MES_MAS_RAPIDO"
    assert diferencia(None, 30, 10)["estado"] == "SIN_DATOS_MES"
    assert diferencia(30, None, 10)["estado"] == "SIN_TIEMPO_SAP"


def test_texto_t435t_con_forma_de_operacion_mes():
    from app.services.sap_mes.comparador import _RE_OPERACION_MES
    assert _RE_OPERACION_MES.match("PCB_SMT_T")
    assert _RE_OPERACION_MES.match("OBC_FASSY_ST040_2")
    assert _RE_OPERACION_MES.match("GLUE")
    assert not _RE_OPERACION_MES.match("MANUAL ASSEMBLY, BEZEL, BONDING")


# --- Selector de tiempo SAP (VGW01 / VGW02 / VGW03) ---
from types import SimpleNamespace  # noqa: E402

from app.services.sap_mes.conversion import valor_y_unidad  # noqa: E402
from app.services.sap_mes.comparador import campos_disponibles  # noqa: E402


def _fila(**kw):
    base = dict(tiempo=8.3333, unidad_t="H", tiempo_preparacion=0, unidad_preparacion=None,
                tiempo_mano_obra=2.5, unidad_mano_obra="MIN", cantidad_base=1000)
    base.update(kw)
    return SimpleNamespace(**base)


def test_valor_y_unidad_por_campo():
    f = _fila()
    assert valor_y_unidad(f, "tiempo") == (8.3333, "H", False)
    assert valor_y_unidad(f, "tiempo_mano_obra") == (2.5, "MIN", False)


def test_unidad_vacia_hereda_vge01():
    f = _fila(tiempo_preparacion=3.0, unidad_preparacion="")
    assert valor_y_unidad(f, "tiempo_preparacion") == (3.0, "H", True)


def test_campos_disponibles_cuenta_operaciones_con_valor():
    ops = [_fila(), _fila(tiempo_mano_obra=0), _fila(tiempo_preparacion=1.2)]
    por_campo = {c["campo"]: c["operaciones_con_valor"] for c in campos_disponibles(ops)}
    assert por_campo == {"tiempo": 3, "tiempo_preparacion": 1, "tiempo_mano_obra": 2}


# --- Grupos de procesos (Fase 11) ---
from app.schemas.sap_mes.sap_mes_schema import clave_operacion  # noqa: E402
from app.services.sap_mes.comparador import en_rango, resumir_grupo  # noqa: E402


def test_rango_por_numero_de_operacion():
    assert clave_operacion("0100") < clave_operacion("0110") < clave_operacion("1000")
    assert en_rango("0150", "0100", "0160") and not en_rango("0200", "0100", "0160")
    assert en_rango("0100", "100", "0160")  # ceros a la izquierda no importan


def _op(num, sap, sap_linea, mes_pr, mes_sa):
    dif = {"estado": "OK"}
    return {
        "operacion_num": num, "descripcion": f"Op {num}",
        "sap": {"seg_pz": sap, "seg_pz_linea": sap_linea},
        "mes": {"proceso": mes_pr, "salida": mes_sa},
        "mapeo": {"mes_operations": ["X"], "origen": "AUTO_T435T"}, "regla": None,
        "dif_proceso": dif, "dif_salida": dif,
    }


def test_resumen_de_grupo():
    ops = [_op("0100", 20, 20, 22, 25), _op("0110", 30, 15, 33, 18), _op("0120", 10, 10, None, None),
           _op("0200", 50, 50, 55, 60)]
    g = SimpleNamespace(id=1, nombre="SMT", plnal=None, op_inicio="0100", op_fin="0120")
    r = resumir_grupo(g, ops)
    assert r["operaciones"] == ["0100", "0110", "0120"]
    # Proceso: solo comparables (0100 y 0110): SAP 50 vs MES 55 -> +10 %
    assert r["proceso"] == {"comparables": 2, "sap_seg_pz": 50, "mes_seg_pz": 55, "dif_pct": 10.0}
    # Salida: cuello SAP 20 (0100) vs cuello MES 25 (0100) -> +25 %
    assert r["salida"]["sap_seg_pz"] == 20 and r["salida"]["mes_seg_pz"] == 25 and r["salida"]["dif_pct"] == 25.0
    assert r["salida"]["mes_pzs_hr"] == 144.0


def test_cache_de_estadisticas_mes(monkeypatch):
    from app.services.sap_mes import mes_client
    llamadas = []
    monkeypatch.setattr(mes_client, "_get", lambda ruta, params: llamadas.append(params) or {"data": [], "n": len(llamadas)})
    mes_client._cache.clear()
    a = mes_client.estadisticas_ciclo(["B", "A"], ["1"], "20260901", "20260914", 600, 3600)
    b = mes_client.estadisticas_ciclo(["A", "B"], ["1"], "20260901", "20260914", 600, 3600)
    c = mes_client.estadisticas_ciclo(["A"], ["1"], "20260901", "20260914", 600, 3600)
    assert a is b and len(llamadas) == 2 and c["n"] == 2


def test_tiempos_simbolicos_se_toman_como_cero():
    for t in (0.001, 0.01):
        seg, aviso = seg_por_pieza(t, "H", 1000)
        assert seg is None and "simbolico" in aviso
    assert seg_por_pieza(0.02, "H", 1) == (72.0, None)
    ops = [_fila(tiempo=0.001, tiempo_mano_obra=0.01), _fila()]
    por_campo = {c["campo"]: c["operaciones_con_valor"] for c in campos_disponibles(ops)}
    assert por_campo["tiempo"] == 1 and por_campo["tiempo_mano_obra"] == 1


def test_divisor_de_salida_mes():
    from app.services.sap_mes.comparador import dividir_stats
    original = {"n": 100, "excluidos": 3, "mediana": 40.0, "p25": 36.0, "p75": 44.0, "promedio": None}
    d = dividir_stats(original, 4)
    assert d == {"n": 100, "excluidos": 3, "mediana": 10.0, "p25": 9.0, "p75": 11.0, "promedio": None}
    assert original["mediana"] == 40.0          # no toca el dict del cache
    assert dividir_stats(original, 1) is original


# ---- Fase 15: endpoint /tabla ----
import pytest  # noqa: E402
from app.services.sap_mes.comparador import tabla_sap_mes  # noqa: E402


def _op_tabla(num, seg, mes):
    return {
        "operacion_num": num, "descripcion": f"Op {num}", "clave_modelo": "RPB", "plnnr": "1",
        "sap": {"tiempo": seg / 3.6, "unidad_t": "H", "cantidad_base": 1000.0, "seg_pz": seg,
                "seg_pz_linea": seg, "aviso": None},
        "mes": {"proceso": mes, "salida": mes, "n_proceso": 10, "n_salida": 10, "incompleto": False,
                "estaciones": [{"operation": "EST", "proceso": {"mediana": mes, "n": 10}, "salida": {"mediana": mes, "n": 10}, "recursos": 1}]},
        "mapeo": {"mes_operations": ["EST"], "origen": "AUTO_T435T", "agregacion": "SERIE"},
        "equipos": {"valor": 1, "origen": "MES"},
        "dif_proceso": diferencia(mes, seg, 10), "dif_salida": diferencia(mes, seg, 10),
    }


def _datos():
    return {
        "numero_material": "1", "nombre_pieza": "P", "centro": "0094", "version": {}, "parametros": {},
        "mes": {"error": None},
        "operaciones": [_op_tabla("0010", 10.0, 10.5), _op_tabla("0020", 20.0, 30.0), _op_tabla("0030", 5.0, None)],
        "grupos": [{"id": 7, "nombre": "G", "operaciones": ["0020", "0030"]}],
    }


def test_tabla_una_fila_por_operacion_con_columnas_de_la_pantalla():
    t = tabla_sap_mes(_datos())
    assert [f["operacion_num"] for f in t["filas"]] == ["0010", "0020", "0030"]
    f = t["filas"][1]
    assert f["sap_seg_pz"] == 20.0 and f["mes_proceso"] == 30.0
    assert f["estado_proceso"] == "MES_MAS_LENTO" and f["dif_proceso_pct"] == 50.0
    assert t["filas"][2]["estado_proceso"] == "SIN_DATOS_MES"
    assert f["estaciones"][0]["operation"] == "EST"


def test_tabla_sin_estaciones_y_filtrada_por_grupo():
    t = tabla_sap_mes(_datos(), grupo_id=7, incluir_estaciones=False)
    assert t["grupo"] == {"id": 7, "nombre": "G"}
    assert [f["operacion_num"] for f in t["filas"]] == ["0020", "0030"]
    assert "estaciones" not in t["filas"][0]
    with pytest.raises(ValueError):
        tabla_sap_mes(_datos(), grupo_id=99)
