# OpTimeSAP v9: corrección "MES salida ÷ undefined"

## Qué pasó
En tus capturas el encabezado dice **"salida MES ÷ undefined"** y la columna MES salida no cambia (26.0, 50.0, 55.0… igual con ÷ 7 que con ÷ 1).

Eso significa que el **frontend v8 está publicado, pero el backend que responde es anterior a la v8**. La división se hace en el backend; el backend viejo ignora el parámetro y no devuelve `divisor_salida`, y por eso aparece "undefined".

Lo reproduje con el backend de la v7 y el frontend de la v8: sale exactamente lo de tus capturas. Con el backend de la v8, ÷ 7 funciona en la columna, la gráfica, los KPIs y los grupos (ver `captura_salida_div7.png`).

## Qué cambia en la v9 (solo frontend)
- Ya no puede aparecer "÷ undefined". Si el backend no devuelve el divisor, se toma como 1.
- Si pides un divisor y el backend no lo aplicó, aparece un **aviso en rojo**: "El servidor no aplicó MES salida ÷ 7: el backend de OpTimeSAP que está corriendo es anterior a la v8…". Así se nota de inmediato que falta actualizar el servidor (ver `captura_backend_viejo_aviso.png`).

## Despliegue: lo importante es actualizar y reiniciar el BACKEND

🖥 **SERVER**: detén OpTimeSAP (cierra la consola o el servicio que lo corre).

🖥 **SERVER**: descomprime `optimesap_v9.zip` encima de la carpeta del proyecto, **incluyendo `proyecto_backend\app`**. Tu `.env` no se toca.

🖥 **SERVER**: verifica que el backend sea el nuevo. Este comando debe encontrar texto:
```powershell
Select-String -Path "C:\ruta\OpTimeSAP\proyecto_backend\app\services\sap_mes\comparador.py" -Pattern "divisor_salida"
```

🖥 **SERVER**: si lo corres como **.exe (PyInstaller)**, vuelve a generarlo. El .exe lleva el código adentro, así que copiar archivos no basta:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```

🖥 **SERVER**: arranca de nuevo, con el .exe nuevo o con `iniciar_api.bat`.

🌐 **BROWSER**: entra a `http://10.113.2.242:5159/app/sap-mes` y recarga con **Ctrl + F5**.
1. Elige el material, pon **MES salida ÷ 7** y presiona **Comparar**.
2. El encabezado debe decir "salida MES ÷ 7", y la columna "MES salida ÷ 7" debe valer la séptima parte. Por ejemplo, 50.0 → 7.1.
3. Si aparece el aviso rojo, el backend sigue siendo el viejo: revisa el paso del .exe.
