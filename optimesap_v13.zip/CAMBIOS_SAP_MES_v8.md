# OpTimeSAP v8: divisor de la salida MES en SAP/MES

Este ZIP parte de la v7. Incluye el proyecto completo y en `_cambios/` el diff `07_Fase_13_divisor_salida_MES.diff`. **No incluye `.env`.** No hay cambios en la BD.

## Para qué sirve
En algunos materiales MES registra **varias piezas juntas** en un solo evento (por ejemplo, un panel de 2 o de 4). Entonces START→START mide cada cuánto sale el grupo, no cada pieza. El campo nuevo divide esa salida para compararla pieza contra pieza con SAP.

## En pantalla
- En los filtros hay un campo nuevo: **MES salida ÷**. Default 1, sin cambio. Se aplica al presionar **Comparar**.
- Con un valor distinto de 1:
  - la **gráfica** en modo Salida muestra la salida MES ya dividida; la leyenda dice "MES salida (START→START ÷ 2)";
  - la **tabla** muestra la columna "MES salida ÷ 2", y la Δ salida se recalcula con el valor dividido;
  - al expandir una operación, la mediana y el rango P25–P75 de cada estación también salen divididos;
  - los **KPIs** de cuello de botella MES y el **resumen por grupo** ("Cuello MES salida ÷ 2") usan el valor dividido;
  - el encabezado del resultado lo indica: "… · salida MES ÷ 2 · …".
- **Proceso** (START→COMPLETE) no se divide: mide el tiempo de cada evento en la estación. El número de piezas MES (`n`) tampoco cambia.

Ejemplo probado con datos simulados: salida de 36 s ÷ 2 = **18 s/pz (200 pzs/hr)**. La Δ contra el cuello SAP de 35 s pasa de +2.9 % a −48.6 %.

## Backend
- `GET /api/sap-mes/{material}/comparativa` acepta `divisor_salida` (mayor que 0 y hasta 1000; default 1). Lo devuelve en `parametros.divisor_salida`.
- La división se hace en el backend antes de agregar estaciones y comparar, así que gráfica, tabla, KPIs y grupos usan el mismo número.
- La respuesta de MES que está en cache no se modifica: se divide sobre una copia. Cambiar el divisor no vuelve a consultar HANA.
- Pruebas: `python -m pytest tests -q` → 16 pasan (1 nueva).

## Despliegue (solo OpTimeSAP)

🖥 **SERVER**: detén OpTimeSAP y respalda la carpeta.

🖥 **SERVER**: descomprime `optimesap_v8.zip` encima. Tu `.env` no se toca. Ya trae `proyecto_frontend/dist` compilado.

🖥 **SERVER**: si empaquetas con PyInstaller:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: arranca como siempre.

🌐 **BROWSER**: entra a `http://10.113.2.242:5159/app/sap-mes`.
1. Elige el material, pon **MES salida ÷ 2** y presiona **Comparar**.
2. Cambia a **Salida**: las barras de MES deben valer la mitad.
3. La columna de la tabla debe decir "MES salida ÷ 2".
