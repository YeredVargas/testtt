# OpTimeSAP v6: referencia de 1 persona y tiempos simbólicos

Este ZIP parte de la v5. Incluye el proyecto completo y en `_cambios/` un diff por fase; el de esta entrega es `05_Fase_12b_mayor_repetido_y_tiempos_simbolicos.diff`. **No incluye `.env`.** No hay cambios en la BD.

## 1. Referencia "1 persona" = el mayor valor que se repite

Antes se tomaba el valor de mano de obra (VGW03) que más se repetía. Ahora se toma **el valor más alto entre los que se repiten** (los que aparecen 2 o más veces).

| VGW03 de las operaciones | Referencia |
|---|---|
| 5 ×4, 10 ×2, 2.5 ×1 | **10** (el mayor de los repetidos) |
| 5 ×4, 10 ×1, 2.5 ×1 | **5** (10 no se repite) |
| 2.1, 6.5 y 9, ninguno se repite | **9** (el mayor) |

El resto de la regla no cambia: cada operación vale `VGW03 / referencia` personas, y **% mano de obra = personas / procesos**.

Ejemplo probado en pantalla con mano de obra 5, 5, 10, 10, 2.5, 5 y una operación con 0.001:
- referencia = 10 (repetido 2 veces);
- personas = 0.5 + 0.5 + 1 + 1 + 0.25 + 0.5 = **3.75**;
- procesos = **6** (la de 0.001 se excluye);
- resultado: **62.5 % mano de obra · 37.5 % automatización**.

El tooltip dice si la referencia fue "mayor repetido, N×" o "mayor, ninguno se repite".

## 2. Tiempos simbólicos (≤ 0.01) = 0

Cualquier tiempo de 0.01 o menos (0.001, 0.01) se toma como **0**, en VGW01, VGW02 y VGW03.

**Comparativa**
- Una operación con **todos** sus tiempos ≤ 0.01 no es un proceso real.
  - No cuenta en el número de procesos ni en las sumas.
  - No aparece en la gráfica de balanceo ni en los selects de estación.
  - El tooltip indica cuántas se excluyeron de la ruta.
- Si una operación tiene tiempo real en VGW01 pero su mano de obra es 0.001, cuenta como **operación automática**: está en los procesos, pero con 0 personas.

**SAP / MES**
- Un tiempo SAP ≤ 0.01 se marca "Sin tiempo SAP", con el aviso "Tiempo SAP simbólico (0.001): se toma como 0".
  - No entra en las sumas ni en los cuellos de botella de los grupos.
  - Tampoco cuenta en "N/M ops" del selector de tiempo.
- La operación sigue visible en la tabla, para que se vea su dato de MES.

La regla está en un solo lugar en cada capa:
- frontend: `src/utils/manoObra.js` (`TIEMPO_MINIMO`, `tiempoReal`, `esProcesoReal`);
- backend: `app/services/sap_mes/conversion.py` (`TIEMPO_MINIMO`, `es_tiempo_real`).

Pruebas del backend: 15 pasan (1 nueva).

## Despliegue (solo OpTimeSAP)

🖥 **SERVER**: detén OpTimeSAP y respalda la carpeta.

🖥 **SERVER**: descomprime `optimesap_v6.zip` encima. Tu `.env` no se toca. Ya trae `proyecto_frontend/dist` compilado.

🖥 **SERVER**: si empaquetas con PyInstaller:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: arranca como siempre.

🌐 **BROWSER**: entra a `http://10.113.2.242:5159/app/comparativa`.
1. Agrega un material.
2. En el tooltip de **Automatización vs Mano de Obra** debe decir "1 persona = … (mayor repetido, N×)".
3. Si la ruta tiene operaciones con tiempos de 0.001, debe aparecer "Operaciones excluidas de la ruta".
