# OpTimeSAP v13: aviso de datos MES guardados (con la API de MES v3)

## Qué cambia respecto a la v12
**El guardado de MES ya no vive en OpTimeSAP.** Se movió a la **API de MES v3**, que es la que habla con HANA. Por eso la v13 **quita** de la v12:
- la tabla `sap_mes_estadistica_mes`. Si ya la creaste, no estorba; si quieres borrarla: `DROP TABLE IF EXISTS sap_mes_estadistica_mes;`
- el endpoint `/api/sap-mes/mes-guardado`. Ahora es `http://<servidor>:8015/api/hana/historico?material=…` en la API de MES.

## Qué queda en OpTimeSAP
- Cuando la API de MES responde con datos guardados (`fuente = "BD"`), arriba de la tabla aparece un aviso ámbar: "SAP HANA (MES) no respondió. Se muestran datos MES guardados por la API de MES: MES 28.09.2026 – 05.10.2026, consultado 2026-10-05 17:46". Si algún dato es de otro periodo o de otros límites, el aviso lo dice.
- Las respuestas que vienen de lo guardado **no** se guardan en la caché de 5 minutos. En cuanto HANA vuelve, la siguiente comparación trae datos en vivo.
- Los errores de conexión con la API de MES ahora muestran un mensaje corto. El detalle técnico va al log.
- Todo lo de la v11 sigue igual: endpoint `/tabla`, "Datos MES de", "MES salida ÷" y grupos.

## Despliegue
**Primero la API de MES v3**, en su propia carpeta. Ver `CAMBIOS_MES_API_v3.md`.

🖥 **SERVER**: detén OpTimeSAP.

🖥 **SERVER**: copia del ZIP `proyecto_backend\app` y `proyecto_frontend\dist` encima del proyecto de **OpTimeSAP**, no en la carpeta de la API de MES. Tu `.env` no se toca.

🖥 **SERVER**: si usas el .exe, vuelve a generarlo:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```

🖥 **SERVER**: revisa que `MES_API_URL` en el `.env` de OpTimeSAP apunte a la API v3, por ejemplo `http://10.113.2.242:8015`. Después arranca OpTimeSAP.

🌐 **BROWSER**: compara un material. Con HANA arriba no aparece ningún aviso. Si HANA cae, aparece el aviso ámbar con los datos guardados.
