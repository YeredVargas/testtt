# OpTimeSAP v10: campo "Datos MES de" en SAP/MES

## Por qué 12171981 no aparece en el selector
La lista de materiales sale de la base de datos que usa **tu backend**. `localhost:5155` es el servidor de desarrollo de Vite, y manda todo `/api` a `localhost:5159` en tu misma PC. El código de la lista no filtra nada especial: si 12171980 aparece, 12171981 debe aparecer en cuanto sus filas existan en esa base.

Si no aparece, revisa en este orden:

1. **¿Corriste el script en la misma base que usa el backend?** Revisa `DB_HOST` y `DB_NAME` en el `.env` del backend y corre esto ahí mismo:
   ```sql
   SELECT p.id, p.centro, count(t.id) AS operaciones
   FROM piezas p LEFT JOIN trazabilidad t ON t.pieza_id = p.id
   WHERE p.numero_material = '12171981'
   GROUP BY p.id, p.centro;
   ```
   Debe salir una fila con centro `0094` y 12 operaciones. Si no sale nada, el script no se guardó: córrelo completo con Alt+X y revisa que DBeaver no esté en modo manual de transacciones (si lo está, presiona Commit).
2. **Mira lo que contesta el backend:** abre `http://localhost:5159/api/sap-mes/materiales?centro=0094` y busca `12171981`.
3. **Recarga la página** con Ctrl+F5, porque la lista se guarda 5 minutos en el navegador.

## Nuevo campo: "Datos MES de"
MES se consulta con el número de material. 12171981 todavía no corre en MES, así que sus columnas MES salían vacías.

Ahora hay un campo **Datos MES de** junto a "MES salida ÷":
- **Vacío:** se usa el mismo material (como antes).
- **Con un número, p. ej. `12171980`:** se usan los tiempos SAP del material elegido contra los eventos MES de ese otro material, operación por operación. Tabla, gráfica, KPIs, grupos y la columna "MES salida ÷" funcionan igual.

Arriba de los resultados aparece una franja azul: "SAP de 12171981 contra los eventos MES de 12171980". Así siempre se sabe de dónde vienen los datos MES.

API: `GET /api/sap-mes/{material}/comparativa?...&material_mes=12171980`, y la respuesta trae `parametros.material_mes`.

## Uso con 12171981
1. Elige **12171981** en Material.
2. Escribe **12171980** en "Datos MES de".
3. Usa las mismas fechas MES con las que sacaste las medianas del script.
4. Presiona **Comparar**.

Como el VGW01 del script es la mediana MES proceso × 1.03, la columna Proceso debe quedar casi igual en SAP y en MES, con unos 3 % de diferencia y dentro de tolerancia.

## Despliegue
🖥 **PC (desarrollo, localhost:5155):** detén el backend, copia `proyecto_backend\app` y `proyecto_frontend\src` del ZIP encima de tu proyecto y vuelve a arrancar el backend. Vite toma el frontend solo; recarga con Ctrl+F5.

🖥 **SERVER (.exe):** copia el ZIP, corre `python build.py` en `proyecto_backend` para regenerar el .exe y arranca de nuevo. Tu `.env` no se toca.
