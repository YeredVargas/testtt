# OpTimeSAP v7: regla de mano de obra validada con tu muestra real

Este ZIP parte de la v6. Incluye el proyecto completo y en `_cambios/` el diff `06_Fase_12c_regla_validada_con_muestra_real.diff`. **No incluye `.env`.** Solo cambia el frontend de Comparativa.

## Validación con `trazabilidad_202610021059.csv.xlsx`

Cargué las 66 operaciones de la muestra (OBC FASSY) en la BD de prueba y elegí en Comparativa el rango de los renglones azules: **0005 Loading station → 0240 Water Spider**.

| | Tu Excel | Sistema |
|---|---|---|
| Procesos (renglones azules) | 45 | **45** |
| 1 persona | 16.667 | **16.667** (se repite 18×) |
| Personas | 18 | **18** |
| % mano de obra | 18 / 45 = 40 % | **40 %** |
| % automatización | 60 % | **60 %** |

## Qué cambió respecto a la v6

1. **Todas las operaciones del rango cuentan como proceso.**
   - En la v6, las operaciones con todos sus tiempos en 0.001 (Cleaning system, Automatic flip, Potting machine…) se excluían. Con eso salían 18 / 19 procesos, en lugar de 18 / 45.
   - Ahora cuentan como procesos **automáticos**: están en el denominador con 0 personas.
   - La regla de ≤ 0.01 sigue: esos tiempos valen 0 en las sumas.
2. **Referencia de 1 persona = el valor que más veces se repite; en empate, el mayor.**
   - En el rango azul solo existe 16.667, así que cualquier lectura da 18 personas.
   - La diferencia aparece con la **ruta completa** (66 operaciones), donde la mano de obra tiene 16.667 ×24, 30.303 ×3 y 50 ×2:

| Referencia | Personas (ruta completa) | % mano de obra |
|---|---|---|
| **Más repetido: 16.667** (lo que quedó) | **35.45** | 53.7 % |
| Mayor que se repite: 50 | 11.82 | 17.9 % |

Con 50 como referencia, cada estación de 16.667 valdría 1/3 de persona, y eso no cuadra con tus 18 personas para 18 estaciones. Con 16.667, las estaciones de 50 (FSW #5, CNC 2) cuentan como 3 personas y las de 30.303 como 1.82. **Si el criterio de la planta es otro para esas estaciones, dime y lo ajusto**: está en una sola función, `src/utils/manoObra.js`.

## Un dato que deja la muestra (para la Fase 10)

En esta ruta, VGW01 vale 0.001 en casi todas las operaciones. Solo tienen tiempo real Unloading (16.667), CNC 1 (30.303), CNC 2 (50) y Vision test (16.667). Por eso la gráfica de balanceo sale plana con un pico.

Confirma lo que te pregunté: VGW01 no es el tiempo de cada estación. Lo retomamos cuando veamos la capacidad por turno en Comparativa.

## Despliegue (solo OpTimeSAP)

🖥 **SERVER**: detén OpTimeSAP y respalda la carpeta.

🖥 **SERVER**: descomprime `optimesap_v7.zip` encima. Tu `.env` no se toca. Ya trae `proyecto_frontend/dist` compilado.

🖥 **SERVER**: si empaquetas con PyInstaller:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: arranca como siempre.

🌐 **BROWSER**: entra a `http://10.113.2.242:5159/app/comparativa`.
1. Agrega el material de la muestra.
2. Elige Estación inicial **0005** y Estación final **0240**.
3. El tooltip debe decir **18 / 45**, **40 %** de mano de obra y **60 %** de automatización.
