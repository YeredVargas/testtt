# app/config.py
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from fastapi.middleware.cors import CORSMiddleware

# --- 1. RESOLUCIÓN DE RUTAS DINÁMICAS (DESARROLLO VS EJECUTABLE) ---
BASE_DIR = Path(__file__).resolve().parent.parent

def get_runtime_base_dir() -> Path:
    """Devuelve la carpeta donde está el .exe en producción o la raíz del código en desarrollo."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return BASE_DIR

RUNTIME_BASE_DIR = get_runtime_base_dir()

# Cargar .env base y sobreescribir con el .env local del ejecutable si existe
load_dotenv(BASE_DIR / ".env")
if RUNTIME_BASE_DIR != BASE_DIR:
    load_dotenv(RUNTIME_BASE_DIR / ".env", override=True)


# --- 2. CONFIGURACIÓN DE SAP HANA ---
HANA_CONFIG = {
    "address": os.getenv("HANA_ADDRESS"),
    "port": int(os.getenv("HANA_PORT", 30241)),
    "user": os.getenv("HANA_USER"),
    "password": os.getenv("HANA_PASSWORD"),
    "database": os.getenv("HANA_DB"),
    "schema": os.getenv("HANA_SCHEMA")
}

# Sitio MES ($$F_GMASITE$$) y desfase horario. Antes estaban fijos en cada
# consulta ('10' y -21600). Solo digitos: se inserta como literal en el SQL.
MES_GMASITE = os.getenv("MES_GMASITE", "10").strip()
if not MES_GMASITE.isdigit():
    raise ValueError(f"MES_GMASITE debe ser numerico (recibido: {MES_GMASITE!r})")
# Segundos a sumar a DATE_TIME (UTC) para obtener hora local. Mexico centro = -21600.
MES_TZ_OFFSET_SEC = int(os.getenv("MES_TZ_OFFSET_SEC", "-21600"))

# Verificación inicial de credenciales de SAP HANA
if not HANA_CONFIG["address"] or not HANA_CONFIG["user"]:
    print("[WARN] HANA_ADDRESS o HANA_USER no están completamente configurados en el .env")
else:
    print("[INFO] Configuración de SAP HANA cargada correctamente.")


# --- 3. BASE DE DATOS SQLALCHEMY (POSTGRESQL) ---
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_NAME = os.getenv("DB_NAME", "scrap_fassy_db")

SQLALCHEMY_DATABASE_URL = (
    f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

engine = create_engine(SQLALCHEMY_DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


# --- 4. CONFIGURACIÓN DEL SERVIDOR Y CORS ---
APP_HOST = os.getenv("APP_HOST", "0.0.0.0")
APP_PORT = int(os.getenv("APP_PORT", 8015))

# Origenes CORS separados por coma. "*" solo para desarrollo.
# OpTimeSAP consume esta API servidor-a-servidor, asi que CORS no le afecta.
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()]


def setup_cors(app):
    permite_todo = CORS_ORIGINS == ["*"]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=CORS_ORIGINS,
        # allow_credentials=True con "*" es invalido para los navegadores.
        allow_credentials=not permite_todo,
        allow_methods=["*"],
        allow_headers=["*"],
    )