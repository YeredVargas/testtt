from fastapi import APIRouter

from app.controllers.mes.mes_controller import router as hana_router

router = APIRouter()

router.include_router(hana_router, prefix="/api/hana", tags=["Hana"])