import sys
import os

if sys.stdout is not None:
    sys.stdout.reconfigure(encoding='utf-8')
if sys.stderr is not None:
    sys.stderr.reconfigure(encoding='utf-8')

if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")

import uvicorn
from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import multiprocessing

from app.config import setup_cors, APP_HOST, APP_PORT
from app.routes import router


def resolve_frontend_dist_path() -> Path | None:
    """Detecta la carpeta del frontend compilado (dist) en local o en el release."""
    candidate_paths = [
        Path(__file__).resolve().parent / "dist",
        Path(__file__).resolve().parent.parent / "dist",
    ]

    if getattr(sys, "frozen", False):
        candidate_paths.insert(0, Path(sys.executable).resolve().parent / "dist")

    for candidate in candidate_paths:
        if (candidate / "index.html").exists():
            return candidate

    return None


app = FastAPI(
    title="SapHana API",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

setup_cors(app)

app.include_router(router)

frontend_dist_path = resolve_frontend_dist_path()

if frontend_dist_path and (frontend_dist_path / "assets").exists():
    app.mount("/assets", StaticFiles(directory=frontend_dist_path / "assets"), name="assets")


@app.get("/", include_in_schema=False)
def serve_root():
    if frontend_dist_path:
        return FileResponse(frontend_dist_path / "index.html")
    return JSONResponse({"status": "ok", "service": "saphana-api"})


@app.get("/{full_path:path}", include_in_schema=False)
def serve_spa(full_path: str):
    if (
        not frontend_dist_path 
        or full_path.startswith("api/") 
        or full_path.startswith("docs") 
        or full_path.startswith("redoc") 
        or full_path.startswith("openapi.json")
    ):
        return JSONResponse({"detail": "Not Found"}, status_code=404)

    requested_path = frontend_dist_path / full_path

    if requested_path.is_file():
        return FileResponse(requested_path)

    return FileResponse(frontend_dist_path / "index.html")


if __name__ == "__main__":
    multiprocessing.freeze_support()

    try:
        use_colors = not getattr(sys, "frozen", False)
        # Nota: Al empaquetar, se pasa directamente la instancia 'app' en lugar de un string con reload=True
        uvicorn.run(app, host=APP_HOST, port=APP_PORT, use_colors=use_colors)
    except Exception as e:
        error_file = (
            Path(sys.executable).parent / "error_crash.txt"
            if getattr(sys, "frozen", False)
            else Path("error_crash.txt")
        )
        error_file.write_text(str(e), encoding="utf-8")
        raise e