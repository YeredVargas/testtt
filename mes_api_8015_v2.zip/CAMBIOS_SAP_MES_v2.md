# SAP/MES v2: cruce automático por T435T

Parte de tu versión (la que me pasaste con tus ajustes). Cada ZIP trae el proyecto completo, este documento y `_cambios/` con un diff por fase. **No incluyen `.env`.**

| ZIP | Proyecto | Fase |
|---|---|---|
| `api_sap_v7.4.zip` | API de SAP | 5: catálogo T435T |
| `mes_api_8015_v2.zip` | API de MES | 6: recursos (RESRCE) |
| `optimesap_sap_mes_v2.zip` | OpTimeSAP | 7-8: mapeo automático + interfaz |

---

## Decisión: tabla en BD (sí) + coincidencia exacta (no "iterar" con búsqueda aproximada)

**Recomendación: guardar T435T en una tabla y cruzar por igualdad exacta del texto.**

1. **Por qué tabla y no leer T435T en cada consulta.**
   - Es dato maestro (361 claves) que casi no cambia.
   - OpTimeSAP no tiene conexión RFC, y la comparativa no debe depender de que SAP esté arriba.
   - La API de SAP ya es la única que habla con SAP (rutas, costos). Ahora también llena `catalogo_clave_modelo`.
2. **Por qué igualdad exacta y no parecido.** El texto de la clave **es** el nombre de la operación en MES: `RPBSMDT → PCB_SMT_T`, `RPBRFLB → PCB_OVEN_RFL_B`. Buscar "parecidos" produciría cruces falsos (hay nombres casi iguales: `PCB_SPI_T` / `PCB_SPIA_T`, `PCB_SMT_T` / `PCB_SMT_TOP`). Se compara en mayúsculas y sin espacios extremos.
3. **Filtro de textos que no son operaciones.** T435T también trae descripciones libres (`RIJ4SF1 → "Manual assembly, bezel, bonding"`). Solo se toman textos con forma de operación (letras, números, `_` y `-`). Los demás quedan "Sin mapeo" y la tabla muestra el texto como pista.
4. **Prioridad:**
   - Mapeo: regla manual (esta alternativa > este material > clave general) > **automático T435T** > sin mapeo. El botón **Ajustar** convierte un mapeo automático en regla manual. Se usa cuando una operación SAP corre en varias estaciones MES, o cuando T435T no coincide.
   - Equipos: regla manual > **recursos (RESRCE) que MES vio trabajar** en el rango > 1. La columna Equipos dice de dónde salió el número.

## Fase 5: API de SAP v7.4
- La tabla nueva `catalogo_clave_modelo` guarda `clave_modelo`, `texto`, `idioma`, `operacion_mes`, `activo` y fechas. Se crea sola al arrancar.
- `POST /api/v1/claves-modelo/sincronizar` lee T435T en todos los idiomas y se queda con uno por clave: S > E > D.
  - Pagina de 500 en 500.
  - Las claves que desaparecen de SAP quedan `activo=false`, no se borran.
  - Reporta los textos compartidos por varias claves: `REOL/REOL01 → EOL`, `RPBICT/RPCBICT → PCB_ICT`, `RPBCCO/RPBCOA → PCB_COATING`, etc. No es un error: varias claves SAP apuntan a la misma estación.
- `GET /api/v1/claves-modelo` devuelve el catálogo guardado.
- Tu script `SAP!.py` queda como estaba (ya no se necesita). El servicio nuevo reutiliza la paginación de `tiempo_operacion_service`.

## Fase 6: API de MES
- La consulta de eventos trae `RESRCE`.
- `ciclo-estadisticas` devuelve `recursos` (RESRCE distintos) y `lista_recursos` por material y operación.
- `material-operaciones` devuelve `RECURSOS` por estación.

## Fase 7-8: OpTimeSAP
- El backend lee `catalogo_clave_modelo`. Si todavía no existe, la crea vacía y avisa.
- Nuevo endpoint `GET /api/sap-mes/claves-modelo/estado`.
- La comparativa devuelve, por operación:
  - `mapeo` con origen, estaciones, texto T435T y si es válido;
  - `equipos` con valor, origen y recursos que vio MES;
  - recursos por estación.
- **Interfaz:**
  - Indicador "T435T: N claves · fecha" y botón **Sincronizar**, que llama a la API de SAP.
  - El indicador "Mapeadas" desglosa automáticas y manuales.
  - Columna Mapeo con "Automático (T435T)".
  - Columna Equipos con su origen.
  - Columna Recursos al expandir una operación.
  - El panel de mapeo arranca con lo que propone T435T, muestra el texto SAP y los recursos de cada estación.

## Revisión de tu versión
- `iniciar_api.bat` → puerto 5159: correcto, se conserva.
- ⚠ **`.env.example` de MES y de OpTimeSAP traían usuario y contraseña reales** (HANA y Postgres). `.gitignore` sí sube `.env.example` al repositorio. Los dejé en blanco. Si ya hiciste commit o push con esos valores, **cambia esas contraseñas**.

## Observación sobre hornos (probado con datos simulados)
En operaciones de flujo continuo (hornos de reflujo `PCB_OVEN_RFL_*`, curados), START→COMPLETE mide el tiempo que la tarjeta pasa **dentro** del horno, con muchas tarjetas a la vez. Por eso el "proceso" sale varias veces mayor que el SAP. En esas operaciones **la métrica válida es Salida**. Si quieres, en otra fase se puede marcar esas operaciones para que solo se compare la salida.

---

## Despliegue

> Orden: **1) API de SAP → 2) API de MES → 3) OpTimeSAP**. Conserva tus `.env`; no hay variables nuevas.

**1. API de SAP (5158)**

🖥 **SERVER**: detén la API y respalda la carpeta.

🖥 **SERVER**: descomprime `api_sap_v7.4.zip` encima (tu `.env` no se toca).

🖥 **SERVER**: arráncala como siempre. En el log debe salir `-> DB Setup OK` y crearse `catalogo_clave_modelo`.

🌐 **BROWSER**: `http://10.113.2.242:5158/docs` → `POST /api/v1/claves-modelo/sincronizar` → **Execute**. Debe responder `total_sap` ≈ 361.

**2. API de MES (8015)**

🖥 **SERVER**: detén la API y descomprime `mes_api_8015_v2.zip` encima.

🖥 **SERVER**: arráncala.
```powershell
cd "C:\ruta\saphanaconnection\proyecto_backend"
```
```powershell
.\venv\Scripts\Activate.ps1
```
```powershell
python main.py
```
🌐 **BROWSER**: `http://10.113.2.242:8015/docs` → `material-operaciones` con `12150829`. Debe listar `PCB_SMT_B`, `PCB_AOI_B`, `PCB_OVEN_RFL_B`… con `RECURSOS`.

**3. OpTimeSAP (5159)**

🖥 **SERVER**: detén, respalda y descomprime `optimesap_sap_mes_v2.zip` encima (ya trae `proyecto_frontend/dist` compilado).

🖥 **SERVER**: si empaquetas con PyInstaller:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: arranca (o `iniciar_api.bat`).

🌐 **BROWSER**: `http://10.113.2.242:5159/app/sap-mes`. Arriba debe decir "T435T: 361 claves". Elige `12150829` → **Comparar**. Las operaciones SMT deben salir como "Automático (T435T)" sin capturar nada.

## Validación pendiente con datos reales
1. En el ejemplo que me pasaste solo aparecen eventos **START**. Si en SMT MES no registra COMPLETE, la métrica Proceso saldrá "Sin datos MES" y solo servirá Salida. Revísalo con `ciclo-estadisticas` (`proceso.n` vs `salida.n`).
2. Confirma que `RESRCE` distintos por operación son efectivamente máquinas en paralelo. Si un RESRCE es una estación de retrabajo, conviene fijar Equipos con una regla.
