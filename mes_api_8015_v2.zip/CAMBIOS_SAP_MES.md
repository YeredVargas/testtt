# Apartado SAP/MES: cambios, despliegue y validación

Entrega en tres proyectos. Cada ZIP trae el proyecto completo, este documento y la carpeta `_cambios/` con un diff por fase, para revisar cada fase por separado.

| ZIP | Proyecto | Fases |
|---|---|---|
| `mes_api_8015.zip` | API de MES (saphanaconnection) | 0, 1 |
| `api_sap_v7.3.zip` | API de SAP (api_kostal) | 0 |
| `optimesap_sap_mes.zip` | OpTimeSAP (backend + frontend) | 0, 2, 3, 4 |

**Los `.env` NO vienen en los ZIP**, porque traen contraseñas. Conserva los tuyos y agrega solo las variables nuevas que se indican abajo.

---

## Qué compara el apartado

Por cada operación de la hoja de ruta SAP (material, alternativa y versión elegidos):

| | SAP | MES | Se compara contra |
|---|---|---|---|
| **Proceso** | `tiempo × factor(unidad_t) ÷ cantidad_base` = seg/pz de **un equipo** | START→COMPLETE del mismo SFC | SAP seg/pz |
| **Salida** | seg/pz ÷ **equipos** | START→siguiente START en la estación | SAP ÷ equipos |

- **Δ% = (MES − SAP) / SAP**. Un valor positivo significa que MES tarda más que el estándar. Dentro de ±tolerancia (10% por defecto) la operación queda "En tolerancia".
- **Estadístico MES:** mediana por defecto. El promedio se distorsiona con piezas detenidas; también se puede elegir promedio, P75 o P90.
- **Límites:** en salida se excluyen los huecos mayores a 600 s (comidas, cambios de turno o de modelo). En proceso se excluyen los ciclos mayores a 3600 s (piezas detenidas). Los excluidos se cuentan y se muestran.
- **Versión SAP:** un selector de alternativa y otro de fecha de cambio. Por defecto se usa la versión vigente hoy de la alternativa principal.

### Por qué así (decisiones)

1. **No hay llave común entre operación SAP y operación MES, así que el mapeo se captura.** Hay dos niveles de reglas: por material+operación (opcionalmente solo una alternativa) y general por `clave_modelo`. La regla más específica gana: esta alternativa > este material > clave general.
2. **Una operación SAP puede equivaler a varias estaciones MES.**
   - *Serie:* proceso = suma; salida = la estación más lenta.
   - *Paralelo:* proceso = promedio ponderado por piezas; salida = 1/Σ(1/x), la capacidad combinada.
3. **Equipos se captura en la regla.** El campo `trazabilidad.equipos` que llena la API de SAP es el número de operaciones de la ruta, no de máquinas (`equipos = len(operaciones)`). Por eso no se usa.
4. **El proceso no se divide entre equipos, la salida sí.** El proceso es lo que tarda una máquina con una pieza. La salida real de MES ya incluye todas las máquinas en paralelo.
5. **La conversión de SAP usa `unidad_t` y `cantidad_base` reales.** El resto del sistema asume horas por 1000 piezas (`1000 / tiempo`). Si alguna fila trae otra unidad o base, la comparación sigue saliendo bien. Si la unidad es desconocida o no hay base, se muestra ⚠ en lugar de un número inventado.
6. **OpTimeSAP llama a MES de servidor a servidor.** El cruce necesita Postgres, se evita CORS y se evita el problema de `localhost` que tenía la API de SAP. Se usa `requests`, que ya estaba en `requirements.txt`, así que no hay dependencias nuevas.
7. **HANA solo entrega eventos crudos; los cálculos se hacen en Python.** El SQL nuevo es tan simple como el que ya funciona. No depende de funciones (`PERCENTILE_CONT`, `LAG`) cuyo soporte en la vista calculada no está verificado, y toda la lógica tiene pruebas sin HANA.
8. **El botón "Comparar"** hace que cada consulta vaya a HANA solo cuando tú lo decides, no con cada cambio de filtro.
9. **Solo centro 0094**, como pediste. Supuesto: el sitio MES `10` (el que ya usaban todas las consultas) corresponde a 0094. Ahora es configurable con `MES_GMASITE`.
10. **Si MES no responde, la página no truena:** muestra los tiempos SAP con un aviso.

---

## Fase 0: errores corregidos

### API de MES
| Error | Corrección |
|---|---|
| `/cycle-time` tronaba siempre que había datos (leía `row[4]` de un SELECT de 4 columnas; `series` recibía el valor numérico) | Mapeo correcto; `series` = operación |
| **Inyección SQL:** `start_date`/`end_date` entraban con f-string al placeholder `$$F_CALDAY$$` | Toda fecha se valida (formato `YYYYMMDD` y fecha real) antes de tocar el SQL. Una fecha inválida responde **422**, no 500 |
| Una segunda `get_avg_cycle_time` anidada dentro de un `finally` (código muerto) | Eliminada |
| `get_materials_process_mapping` definida dos veces | Queda una |
| `GMASITE '10'` y `-21600` fijos en cada consulta | `.env`: `MES_GMASITE`, `MES_TZ_OFFSET_SEC` (mismos valores por defecto) |
| Puerto por defecto 8000 | **8015** |
| CORS `*` con `allow_credentials=True` (combinación inválida en navegadores) | `CORS_ORIGINS` del `.env` |

### API de SAP (v7.3)
| Error | Corrección |
|---|---|
| `unidad_preparacion` / `unidad_mano_obra` nunca se llenaban | Se guardan VGE02/VGE03 (en la siguiente sincronización) |
| `vw_trazabilidad_vigente` devolvía una sola alternativa | Particiona también por `plnnr`, `plnal` (se recrea sola al arrancar) |
| Material y centro sin validar dentro de las OPTIONS de `RFC_READ_TABLE` | Se valida el formato → 422 |

### OpTimeSAP backend
| Error | Corrección |
|---|---|
| `/api/graficas/datos` daba **500** sin proceso o con "TODOS" (`rows =` indentado dentro del `if`) | Indentación corregida |
| El modelo `Trazabilidad` declaraba `creado_el`/`modificado_el`, que no existen en la BD | El modelo refleja la tabla real (`creado_sap`, `modificado_sap`, unidades, `vgwts`…) |
| Modelos de costos definidos **dos veces** con restricciones distintas (importar ambos → "Table already defined") | Una sola definición en `models/costos/costos.py`; `trazabilidad.py` la re-exporta |
| Modelos `Pieza` y `CatalogoProceso` desalineados con la BD (faltaba `centro` en la llave de catálogo) | Alineados con la API de SAP; el seeder busca por `(codigo, centro)` |
| `database/init_database.py` ejecutaba `drop_all()` sin preguntar | Por defecto solo crea. Borrar exige `--reset` + escribir el nombre de la BD |
| `operaciones_crudas` mezclaba alternativas; Comparativa tomaba una al azar | Devuelve una sola alternativa (la principal o `?plnal=`). Las cifras de Comparativa pueden cambiar en materiales con varias alternativas: ahora son las de la principal |
| `allow_origins=["10.113.2.242"]` (origen inválido, fijo en código) | `CORS_ORIGINS` del `.env` (ya estaba documentado en `.env.example`) |

### OpTimeSAP frontend
| Error | Corrección |
|---|---|
| `sapClient.js` y `SapService.js` apuntaban a `http://localhost:5158`: solo funcionaba abriendo el sistema desde el propio servidor | `src/api/sapConfig.js`: usa `VITE_SAP_API_URL`; si no existe, el mismo host desde el que se abre la página, puerto 5158 |

### Detectado pero **no cambiado** (a propósito)
- **Endpoints viejos de MES** (`/promedio-*`, `/start-to-start`…): siguen con el emparejamiento `MAX(START)/MAX(COMPLETE)` y el corte de día en UTC. No cambié su semántica porque el módulo nuevo no los usa. Los endpoints nuevos sí resuelven ambos puntos.
- **Dashboard, Gráficas y Tiempos:** siguen calculando `pzs_hr = (1000/tiempo)/equipos` con el `equipos` de la API. Cambiar esto mueve todas las cifras que ya conoce la gente; es una decisión de negocio, no un error. La fuente correcta de máquinas en SAP sería `PLPO-ARBID → CRHD → KAKO-AZNOR` (número de capacidades individuales); se puede agregar como fase aparte.
- **El encabezado dice "Dashboard" en todas las páginas** (el título está fijo en `AppLayout`).
- Quedan el archivo suelto `pages/dashboard/Dashboard ELEMENTOS A LA IZQUIERDA.jsx` y la copia del backend dentro de `proyecto_frontend/`. No se usan; no los borré.
- **Credenciales:** los tres ZIP originales traían `.env` con contraseñas reales (HANA, SAP RFC, Postgres). Si esos ZIP salieron del equipo, conviene cambiarlas.

---

## Fase 1: API de MES, endpoints nuevos

`GET /api/hana/ciclo-estadisticas?operations=A,B&materials=12171980&start_date=YYYYMMDD&end_date=YYYYMMDD&max_gap_sec=600&max_ct_sec=3600`
- Devuelve, por (material, operación): `proceso` y `salida` con `n`, `excluidos`, `promedio`, `mediana`, `p25`, `p75`, `p90`, `minimo` y `maximo`, en segundos.
- El emparejamiento es correcto también con retrabajo: cada COMPLETE se une con el START inmediato anterior del mismo SFC. Un re-START del mismo SFC no cuenta como pieza nueva en la salida.
- El corte de día es en hora local: se consulta CALDAY hasta fin+1 y se filtra por hora local ya convertida.
- Rango máximo de 62 días; hasta 60 operaciones y 200 materiales por consulta.

`GET /api/hana/material-operaciones?material=12171980&dias_atras=60`: estaciones por las que pasó el material. Alimenta la lista del editor de mapeo.

Pruebas: `proyecto_backend/tests/test_ciclo_stats.py` (9 pruebas; HANA simulado).

## Fase 2-3: OpTimeSAP backend (`/api/sap-mes`)

| Método | Ruta | Uso |
|---|---|---|
| GET | `/mes/estado` | Indicador "API MES conectada" |
| GET | `/materiales` | Materiales con ruta (y cuántos mapeos tienen) |
| GET | `/{material}/versiones` | Alternativas y fechas de cambio de la ruta SAP |
| GET | `/{material}/comparativa` | La comparación completa |
| GET | `/{material}/mes-operaciones` | Estaciones MES del material (vía API MES) |
| GET/POST | `/reglas` | Listar / crear regla de mapeo |
| PUT/DELETE | `/reglas/{id}` | Editar / borrar regla |

Tablas nuevas: `sap_mes_regla` y `sap_mes_regla_operacion`. Se crean solas al arrancar (IF NOT EXISTS; no tocan nada existente). El SQL equivalente está en `database/migrations/sap_mes/001_sap_mes.sql`. Pruebas: `tests/test_sap_mes.py`.

## Fase 4: página `SAP / MES` (`/app/sap-mes`)

- **Filtros:** material · alternativa · versión SAP · rango MES · estadístico · tolerancia · límites · **Comparar**.
- **Indicadores:** operaciones, mapeadas, con datos, fuera de tolerancia, cuello de botella SAP vs MES.
- **Gráfica:** SAP vs MES por operación, con selector Proceso/Salida. Colores validados para daltonismo; el estado siempre lleva icono y texto.
- **Tabla:** Δ proceso y Δ salida por operación. Al expandir una fila se ven las estaciones MES con su mediana, P25–P75, n y excluidos.
- **"Mapear / Editar":** abre un panel lateral para elegir estaciones MES, alcance, serie/paralelo, equipos y notas.

Archivos: la lógica está en `services/sapMes`, `hooks/useSapMes.js` y `utils/sapMesFormato.js`; la presentación en `components/sapMes/*` y `pages/sapMes/SapMesPage.jsx`.

---

## Despliegue

> Orden: **1) API de MES → 2) API de SAP → 3) OpTimeSAP.** Deja respaldo de cada carpeta antes de reemplazar.

### 1. API de MES (puerto 8015)

🖥 **SERVER**: detén la API de MES si está corriendo (cierra su ventana o su servicio).

🖥 **SERVER**: respalda la carpeta actual.
```powershell
Copy-Item -Recurse "C:\ruta\saphanaconnection" "C:\ruta\saphanaconnection_respaldo"
```
🖥 **SERVER**: descomprime `mes_api_8015.zip` encima **sin borrar tu `.env`** y agrega al `.env` de `proyecto_backend`:
```
APP_PORT=8015
MES_GMASITE=10
MES_TZ_OFFSET_SEC=-21600
CORS_ORIGINS=*
```
🖥 **SERVER**: abre el puerto (PowerShell como administrador).
```powershell
New-NetFirewallRule -DisplayName "API MES 8015" -Direction Inbound -Protocol TCP -LocalPort 8015 -Action Allow
```
🖥 **SERVER**: arranca (modo desarrollo).
```powershell
cd "C:\ruta\saphanaconnection\proyecto_backend"
```
```powershell
.\venv\Scripts\Activate.ps1
```
```powershell
python main.py
```
🌐 **BROWSER**: `http://10.113.2.242:8015/docs` → ejecuta **material-operaciones** con un material real. Si regresa estaciones, la conexión a HANA y el filtro de material están bien. Después ejecuta **ciclo-estadisticas** con 1–2 de esas estaciones y un rango de 3 días.

### 2. API de SAP (v7.3)

🖥 **SERVER**: detén la API (puerto 5158), respalda, descomprime `api_sap_v7.3.zip` encima (conserva tu `.env`) y arráncala como siempre. No hay migración: la vista se recrea sola. Deben salir las líneas `-> DB Setup OK`.

### 3. OpTimeSAP

🖥 **SERVER**: agrega al `.env` de `proyecto_backend`:
```
MES_API_URL=http://10.113.2.242:8015
MES_API_TIMEOUT_SEG=120
CORS_ORIGINS=http://10.113.2.242:5159,http://localhost:5155,http://localhost:5159
```
💻 **WINDOWS**: si compilas el frontend aparte (el ZIP ya trae `proyecto_frontend/dist` compilado):
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_frontend"
```
```powershell
npm install
```
```powershell
npm run build
```
🖥 **SERVER**: para empaquetar como siempre:
```powershell
cd "C:\ruta\OpTimeSAP\proyecto_backend"
```
```powershell
python build.py
```
🖥 **SERVER**: reinicia OpTimeSAP (puerto 5159). En el log debe aparecer `-> SAP/MES: tablas de mapeo verificadas.`

🌐 **BROWSER**: `http://10.113.2.242:5159/app/sap-mes`. Arriba a la derecha debe decir **API MES conectada**.

---

## Validación con datos reales (pendiente, requiere tu servidor)

1. **Unidades SAP.** Esta consulta va en **PostgreSQL (DBeaver, BD `uzziel_dev3`)**, no en SAP HANA. En la captura estaba en HANA y decía `catidad_base`:
   ```sql
   SELECT unidad_t, cantidad_base, COUNT(*) FROM trazabilidad GROUP BY 1,2 ORDER BY 3 DESC;
   ```
   Si aparece una unidad que no sea H, MIN o S, avísame para agregarla a `conversion.py`.
2. **Sitio MES.** Confirma que `GMASITE = 10` es KEMM (0094).
3. **Formato de material en MES.** El filtro quita ceros a la izquierda en ambos lados. Si `material-operaciones` no regresa nada para un material que sí corre, revisa en HANA cómo viene `MATERIAL`.
4. **Primer mapeo.** Elige un material conocido, mapea sus operaciones y compara la mediana MES contra lo que ves en piso.
