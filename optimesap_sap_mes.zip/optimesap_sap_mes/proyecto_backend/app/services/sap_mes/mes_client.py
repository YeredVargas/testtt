# app/services/sap_mes/mes_client.py
"""
Cliente HTTP hacia la API de MES (saphanaconnection, puerto provisional 8015).

Por que servidor-a-servidor y no desde el navegador:
  - el cruce con SAP necesita Postgres (reglas y ruta), que vive aqui;
  - evita CORS y el problema de "localhost" que tenia la API de SAP;
  - si despues se guarda un historico de MES, solo cambia este archivo.
Se usa `requests`, que ya esta en requirements.txt (sin dependencias nuevas).
"""
import threading
import time
from typing import Iterable, List, Optional

import requests

from app.config import MES_API_URL, MES_API_TIMEOUT_SEG


class MesApiError(Exception):
    """La API de MES no respondio o respondio con error."""


def _get(ruta: str, params: dict) -> dict:
    url = f"{MES_API_URL}{ruta}"
    try:
        r = requests.get(url, params=params, timeout=MES_API_TIMEOUT_SEG)
    except requests.RequestException as e:
        raise MesApiError(f"No se pudo conectar con la API de MES ({MES_API_URL}): {e}") from e
    if r.status_code != 200:
        try:
            detalle = r.json().get("detail")
        except ValueError:
            detalle = r.text[:300]
        raise MesApiError(f"API de MES respondio {r.status_code}: {detalle}")
    return r.json()


# Cache corto en memoria de las estadisticas de ciclo (Fase 11).
# Cambiar el tiempo SAP a comparar o guardar un grupo de procesos vuelve a
# armar la comparativa con LOS MISMOS parametros de MES; sin cache cada cambio
# repetiria la consulta a HANA. 5 minutos es suficiente para esa sesion de
# trabajo y no deja datos viejos mucho tiempo. Si cambia el mapeo, cambian las
# operaciones consultadas y por lo tanto la llave: no hay riesgo de cruce.
_CACHE_TTL_SEG = 300
_CACHE_MAX = 32
_cache: dict = {}
_cache_lock = threading.Lock()


def _cache_get(llave):
    with _cache_lock:
        item = _cache.get(llave)
        if item and time.monotonic() - item[0] < _CACHE_TTL_SEG:
            return item[1]
        _cache.pop(llave, None)
        return None


def _cache_put(llave, valor):
    with _cache_lock:
        if len(_cache) >= _CACHE_MAX:
            _cache.pop(min(_cache, key=lambda k: _cache[k][0]), None)
        _cache[llave] = (time.monotonic(), valor)


def estadisticas_ciclo(
    operations: Iterable[str],
    materials: Optional[List[str]],
    start_date: str,
    end_date: str,
    max_gap_sec: float,
    max_ct_sec: float,
) -> dict:
    ops = sorted({str(o).strip() for o in operations if str(o).strip()})
    mats = sorted({str(m).strip() for m in (materials or []) if str(m).strip()})
    llave = (tuple(ops), tuple(mats), start_date, end_date, float(max_gap_sec), float(max_ct_sec))
    guardado = _cache_get(llave)
    if guardado is not None:
        return guardado
    respuesta = _get("/api/hana/ciclo-estadisticas", {
        "operations": ",".join(ops),
        "materials": ",".join(mats),
        "start_date": start_date,
        "end_date": end_date,
        "max_gap_sec": max_gap_sec,
        "max_ct_sec": max_ct_sec,
    })
    _cache_put(llave, respuesta)
    return respuesta


def operaciones_de_material(material: str, dias_atras: int = 60) -> dict:
    return _get("/api/hana/material-operaciones", {"material": material, "dias_atras": dias_atras})


def estado() -> dict:
    """Verifica que la API de MES este arriba (no consulta HANA)."""
    try:
        r = requests.get(f"{MES_API_URL}/openapi.json", timeout=5)
        return {"url": MES_API_URL, "disponible": r.status_code == 200, "detalle": None if r.status_code == 200 else f"HTTP {r.status_code}"}
    except requests.RequestException as e:
        return {"url": MES_API_URL, "disponible": False, "detalle": str(e)}
