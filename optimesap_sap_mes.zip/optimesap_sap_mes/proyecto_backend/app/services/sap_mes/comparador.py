# app/services/sap_mes/comparador.py
"""
Comparativa SAP vs MES por operacion (Fase 3).

Para cada operacion de la version SAP elegida:

  SAP seg/pz (por equipo)  = tiempo * factor(unidad_t) / cantidad_base
  SAP seg/pz (linea)       = SAP seg/pz / equipos           (equipos de la regla)

  MES proceso = START->COMPLETE  -> se compara contra SAP seg/pz (por equipo):
                ambos son "cuanto tarda UNA maquina con UNA pieza".
  MES salida  = START->START     -> se compara contra SAP seg/pz (linea):
                ambos son "cada cuanto sale una pieza de la operacion"; si hay
                N equipos en paralelo, la salida real ya los incluye.

  Varias estaciones MES por operacion SAP:
    SERIE    proceso = suma de estaciones ; salida = la estacion mas lenta
    PARALELO proceso = promedio ponderado por piezas ; salida = 1 / sum(1/x)

  Diferencia % = (MES - SAP) / SAP * 100.  Positivo = MES mas lento que SAP.

  Tiempo SAP a comparar (campo_tiempo): VGW01 `tiempo` (default), VGW02
  `tiempo_preparacion` o VGW03 `tiempo_mano_obra`. Cada uno con su unidad.
"""
import re
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple

from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, selectinload

from app.models.sap_mes.clave_modelo import CatalogoClaveModelo
from app.models.sap_mes.grupo import SapMesGrupo
from app.models.sap_mes.regla import SapMesRegla
from app.services.sap_mes import mes_client
from app.services.sap_mes.conversion import (
    CAMPO_TIEMPO_DEFAULT, CAMPOS_TIEMPO, TIEMPO_MINIMO, es_tiempo_real, seg_por_pieza, valor_y_unidad,
)
from app.services.sap_mes.ruta_sap import cargar_filas, orden_alternativa, ruta_a_fecha, versiones
from app.schemas.sap_mes.sap_mes_schema import clave_operacion

ESTADISTICOS = ("mediana", "promedio", "p75", "p90")
_RE_OPERACION_MES = re.compile(r"^[A-Z0-9][A-Z0-9_\-]*$")


def normalizar_material(valor) -> str:
    texto = str(valor).strip() if valor is not None else ""
    if texto.isdigit():
        return texto.lstrip("0") or "0"
    return texto.upper()


# ----------------------------------------------------------------------------
# Reglas
# ----------------------------------------------------------------------------
def reglas_aplicables(db: Session, centro: str, material: str) -> Tuple[list, dict]:
    """(reglas del material, reglas por clave_modelo en MAYUSCULAS)."""
    reglas = (
        db.query(SapMesRegla)
        .options(selectinload(SapMesRegla.operaciones))
        .filter(SapMesRegla.centro == centro, SapMesRegla.activo.is_(True))
        .filter(
            ((SapMesRegla.alcance == "MATERIAL") & (SapMesRegla.numero_material == material))
            | (SapMesRegla.alcance == "CLAVE")
        )
        .all()
    )
    de_material = [r for r in reglas if r.alcance == "MATERIAL"]
    por_clave = {(r.clave_modelo or "").strip().upper(): r for r in reglas if r.alcance == "CLAVE"}
    return de_material, por_clave


def resolver_regla(de_material: list, por_clave: dict, plnal: str, operacion_num: str, clave_modelo: Optional[str]):
    especifica = next((r for r in de_material if r.operacion_num == operacion_num and r.plnal == plnal), None)
    if especifica:
        return especifica, "MATERIAL_ALTERNATIVA"
    general = next((r for r in de_material if r.operacion_num == operacion_num and not r.plnal), None)
    if general:
        return general, "MATERIAL"
    clave = (clave_modelo or "").strip().upper()
    if clave and clave in por_clave:
        return por_clave[clave], "CLAVE"
    return None, None


# ----------------------------------------------------------------------------
# Agregacion de estaciones MES
# ----------------------------------------------------------------------------
def agregar_estaciones(estaciones: List[dict], agregacion: str, estadistico: str) -> dict:
    """
    estaciones: [{"operation", "proceso": {...stats}, "salida": {...stats}}]
    Devuelve {"proceso", "salida", "n_proceso", "n_salida", "incompleto"}.
    """
    def valores(metrica):
        pares = []
        for e in estaciones:
            st = e.get(metrica) or {}
            v = st.get(estadistico)
            if v is not None and v > 0 and (st.get("n") or 0) > 0:
                pares.append((float(v), int(st["n"])))
        return pares

    resultado = {"proceso": None, "salida": None, "n_proceso": 0, "n_salida": 0, "incompleto": False}
    for metrica in ("proceso", "salida"):
        pares = valores(metrica)
        resultado[f"n_{metrica}"] = sum(n for _, n in pares)
        if not pares:
            continue
        if len(pares) < len(estaciones):
            resultado["incompleto"] = True
        if agregacion == "PARALELO":
            if metrica == "proceso":
                total_n = sum(n for _, n in pares)
                valor = sum(v * n for v, n in pares) / total_n
            else:
                valor = 1.0 / sum(1.0 / v for v, _ in pares)
        else:  # SERIE
            valor = sum(v for v, _ in pares) if metrica == "proceso" else max(v for v, _ in pares)
        resultado[metrica] = round(valor, 2)
    return resultado


_CAMPOS_TIEMPO_STATS = ("promedio", "mediana", "p25", "p75", "p90", "minimo", "maximo")


def dividir_stats(stats: Optional[dict], divisor: float) -> Optional[dict]:
    """
    Copia de las estadisticas de salida con los tiempos divididos entre `divisor`.
    Para materiales donde MES registra un evento por varias piezas juntas
    (p. ej. un panel de 4): START->START mide el ritmo del grupo, no de la pieza.
    `n` y `excluidos` no cambian. Nunca modifica el dict original (viene del cache).
    """
    if not stats or not divisor or divisor == 1:
        return stats
    copia = dict(stats)
    for k in _CAMPOS_TIEMPO_STATS:
        if copia.get(k) is not None:
            copia[k] = round(float(copia[k]) / divisor, 3)
    return copia


def diferencia(mes: Optional[float], sap: Optional[float], tolerancia_pct: float) -> dict:
    if sap is None or sap <= 0:
        return {"seg": None, "pct": None, "estado": "SIN_TIEMPO_SAP"}
    if mes is None:
        return {"seg": None, "pct": None, "estado": "SIN_DATOS_MES"}
    pct = (mes - sap) / sap * 100
    if abs(pct) <= tolerancia_pct:
        estado = "OK"
    elif pct > 0:
        estado = "MES_MAS_LENTO"
    else:
        estado = "MES_MAS_RAPIDO"
    return {"seg": round(mes - sap, 2), "pct": round(pct, 1), "estado": estado}


# ----------------------------------------------------------------------------
# Catalogo T435T (Fase 7)
# ----------------------------------------------------------------------------
def catalogo_claves(db: Session) -> Tuple[dict, Optional[str]]:
    """
    {clave_modelo: operacion_mes} de las claves activas.
    La tabla la llena la API de SAP; si aun no existe o esta vacia, el modulo
    sigue funcionando solo con reglas manuales y se devuelve un aviso.
    """
    try:
        filas = (
            db.query(CatalogoClaveModelo.clave_modelo, CatalogoClaveModelo.operacion_mes)
            .filter(CatalogoClaveModelo.activo.is_(True))
            .all()
        )
    except SQLAlchemyError as e:
        db.rollback()
        return {}, f"No se pudo leer catalogo_clave_modelo: {e.__class__.__name__}"
    # Solo textos con forma de operacion MES (PCB_SMT_T, OBC_FASSY_ST010...).
    # T435T tambien trae descripciones libres ("Manual assembly, bezel, bonding")
    # que no son nombres de operacion: esas claves quedan sin mapeo automatico.
    catalogo = {c.strip().upper(): o for c, o in filas if c and o and _RE_OPERACION_MES.match(o)}
    if not catalogo:
        return {}, "El catalogo de claves de modelo (T435T) esta vacio: sincronizalo desde la API de SAP."
    return catalogo, None


def textos_t435t(db: Session, claves) -> dict:
    """Texto T435T original (sin filtrar) de las claves pedidas; {} si la tabla no existe."""
    claves = sorted({(c or "").strip().upper() for c in claves if c})
    if not claves:
        return {}
    try:
        filas = (
            db.query(CatalogoClaveModelo.clave_modelo, CatalogoClaveModelo.texto)
            .filter(CatalogoClaveModelo.clave_modelo.in_(claves))
            .all()
        )
    except SQLAlchemyError:
        db.rollback()
        return {}
    return {c.strip().upper(): t for c, t in filas}


def estado_catalogo(db: Session) -> dict:
    try:
        total, activos, ultima = db.query(
            func.count(CatalogoClaveModelo.clave_modelo),
            func.count(CatalogoClaveModelo.clave_modelo).filter(CatalogoClaveModelo.activo.is_(True)),
            func.max(CatalogoClaveModelo.modificado_en),
        ).one()
    except SQLAlchemyError as e:
        db.rollback()
        return {"total": 0, "activos": 0, "ultima_sincronizacion": None, "aviso": str(e.__class__.__name__)}
    return {
        "total": int(total or 0),
        "activos": int(activos or 0),
        "ultima_sincronizacion": ultima.isoformat() if ultima else None,
        "aviso": None if activos else "Catalogo vacio: sincroniza T435T desde la API de SAP.",
    }


# ----------------------------------------------------------------------------
# Consultas para el frontend
# ----------------------------------------------------------------------------
def listar_materiales(db: Session, centro: str) -> List[dict]:
    from app.models.dashboard.pieza import Pieza
    from app.models.dashboard.trazabilidad import Trazabilidad

    con_tiempo = (
        db.query(Pieza.numero_material, Pieza.nombre_pieza)
        .join(Trazabilidad, Trazabilidad.pieza_id == Pieza.id)
        .filter(Pieza.centro == centro)
        .filter(
            (Trazabilidad.tiempo > TIEMPO_MINIMO)
            | (Trazabilidad.tiempo_preparacion > TIEMPO_MINIMO)
            | (Trazabilidad.tiempo_mano_obra > TIEMPO_MINIMO)
        )
        .distinct()
        .order_by(Pieza.numero_material)
        .all()
    )
    reglas = dict(
        db.query(SapMesRegla.numero_material, func.count(SapMesRegla.id))
        .filter(SapMesRegla.centro == centro, SapMesRegla.alcance == "MATERIAL", SapMesRegla.activo.is_(True))
        .group_by(SapMesRegla.numero_material)
        .all()
    )
    return [
        {"numero_material": m, "nombre_pieza": n, "reglas": int(reglas.get(m, 0))}
        for m, n in con_tiempo
    ]


def obtener_versiones(db: Session, material: str, centro: str) -> Optional[dict]:
    pieza, filas = cargar_filas(db, material, centro)
    if not pieza:
        return None
    alts = versiones(filas)
    return {
        "numero_material": pieza.numero_material,
        "nombre_pieza": pieza.nombre_pieza,
        "alternativas": [
            {
                "plnal": a["plnal"],
                "vigente": a["vigente"].isoformat() if a["vigente"] else None,
                "fechas": [d.isoformat() for d in a["fechas"]],
            }
            for a in alts
        ],
        "default": {
            "plnal": alts[0]["plnal"] if alts else None,
            "fecha": alts[0]["vigente"].isoformat() if alts and alts[0]["vigente"] else None,
        },
    }


def campos_disponibles(ops_sap) -> List[dict]:
    """Por cada campo de tiempo: cuantas operaciones de la version elegida lo traen > 0."""
    salida = []
    for campo, info in CAMPOS_TIEMPO.items():
        con_valor = 0
        for op in ops_sap:
            if es_tiempo_real(getattr(op, campo, None)):
                con_valor += 1
        salida.append({
            "campo": campo, "vgw": info["vgw"], "etiqueta": info["etiqueta"],
            "operaciones_con_valor": con_valor, "operaciones": len(ops_sap),
        })
    return salida


# ----------------------------------------------------------------------------
# Resumenes (general y por grupo de procesos)
# ----------------------------------------------------------------------------
_FUERA = ("MES_MAS_LENTO", "MES_MAS_RAPIDO")


def _cuello(op: Optional[dict], seg_pz: Optional[float]) -> Optional[dict]:
    if not op or not seg_pz:
        return None
    return {
        "operacion_num": op["operacion_num"], "descripcion": op["descripcion"],
        "seg_pz": seg_pz, "pzs_hr": round(3600 / seg_pz, 1),
    }


def resumir(operaciones: List[dict]) -> dict:
    """KPIs de un conjunto de operaciones (toda la ruta o un grupo)."""
    con_sap = [o for o in operaciones if o["sap"]["seg_pz_linea"]]
    cuello_sap = max(con_sap, key=lambda o: o["sap"]["seg_pz_linea"], default=None)
    con_mes = [o for o in operaciones if o["mes"]["salida"]]
    cuello_mes = max(con_mes, key=lambda o: o["mes"]["salida"], default=None)
    estados = [o["dif_salida"]["estado"] for o in operaciones] + [o["dif_proceso"]["estado"] for o in operaciones]
    return {
        "operaciones_sap": len(operaciones),
        "operaciones_con_tiempo": len(con_sap),
        "operaciones_mapeadas": sum(1 for o in operaciones if o["mapeo"]["mes_operations"]),
        "operaciones_auto": sum(1 for o in operaciones if o["mapeo"]["origen"] == "AUTO_T435T"),
        "operaciones_manual": sum(1 for o in operaciones if o["regla"]),
        "operaciones_con_datos_mes": sum(1 for o in operaciones if o["mes"]["proceso"] or o["mes"]["salida"]),
        "fuera_de_tolerancia": sum(
            1 for o in operaciones if o["dif_proceso"]["estado"] in _FUERA or o["dif_salida"]["estado"] in _FUERA
        ),
        "cuello_sap": _cuello(cuello_sap, cuello_sap["sap"]["seg_pz_linea"] if cuello_sap else None),
        "cuello_mes": _cuello(cuello_mes, cuello_mes["mes"]["salida"] if cuello_mes else None),
        "estados": {e: estados.count(e) for e in sorted(set(estados))},
    }


def grupos_de_material(db: Session, centro: str, material: str, plnal: Optional[str]) -> list:
    """Grupos activos del material para la alternativa (o para todas). [] si la tabla no existe."""
    try:
        q = db.query(SapMesGrupo).filter(
            SapMesGrupo.centro == centro,
            SapMesGrupo.numero_material == material,
            SapMesGrupo.activo.is_(True),
        )
        if plnal:
            q = q.filter((SapMesGrupo.plnal.is_(None)) | (SapMesGrupo.plnal == plnal))
        return q.order_by(SapMesGrupo.orden, SapMesGrupo.id).all()
    except SQLAlchemyError:
        db.rollback()
        return []


def en_rango(operacion_num: str, op_inicio: str, op_fin: str) -> bool:
    return clave_operacion(op_inicio) <= clave_operacion(operacion_num) <= clave_operacion(op_fin)


def _delta(mes: Optional[float], sap: Optional[float]) -> Optional[float]:
    if not mes or not sap:
        return None
    return round((mes - sap) / sap * 100, 1)


def resumir_grupo(grupo, operaciones: List[dict]) -> dict:
    """
    Resumen SAP vs MES de un rango de operaciones.

    Proceso (contenido de trabajo): suma de seg/pz SAP contra suma de MES proceso,
      solo con las operaciones que tienen ambos valores (comparables), para no
      comparar un total SAP completo contra un total MES incompleto.
    Salida (ritmo del grupo): manda la operacion mas lenta. Cuello SAP (seg/pz
      / equipos) contra cuello MES (salida), aunque sean operaciones distintas.
    """
    ops = [o for o in operaciones if en_rango(o["operacion_num"], grupo.op_inicio, grupo.op_fin)]
    comparables = [o for o in ops if o["sap"]["seg_pz"] and o["mes"]["proceso"]]
    sap_proceso = round(sum(o["sap"]["seg_pz"] for o in comparables), 2) if comparables else None
    mes_proceso = round(sum(o["mes"]["proceso"] for o in comparables), 2) if comparables else None
    resumen = resumir(ops)
    sap_salida = resumen["cuello_sap"]["seg_pz"] if resumen["cuello_sap"] else None
    mes_salida = resumen["cuello_mes"]["seg_pz"] if resumen["cuello_mes"] else None
    return {
        "id": grupo.id,
        "nombre": grupo.nombre,
        "plnal": grupo.plnal,
        "op_inicio": grupo.op_inicio,
        "op_fin": grupo.op_fin,
        "operaciones": [o["operacion_num"] for o in ops],
        "proceso": {
            "comparables": len(comparables),
            "sap_seg_pz": sap_proceso,
            "mes_seg_pz": mes_proceso,
            "dif_pct": _delta(mes_proceso, sap_proceso),
        },
        "salida": {
            "sap_seg_pz": sap_salida,
            "mes_seg_pz": mes_salida,
            "sap_pzs_hr": resumen["cuello_sap"]["pzs_hr"] if resumen["cuello_sap"] else None,
            "mes_pzs_hr": resumen["cuello_mes"]["pzs_hr"] if resumen["cuello_mes"] else None,
            "dif_pct": _delta(mes_salida, sap_salida),
        },
        "resumen": resumen,
    }


def construir_comparativa(
    db: Session,
    material: str,
    centro: str,
    plnal: Optional[str],
    fecha: Optional[date],
    start_date: str,
    end_date: str,
    max_gap_sec: float,
    max_ct_sec: float,
    tolerancia_pct: float,
    estadistico: str,
    campo_tiempo: str = CAMPO_TIEMPO_DEFAULT,
    divisor_salida: float = 1.0,
    material_mes: Optional[str] = None,
) -> Optional[dict]:
    divisor_salida = float(divisor_salida) if divisor_salida and divisor_salida > 0 else 1.0
    if campo_tiempo not in CAMPOS_TIEMPO:
        campo_tiempo = CAMPO_TIEMPO_DEFAULT
    pieza, filas = cargar_filas(db, material, centro)
    if not pieza:
        return None
    # Material con el que se consulta MES. Default: el mismo material SAP.
    # Sirve para materiales nuevos que aun no corren en MES pero comparten ruta
    # con otro (p. ej. 12171981 contra los eventos de 12171980).
    material_mes = normalizar_material(material_mes) if material_mes and str(material_mes).strip() else pieza.numero_material

    alts = versiones(filas)
    alternativas = [a["plnal"] for a in alts]
    if not alternativas:
        plnal_usada, fecha_usada = None, None
        ops_sap = []
    else:
        plnal_usada = plnal if plnal in alternativas else sorted(alternativas, key=orden_alternativa)[0]
        info_alt = next(a for a in alts if a["plnal"] == plnal_usada)
        fecha_usada = fecha or info_alt["vigente"] or date.today()
        ops_sap = ruta_a_fecha(filas, plnal_usada, fecha_usada)

    de_material, por_clave = reglas_aplicables(db, centro, pieza.numero_material)
    catalogo, catalogo_aviso = catalogo_claves(db)
    textos_crudos = textos_t435t(db, [o.clave_modelo for o in ops_sap])

    # 1) Operaciones SAP con su mapeo.
    #    Prioridad (Fase 7): regla manual (alternativa > material > clave) > T435T automatico.
    operaciones = []
    todas_mes = []
    for op in ops_sap:
        regla, origen = resolver_regla(de_material, por_clave, plnal_usada, op.operacion_num, op.clave_modelo)
        clave = (op.clave_modelo or "").strip().upper()
        texto_t435t = catalogo.get(clave)
        if regla:
            mes_ops = [o.mes_operation for o in regla.operaciones]
            agregacion = regla.agregacion
        elif texto_t435t:
            mes_ops, agregacion, origen = [texto_t435t], "SERIE", "AUTO_T435T"
        else:
            mes_ops, agregacion, origen = [], "SERIE", None
        for m in mes_ops:
            if m not in todas_mes:
                todas_mes.append(m)
        valor_t, unidad_t, unidad_heredada = valor_y_unidad(op, campo_tiempo)
        seg_pz, aviso = seg_por_pieza(valor_t, unidad_t, op.cantidad_base)
        if seg_pz is not None and unidad_heredada:
            aviso = f"{CAMPOS_TIEMPO[campo_tiempo]['vgw']} sin unidad en SAP: se uso la de VGW01 ({unidad_t})."
        operaciones.append({
            "operacion_num": op.operacion_num,
            "descripcion": op.descripcion,
            "clave_modelo": op.clave_modelo,
            "proceso": op.proceso,
            "plnnr": op.plnnr,
            "fecha_inicio": op.fecha_inicio.isoformat() if op.fecha_inicio else None,
            "fecha_fin": op.fecha_fin.isoformat() if op.fecha_fin else None,
            "sap": {
                "campo": campo_tiempo,
                "tiempo": valor_t,
                "unidad_t": unidad_t,
                "cantidad_base": float(op.cantidad_base) if op.cantidad_base is not None else None,
                "seg_pz": round(seg_pz, 3) if seg_pz is not None else None,
                "seg_pz_linea": None,   # se calcula al conocer los equipos (paso 3)
                "aviso": aviso,
            },
            "mapeo": {
                "origen": origen,              # MATERIAL_ALTERNATIVA | MATERIAL | CLAVE | AUTO_T435T | None
                "mes_operations": mes_ops,
                "agregacion": agregacion,
                "texto_t435t": textos_crudos.get(clave),   # texto SAP tal cual, aunque haya regla manual
                "t435t_valido": texto_t435t is not None,   # False = texto descriptivo, no es operacion MES
            },
            "regla": None if not regla else {
                "id": regla.id,
                "origen": origen,
                "equipos": regla.equipos,
                "agregacion": regla.agregacion,
                "mes_operations": mes_ops,
                "notas": regla.notas,
            },
        })

    # 2) Una sola llamada a MES con todas las estaciones.
    mes_error = None
    mes_meta = None
    stats_por_op: Dict[str, dict] = {}
    if todas_mes:
        try:
            respuesta = mes_client.estadisticas_ciclo(
                todas_mes, [material_mes], start_date, end_date, max_gap_sec, max_ct_sec,
            )
            material_norm = normalizar_material(material_mes)
            for fila in respuesta.get("data", []):
                if normalizar_material(fila.get("MATERIAL")) == material_norm:
                    stats_por_op[str(fila["OPERATION"]).strip().upper()] = fila
            mes_meta = {k: respuesta.get(k) for k in ("gmasite", "tz_offset_sec", "total_eventos", "eventos_descartados")}
        except mes_client.MesApiError as e:
            mes_error = str(e)

    # 3) Agregar estaciones, decidir equipos y comparar.
    vacio = {"n": 0, "excluidos": 0}
    for op in operaciones:
        mes_ops = op["mapeo"]["mes_operations"]
        estaciones = []
        for m in mes_ops:
            fila = stats_por_op.get(m.strip().upper()) or {}
            estaciones.append({
                "operation": m,
                "proceso": fila.get("proceso") or vacio,
                "salida": dividir_stats(fila.get("salida"), divisor_salida) or vacio,
                "recursos": int(fila.get("recursos") or 0),
                "lista_recursos": fila.get("lista_recursos") or [],
            })
        if mes_ops:
            agregado = agregar_estaciones(estaciones, op["mapeo"]["agregacion"], estadistico)
        else:
            agregado = {"proceso": None, "salida": None, "n_proceso": 0, "n_salida": 0, "incompleto": False}
        recursos_mes = sum(e["recursos"] for e in estaciones)
        op["mes"] = {"estaciones": estaciones, "recursos": recursos_mes, **agregado}

        # Equipos: regla manual > recursos (RESRCE) que MES vio trabajar > 1.
        if op["regla"]:
            equipos, origen_eq = op["regla"]["equipos"], "REGLA"
        elif recursos_mes > 0:
            equipos, origen_eq = recursos_mes, "MES"
        else:
            equipos, origen_eq = 1, "DEFAULT"
        op["equipos"] = {"valor": equipos, "origen": origen_eq, "recursos_mes": recursos_mes}
        if op["sap"]["seg_pz"] is not None:
            op["sap"]["seg_pz_linea"] = round(op["sap"]["seg_pz"] / equipos, 3)

        if not mes_ops:
            op["dif_proceso"] = {"seg": None, "pct": None, "estado": "SIN_MAPEO"}
            op["dif_salida"] = {"seg": None, "pct": None, "estado": "SIN_MAPEO"}
        else:
            op["dif_proceso"] = diferencia(agregado["proceso"], op["sap"]["seg_pz"], tolerancia_pct)
            op["dif_salida"] = diferencia(agregado["salida"], op["sap"]["seg_pz_linea"], tolerancia_pct)

    # 4) Resumen general y por grupo de procesos (Fase 11).
    grupos = grupos_de_material(db, centro, pieza.numero_material, plnal_usada)

    return {
        "numero_material": pieza.numero_material,
        "nombre_pieza": pieza.nombre_pieza,
        "centro": centro,
        "version": {
            "plnal": plnal_usada,
            "fecha": fecha_usada.isoformat() if fecha_usada else None,
            "alternativas": alternativas,
        },
        "parametros": {
            "start_date": start_date,
            "end_date": end_date,
            "max_gap_sec": max_gap_sec,
            "max_ct_sec": max_ct_sec,
            "tolerancia_pct": tolerancia_pct,
            "estadistico": estadistico,
            "campo_tiempo": campo_tiempo,
            "divisor_salida": divisor_salida,
            "material_mes": material_mes,
        },
        "campos_tiempo": campos_disponibles(ops_sap),
        "mes": {"error": mes_error, "meta": mes_meta, "operaciones_consultadas": todas_mes},
        "catalogo_t435t": {"claves": len(catalogo), "aviso": catalogo_aviso},
        "resumen": resumir(operaciones),
        "grupos": [resumir_grupo(g, operaciones) for g in grupos],
        "operaciones": operaciones,
    }


def rango_default(start_date: Optional[str], end_date: Optional[str], dias: int = 14) -> Tuple[str, str]:
    hoy = date.today()
    fin = end_date or hoy.strftime("%Y%m%d")
    inicio = start_date or (datetime.strptime(fin, "%Y%m%d").date() - timedelta(days=dias - 1)).strftime("%Y%m%d")
    return inicio, fin


# ----------------------------------------------------------------------------
# Tabla SAP/MES (Fase 15): solo lo que muestra la tabla de la pantalla,
# una fila plana por operacion. Sale de construir_comparativa para que los
# numeros sean siempre los mismos que se ven en SAP/MES.
# ----------------------------------------------------------------------------
def _estacion_plana(e: dict) -> dict:
    p, s = e.get("proceso") or {}, e.get("salida") or {}
    return {
        "operation": e.get("operation"),
        "proceso": {k: p.get(k) for k in ("mediana", "promedio", "p25", "p75", "p90", "n", "excluidos")},
        "salida": {k: s.get(k) for k in ("mediana", "promedio", "p25", "p75", "p90", "n", "excluidos")},
        "recursos": e.get("recursos", 0),
    }


def fila_tabla(op: dict, incluir_estaciones: bool = True) -> dict:
    sap, mes, mapeo = op["sap"], op["mes"], op["mapeo"]
    fila = {
        "operacion_num": op["operacion_num"],
        "descripcion": op["descripcion"],
        "clave_modelo": op["clave_modelo"],
        "equipos": op["equipos"]["valor"],
        "equipos_origen": op["equipos"]["origen"],            # REGLA | MES | DEFAULT
        "tiempo_sap": sap["tiempo"],
        "unidad_sap": sap["unidad_t"],
        "cantidad_base": sap["cantidad_base"],
        "sap_seg_pz": sap["seg_pz"],
        "sap_aviso": sap["aviso"],
        "mes_proceso": mes.get("proceso"),
        "mes_proceso_n": mes.get("n_proceso", 0),
        "dif_proceso_seg": op["dif_proceso"]["seg"],
        "dif_proceso_pct": op["dif_proceso"]["pct"],
        "estado_proceso": op["dif_proceso"]["estado"],
        "sap_seg_pz_equipos": sap["seg_pz_linea"],
        "mes_salida": mes.get("salida"),
        "mes_salida_n": mes.get("n_salida", 0),
        "dif_salida_seg": op["dif_salida"]["seg"],
        "dif_salida_pct": op["dif_salida"]["pct"],
        "estado_salida": op["dif_salida"]["estado"],
        "mes_operations": mapeo["mes_operations"],
        "mapeo_origen": mapeo["origen"],                       # MATERIAL_ALTERNATIVA | MATERIAL | CLAVE | AUTO_T435T | None
        "agregacion": mapeo["agregacion"],
        "mes_incompleto": bool(mes.get("incompleto")),
    }
    if incluir_estaciones:
        fila["estaciones"] = [_estacion_plana(e) for e in mes.get("estaciones", [])]
    return fila


def tabla_sap_mes(datos: dict, grupo_id: Optional[int] = None, incluir_estaciones: bool = True) -> dict:
    """Recorta la comparativa a la tabla. grupo_id filtra como el selector de grupos de la pantalla."""
    operaciones = datos["operaciones"]
    grupo = None
    if grupo_id is not None:
        grupo = next((g for g in datos.get("grupos", []) if g.get("id") == grupo_id), None)
        if grupo is None:
            raise ValueError(f"El grupo {grupo_id} no existe para este material y alternativa.")
        incluidas = set(grupo.get("operaciones") or [])
        operaciones = [o for o in operaciones if o["operacion_num"] in incluidas]
    return {
        "numero_material": datos["numero_material"],
        "nombre_pieza": datos["nombre_pieza"],
        "centro": datos["centro"],
        "version": datos["version"],
        "parametros": datos["parametros"],
        "grupo": None if grupo is None else {"id": grupo["id"], "nombre": grupo.get("nombre")},
        "mes_error": datos["mes"]["error"],
        "filas": [fila_tabla(o, incluir_estaciones) for o in operaciones],
    }
