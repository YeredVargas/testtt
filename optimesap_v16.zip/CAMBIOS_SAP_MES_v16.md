# OpTimeSAP v16: diagnóstico del módulo SAP/MES

- Nuevo **`GET /api/sap-mes/diagnostico`**. Muestra, sin credenciales:
  - a qué PostgreSQL está conectado este backend (host, puerto y base);
  - si existen las tablas `sap_mes_relacion`, `sap_mes_regla`, `sap_mes_grupo`, `catalogo_clave_modelo`, `piezas` y `trazabilidad`, y cuántas filas tiene cada una;
  - el estado de la API de MES y de su historial: base que usa, si está conectada y cuántas filas tiene.
- **`GET /api/sap-mes/relacion`**: si no hay filas, dice el motivo y qué hacer. Si la tabla no existe, responde 503 indicando que revises `/diagnostico`.
- Al arrancar, la consola muestra en qué `host:puerto/base` se verificaron las tablas.

Instalación: igual que la v15 (ver `INSTALACION_LIMPIA.md`).
