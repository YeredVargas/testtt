# app/controllers/sap_mes/sap_mes_controller.py
"""
Apartado SAP/MES: comparativa del tiempo de operacion SAP contra el tiempo
ciclo real de MES, por material y operacion.  Prefijo: /api/sap-mes
"""
import re
from datetime import date, datetime
from typing import List, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session, selectinload

from app.config import SessionLocal
from app.models.sap_mes.grupo import SapMesGrupo
from app.models.sap_mes.regla import SapMesRegla, SapMesReglaOperacion
from app.schemas.sap_mes.sap_mes_schema import GrupoEntrada, GrupoSalida, ReglaEntrada, ReglaSalida, clave_operacion
from app.services.sap_mes import comparador, mes_client
from app.services.sap_mes import relacion as relacion_sap_mes

router = APIRouter()

CENTRO_DEFAULT = "0094"   # Por ahora el modulo solo trabaja con KEMM (0094).
_RE_FECHA = re.compile(r"^\d{8}$")
MAX_DIAS = 62


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _validar_rango(start_date: Optional[str], end_date: Optional[str]):
    for nombre, valor in (("start_date", start_date), ("end_date", end_date)):
        if valor and not _RE_FECHA.match(valor):
            raise HTTPException(422, f"{nombre} debe tener formato YYYYMMDD.")
    try:
        inicio, fin = comparador.rango_default(start_date, end_date)
        d_ini = datetime.strptime(inicio, "%Y%m%d").date()
        d_fin = datetime.strptime(fin, "%Y%m%d").date()
    except ValueError:
        raise HTTPException(422, "Fecha invalida.")
    if d_ini > d_fin:
        raise HTTPException(422, "start_date no puede ser mayor que end_date.")
    if (d_fin - d_ini).days + 1 > MAX_DIAS:
        raise HTTPException(422, f"El rango maximo es de {MAX_DIAS} dias.")
    return inicio, fin


def _regla_a_dict(r: SapMesRegla) -> dict:
    return {
        "id": r.id, "centro": r.centro, "alcance": r.alcance,
        "numero_material": r.numero_material, "plnal": r.plnal,
        "operacion_num": r.operacion_num, "clave_modelo": r.clave_modelo,
        "equipos": r.equipos, "agregacion": r.agregacion, "notas": r.notas,
        "activo": r.activo, "mes_operations": [o.mes_operation for o in r.operaciones],
    }


# ---------------------------------------------------------------------------
# Rutas fijas (van antes que las rutas con {material})
# ---------------------------------------------------------------------------
@router.get("/mes/estado")
def estado_mes():
    """Indica si la API de MES responde (no consulta HANA)."""
    return mes_client.estado()


@router.get("/claves-modelo/estado")
def estado_claves_modelo(db: Session = Depends(get_db)):
    """Cuantas claves T435T hay en BD y cuando se sincronizaron (las llena la API de SAP)."""
    return comparador.estado_catalogo(db)


@router.get("/materiales")
def listar_materiales(centro: str = Query(CENTRO_DEFAULT), db: Session = Depends(get_db)):
    """Materiales con hoja de ruta (tiempo > 0) y cuantas reglas propias tienen."""
    return comparador.listar_materiales(db, centro)


@router.get("/reglas", response_model=List[ReglaSalida])
def listar_reglas(
    centro: str = Query(CENTRO_DEFAULT),
    numero_material: Optional[str] = Query(None, description="Reglas del material + reglas generales por clave"),
    db: Session = Depends(get_db),
):
    q = db.query(SapMesRegla).options(selectinload(SapMesRegla.operaciones)).filter(SapMesRegla.centro == centro)
    if numero_material:
        mat = comparador.normalizar_material(numero_material)
        q = q.filter(
            ((SapMesRegla.alcance == "MATERIAL") & (SapMesRegla.numero_material == mat))
            | (SapMesRegla.alcance == "CLAVE")
        )
    reglas = q.order_by(SapMesRegla.alcance, SapMesRegla.numero_material, SapMesRegla.operacion_num, SapMesRegla.clave_modelo).all()
    return [_regla_a_dict(r) for r in reglas]


def _guardar_regla(db: Session, regla: SapMesRegla, datos: ReglaEntrada) -> dict:
    for campo in ("centro", "alcance", "numero_material", "plnal", "operacion_num",
                  "clave_modelo", "equipos", "agregacion", "notas", "activo"):
        setattr(regla, campo, getattr(datos, campo))
    regla.operaciones = [
        SapMesReglaOperacion(mes_operation=op, orden=i) for i, op in enumerate(datos.mes_operations)
    ]
    try:
        db.add(regla)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Ya existe una regla para esa operacion (mismo material/alternativa/operacion o misma clave).")
    db.refresh(regla)
    return _regla_a_dict(regla)


@router.post("/reglas", response_model=ReglaSalida, status_code=201)
def crear_regla(datos: ReglaEntrada, db: Session = Depends(get_db)):
    return _guardar_regla(db, SapMesRegla(), datos)


@router.put("/reglas/{regla_id}", response_model=ReglaSalida)
def actualizar_regla(regla_id: int, datos: ReglaEntrada, db: Session = Depends(get_db)):
    regla = db.query(SapMesRegla).options(selectinload(SapMesRegla.operaciones)).get(regla_id)
    if not regla:
        raise HTTPException(404, "Regla no encontrada.")
    # Reemplazo limpio de las estaciones: se borran antes de insertar las nuevas
    # para no chocar con el indice unico (regla_id, mes_operation).
    regla.operaciones.clear()
    db.flush()
    return _guardar_regla(db, regla, datos)


@router.delete("/reglas/{regla_id}", status_code=204)
def eliminar_regla(regla_id: int, db: Session = Depends(get_db)):
    regla = db.get(SapMesRegla, regla_id)
    if not regla:
        raise HTTPException(404, "Regla no encontrada.")
    db.delete(regla)
    db.commit()


# ---------------------------------------------------------------------------
# Grupos de procesos (Fase 11): rangos de operaciones con nombre, por material
# ---------------------------------------------------------------------------
def _grupo_a_dict(g: SapMesGrupo) -> dict:
    return {
        "id": g.id, "centro": g.centro, "numero_material": g.numero_material, "plnal": g.plnal,
        "nombre": g.nombre, "op_inicio": g.op_inicio, "op_fin": g.op_fin,
        "orden": g.orden, "activo": g.activo,
    }


@router.get("/grupos", response_model=List[GrupoSalida])
def listar_grupos(
    numero_material: str = Query(...),
    centro: str = Query(CENTRO_DEFAULT),
    db: Session = Depends(get_db),
):
    mat = comparador.normalizar_material(numero_material)
    grupos = (
        db.query(SapMesGrupo)
        .filter(SapMesGrupo.centro == centro, SapMesGrupo.numero_material == mat)
        .all()
    )
    grupos.sort(key=lambda g: (g.orden, clave_operacion(g.op_inicio), g.id))
    return [_grupo_a_dict(g) for g in grupos]


def _guardar_grupo(db: Session, grupo: SapMesGrupo, datos: GrupoEntrada) -> dict:
    for campo in ("centro", "numero_material", "plnal", "nombre", "op_inicio", "op_fin", "orden", "activo"):
        setattr(grupo, campo, getattr(datos, campo))
    try:
        db.add(grupo)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, f"Ya existe un grupo llamado \"{datos.nombre}\" para este material y alternativa.")
    db.refresh(grupo)
    return _grupo_a_dict(grupo)


@router.post("/grupos", response_model=GrupoSalida, status_code=201)
def crear_grupo(datos: GrupoEntrada, db: Session = Depends(get_db)):
    return _guardar_grupo(db, SapMesGrupo(), datos)


@router.put("/grupos/{grupo_id}", response_model=GrupoSalida)
def actualizar_grupo(grupo_id: int, datos: GrupoEntrada, db: Session = Depends(get_db)):
    grupo = db.get(SapMesGrupo, grupo_id)
    if not grupo:
        raise HTTPException(404, "Grupo no encontrado.")
    return _guardar_grupo(db, grupo, datos)


@router.delete("/grupos/{grupo_id}", status_code=204)
def eliminar_grupo(grupo_id: int, db: Session = Depends(get_db)):
    grupo = db.get(SapMesGrupo, grupo_id)
    if not grupo:
        raise HTTPException(404, "Grupo no encontrado.")
    db.delete(grupo)
    db.commit()


# ---------------------------------------------------------------------------
# Por material
# ---------------------------------------------------------------------------
@router.get("/{numero_material}/versiones")
def versiones_material(numero_material: str, centro: str = Query(CENTRO_DEFAULT), db: Session = Depends(get_db)):
    """Alternativas y fechas de cambio de la hoja de ruta SAP (para el selector de version)."""
    datos = comparador.obtener_versiones(db, comparador.normalizar_material(numero_material), centro)
    if datos is None:
        raise HTTPException(404, "El material no esta sincronizado para este centro.")
    return datos


@router.get("/{numero_material}/mes-operaciones")
def operaciones_mes_material(numero_material: str, dias_atras: int = Query(60, ge=1, le=365)):
    """Estaciones MES por las que ha pasado el material (para capturar el mapeo)."""
    try:
        return mes_client.operaciones_de_material(comparador.normalizar_material(numero_material), dias_atras)
    except mes_client.MesApiError as e:
        raise HTTPException(502, str(e))


@router.get("/relacion")
def relacion_sap_mes_listar(
    numero_material: Optional[str] = Query(None, description="Material. Vacio = todos los materiales comparados."),
    centro: str = Query(CENTRO_DEFAULT),
    plnal: Optional[str] = Query(None, description="Alternativa SAP (opcional)"),
    limite: int = Query(2000, ge=1, le=20000),
    db: Session = Depends(get_db),
):
    """
    Relacion SAP vs MES operacion por operacion guardada en sap_mes_relacion (Fase 17):
    cantidad SAP (tiempo, seg/pz) y cantidad MES (seg/pz de proceso y salida, piezas medidas)
    de la ultima comparacion de cada material.
    """
    mat = comparador.normalizar_material(numero_material) if numero_material else None
    try:
        filas = relacion_sap_mes.listar(db, centro, mat, plnal, limite)
    except SQLAlchemyError as e:
        db.rollback()
        raise HTTPException(503, f"No se pudo leer sap_mes_relacion (¿existe la tabla?). Revisa /api/sap-mes/diagnostico. "
                                 f"Detalle: {e.__class__.__name__}")
    respuesta = {"centro": centro, "numero_material": mat, "total": len(filas), "filas": filas}
    if not filas:
        respuesta["motivo"] = (
            "Todavia no hay filas: la tabla se llena cada vez que se presiona Comparar en SAP/MES "
            "(o se llama /comparativa o /tabla) con este backend v14 o posterior."
            if not mat else
            f"No hay filas para {mat} en el centro {centro}. Compara ese material en SAP/MES y vuelve a consultar."
        )
    return respuesta


@router.get("/diagnostico")
def diagnostico(db: Session = Depends(get_db)):
    """
    Estado del modulo SAP/MES (v16), sin credenciales: base de datos a la que esta
    conectado este backend, tablas del modulo con su numero de filas y estado de la
    API de MES (incluido su historico).
    """
    from sqlalchemy import inspect, text
    from app.config import DB_HOST, DB_NAME, DB_PORT, MES_API_URL
    from app.services.sap_mes import schema as schema_sap_mes

    creadas = schema_sap_mes.asegurar_tablas_sap_mes()      # idempotente: crea lo que falte
    info = {
        "postgres": {"host": DB_HOST, "port": DB_PORT, "database": DB_NAME},
        "tablas_verificadas": creadas,
        "error_tablas": schema_sap_mes.ULTIMO_ERROR,
        "tablas": {},
        "api_mes": {"url": MES_API_URL},
    }
    try:
        existentes = set(inspect(db.get_bind()).get_table_names())
        for t in ("sap_mes_relacion", "sap_mes_regla", "sap_mes_regla_operacion", "sap_mes_grupo",
                  "catalogo_clave_modelo", "piezas", "trazabilidad"):
            filas = db.execute(text(f'SELECT count(*) FROM "{t}"')).scalar() if t in existentes else None
            info["tablas"][t] = {"existe": t in existentes, "filas": filas}
    except SQLAlchemyError as e:
        db.rollback()
        info["error_bd"] = f"{e.__class__.__name__}: {' '.join(str(getattr(e, 'orig', None) or e).split())[:300]}"

    info["api_mes"].update(mes_client.estado())
    if info["api_mes"].get("disponible") and info["api_mes"].get("historico"):
        try:
            info["api_mes"]["historico_estado"] = mes_client._get("/api/hana/historico/estado", {})
        except mes_client.MesApiError as e:
            info["api_mes"]["historico_estado"] = {"error": str(e)}
    return info




@router.get("/{numero_material}/comparativa")
def comparativa_material(
    numero_material: str,
    centro: str = Query(CENTRO_DEFAULT),
    plnal: Optional[str] = Query(None, description="Alternativa SAP. Default: la principal."),
    fecha: Optional[date] = Query(None, description="Version SAP vigente a esta fecha (YYYY-MM-DD). Default: hoy."),
    start_date: Optional[str] = Query(None, description="MES desde YYYYMMDD. Default: hace 14 dias."),
    end_date: Optional[str] = Query(None, description="MES hasta YYYYMMDD (inclusive). Default: hoy."),
    max_gap_sec: float = Query(600, gt=0, le=86400),
    max_ct_sec: float = Query(3600, gt=0, le=86400),
    tolerancia_pct: float = Query(10, ge=0, le=100),
    estadistico: Literal["mediana", "promedio", "p75", "p90"] = Query("mediana"),
    campo_tiempo: Literal["tiempo", "tiempo_preparacion", "tiempo_mano_obra"] = Query(
        "tiempo", description="Tiempo SAP a comparar: VGW01 tiempo, VGW02 tiempo_preparacion, VGW03 tiempo_mano_obra."),
    divisor_salida: float = Query(
        1, gt=0, le=1000, description="Divide la salida MES (START->START) cuando MES registra varias piezas juntas."),
    material_mes: Optional[str] = Query(
        None, max_length=40, description="Consultar MES con otro material (misma ruta). Default: el mismo material."),
    db: Session = Depends(get_db),
):
    inicio, fin = _validar_rango(start_date, end_date)
    datos = comparador.construir_comparativa(
        db, comparador.normalizar_material(numero_material), centro, plnal, fecha,
        inicio, fin, max_gap_sec, max_ct_sec, tolerancia_pct, estadistico, campo_tiempo,
        divisor_salida, material_mes,
    )
    if datos is None:
        raise HTTPException(404, "El material no esta sincronizado para este centro.")
    datos["relacion_guardada"] = relacion_sap_mes.guardar(db, datos)
    return datos


@router.get("/{numero_material}/tabla")
def tabla_material(
    numero_material: str,
    centro: str = Query(CENTRO_DEFAULT),
    plnal: Optional[str] = Query(None, description="Alternativa SAP. Default: la principal."),
    fecha: Optional[date] = Query(None, description="Version SAP vigente a esta fecha (YYYY-MM-DD). Default: la vigente."),
    start_date: Optional[str] = Query(None, description="MES desde YYYYMMDD. Default: hace 14 dias."),
    end_date: Optional[str] = Query(None, description="MES hasta YYYYMMDD (inclusive). Default: hoy."),
    max_gap_sec: float = Query(600, gt=0, le=86400),
    max_ct_sec: float = Query(3600, gt=0, le=86400),
    tolerancia_pct: float = Query(10, ge=0, le=100),
    estadistico: Literal["mediana", "promedio", "p75", "p90"] = Query("mediana"),
    campo_tiempo: Literal["tiempo", "tiempo_preparacion", "tiempo_mano_obra"] = Query("tiempo"),
    divisor_salida: float = Query(1, gt=0, le=1000),
    material_mes: Optional[str] = Query(None, max_length=40, description="Consultar MES con otro material. Default: el mismo."),
    grupo_id: Optional[int] = Query(None, description="Solo las operaciones de este grupo de procesos."),
    estaciones: bool = Query(True, description="Incluir el detalle por estacion MES (lo que se ve al expandir una fila)."),
    db: Session = Depends(get_db),
):
    """
    Solo la tabla de SAP/MES: una fila por operacion con tiempo SAP, SAP seg/pz,
    MES proceso, delta proceso, SAP / equipos, MES salida, delta salida y mapeo.
    Mismos calculos que /comparativa (sin resumen, KPIs ni grafica).
    """
    inicio, fin = _validar_rango(start_date, end_date)
    datos = comparador.construir_comparativa(
        db, comparador.normalizar_material(numero_material), centro, plnal, fecha,
        inicio, fin, max_gap_sec, max_ct_sec, tolerancia_pct, estadistico, campo_tiempo,
        divisor_salida, material_mes,
    )
    if datos is None:
        raise HTTPException(404, "El material no esta sincronizado para este centro.")
    relacion_sap_mes.guardar(db, datos)
    try:
        return comparador.tabla_sap_mes(datos, grupo_id, estaciones)
    except ValueError as e:
        raise HTTPException(404, str(e))
